/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Det_ReportError
//
// #pragma POLYSPACE_PURE "Det_ReportError"
// #pragma POLYSPACE_CLEAN "Det_ReportError"
// #pragma POLYSPACE_WORST "Det_ReportError"
//
// __PST__UINT8 Det_ReportError(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT8 P_3)
// {
//    ...
// }


// Pragmas for function Dem_ClearDTC
//
// #pragma POLYSPACE_PURE "Dem_ClearDTC"
// #pragma POLYSPACE_CLEAN "Dem_ClearDTC"
// #pragma POLYSPACE_WORST "Dem_ClearDTC"
//
// __PST__UINT8 Dem_ClearDTC(__PST__UINT32 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2)
// {
//    ...
// }


// Pragmas for function Dem_SetEventStatus
//
// #pragma POLYSPACE_PURE "Dem_SetEventStatus"
// #pragma POLYSPACE_CLEAN "Dem_SetEventStatus"
// #pragma POLYSPACE_WORST "Dem_SetEventStatus"
//
// __PST__UINT8 Dem_SetEventStatus(__PST__UINT16 P_0, __PST__UINT8 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Call_DiagcMgr_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_DiagcMgr_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_DiagcMgr_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_DiagcMgr_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_DiagcMgr_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea"
//
// __PST__VOID Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea"
//
// __PST__VOID Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea(__PST__VOID)
// {
//    ...
// }


// Pragmas for function NvMProxy_SetRamBlockStatus
//
// #pragma POLYSPACE_PURE "NvMProxy_SetRamBlockStatus"
// #pragma POLYSPACE_CLEAN "NvMProxy_SetRamBlockStatus"
// #pragma POLYSPACE_WORST "NvMProxy_SetRamBlockStatus"
//
// __PST__UINT8 NvMProxy_SetRamBlockStatus(__PST__UINT16 P_0, __PST__UINT8 P_1)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Enter_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9
//
// #pragma POLYSPACE_PURE "Rte_Enter_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9"
// #pragma POLYSPACE_CLEAN "Rte_Enter_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9"
// #pragma POLYSPACE_WORST "Rte_Enter_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9"
//
// __PST__VOID Rte_Enter_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9(__PST__VOID)
// {
//    ...
// }


// Pragmas for function Rte_Exit_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9
//
// #pragma POLYSPACE_PURE "Rte_Exit_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9"
// #pragma POLYSPACE_CLEAN "Rte_Exit_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9"
// #pragma POLYSPACE_WORST "Rte_Exit_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9"
//
// __PST__VOID Rte_Exit_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9(__PST__VOID)
// {
//    ...
// }

