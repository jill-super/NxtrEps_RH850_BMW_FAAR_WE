#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Det_ReportError
 */

#pragma POLYSPACE_POLYMORPHIC "Det_ReportError"


__PST__UINT8 Det_ReportError(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT8 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Dem_ClearDTC
 */

#pragma POLYSPACE_POLYMORPHIC "Dem_ClearDTC"


__PST__UINT8 Dem_ClearDTC(__PST__UINT32 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Dem_SetEventStatus
 */

#pragma POLYSPACE_POLYMORPHIC "Dem_SetEventStatus"


__PST__UINT8 Dem_SetEventStatus(__PST__UINT16 P_0, __PST__UINT8 P_1)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_DiagcMgr_SetNtcSts_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_DiagcMgr_SetNtcSts_Oper"


__PST__UINT8 Rte_Call_DiagcMgr_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea"


__PST__VOID Rte_Enter_DiagcMgr_DiagcMgrExclusiveArea(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea"


__PST__VOID Rte_Exit_DiagcMgr_DiagcMgrExclusiveArea(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * NvMProxy_SetRamBlockStatus
 */

#pragma POLYSPACE_POLYMORPHIC "NvMProxy_SetRamBlockStatus"


__PST__UINT8 NvMProxy_SetRamBlockStatus(__PST__UINT16 P_0, __PST__UINT8 P_1)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Enter_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl0_DiagcMgrProxyAppl0(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Enter_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl1_DiagcMgrProxyAppl1(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl10_DiagcMgrProxyAppl10(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Enter_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl2_DiagcMgrProxyAppl2(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Enter_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl3_DiagcMgrProxyAppl3(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Enter_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl4_DiagcMgrProxyAppl4(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Enter_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl5_DiagcMgrProxyAppl5(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl6_DiagcMgrProxyAppl6(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Enter_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl7_DiagcMgrProxyAppl7(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Enter_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl8_DiagcMgrProxyAppl8(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Enter_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Enter_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9"


__PST__VOID Rte_Enter_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9(__PST__VOID)
{
    /* function is pure */

    return;
}

/*
 * Rte_Exit_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Exit_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9"


__PST__VOID Rte_Exit_DiagcMgrProxyAppl9_DiagcMgrProxyAppl9(__PST__VOID)
{
    /* function is pure */

    return;
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

