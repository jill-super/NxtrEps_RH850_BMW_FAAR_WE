#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;
static volatile __PST__SINT8 pst_random_g_2;
static volatile __PST__SINT32 pst_random_g_4;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT32 _main_gen_init_g4(void);

extern __PST__SINT8 _main_gen_init_g2(void);

extern __PST__SINT16 _main_gen_init_g3(void);

extern struct __PST__g__25 _main_gen_init_g25(void);

extern struct __PST__g__27 _main_gen_init_g27(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

struct __PST__g__27 _main_gen_init_g27(void)
{
    static struct __PST__g__27 x;
    /* struct/union type */
    x.DiagcSts = _main_gen_init_g6();
    x.ActvRampRate = _main_gen_init_g10();
    x.ActvMotTqCmdSca = _main_gen_init_g10();
    return x;
}

struct __PST__g__25 _main_gen_init_g25(void)
{
    static struct __PST__g__25 x;
    /* struct/union type */
    x.NtcStInfo = _main_gen_init_g6();
    x.Sts = _main_gen_init_g6();
    x.AgiCntr = _main_gen_init_g6();
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}

__PST__SINT8 _main_gen_init_g2(void)
{
    __PST__SINT8 x;
    /* base type */
    x = pst_random_g_2;
    return x;
}

__PST__SINT32 _main_gen_init_g4(void)
{
    __PST__SINT32 x;
    /* base type */
    x = pst_random_g_4;
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_DiagcMgr_Ip_BrdgVltg(void)
{
    extern __PST__FLOAT32 DiagcMgr_Ip_BrdgVltg;
    
    /* initialization with random value */
    {
        DiagcMgr_Ip_BrdgVltg = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DiagcMgr_Ip_EcuTFild(void)
{
    extern __PST__FLOAT32 DiagcMgr_Ip_EcuTFild;
    
    /* initialization with random value */
    {
        DiagcMgr_Ip_EcuTFild = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DiagcMgr_Ip_HwTq(void)
{
    extern __PST__FLOAT32 DiagcMgr_Ip_HwTq;
    
    /* initialization with random value */
    {
        DiagcMgr_Ip_HwTq = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DiagcMgr_Ip_IgnCntr(void)
{
    extern __PST__UINT32 DiagcMgr_Ip_IgnCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Ip_IgnCntr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Ip_MfgDiagcInhb(void)
{
    extern __PST__UINT8 DiagcMgr_Ip_MfgDiagcInhb;
    
    /* initialization with random value */
    {
        DiagcMgr_Ip_MfgDiagcInhb = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Ip_MfgEnaSt(void)
{
    extern __PST__UINT8 DiagcMgr_Ip_MfgEnaSt;
    
    /* initialization with random value */
    {
        DiagcMgr_Ip_MfgEnaSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Ip_MotTqCmdMrfScad(void)
{
    extern __PST__FLOAT32 DiagcMgr_Ip_MotTqCmdMrfScad;
    
    /* initialization with random value */
    {
        DiagcMgr_Ip_MotTqCmdMrfScad = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DiagcMgr_Ip_SwApplCrc(void)
{
    extern __PST__UINT32 DiagcMgr_Ip_SwApplCrc;
    
    /* initialization with random value */
    {
        DiagcMgr_Ip_SwApplCrc = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Ip_SysSt(void)
{
    extern __PST__UINT8 DiagcMgr_Ip_SysSt;
    
    /* initialization with random value */
    {
        DiagcMgr_Ip_SysSt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgr_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 512; _main_gen_tmp_0_0++)
            {
                /* base type */
                DiagcMgr_Cal_DiagcMgrFltResp[_main_gen_tmp_0_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgr_Pim_DiagcMgrApplCrc(void)
{
    extern __PST__UINT32 DiagcMgr_Pim_DiagcMgrApplCrc;
    
    /* initialization with random value */
    {
        DiagcMgr_Pim_DiagcMgrApplCrc = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Pim_DiagcMgrLtchCntrAry(void)
{
    extern __PST__g__85 DiagcMgr_Pim_DiagcMgrLtchCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 20; _main_gen_tmp_1_0++)
            {
                /* base type */
                DiagcMgr_Pim_DiagcMgrLtchCntrAry[_main_gen_tmp_1_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgr_Pim_DiagcMgrNtcFltAry(void)
{
    extern __PST__g__86 DiagcMgr_Pim_DiagcMgrNtcFltAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 20; _main_gen_tmp_2_0++)
            {
                /* struct/union type */
                DiagcMgr_Pim_DiagcMgrNtcFltAry[_main_gen_tmp_2_0].NtcNr = _main_gen_init_g7();
                DiagcMgr_Pim_DiagcMgrNtcFltAry[_main_gen_tmp_2_0].AgiCntr = _main_gen_init_g6();
                DiagcMgr_Pim_DiagcMgrNtcFltAry[_main_gen_tmp_2_0].Sts = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgr_Pim_ClrDiagcFlg(void)
{
    extern __PST__UINT8 DiagcMgr_Pim_ClrDiagcFlg;
    
    /* initialization with random value */
    {
        DiagcMgr_Pim_ClrDiagcFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Pim_DtcEnaSts(void)
{
    extern __PST__UINT16 DiagcMgr_Pim_DtcEnaSts;
    
    /* initialization with random value */
    {
        DiagcMgr_Pim_DtcEnaSts = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgr_Pim_DtcIdxPrevSts(void)
{
    extern __PST__g__88 DiagcMgr_Pim_DtcIdxPrevSts;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < 65535; _main_gen_tmp_3_0++)
            {
                /* base type */
                DiagcMgr_Pim_DtcIdxPrevSts[_main_gen_tmp_3_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgr_Pim_PrevClrDtcFlg(void)
{
    extern __PST__UINT8 DiagcMgr_Pim_PrevClrDtcFlg;
    
    /* initialization with random value */
    {
        DiagcMgr_Pim_PrevClrDtcFlg = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl0_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < 512; _main_gen_tmp_4_0++)
            {
                /* base type */
                DiagcMgrProxyAppl0_Cal_DiagcMgrFltResp[_main_gen_tmp_4_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Pim_DiagcData0(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl0_Pim_DiagcData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Pim_DiagcData0 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < 65535; _main_gen_tmp_5_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0Ary[_main_gen_tmp_5_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0Ary[_main_gen_tmp_5_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0Ary[_main_gen_tmp_5_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < 512; _main_gen_tmp_6_0++)
            {
                /* base type */
                DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0DebCntrAry[_main_gen_tmp_6_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Pim_PrevClrNtcFlg0(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Pim_PrevClrNtcFlg0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Pim_PrevClrNtcFlg0 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Pim_ProxySetNtcData0(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl0_Pim_ProxySetNtcData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Pim_ProxySetNtcData0 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl1_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < 512; _main_gen_tmp_7_0++)
            {
                /* base type */
                DiagcMgrProxyAppl1_Cal_DiagcMgrFltResp[_main_gen_tmp_7_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Pim_DiagcData1(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl1_Pim_DiagcData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Pim_DiagcData1 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < 65535; _main_gen_tmp_8_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1Ary[_main_gen_tmp_8_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1Ary[_main_gen_tmp_8_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1Ary[_main_gen_tmp_8_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < 512; _main_gen_tmp_9_0++)
            {
                /* base type */
                DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1DebCntrAry[_main_gen_tmp_9_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Pim_PrevClrNtcFlg1(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Pim_PrevClrNtcFlg1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Pim_PrevClrNtcFlg1 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Pim_ProxySetNtcData1(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl1_Pim_ProxySetNtcData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Pim_ProxySetNtcData1 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl10_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < 512; _main_gen_tmp_10_0++)
            {
                /* base type */
                DiagcMgrProxyAppl10_Cal_DiagcMgrFltResp[_main_gen_tmp_10_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Pim_DiagcData10(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl10_Pim_DiagcData10;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Pim_DiagcData10 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < 65535; _main_gen_tmp_11_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10Ary[_main_gen_tmp_11_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10Ary[_main_gen_tmp_11_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10Ary[_main_gen_tmp_11_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < 512; _main_gen_tmp_12_0++)
            {
                /* base type */
                DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10DebCntrAry[_main_gen_tmp_12_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Pim_PrevClrNtcFlg10(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Pim_PrevClrNtcFlg10;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Pim_PrevClrNtcFlg10 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Pim_ProxySetNtcData10(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl10_Pim_ProxySetNtcData10;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Pim_ProxySetNtcData10 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl2_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < 512; _main_gen_tmp_13_0++)
            {
                /* base type */
                DiagcMgrProxyAppl2_Cal_DiagcMgrFltResp[_main_gen_tmp_13_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Pim_DiagcData2(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl2_Pim_DiagcData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Pim_DiagcData2 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_14_0;
            
            for (_main_gen_tmp_14_0 = 0; _main_gen_tmp_14_0 < 65535; _main_gen_tmp_14_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2Ary[_main_gen_tmp_14_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2Ary[_main_gen_tmp_14_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2Ary[_main_gen_tmp_14_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_15_0;
            
            for (_main_gen_tmp_15_0 = 0; _main_gen_tmp_15_0 < 512; _main_gen_tmp_15_0++)
            {
                /* base type */
                DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2DebCntrAry[_main_gen_tmp_15_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Pim_PrevClrNtcFlg2(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Pim_PrevClrNtcFlg2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Pim_PrevClrNtcFlg2 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Pim_ProxySetNtcData2(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl2_Pim_ProxySetNtcData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Pim_ProxySetNtcData2 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl3_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_16_0;
            
            for (_main_gen_tmp_16_0 = 0; _main_gen_tmp_16_0 < 512; _main_gen_tmp_16_0++)
            {
                /* base type */
                DiagcMgrProxyAppl3_Cal_DiagcMgrFltResp[_main_gen_tmp_16_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Pim_DiagcData3(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl3_Pim_DiagcData3;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Pim_DiagcData3 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_17_0;
            
            for (_main_gen_tmp_17_0 = 0; _main_gen_tmp_17_0 < 65535; _main_gen_tmp_17_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3Ary[_main_gen_tmp_17_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3Ary[_main_gen_tmp_17_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3Ary[_main_gen_tmp_17_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_18_0;
            
            for (_main_gen_tmp_18_0 = 0; _main_gen_tmp_18_0 < 512; _main_gen_tmp_18_0++)
            {
                /* base type */
                DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3DebCntrAry[_main_gen_tmp_18_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Pim_PrevClrNtcFlg3(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Pim_PrevClrNtcFlg3;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Pim_PrevClrNtcFlg3 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Pim_ProxySetNtcData3(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl3_Pim_ProxySetNtcData3;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Pim_ProxySetNtcData3 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl4_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_19_0;
            
            for (_main_gen_tmp_19_0 = 0; _main_gen_tmp_19_0 < 512; _main_gen_tmp_19_0++)
            {
                /* base type */
                DiagcMgrProxyAppl4_Cal_DiagcMgrFltResp[_main_gen_tmp_19_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Pim_DiagcData4(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl4_Pim_DiagcData4;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Pim_DiagcData4 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_20_0;
            
            for (_main_gen_tmp_20_0 = 0; _main_gen_tmp_20_0 < 65535; _main_gen_tmp_20_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4Ary[_main_gen_tmp_20_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4Ary[_main_gen_tmp_20_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4Ary[_main_gen_tmp_20_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_21_0;
            
            for (_main_gen_tmp_21_0 = 0; _main_gen_tmp_21_0 < 512; _main_gen_tmp_21_0++)
            {
                /* base type */
                DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4DebCntrAry[_main_gen_tmp_21_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Pim_PrevClrNtcFlg4(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Pim_PrevClrNtcFlg4;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Pim_PrevClrNtcFlg4 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Pim_ProxySetNtcData4(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl4_Pim_ProxySetNtcData4;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Pim_ProxySetNtcData4 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl5_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_22_0;
            
            for (_main_gen_tmp_22_0 = 0; _main_gen_tmp_22_0 < 512; _main_gen_tmp_22_0++)
            {
                /* base type */
                DiagcMgrProxyAppl5_Cal_DiagcMgrFltResp[_main_gen_tmp_22_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Pim_DiagcData5(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl5_Pim_DiagcData5;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Pim_DiagcData5 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_23_0;
            
            for (_main_gen_tmp_23_0 = 0; _main_gen_tmp_23_0 < 65535; _main_gen_tmp_23_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5Ary[_main_gen_tmp_23_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5Ary[_main_gen_tmp_23_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5Ary[_main_gen_tmp_23_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_24_0;
            
            for (_main_gen_tmp_24_0 = 0; _main_gen_tmp_24_0 < 512; _main_gen_tmp_24_0++)
            {
                /* base type */
                DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5DebCntrAry[_main_gen_tmp_24_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Pim_PrevClrNtcFlg5(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Pim_PrevClrNtcFlg5;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Pim_PrevClrNtcFlg5 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Pim_ProxySetNtcData5(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl5_Pim_ProxySetNtcData5;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Pim_ProxySetNtcData5 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl6_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_25_0;
            
            for (_main_gen_tmp_25_0 = 0; _main_gen_tmp_25_0 < 512; _main_gen_tmp_25_0++)
            {
                /* base type */
                DiagcMgrProxyAppl6_Cal_DiagcMgrFltResp[_main_gen_tmp_25_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Pim_DiagcData6(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl6_Pim_DiagcData6;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Pim_DiagcData6 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_26_0;
            
            for (_main_gen_tmp_26_0 = 0; _main_gen_tmp_26_0 < 65535; _main_gen_tmp_26_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6Ary[_main_gen_tmp_26_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6Ary[_main_gen_tmp_26_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6Ary[_main_gen_tmp_26_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_27_0;
            
            for (_main_gen_tmp_27_0 = 0; _main_gen_tmp_27_0 < 512; _main_gen_tmp_27_0++)
            {
                /* base type */
                DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6DebCntrAry[_main_gen_tmp_27_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Pim_PrevClrNtcFlg6(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Pim_PrevClrNtcFlg6;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Pim_PrevClrNtcFlg6 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Pim_ProxySetNtcData6(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl6_Pim_ProxySetNtcData6;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Pim_ProxySetNtcData6 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl7_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_28_0;
            
            for (_main_gen_tmp_28_0 = 0; _main_gen_tmp_28_0 < 512; _main_gen_tmp_28_0++)
            {
                /* base type */
                DiagcMgrProxyAppl7_Cal_DiagcMgrFltResp[_main_gen_tmp_28_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Pim_DiagcData7(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl7_Pim_DiagcData7;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Pim_DiagcData7 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_29_0;
            
            for (_main_gen_tmp_29_0 = 0; _main_gen_tmp_29_0 < 65535; _main_gen_tmp_29_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7Ary[_main_gen_tmp_29_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7Ary[_main_gen_tmp_29_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7Ary[_main_gen_tmp_29_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_30_0;
            
            for (_main_gen_tmp_30_0 = 0; _main_gen_tmp_30_0 < 512; _main_gen_tmp_30_0++)
            {
                /* base type */
                DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7DebCntrAry[_main_gen_tmp_30_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Pim_PrevClrNtcFlg7(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Pim_PrevClrNtcFlg7;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Pim_PrevClrNtcFlg7 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Pim_ProxySetNtcData7(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl7_Pim_ProxySetNtcData7;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Pim_ProxySetNtcData7 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl8_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_31_0;
            
            for (_main_gen_tmp_31_0 = 0; _main_gen_tmp_31_0 < 512; _main_gen_tmp_31_0++)
            {
                /* base type */
                DiagcMgrProxyAppl8_Cal_DiagcMgrFltResp[_main_gen_tmp_31_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Pim_DiagcData8(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl8_Pim_DiagcData8;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Pim_DiagcData8 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_32_0;
            
            for (_main_gen_tmp_32_0 = 0; _main_gen_tmp_32_0 < 65535; _main_gen_tmp_32_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8Ary[_main_gen_tmp_32_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8Ary[_main_gen_tmp_32_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8Ary[_main_gen_tmp_32_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_33_0;
            
            for (_main_gen_tmp_33_0 = 0; _main_gen_tmp_33_0 < 512; _main_gen_tmp_33_0++)
            {
                /* base type */
                DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8DebCntrAry[_main_gen_tmp_33_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Pim_PrevClrNtcFlg8(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Pim_PrevClrNtcFlg8;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Pim_PrevClrNtcFlg8 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Pim_ProxySetNtcData8(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl8_Pim_ProxySetNtcData8;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Pim_ProxySetNtcData8 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Ip_ClrDiagcFlgProxy(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Ip_ClrDiagcFlgProxy;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Ip_ClrDiagcFlgProxy = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cal_DiagcMgrFltResp(void)
{
    extern __PST__g__84 DiagcMgrProxyAppl9_Cal_DiagcMgrFltResp;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_34_0;
            
            for (_main_gen_tmp_34_0 = 0; _main_gen_tmp_34_0 < 512; _main_gen_tmp_34_0++)
            {
                /* base type */
                DiagcMgrProxyAppl9_Cal_DiagcMgrFltResp[_main_gen_tmp_34_0] = pst_random_g_7;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Pim_DiagcData9(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl9_Pim_DiagcData9;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Pim_DiagcData9 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9Ary(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9Ary;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_35_0;
            
            for (_main_gen_tmp_35_0 = 0; _main_gen_tmp_35_0 < 65535; _main_gen_tmp_35_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9Ary[_main_gen_tmp_35_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9Ary[_main_gen_tmp_35_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9Ary[_main_gen_tmp_35_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9DebCntrAry(void)
{
    extern __PST__g__94 DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9DebCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_36_0;
            
            for (_main_gen_tmp_36_0 = 0; _main_gen_tmp_36_0 < 512; _main_gen_tmp_36_0++)
            {
                /* base type */
                DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9DebCntrAry[_main_gen_tmp_36_0] = pst_random_g_3;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Pim_PrevClrNtcFlg9(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Pim_PrevClrNtcFlg9;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Pim_PrevClrNtcFlg9 = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Pim_ProxySetNtcData9(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl9_Pim_ProxySetNtcData9;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Pim_ProxySetNtcData9 = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_37_0;
            
            for (_main_gen_tmp_37_0 = 0; _main_gen_tmp_37_0 < 65535; _main_gen_tmp_37_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_37_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_37_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_37_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl0_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl0_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetDiagcDataAppl0_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl0_Cli_GetDiagcDataAppl0_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetDiagcDataAppl0_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcActv0_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl0_Cli_GetNtcActv0_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetNtcActv0_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcActv0_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Cli_GetNtcActv0_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetNtcActv0_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcDebCntrAppl0_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Cli_GetNtcDebCntrAppl0_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetNtcDebCntrAppl0_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcDebCntrAppl0_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl0_Cli_GetNtcDebCntrAppl0_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetNtcDebCntrAppl0_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcInfoAppl0_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Cli_GetNtcInfoAppl0_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetNtcInfoAppl0_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcInfoAppl0_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl0_Cli_GetNtcInfoAppl0_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetNtcInfoAppl0_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcSts0_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl0_Cli_GetNtcSts0_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetNtcSts0_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcSts0_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Cli_GetNtcSts0_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_GetNtcSts0_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcSts0_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl0_Cli_SetNtcSts0_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcSts0_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_38_0;
            
            for (_main_gen_tmp_38_0 = 0; _main_gen_tmp_38_0 < 65535; _main_gen_tmp_38_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_38_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_38_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_38_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl10_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl10_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetDiagcDataAppl10_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl10_Cli_GetDiagcDataAppl10_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetDiagcDataAppl10_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcActv10_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl10_Cli_GetNtcActv10_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetNtcActv10_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcActv10_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Cli_GetNtcActv10_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetNtcActv10_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcDebCntrAppl10_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Cli_GetNtcDebCntrAppl10_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetNtcDebCntrAppl10_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcDebCntrAppl10_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl10_Cli_GetNtcDebCntrAppl10_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetNtcDebCntrAppl10_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcInfoAppl10_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Cli_GetNtcInfoAppl10_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetNtcInfoAppl10_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcInfoAppl10_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl10_Cli_GetNtcInfoAppl10_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetNtcInfoAppl10_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcSts10_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl10_Cli_GetNtcSts10_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetNtcSts10_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcSts10_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Cli_GetNtcSts10_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_GetNtcSts10_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcSts10_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl10_Cli_SetNtcSts10_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcSts10_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_39_0;
            
            for (_main_gen_tmp_39_0 = 0; _main_gen_tmp_39_0 < 65535; _main_gen_tmp_39_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_39_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_39_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_39_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl1_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl1_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetDiagcDataAppl1_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl1_Cli_GetDiagcDataAppl1_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetDiagcDataAppl1_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcActv1_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl1_Cli_GetNtcActv1_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetNtcActv1_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcActv1_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Cli_GetNtcActv1_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetNtcActv1_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcDebCntrAppl1_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Cli_GetNtcDebCntrAppl1_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetNtcDebCntrAppl1_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcDebCntrAppl1_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl1_Cli_GetNtcDebCntrAppl1_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetNtcDebCntrAppl1_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcInfoAppl1_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Cli_GetNtcInfoAppl1_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetNtcInfoAppl1_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcInfoAppl1_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl1_Cli_GetNtcInfoAppl1_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetNtcInfoAppl1_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcSts1_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl1_Cli_GetNtcSts1_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetNtcSts1_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcSts1_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Cli_GetNtcSts1_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_GetNtcSts1_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcSts1_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl1_Cli_SetNtcSts1_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcSts1_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_40_0;
            
            for (_main_gen_tmp_40_0 = 0; _main_gen_tmp_40_0 < 65535; _main_gen_tmp_40_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_40_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_40_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_40_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl2_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl2_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetDiagcDataAppl2_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl2_Cli_GetDiagcDataAppl2_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetDiagcDataAppl2_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcActv2_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl2_Cli_GetNtcActv2_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetNtcActv2_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcActv2_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Cli_GetNtcActv2_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetNtcActv2_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcDebCntrAppl2_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Cli_GetNtcDebCntrAppl2_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetNtcDebCntrAppl2_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcDebCntrAppl2_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl2_Cli_GetNtcDebCntrAppl2_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetNtcDebCntrAppl2_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcInfoAppl2_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Cli_GetNtcInfoAppl2_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetNtcInfoAppl2_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcInfoAppl2_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl2_Cli_GetNtcInfoAppl2_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetNtcInfoAppl2_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcSts2_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl2_Cli_GetNtcSts2_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetNtcSts2_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcSts2_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Cli_GetNtcSts2_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_GetNtcSts2_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcSts2_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl2_Cli_SetNtcSts2_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcSts2_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_41_0;
            
            for (_main_gen_tmp_41_0 = 0; _main_gen_tmp_41_0 < 65535; _main_gen_tmp_41_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_41_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_41_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_41_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl3_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl3_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetDiagcDataAppl3_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl3_Cli_GetDiagcDataAppl3_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetDiagcDataAppl3_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcActv3_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl3_Cli_GetNtcActv3_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetNtcActv3_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcActv3_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Cli_GetNtcActv3_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetNtcActv3_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcDebCntrAppl3_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Cli_GetNtcDebCntrAppl3_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetNtcDebCntrAppl3_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcDebCntrAppl3_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl3_Cli_GetNtcDebCntrAppl3_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetNtcDebCntrAppl3_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcInfoAppl3_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Cli_GetNtcInfoAppl3_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetNtcInfoAppl3_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcInfoAppl3_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl3_Cli_GetNtcInfoAppl3_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetNtcInfoAppl3_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcSts3_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl3_Cli_GetNtcSts3_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetNtcSts3_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcSts3_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Cli_GetNtcSts3_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_GetNtcSts3_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcSts3_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl3_Cli_SetNtcSts3_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcSts3_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_42_0;
            
            for (_main_gen_tmp_42_0 = 0; _main_gen_tmp_42_0 < 65535; _main_gen_tmp_42_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_42_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_42_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_42_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl4_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl4_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetDiagcDataAppl4_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl4_Cli_GetDiagcDataAppl4_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetDiagcDataAppl4_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcActv4_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl4_Cli_GetNtcActv4_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetNtcActv4_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcActv4_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Cli_GetNtcActv4_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetNtcActv4_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcDebCntrAppl4_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Cli_GetNtcDebCntrAppl4_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetNtcDebCntrAppl4_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcDebCntrAppl4_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl4_Cli_GetNtcDebCntrAppl4_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetNtcDebCntrAppl4_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcInfoAppl4_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Cli_GetNtcInfoAppl4_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetNtcInfoAppl4_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcInfoAppl4_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl4_Cli_GetNtcInfoAppl4_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetNtcInfoAppl4_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcSts4_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl4_Cli_GetNtcSts4_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetNtcSts4_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcSts4_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Cli_GetNtcSts4_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_GetNtcSts4_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcSts4_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl4_Cli_SetNtcSts4_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcSts4_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_43_0;
            
            for (_main_gen_tmp_43_0 = 0; _main_gen_tmp_43_0 < 65535; _main_gen_tmp_43_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_43_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_43_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_43_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl5_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl5_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetDiagcDataAppl5_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl5_Cli_GetDiagcDataAppl5_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetDiagcDataAppl5_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcActv5_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl5_Cli_GetNtcActv5_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetNtcActv5_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcActv5_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Cli_GetNtcActv5_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetNtcActv5_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcDebCntrAppl5_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Cli_GetNtcDebCntrAppl5_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetNtcDebCntrAppl5_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcDebCntrAppl5_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl5_Cli_GetNtcDebCntrAppl5_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetNtcDebCntrAppl5_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcInfoAppl5_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Cli_GetNtcInfoAppl5_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetNtcInfoAppl5_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcInfoAppl5_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl5_Cli_GetNtcInfoAppl5_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetNtcInfoAppl5_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcSts5_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl5_Cli_GetNtcSts5_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetNtcSts5_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcSts5_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Cli_GetNtcSts5_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_GetNtcSts5_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcSts5_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl5_Cli_SetNtcSts5_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcSts5_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_44_0;
            
            for (_main_gen_tmp_44_0 = 0; _main_gen_tmp_44_0 < 65535; _main_gen_tmp_44_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_44_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_44_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_44_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl6_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl6_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetDiagcDataAppl6_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl6_Cli_GetDiagcDataAppl6_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetDiagcDataAppl6_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcActv6_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl6_Cli_GetNtcActv6_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetNtcActv6_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcActv6_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Cli_GetNtcActv6_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetNtcActv6_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcDebCntrAppl6_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Cli_GetNtcDebCntrAppl6_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetNtcDebCntrAppl6_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcDebCntrAppl6_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl6_Cli_GetNtcDebCntrAppl6_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetNtcDebCntrAppl6_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcInfoAppl6_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Cli_GetNtcInfoAppl6_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetNtcInfoAppl6_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcInfoAppl6_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl6_Cli_GetNtcInfoAppl6_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetNtcInfoAppl6_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcSts6_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl6_Cli_GetNtcSts6_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetNtcSts6_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcSts6_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Cli_GetNtcSts6_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_GetNtcSts6_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcSts6_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl6_Cli_SetNtcSts6_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcSts6_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_45_0;
            
            for (_main_gen_tmp_45_0 = 0; _main_gen_tmp_45_0 < 65535; _main_gen_tmp_45_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_45_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_45_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_45_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl7_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl7_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetDiagcDataAppl7_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl7_Cli_GetDiagcDataAppl7_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetDiagcDataAppl7_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcActv7_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl7_Cli_GetNtcActv7_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetNtcActv7_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcActv7_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Cli_GetNtcActv7_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetNtcActv7_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcDebCntrAppl7_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Cli_GetNtcDebCntrAppl7_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetNtcDebCntrAppl7_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcDebCntrAppl7_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl7_Cli_GetNtcDebCntrAppl7_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetNtcDebCntrAppl7_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcInfoAppl7_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Cli_GetNtcInfoAppl7_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetNtcInfoAppl7_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcInfoAppl7_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl7_Cli_GetNtcInfoAppl7_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetNtcInfoAppl7_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcSts7_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl7_Cli_GetNtcSts7_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetNtcSts7_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcSts7_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Cli_GetNtcSts7_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_GetNtcSts7_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcSts7_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl7_Cli_SetNtcSts7_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcSts7_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_46_0;
            
            for (_main_gen_tmp_46_0 = 0; _main_gen_tmp_46_0 < 65535; _main_gen_tmp_46_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_46_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_46_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_46_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl8_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl8_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetDiagcDataAppl8_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl8_Cli_GetDiagcDataAppl8_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetDiagcDataAppl8_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcActv8_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl8_Cli_GetNtcActv8_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetNtcActv8_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcActv8_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Cli_GetNtcActv8_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetNtcActv8_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcDebCntrAppl8_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Cli_GetNtcDebCntrAppl8_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetNtcDebCntrAppl8_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcDebCntrAppl8_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl8_Cli_GetNtcDebCntrAppl8_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetNtcDebCntrAppl8_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcInfoAppl8_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Cli_GetNtcInfoAppl8_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetNtcInfoAppl8_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcInfoAppl8_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl8_Cli_GetNtcInfoAppl8_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetNtcInfoAppl8_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcSts8_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl8_Cli_GetNtcSts8_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetNtcSts8_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcSts8_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Cli_GetNtcSts8_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_GetNtcSts8_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcSts8_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl8_Cli_SetNtcSts8_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcSts8_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_47_0;
            
            for (_main_gen_tmp_47_0 = 0; _main_gen_tmp_47_0 < 65535; _main_gen_tmp_47_0++)
            {
                /* struct/union type */
                DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_47_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_47_0].Sts = _main_gen_init_g6();
                DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_47_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Srv_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Srv_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Srv_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Srv_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Srv_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Srv_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl9_Srv_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Srv_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl9_Srv_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Srv_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_SetNtcStsCore_Return(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Srv_SetNtcStsCore_Return;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Srv_SetNtcStsCore_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetDiagcDataAppl9_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgrProxyAppl9_Cli_GetDiagcDataAppl9_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetDiagcDataAppl9_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcActv9_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl9_Cli_GetNtcActv9_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetNtcActv9_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcActv9_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Cli_GetNtcActv9_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetNtcActv9_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcDebCntrAppl9_DebCntrIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Cli_GetNtcDebCntrAppl9_DebCntrIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetNtcDebCntrAppl9_DebCntrIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcDebCntrAppl9_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgrProxyAppl9_Cli_GetNtcDebCntrAppl9_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetNtcDebCntrAppl9_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcInfoAppl9_NtcInfoIdx(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Cli_GetNtcInfoAppl9_NtcInfoIdx;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetNtcInfoAppl9_NtcInfoIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcInfoAppl9_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgrProxyAppl9_Cli_GetNtcInfoAppl9_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetNtcInfoAppl9_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcSts9_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl9_Cli_GetNtcSts9_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetNtcSts9_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcSts9_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Cli_GetNtcSts9_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_GetNtcSts9_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcSts9_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl9_Cli_SetNtcSts9_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcSts9_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_DebStep(void)
{
    extern __PST__UINT16 DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_DiagcMgrApplCrc_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 DiagcMgr_Srv_DiagcMgrApplCrc_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_DiagcMgrApplCrc_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_DiagcMgrLtchCntrAry_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 DiagcMgr_Srv_DiagcMgrLtchCntrAry_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_DiagcMgrLtchCntrAry_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl0_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl0_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl0_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl1_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl1_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl1_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl2_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl2_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl2_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl3_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl3_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl3_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl4_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl4_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl4_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl5_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl5_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl5_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl6_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl6_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl6_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl7_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl7_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl7_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl8_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl8_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl8_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl9_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl9_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl9_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl10_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Srv_GetDiagcDataAppl10_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetDiagcDataAppl10_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetMcuDiagcSpplData_McuDiagcData1(void)
{
    extern __PST__UINT32 DiagcMgr_Srv_GetMcuDiagcSpplData_McuDiagcData1;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetMcuDiagcSpplData_McuDiagcData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl0_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl0_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl0_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl1_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl1_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl1_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl2_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl2_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl2_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl3_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl3_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl3_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl4_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl4_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl4_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl5_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl5_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl5_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl6_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl6_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl6_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl7_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl7_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl7_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl8_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl8_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl8_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl9_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl9_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl9_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl10_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Srv_GetNtcDebCntrAppl10_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcDebCntrAppl10_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl0_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl0_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl0_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl1_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl1_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl1_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl2_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl2_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl2_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl3_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl3_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl3_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl4_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl4_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl4_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl5_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl5_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl5_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl6_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl6_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl6_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl7_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl7_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl7_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl8_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl8_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl8_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl9_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl9_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl9_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl10_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Srv_GetNtcInfoAppl10_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_GetNtcInfoAppl10_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Srv_SnpshtDataAry_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 DiagcMgr_Srv_SnpshtDataAry_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        DiagcMgr_Srv_SnpshtDataAry_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_f32_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 DiagcMgr_Cli_CnvSnpshtData_f32_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_f32_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_f32_SnpshtData(void)
{
    extern __PST__FLOAT32 DiagcMgr_Cli_CnvSnpshtData_f32_SnpshtData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_f32_SnpshtData = _main_gen_init_g10();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_logl_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 DiagcMgr_Cli_CnvSnpshtData_logl_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_logl_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_logl_SnpshtData(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_CnvSnpshtData_logl_SnpshtData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_logl_SnpshtData = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s08_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 DiagcMgr_Cli_CnvSnpshtData_s08_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_s08_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s08_SnpshtData(void)
{
    extern __PST__SINT8 DiagcMgr_Cli_CnvSnpshtData_s08_SnpshtData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_s08_SnpshtData = _main_gen_init_g2();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s16_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 DiagcMgr_Cli_CnvSnpshtData_s16_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_s16_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s16_SnpshtData(void)
{
    extern __PST__SINT16 DiagcMgr_Cli_CnvSnpshtData_s16_SnpshtData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_s16_SnpshtData = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s32_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 DiagcMgr_Cli_CnvSnpshtData_s32_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_s32_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s32_SnpshtData(void)
{
    extern __PST__SINT32 DiagcMgr_Cli_CnvSnpshtData_s32_SnpshtData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_s32_SnpshtData = _main_gen_init_g4();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_u08_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 DiagcMgr_Cli_CnvSnpshtData_u08_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_u08_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_u08_SnpshtData(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_CnvSnpshtData_u08_SnpshtData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_u08_SnpshtData = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_u16_SnpshtDataCnvd(void)
{
    extern __PST__UINT32 DiagcMgr_Cli_CnvSnpshtData_u16_SnpshtDataCnvd;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_u16_SnpshtDataCnvd = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_u16_SnpshtData(void)
{
    extern __PST__UINT16 DiagcMgr_Cli_CnvSnpshtData_u16_SnpshtData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_CnvSnpshtData_u16_SnpshtData = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_DiagcMgrIninCore_ApplIdx(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_DiagcMgrIninCore_ApplIdx;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_DiagcMgrIninCore_ApplIdx = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoArySize(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoArySize;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoArySize = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoAry(void)
{
    extern __PST__g__93 DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_48_0;
            
            for (_main_gen_tmp_48_0 = 0; _main_gen_tmp_48_0 < 65535; _main_gen_tmp_48_0++)
            {
                /* struct/union type */
                DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_48_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_48_0].Sts = _main_gen_init_g6();
                DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoAry[_main_gen_tmp_48_0].AgiCntr = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_DiagcMgrIninCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Cli_DiagcMgrIninCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_DiagcMgrIninCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_DiagcMgrIninCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Cli_DiagcMgrIninCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_DiagcMgrIninCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_GetNtcActvCore_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgr_Cli_GetNtcActvCore_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_GetNtcActvCore_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_GetNtcActvCore_NtcActv(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_GetNtcActvCore_NtcActv;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_GetNtcActvCore_NtcActv = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_GetNtcQlfrStsCore_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgr_Cli_GetNtcQlfrStsCore_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_GetNtcQlfrStsCore_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_GetNtcQlfrStsCore_NtcQlfr(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_GetNtcQlfrStsCore_NtcQlfr;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_GetNtcQlfrStsCore_NtcQlfr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_GetNtcStsCore_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgr_Cli_GetNtcStsCore_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_GetNtcStsCore_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_GetNtcStsCore_NtcInfoSts(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_GetNtcStsCore_NtcInfoSts;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_GetNtcStsCore_NtcInfoSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_ReadLtchCntrData_ReadLtchCntrAry(void)
{
    extern __PST__g__85 DiagcMgr_Cli_ReadLtchCntrData_ReadLtchCntrAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_49_0;
            
            for (_main_gen_tmp_49_0 = 0; _main_gen_tmp_49_0 < 20; _main_gen_tmp_49_0++)
            {
                /* base type */
                DiagcMgr_Cli_ReadLtchCntrData_ReadLtchCntrAry[_main_gen_tmp_49_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_ReadNtcFltAry_DiagcMgrReadFltInfo(void)
{
    extern __PST__g__95 DiagcMgr_Cli_ReadNtcFltAry_DiagcMgrReadFltInfo;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_50_0;
            
            for (_main_gen_tmp_50_0 = 0; _main_gen_tmp_50_0 < 20; _main_gen_tmp_50_0++)
            {
                /* struct/union type */
                DiagcMgr_Cli_ReadNtcFltAry_DiagcMgrReadFltInfo[_main_gen_tmp_50_0].NtcNr = _main_gen_init_g7();
                DiagcMgr_Cli_ReadNtcFltAry_DiagcMgrReadFltInfo[_main_gen_tmp_50_0].AgiCntr = _main_gen_init_g6();
                DiagcMgr_Cli_ReadNtcFltAry_DiagcMgrReadFltInfo[_main_gen_tmp_50_0].Sts = _main_gen_init_g6();
                DiagcMgr_Cli_ReadNtcFltAry_DiagcMgrReadFltInfo[_main_gen_tmp_50_0].NtcStInfo = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_ReadNtcInfoAndDebCntr_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgr_Cli_ReadNtcInfoAndDebCntr_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_ReadNtcInfoAndDebCntr_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_ReadNtcInfoAndDebCntr_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Cli_ReadNtcInfoAndDebCntr_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_ReadNtcInfoAndDebCntr_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_ReadNtcInfoAndDebCntr_DebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Cli_ReadNtcInfoAndDebCntr_DebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_ReadNtcInfoAndDebCntr_DebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry(void)
{
    extern __PST__g__65 DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_51_0;
            
            for (_main_gen_tmp_51_0 = 0; _main_gen_tmp_51_0 < 8; _main_gen_tmp_51_0++)
            {
                /* struct/union type */
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].SpclSnpshtData0 = _main_gen_init_g8();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].SpclSnpshtData1 = _main_gen_init_g8();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].SpclSnpshtData2 = _main_gen_init_g8();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].MicroDiagcData = _main_gen_init_g8();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].IgnCntr = _main_gen_init_g8();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].HwTq = _main_gen_init_g3();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].MotTq = _main_gen_init_g3();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].BrdgVltg = _main_gen_init_g7();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].EcuT = _main_gen_init_g3();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].NtcNr = _main_gen_init_g7();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].NtcStInfo = _main_gen_init_g6();
                DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry[_main_gen_tmp_51_0].SysSt = _main_gen_init_g6();
            }
        }
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_NtcNr(void)
{
    extern __PST__UINT16 DiagcMgr_Cli_SetNtcStsCore_NtcNr;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_NtcNr = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_NtcStInfo(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_SetNtcStsCore_NtcStInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_NtcStInfo = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_NtcSts(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_SetNtcStsCore_NtcSts;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_NtcSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_DebStep(void)
{
    extern __PST__UINT16 DiagcMgr_Cli_SetNtcStsCore_DebStep;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_DebStep = _main_gen_init_g7();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_DiagcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Cli_SetNtcStsCore_DiagcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_DiagcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_ProxySetNtcData(void)
{
    extern struct __PST__g__27 DiagcMgr_Cli_SetNtcStsCore_ProxySetNtcData;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_ProxySetNtcData = _main_gen_init_g27();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_NtcInfo(void)
{
    extern struct __PST__g__25 DiagcMgr_Cli_SetNtcStsCore_NtcInfo;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_NtcInfo = _main_gen_init_g25();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_NtcInfoDebCntr(void)
{
    extern __PST__SINT16 DiagcMgr_Cli_SetNtcStsCore_NtcInfoDebCntr;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_NtcInfoDebCntr = _main_gen_init_g3();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData0(void)
{
    extern __PST__UINT32 DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData0;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData0 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData1(void)
{
    extern __PST__UINT32 DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData1;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData1 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData2(void)
{
    extern __PST__UINT32 DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData2;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData2 = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtDataPrsnt(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtDataPrsnt;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtDataPrsnt = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_UpdDtcEnaCdn_DtcEnaCdnSts(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_UpdDtcEnaCdn_DtcEnaCdnSts;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_UpdDtcEnaCdn_DtcEnaCdnSts = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_DiagcMgr_Cli_UpdDtcEnaCdn_DtcEnaCdnId(void)
{
    extern __PST__UINT8 DiagcMgr_Cli_UpdDtcEnaCdn_DtcEnaCdnId;
    
    /* initialization with random value */
    {
        DiagcMgr_Cli_UpdDtcEnaCdn_DtcEnaCdnId = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable DiagcMgr_Ip_BrdgVltg */
    _main_gen_init_sym_DiagcMgr_Ip_BrdgVltg();
    
    /* init for variable DiagcMgr_Ip_EcuTFild */
    _main_gen_init_sym_DiagcMgr_Ip_EcuTFild();
    
    /* init for variable DiagcMgr_Ip_HwTq */
    _main_gen_init_sym_DiagcMgr_Ip_HwTq();
    
    /* init for variable DiagcMgr_Ip_IgnCntr */
    _main_gen_init_sym_DiagcMgr_Ip_IgnCntr();
    
    /* init for variable DiagcMgr_Ip_MfgDiagcInhb */
    _main_gen_init_sym_DiagcMgr_Ip_MfgDiagcInhb();
    
    /* init for variable DiagcMgr_Ip_MfgEnaSt */
    _main_gen_init_sym_DiagcMgr_Ip_MfgEnaSt();
    
    /* init for variable DiagcMgr_Ip_MotTqCmdMrfScad */
    _main_gen_init_sym_DiagcMgr_Ip_MotTqCmdMrfScad();
    
    /* init for variable DiagcMgr_Ip_SwApplCrc */
    _main_gen_init_sym_DiagcMgr_Ip_SwApplCrc();
    
    /* init for variable DiagcMgr_Ip_SysSt */
    _main_gen_init_sym_DiagcMgr_Ip_SysSt();
    
    /* init for variable DiagcMgr_Op_ClrDiagcFlgProxy : useless (never read) */

    /* init for variable DiagcMgr_Op_DiagcStsCtrldShtDwnFltPrsnt : useless (never read) */

    /* init for variable DiagcMgr_Op_DiagcStsNonRcvrlReqDiFltPrsnt : useless (never read) */

    /* init for variable DiagcMgr_Op_SysDiMotTqCmdSca : useless (never read) */

    /* init for variable DiagcMgr_Op_SysDiRampRate : useless (never read) */

    /* init for variable DiagcMgr_Op_SysStFltOutpReqDi : useless (never read) */

    /* init for variable DiagcMgr_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgr_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgr_Pim_DiagcMgrApplCrc */
    _main_gen_init_sym_DiagcMgr_Pim_DiagcMgrApplCrc();
    
    /* init for variable DiagcMgr_Pim_DiagcMgrLtchCntrAry */
    _main_gen_init_sym_DiagcMgr_Pim_DiagcMgrLtchCntrAry();
    
    /* init for variable DiagcMgr_Pim_DiagcMgrNtcFltAry */
    _main_gen_init_sym_DiagcMgr_Pim_DiagcMgrNtcFltAry();
    
    /* init for variable DiagcMgr_Pim_ClrDiagcFlg */
    _main_gen_init_sym_DiagcMgr_Pim_ClrDiagcFlg();
    
    /* init for variable DiagcMgr_Pim_DtcEnaSts */
    _main_gen_init_sym_DiagcMgr_Pim_DtcEnaSts();
    
    /* init for variable DiagcMgr_Pim_DtcIdxPrevSts */
    _main_gen_init_sym_DiagcMgr_Pim_DtcIdxPrevSts();
    
    /* init for variable DiagcMgr_Pim_PrevClrDtcFlg */
    _main_gen_init_sym_DiagcMgr_Pim_PrevClrDtcFlg();
    
    /* init for variable DiagcMgrProxyAppl0_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl0_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl0_Pim_DiagcData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Pim_DiagcData0();
    
    /* init for variable DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0Ary();
    
    /* init for variable DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Pim_DiagcMgrNtcInfo0DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl0_Pim_PrevClrNtcFlg0 */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Pim_PrevClrNtcFlg0();
    
    /* init for variable DiagcMgrProxyAppl0_Pim_ProxySetNtcData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Pim_ProxySetNtcData0();
    
    /* init for variable DiagcMgrProxyAppl1_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl1_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl1_Pim_DiagcData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Pim_DiagcData1();
    
    /* init for variable DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1Ary();
    
    /* init for variable DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Pim_DiagcMgrNtcInfo1DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl1_Pim_PrevClrNtcFlg1 */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Pim_PrevClrNtcFlg1();
    
    /* init for variable DiagcMgrProxyAppl1_Pim_ProxySetNtcData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Pim_ProxySetNtcData1();
    
    /* init for variable DiagcMgrProxyAppl10_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl10_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl10_Pim_DiagcData10 */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Pim_DiagcData10();
    
    /* init for variable DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10Ary();
    
    /* init for variable DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Pim_DiagcMgrNtcInfo10DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl10_Pim_PrevClrNtcFlg10 */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Pim_PrevClrNtcFlg10();
    
    /* init for variable DiagcMgrProxyAppl10_Pim_ProxySetNtcData10 */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Pim_ProxySetNtcData10();
    
    /* init for variable DiagcMgrProxyAppl2_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl2_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl2_Pim_DiagcData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Pim_DiagcData2();
    
    /* init for variable DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2Ary();
    
    /* init for variable DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Pim_DiagcMgrNtcInfo2DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl2_Pim_PrevClrNtcFlg2 */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Pim_PrevClrNtcFlg2();
    
    /* init for variable DiagcMgrProxyAppl2_Pim_ProxySetNtcData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Pim_ProxySetNtcData2();
    
    /* init for variable DiagcMgrProxyAppl3_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl3_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl3_Pim_DiagcData3 */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Pim_DiagcData3();
    
    /* init for variable DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3Ary();
    
    /* init for variable DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Pim_DiagcMgrNtcInfo3DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl3_Pim_PrevClrNtcFlg3 */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Pim_PrevClrNtcFlg3();
    
    /* init for variable DiagcMgrProxyAppl3_Pim_ProxySetNtcData3 */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Pim_ProxySetNtcData3();
    
    /* init for variable DiagcMgrProxyAppl4_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl4_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl4_Pim_DiagcData4 */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Pim_DiagcData4();
    
    /* init for variable DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4Ary();
    
    /* init for variable DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Pim_DiagcMgrNtcInfo4DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl4_Pim_PrevClrNtcFlg4 */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Pim_PrevClrNtcFlg4();
    
    /* init for variable DiagcMgrProxyAppl4_Pim_ProxySetNtcData4 */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Pim_ProxySetNtcData4();
    
    /* init for variable DiagcMgrProxyAppl5_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl5_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl5_Pim_DiagcData5 */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Pim_DiagcData5();
    
    /* init for variable DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5Ary();
    
    /* init for variable DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Pim_DiagcMgrNtcInfo5DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl5_Pim_PrevClrNtcFlg5 */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Pim_PrevClrNtcFlg5();
    
    /* init for variable DiagcMgrProxyAppl5_Pim_ProxySetNtcData5 */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Pim_ProxySetNtcData5();
    
    /* init for variable DiagcMgrProxyAppl6_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl6_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl6_Pim_DiagcData6 */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Pim_DiagcData6();
    
    /* init for variable DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6Ary();
    
    /* init for variable DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Pim_DiagcMgrNtcInfo6DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl6_Pim_PrevClrNtcFlg6 */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Pim_PrevClrNtcFlg6();
    
    /* init for variable DiagcMgrProxyAppl6_Pim_ProxySetNtcData6 */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Pim_ProxySetNtcData6();
    
    /* init for variable DiagcMgrProxyAppl7_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl7_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl7_Pim_DiagcData7 */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Pim_DiagcData7();
    
    /* init for variable DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7Ary();
    
    /* init for variable DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Pim_DiagcMgrNtcInfo7DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl7_Pim_PrevClrNtcFlg7 */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Pim_PrevClrNtcFlg7();
    
    /* init for variable DiagcMgrProxyAppl7_Pim_ProxySetNtcData7 */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Pim_ProxySetNtcData7();
    
    /* init for variable DiagcMgrProxyAppl8_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl8_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl8_Pim_DiagcData8 */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Pim_DiagcData8();
    
    /* init for variable DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8Ary();
    
    /* init for variable DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Pim_DiagcMgrNtcInfo8DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl8_Pim_PrevClrNtcFlg8 */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Pim_PrevClrNtcFlg8();
    
    /* init for variable DiagcMgrProxyAppl8_Pim_ProxySetNtcData8 */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Pim_ProxySetNtcData8();
    
    /* init for variable DiagcMgrProxyAppl9_Ip_ClrDiagcFlgProxy */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Ip_ClrDiagcFlgProxy();
    
    /* init for variable DiagcMgrProxyAppl9_Cal_DiagcMgrFltResp */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cal_DiagcMgrFltResp();
    
    /* init for variable DiagcMgrProxyAppl9_Pim_DiagcData9 */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Pim_DiagcData9();
    
    /* init for variable DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9Ary */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9Ary();
    
    /* init for variable DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9DebCntrAry */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Pim_DiagcMgrNtcInfo9DebCntrAry();
    
    /* init for variable DiagcMgrProxyAppl9_Pim_PrevClrNtcFlg9 */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Pim_PrevClrNtcFlg9();
    
    /* init for variable DiagcMgrProxyAppl9_Pim_ProxySetNtcData9 */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Pim_ProxySetNtcData9();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetDiagcDataAppl0_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetDiagcDataAppl0_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcActv0_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcActv0_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcActv0_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcActv0_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcActv0_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcDebCntrAppl0_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcDebCntrAppl0_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcDebCntrAppl0_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcDebCntrAppl0_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcInfoAppl0_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcInfoAppl0_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcInfoAppl0_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcInfoAppl0_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcQlfrSts0_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcSts0_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcSts0_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcSts0_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_GetNtcSts0_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_GetNtcSts0_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcSts0_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcSts0_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcSts0_DebStep();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcSts0_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_DebStep();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl0_Cli_SetNtcStsAndSnpshtData0_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl10_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl10_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl10_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetDiagcDataAppl10_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetDiagcDataAppl10_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcActv10_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcActv10_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcActv10_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcActv10_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcActv10_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcDebCntrAppl10_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcDebCntrAppl10_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcDebCntrAppl10_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcDebCntrAppl10_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcInfoAppl10_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcInfoAppl10_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcInfoAppl10_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcInfoAppl10_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcQlfrSts10_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcSts10_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcSts10_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcSts10_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_GetNtcSts10_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_GetNtcSts10_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcSts10_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcSts10_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcSts10_DebStep();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcSts10_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_DebStep();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl10_Cli_SetNtcStsAndSnpshtData10_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl1_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl1_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl1_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetDiagcDataAppl1_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetDiagcDataAppl1_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcActv1_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcActv1_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcActv1_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcActv1_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcActv1_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcDebCntrAppl1_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcDebCntrAppl1_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcDebCntrAppl1_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcDebCntrAppl1_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcInfoAppl1_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcInfoAppl1_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcInfoAppl1_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcInfoAppl1_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcQlfrSts1_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcSts1_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcSts1_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcSts1_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_GetNtcSts1_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_GetNtcSts1_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcSts1_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcSts1_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcSts1_DebStep();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcSts1_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_DebStep();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl1_Cli_SetNtcStsAndSnpshtData1_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl2_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl2_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl2_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetDiagcDataAppl2_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetDiagcDataAppl2_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcActv2_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcActv2_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcActv2_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcActv2_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcActv2_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcDebCntrAppl2_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcDebCntrAppl2_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcDebCntrAppl2_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcDebCntrAppl2_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcInfoAppl2_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcInfoAppl2_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcInfoAppl2_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcInfoAppl2_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcQlfrSts2_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcSts2_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcSts2_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcSts2_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_GetNtcSts2_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_GetNtcSts2_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcSts2_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcSts2_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcSts2_DebStep();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcSts2_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_DebStep();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl2_Cli_SetNtcStsAndSnpshtData2_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl3_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl3_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl3_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetDiagcDataAppl3_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetDiagcDataAppl3_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcActv3_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcActv3_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcActv3_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcActv3_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcActv3_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcDebCntrAppl3_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcDebCntrAppl3_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcDebCntrAppl3_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcDebCntrAppl3_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcInfoAppl3_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcInfoAppl3_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcInfoAppl3_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcInfoAppl3_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcQlfrSts3_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcSts3_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcSts3_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcSts3_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_GetNtcSts3_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_GetNtcSts3_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcSts3_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcSts3_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcSts3_DebStep();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcSts3_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_DebStep();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl3_Cli_SetNtcStsAndSnpshtData3_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl4_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl4_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl4_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetDiagcDataAppl4_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetDiagcDataAppl4_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcActv4_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcActv4_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcActv4_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcActv4_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcActv4_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcDebCntrAppl4_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcDebCntrAppl4_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcDebCntrAppl4_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcDebCntrAppl4_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcInfoAppl4_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcInfoAppl4_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcInfoAppl4_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcInfoAppl4_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcQlfrSts4_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcSts4_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcSts4_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcSts4_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_GetNtcSts4_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_GetNtcSts4_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcSts4_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcSts4_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcSts4_DebStep();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcSts4_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_DebStep();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl4_Cli_SetNtcStsAndSnpshtData4_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl5_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl5_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl5_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetDiagcDataAppl5_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetDiagcDataAppl5_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcActv5_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcActv5_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcActv5_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcActv5_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcActv5_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcDebCntrAppl5_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcDebCntrAppl5_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcDebCntrAppl5_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcDebCntrAppl5_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcInfoAppl5_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcInfoAppl5_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcInfoAppl5_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcInfoAppl5_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcQlfrSts5_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcSts5_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcSts5_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcSts5_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_GetNtcSts5_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_GetNtcSts5_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcSts5_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcSts5_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcSts5_DebStep();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcSts5_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_DebStep();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl5_Cli_SetNtcStsAndSnpshtData5_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl6_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl6_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl6_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetDiagcDataAppl6_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetDiagcDataAppl6_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcActv6_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcActv6_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcActv6_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcActv6_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcActv6_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcDebCntrAppl6_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcDebCntrAppl6_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcDebCntrAppl6_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcDebCntrAppl6_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcInfoAppl6_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcInfoAppl6_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcInfoAppl6_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcInfoAppl6_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcQlfrSts6_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcSts6_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcSts6_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcSts6_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_GetNtcSts6_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_GetNtcSts6_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcSts6_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcSts6_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcSts6_DebStep();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcSts6_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_DebStep();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl6_Cli_SetNtcStsAndSnpshtData6_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl7_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl7_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl7_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetDiagcDataAppl7_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetDiagcDataAppl7_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcActv7_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcActv7_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcActv7_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcActv7_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcActv7_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcDebCntrAppl7_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcDebCntrAppl7_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcDebCntrAppl7_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcDebCntrAppl7_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcInfoAppl7_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcInfoAppl7_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcInfoAppl7_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcInfoAppl7_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcQlfrSts7_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcSts7_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcSts7_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcSts7_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_GetNtcSts7_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_GetNtcSts7_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcSts7_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcSts7_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcSts7_DebStep();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcSts7_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_DebStep();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl7_Cli_SetNtcStsAndSnpshtData7_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl8_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl8_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl8_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetDiagcDataAppl8_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetDiagcDataAppl8_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcActv8_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcActv8_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcActv8_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcActv8_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcActv8_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcDebCntrAppl8_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcDebCntrAppl8_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcDebCntrAppl8_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcDebCntrAppl8_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcInfoAppl8_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcInfoAppl8_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcInfoAppl8_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcInfoAppl8_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcQlfrSts8_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcSts8_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcSts8_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcSts8_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_GetNtcSts8_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_GetNtcSts8_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcSts8_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcSts8_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcSts8_DebStep();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcSts8_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_DebStep();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl8_Cli_SetNtcStsAndSnpshtData8_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_ApplIdx : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_NtcInfoArySize : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl9_Srv_GetNtcActvCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl9_Srv_GetNtcQlfrStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl9_Srv_GetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcNr : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcStInfo : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcSts : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_DebStep : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_SpclSnpshtData0 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_SpclSnpshtData1 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_SpclSnpshtData2 : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_SpclSnpshtDataPrsnt : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Srv_SetNtcStsCore_Return */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Srv_SetNtcStsCore_Return();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetDiagcDataAppl9_DiagcData */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetDiagcDataAppl9_DiagcData();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcActv9_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcActv9_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcActv9_NtcActv */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcActv9_NtcActv();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcActv9_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcDebCntrAppl9_DebCntrIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcDebCntrAppl9_DebCntrIdx();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcDebCntrAppl9_DebCntr */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcDebCntrAppl9_DebCntr();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcInfoAppl9_NtcInfoIdx */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcInfoAppl9_NtcInfoIdx();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcInfoAppl9_NtcInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcInfoAppl9_NtcInfo();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_NtcQlfr */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_NtcQlfr();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcQlfrSts9_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcSts9_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcSts9_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcSts9_NtcInfoSts */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_GetNtcSts9_NtcInfoSts();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_GetNtcSts9_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcSts9_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcSts9_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcSts9_DebStep();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcSts9_Return : useless (never read) */

    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcNr */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcNr();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcStInfo */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcStInfo();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcSts */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_NtcSts();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_DebStep */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_DebStep();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData0();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData1();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_SpclSnpshtData2();
    
    /* init for variable DiagcMgrProxyAppl9_Cli_SetNtcStsAndSnpshtData9_Return : useless (never read) */

    /* init for variable DiagcMgr_Srv_DiagcMgrApplCrc_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable DiagcMgr_Srv_DiagcMgrApplCrc_SetRamBlockStatus_Return */
    _main_gen_init_sym_DiagcMgr_Srv_DiagcMgrApplCrc_SetRamBlockStatus_Return();
    
    /* init for variable DiagcMgr_Srv_DiagcMgrLtchCntrAry_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable DiagcMgr_Srv_DiagcMgrLtchCntrAry_SetRamBlockStatus_Return */
    _main_gen_init_sym_DiagcMgr_Srv_DiagcMgrLtchCntrAry_SetRamBlockStatus_Return();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl0_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl0_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl1_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl1_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl2_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl2_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl3_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl3_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl4_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl4_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl5_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl5_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl6_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl6_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl7_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl7_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl8_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl8_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl9_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl9_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetDiagcDataAppl10_DiagcData */
    _main_gen_init_sym_DiagcMgr_Srv_GetDiagcDataAppl10_DiagcData();
    
    /* init for variable DiagcMgr_Srv_GetMcuDiagcSpplData_McuDiagcData1 */
    _main_gen_init_sym_DiagcMgr_Srv_GetMcuDiagcSpplData_McuDiagcData1();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl0_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl0_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl0_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl1_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl1_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl1_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl2_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl2_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl2_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl3_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl3_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl3_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl4_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl4_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl4_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl5_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl5_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl5_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl6_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl6_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl6_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl7_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl7_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl7_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl8_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl8_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl8_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl9_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl9_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl9_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl10_DebCntrIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcDebCntrAppl10_DebCntr */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcDebCntrAppl10_DebCntr();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl0_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl0_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl0_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl1_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl1_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl1_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl2_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl2_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl2_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl3_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl3_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl3_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl4_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl4_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl4_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl5_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl5_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl5_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl6_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl6_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl6_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl7_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl7_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl7_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl8_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl8_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl8_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl9_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl9_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl9_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl10_NtcInfoIdx : useless (never read) */

    /* init for variable DiagcMgr_Srv_GetNtcInfoAppl10_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Srv_GetNtcInfoAppl10_NtcInfo();
    
    /* init for variable DiagcMgr_Srv_SnpshtDataAry_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable DiagcMgr_Srv_SnpshtDataAry_SetRamBlockStatus_Return */
    _main_gen_init_sym_DiagcMgr_Srv_SnpshtDataAry_SetRamBlockStatus_Return();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_f32_SnpshtDataCnvd */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_f32_SnpshtDataCnvd();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_f32_SnpshtData */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_f32_SnpshtData();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_logl_SnpshtDataCnvd */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_logl_SnpshtDataCnvd();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_logl_SnpshtData */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_logl_SnpshtData();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_s08_SnpshtDataCnvd */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s08_SnpshtDataCnvd();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_s08_SnpshtData */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s08_SnpshtData();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_s16_SnpshtDataCnvd */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s16_SnpshtDataCnvd();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_s16_SnpshtData */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s16_SnpshtData();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_s32_SnpshtDataCnvd */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s32_SnpshtDataCnvd();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_s32_SnpshtData */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_s32_SnpshtData();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_u08_SnpshtDataCnvd */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_u08_SnpshtDataCnvd();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_u08_SnpshtData */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_u08_SnpshtData();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_u16_SnpshtDataCnvd */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_u16_SnpshtDataCnvd();
    
    /* init for variable DiagcMgr_Cli_CnvSnpshtData_u16_SnpshtData */
    _main_gen_init_sym_DiagcMgr_Cli_CnvSnpshtData_u16_SnpshtData();
    
    /* init for variable DiagcMgr_Cli_DiagcMgrIninCore_ApplIdx */
    _main_gen_init_sym_DiagcMgr_Cli_DiagcMgrIninCore_ApplIdx();
    
    /* init for variable DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoArySize */
    _main_gen_init_sym_DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoArySize();
    
    /* init for variable DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoAry */
    _main_gen_init_sym_DiagcMgr_Cli_DiagcMgrIninCore_NtcInfoAry();
    
    /* init for variable DiagcMgr_Cli_DiagcMgrIninCore_DiagcData */
    _main_gen_init_sym_DiagcMgr_Cli_DiagcMgrIninCore_DiagcData();
    
    /* init for variable DiagcMgr_Cli_DiagcMgrIninCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgr_Cli_DiagcMgrIninCore_ProxySetNtcData();
    
    /* init for variable DiagcMgr_Cli_GetNtcActvCore_NtcNr */
    _main_gen_init_sym_DiagcMgr_Cli_GetNtcActvCore_NtcNr();
    
    /* init for variable DiagcMgr_Cli_GetNtcActvCore_NtcActv */
    _main_gen_init_sym_DiagcMgr_Cli_GetNtcActvCore_NtcActv();
    
    /* init for variable DiagcMgr_Cli_GetNtcQlfrStsCore_NtcNr */
    _main_gen_init_sym_DiagcMgr_Cli_GetNtcQlfrStsCore_NtcNr();
    
    /* init for variable DiagcMgr_Cli_GetNtcQlfrStsCore_NtcQlfr */
    _main_gen_init_sym_DiagcMgr_Cli_GetNtcQlfrStsCore_NtcQlfr();
    
    /* init for variable DiagcMgr_Cli_GetNtcStsCore_NtcNr */
    _main_gen_init_sym_DiagcMgr_Cli_GetNtcStsCore_NtcNr();
    
    /* init for variable DiagcMgr_Cli_GetNtcStsCore_NtcInfoSts */
    _main_gen_init_sym_DiagcMgr_Cli_GetNtcStsCore_NtcInfoSts();
    
    /* init for variable DiagcMgr_Cli_ReadLtchCntrData_ReadLtchCntrAry */
    _main_gen_init_sym_DiagcMgr_Cli_ReadLtchCntrData_ReadLtchCntrAry();
    
    /* init for variable DiagcMgr_Cli_ReadNtcFltAry_DiagcMgrReadFltInfo */
    _main_gen_init_sym_DiagcMgr_Cli_ReadNtcFltAry_DiagcMgrReadFltInfo();
    
    /* init for variable DiagcMgr_Cli_ReadNtcInfoAndDebCntr_NtcNr */
    _main_gen_init_sym_DiagcMgr_Cli_ReadNtcInfoAndDebCntr_NtcNr();
    
    /* init for variable DiagcMgr_Cli_ReadNtcInfoAndDebCntr_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Cli_ReadNtcInfoAndDebCntr_NtcInfo();
    
    /* init for variable DiagcMgr_Cli_ReadNtcInfoAndDebCntr_DebCntr */
    _main_gen_init_sym_DiagcMgr_Cli_ReadNtcInfoAndDebCntr_DebCntr();
    
    /* init for variable DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry */
    _main_gen_init_sym_DiagcMgr_Cli_ReadSnpshtData_ReadSnpshtAry();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_NtcNr */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_NtcNr();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_NtcStInfo */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_NtcStInfo();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_NtcSts */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_NtcSts();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_DebStep */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_DebStep();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_DiagcData */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_DiagcData();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_ProxySetNtcData */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_ProxySetNtcData();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_NtcInfo */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_NtcInfo();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_NtcInfoDebCntr */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_NtcInfoDebCntr();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData0 */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData0();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData1 */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData1();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData2 */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtData2();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtDataPrsnt */
    _main_gen_init_sym_DiagcMgr_Cli_SetNtcStsCore_SpclSnpshtDataPrsnt();
    
    /* init for variable DiagcMgr_Cli_SetNtcStsCore_Return : useless (never read) */

    /* init for variable DiagcMgr_Cli_UpdDtcEnaCdn_DtcEnaCdnSts */
    _main_gen_init_sym_DiagcMgr_Cli_UpdDtcEnaCdn_DtcEnaCdnSts();
    
    /* init for variable DiagcMgr_Cli_UpdDtcEnaCdn_DtcEnaCdnId */
    _main_gen_init_sym_DiagcMgr_Cli_UpdDtcEnaCdn_DtcEnaCdnId();
    
}
