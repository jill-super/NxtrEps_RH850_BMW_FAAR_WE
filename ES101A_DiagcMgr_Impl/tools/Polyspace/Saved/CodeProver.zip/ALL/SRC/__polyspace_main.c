#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function Rte_DiagcMgrProxyAppl0_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl0_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl0_Stub();
        }
        
        /* call of function Rte_DiagcMgrProxyAppl10_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl10_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl10_Stub();
        }
        
        /* call of function Rte_DiagcMgrProxyAppl1_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl1_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl1_Stub();
        }
        
        /* call of function Rte_DiagcMgrProxyAppl2_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl2_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl2_Stub();
        }
        
        /* call of function Rte_DiagcMgrProxyAppl3_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl3_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl3_Stub();
        }
        
        /* call of function Rte_DiagcMgrProxyAppl4_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl4_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl4_Stub();
        }
        
        /* call of function Rte_DiagcMgrProxyAppl5_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl5_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl5_Stub();
        }
        
        /* call of function Rte_DiagcMgrProxyAppl6_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl6_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl6_Stub();
        }
        
        /* call of function Rte_DiagcMgrProxyAppl7_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl7_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl7_Stub();
        }
        
        /* call of function Rte_DiagcMgrProxyAppl8_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl8_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl8_Stub();
        }
        
        /* call of function Rte_DiagcMgrProxyAppl9_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrProxyAppl9_Stub(__PST__VOID);

            Rte_DiagcMgrProxyAppl9_Stub();
        }
        
        /* call of function Rte_DiagcMgrStub_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgrStub_Stub(__PST__VOID);

            Rte_DiagcMgrStub_Stub();
        }
        
        /* call of function Rte_DiagcMgr_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_DiagcMgr_Stub(__PST__VOID);

            Rte_DiagcMgr_Stub();
        }
        
    }
}
