#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__883 _main_gen_init_g883(void);

extern union __PST__g__882 _main_gen_init_g882(void);

extern struct __PST__g__881 _main_gen_init_g881(void);

extern union __PST__g__880 _main_gen_init_g880(void);

extern __PST__g__878 _main_gen_init_g878(void);

extern union __PST__g__851 _main_gen_init_g851(void);

extern union __PST__g__847 _main_gen_init_g847(void);

extern __PST__g__831 _main_gen_init_g831(void);

extern union __PST__g__821 _main_gen_init_g821(void);

extern __PST__g__814 _main_gen_init_g814(void);

extern __PST__g__804 _main_gen_init_g804(void);

extern union __PST__g__762 _main_gen_init_g762(void);

extern __PST__g__547 _main_gen_init_g547(void);

extern __PST__g__545 _main_gen_init_g545(void);

extern __PST__g__543 _main_gen_init_g543(void);

extern __PST__g__541 _main_gen_init_g541(void);

extern __PST__g__525 _main_gen_init_g525(void);

extern union __PST__g__523 _main_gen_init_g523(void);

extern __PST__g__521 _main_gen_init_g521(void);

extern union __PST__g__514 _main_gen_init_g514(void);

extern __PST__g__512 _main_gen_init_g512(void);

extern union __PST__g__489 _main_gen_init_g489(void);

extern union __PST__g__479 _main_gen_init_g479(void);

extern __PST__g__451 _main_gen_init_g451(void);

extern union __PST__g__269 _main_gen_init_g269(void);

extern union __PST__g__119 _main_gen_init_g119(void);

extern __PST__g__105 _main_gen_init_g105(void);

extern union __PST__g__81 _main_gen_init_g81(void);

extern union __PST__g__78 _main_gen_init_g78(void);

extern union __PST__g__75 _main_gen_init_g75(void);

extern __PST__g__73 _main_gen_init_g73(void);

extern union __PST__g__63 _main_gen_init_g63(void);

extern union __PST__g__61 _main_gen_init_g61(void);

extern union __PST__g__58 _main_gen_init_g58(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__54 _main_gen_init_g54(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__50 _main_gen_init_g50(void);

extern __PST__g__48 _main_gen_init_g48(void);

extern union __PST__g__45 _main_gen_init_g45(void);

extern union __PST__g__43 _main_gen_init_g43(void);

extern union __PST__g__40 _main_gen_init_g40(void);

extern union __PST__g__38 _main_gen_init_g38(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern union __PST__g__34 _main_gen_init_g34(void);

extern __PST__g__23 _main_gen_init_g23(void);

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

union __PST__g__34 _main_gen_init_g34(void)
{
    static union __PST__g__34 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__38 _main_gen_init_g38(void)
{
    static union __PST__g__38 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__40 _main_gen_init_g40(void)
{
    static union __PST__g__40 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__43 _main_gen_init_g43(void)
{
    static union __PST__g__43 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

union __PST__g__45 _main_gen_init_g45(void)
{
    static union __PST__g__45 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__23 _main_gen_init_g23(void)
{
    __PST__g__23 x;
    /* struct/union type */
    x.ENUM = _main_gen_init_g34();
    x.PMTUM0 = _main_gen_init_g38();
    x.PMTUM2 = _main_gen_init_g40();
    x.PMTUM3 = _main_gen_init_g43();
    x.PMTUM4 = _main_gen_init_g45();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__50 _main_gen_init_g50(void)
{
    static union __PST__g__50 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

union __PST__g__54 _main_gen_init_g54(void)
{
    static union __PST__g__54 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__58 _main_gen_init_g58(void)
{
    static union __PST__g__58 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__61 _main_gen_init_g61(void)
{
    static union __PST__g__61 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__63 _main_gen_init_g63(void)
{
    static union __PST__g__63 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__48 _main_gen_init_g48(void)
{
    __PST__g__48 x;
    /* struct/union type */
    x.SP = _main_gen_init_g50();
    x.G0MK = _main_gen_init_g54();
    x.G0BA = _main_gen_init_g58();
    x.G1MK = _main_gen_init_g61();
    x.G1BA = _main_gen_init_g63();
    return x;
}

union __PST__g__75 _main_gen_init_g75(void)
{
    static union __PST__g__75 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__78 _main_gen_init_g78(void)
{
    static union __PST__g__78 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__81 _main_gen_init_g81(void)
{
    static union __PST__g__81 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__73 _main_gen_init_g73(void)
{
    __PST__g__73 x;
    /* struct/union type */
    x.FSGD3ADPROT0 = _main_gen_init_g75();
    x.FSGD3ADPROT1 = _main_gen_init_g75();
    x.FSGD3ADPROT2 = _main_gen_init_g75();
    x.FSGD3ADPROT3 = _main_gen_init_g75();
    x.FSGD3ADPROT4 = _main_gen_init_g75();
    x.FSGD3ADPROT5 = _main_gen_init_g75();
    x.FSGD3ADPROT6 = _main_gen_init_g75();
    x.FSGD3ADPROT7 = _main_gen_init_g75();
    x.FSGD3ADPROT8 = _main_gen_init_g75();
    x.FSGD3ADPROT9 = _main_gen_init_g75();
    x.FSGD3ADPROT10 = _main_gen_init_g75();
    x.FSGD3ADPROT11 = _main_gen_init_g75();
    x.ERRSLV3ACTL = _main_gen_init_g78();
    x.ERRSLV3ASTAT = _main_gen_init_g81();
    x.FSGD0ADPROT0 = _main_gen_init_g75();
    x.FSGD0ADPROT1 = _main_gen_init_g75();
    x.FSGD1ADPROT0 = _main_gen_init_g75();
    x.FSGD1ADPROT1 = _main_gen_init_g75();
    x.FSGD1ADPROT2 = _main_gen_init_g75();
    x.FSGD1ADPROT3 = _main_gen_init_g75();
    x.FSGD1ADPROT4 = _main_gen_init_g75();
    x.FSGD1ADPROT5 = _main_gen_init_g75();
    x.FSGD1ADPROT6 = _main_gen_init_g75();
    x.FSGD1ADPROT7 = _main_gen_init_g75();
    x.FSGD1ADPROT8 = _main_gen_init_g75();
    x.FSGD1ADPROT9 = _main_gen_init_g75();
    x.FSGD1ADPROT10 = _main_gen_init_g75();
    x.FSGD1ADPROT11 = _main_gen_init_g75();
    x.FSGD1ADPROT12 = _main_gen_init_g75();
    x.FSGD1ADPROT13 = _main_gen_init_g75();
    x.FSGD1ADPROT14 = _main_gen_init_g75();
    x.FSGD1BDPROT0 = _main_gen_init_g75();
    x.FSGD1BDPROT1 = _main_gen_init_g75();
    x.FSGD1BDPROT2 = _main_gen_init_g75();
    x.FSGD1BDPROT3 = _main_gen_init_g75();
    x.FSGD1BDPROT4 = _main_gen_init_g75();
    x.FSGD1BDPROT5 = _main_gen_init_g75();
    x.FSGD1BDPROT6 = _main_gen_init_g75();
    x.FSGD1BDPROT7 = _main_gen_init_g75();
    x.FSGD1BDPROT8 = _main_gen_init_g75();
    x.FSGD1BDPROT9 = _main_gen_init_g75();
    x.FSGD1BDPROT10 = _main_gen_init_g75();
    x.FSGD1BDPROT11 = _main_gen_init_g75();
    x.FSGD1BDPROT12 = _main_gen_init_g75();
    x.FSGD1BDPROT13 = _main_gen_init_g75();
    x.FSGD1BDPROT14 = _main_gen_init_g75();
    x.FSGD5ADPROT0 = _main_gen_init_g75();
    x.FSGD2ADPROT0 = _main_gen_init_g75();
    x.FSGD2ADPROT1 = _main_gen_init_g75();
    x.FSGD2ADPROT2 = _main_gen_init_g75();
    x.FSGD2ADPROT3 = _main_gen_init_g75();
    x.FSGD2ADPROT4 = _main_gen_init_g75();
    x.FSGD2ADPROT5 = _main_gen_init_g75();
    x.FSGD2ADPROT6 = _main_gen_init_g75();
    x.FSGD2ADPROT7 = _main_gen_init_g75();
    x.FSGD2ADPROT8 = _main_gen_init_g75();
    x.FSGD2ADPROT9 = _main_gen_init_g75();
    x.FSGD2ADPROT10 = _main_gen_init_g75();
    x.FSGD2ADPROT11 = _main_gen_init_g75();
    x.FSGD2ADPROT12 = _main_gen_init_g75();
    x.FSGD2ADPROT13 = _main_gen_init_g75();
    x.FSGD2ADPROT14 = _main_gen_init_g75();
    x.FSGD2ADPROT15 = _main_gen_init_g75();
    return x;
}

union __PST__g__119 _main_gen_init_g119(void)
{
    static union __PST__g__119 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__269 _main_gen_init_g269(void)
{
    static union __PST__g__269 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__105 _main_gen_init_g105(void)
{
    __PST__g__105 x;
    /* struct/union type */
    x.PMC0 = _main_gen_init_g119();
    x.PCR0_0 = _main_gen_init_g269();
    return x;
}

union __PST__g__479 _main_gen_init_g479(void)
{
    static union __PST__g__479 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__489 _main_gen_init_g489(void)
{
    static union __PST__g__489 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__451 _main_gen_init_g451(void)
{
    __PST__g__451 x;
    /* struct/union type */
    x.JPCR0_0 = _main_gen_init_g479();
    x.JPIBC0 = _main_gen_init_g489();
    return x;
}

union __PST__g__514 _main_gen_init_g514(void)
{
    static union __PST__g__514 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__512 _main_gen_init_g512(void)
{
    __PST__g__512 x;
    /* struct/union type */
    x.CTL = _main_gen_init_g514();
    return x;
}

union __PST__g__523 _main_gen_init_g523(void)
{
    static union __PST__g__523 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__521 _main_gen_init_g521(void)
{
    __PST__g__521 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g523();
    return x;
}

__PST__g__525 _main_gen_init_g525(void)
{
    __PST__g__525 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g523();
    return x;
}

__PST__g__541 _main_gen_init_g541(void)
{
    __PST__g__541 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g523();
    return x;
}

__PST__g__543 _main_gen_init_g543(void)
{
    __PST__g__543 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g523();
    return x;
}

__PST__g__545 _main_gen_init_g545(void)
{
    __PST__g__545 x;
    /* struct/union type */
    x.CTL0 = _main_gen_init_g523();
    return x;
}

union __PST__g__762 _main_gen_init_g762(void)
{
    static union __PST__g__762 x;
    /* struct/union type */
    x.UINT8 = _main_gen_init_g6();
    return x;
}

__PST__g__547 _main_gen_init_g547(void)
{
    __PST__g__547 x;
    /* struct/union type */
    x.THACR = _main_gen_init_g762();
    return x;
}

__PST__g__804 _main_gen_init_g804(void)
{
    __PST__g__804 x;
    /* struct/union type */
    x.THACR = _main_gen_init_g762();
    return x;
}

union __PST__g__821 _main_gen_init_g821(void)
{
    static union __PST__g__821 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__814 _main_gen_init_g814(void)
{
    __PST__g__814 x;
    /* struct/union type */
    x.ESSTR0 = _main_gen_init_g821();
    return x;
}

union __PST__g__847 _main_gen_init_g847(void)
{
    static union __PST__g__847 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__851 _main_gen_init_g851(void)
{
    static union __PST__g__851 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__831 _main_gen_init_g831(void)
{
    __PST__g__831 x;
    /* struct/union type */
    x.EMK0 = _main_gen_init_g847();
    x.ESSTC0 = _main_gen_init_g851();
    return x;
}

struct __PST__g__881 _main_gen_init_g881(void)
{
    static struct __PST__g__881 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.VCIE = bitf;
    }
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.VPGE = bitf;
    }
    return x;
}

union __PST__g__880 _main_gen_init_g880(void)
{
    static union __PST__g__880 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g881();
    x.UINT16 = _main_gen_init_g7();
    return x;
}

struct __PST__g__883 _main_gen_init_g883(void)
{
    static struct __PST__g__883 x;
    /* struct/union type */
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.VCIF = bitf;
    }
    {
        __PST__UINT16 bitf;
        bitf = _main_gen_init_g7();
        unchecked_assert(bitf <= 1);
        x.VPGF = bitf;
    }
    return x;
}

union __PST__g__882 _main_gen_init_g882(void)
{
    static union __PST__g__882 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g883();
    return x;
}

__PST__g__878 _main_gen_init_g878(void)
{
    __PST__g__878 x;
    /* struct/union type */
    x.CONT = _main_gen_init_g880();
    x.FLAG = _main_gen_init_g882();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_IPG(void)
{
    extern __PST__g__23 IPG;
    
    /* initialization with random value */
    {
        IPG = _main_gen_init_g23();
    }
}

static void _main_gen_init_sym_PEG(void)
{
    extern __PST__g__48 PEG;
    
    /* initialization with random value */
    {
        PEG = _main_gen_init_g48();
    }
}

static void _main_gen_init_sym_PBG(void)
{
    extern __PST__g__73 PBG;
    
    /* initialization with random value */
    {
        PBG = _main_gen_init_g73();
    }
}

static void _main_gen_init_sym_PORT(void)
{
    extern __PST__g__105 PORT;
    
    /* initialization with random value */
    {
        PORT = _main_gen_init_g105();
    }
}

static void _main_gen_init_sym_PORTJ(void)
{
    extern __PST__g__451 PORTJ;
    
    /* initialization with random value */
    {
        PORTJ = _main_gen_init_g451();
    }
}

static void _main_gen_init_sym_DNFA0(void)
{
    extern __PST__g__512 DNFA0;
    
    /* initialization with random value */
    {
        DNFA0 = _main_gen_init_g512();
    }
}

static void _main_gen_init_sym_FCLA0(void)
{
    extern __PST__g__521 FCLA0;
    
    /* initialization with random value */
    {
        FCLA0 = _main_gen_init_g521();
    }
}

static void _main_gen_init_sym_FCLA1(void)
{
    extern __PST__g__525 FCLA1;
    
    /* initialization with random value */
    {
        FCLA1 = _main_gen_init_g525();
    }
}

static void _main_gen_init_sym_FCLA2(void)
{
    extern __PST__g__541 FCLA2;
    
    /* initialization with random value */
    {
        FCLA2 = _main_gen_init_g541();
    }
}

static void _main_gen_init_sym_FCLA3(void)
{
    extern __PST__g__543 FCLA3;
    
    /* initialization with random value */
    {
        FCLA3 = _main_gen_init_g543();
    }
}

static void _main_gen_init_sym_FCLA4(void)
{
    extern __PST__g__545 FCLA4;
    
    /* initialization with random value */
    {
        FCLA4 = _main_gen_init_g545();
    }
}

static void _main_gen_init_sym_ADCD0(void)
{
    extern __PST__g__547 ADCD0;
    
    /* initialization with random value */
    {
        ADCD0 = _main_gen_init_g547();
    }
}

static void _main_gen_init_sym_ADCD1(void)
{
    extern __PST__g__804 ADCD1;
    
    /* initialization with random value */
    {
        ADCD1 = _main_gen_init_g804();
    }
}

static void _main_gen_init_sym_ECMM(void)
{
    extern __PST__g__814 ECMM;
    
    /* initialization with random value */
    {
        ECMM = _main_gen_init_g814();
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__831 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g831();
    }
}

static void _main_gen_init_sym_SEG(void)
{
    extern __PST__g__878 SEG;
    
    /* initialization with random value */
    {
        SEG = _main_gen_init_g878();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable IPG */
    _main_gen_init_sym_IPG();
    
    /* init for variable PEG */
    _main_gen_init_sym_PEG();
    
    /* init for variable PBG */
    _main_gen_init_sym_PBG();
    
    /* init for variable PORT */
    _main_gen_init_sym_PORT();
    
    /* init for variable PORTJ */
    _main_gen_init_sym_PORTJ();
    
    /* init for variable DNFA0 */
    _main_gen_init_sym_DNFA0();
    
    /* init for variable FCLA0 */
    _main_gen_init_sym_FCLA0();
    
    /* init for variable FCLA1 */
    _main_gen_init_sym_FCLA1();
    
    /* init for variable FCLA2 */
    _main_gen_init_sym_FCLA2();
    
    /* init for variable FCLA3 */
    _main_gen_init_sym_FCLA3();
    
    /* init for variable FCLA4 */
    _main_gen_init_sym_FCLA4();
    
    /* init for variable ADCD0 */
    _main_gen_init_sym_ADCD0();
    
    /* init for variable ADCD1 */
    _main_gen_init_sym_ADCD1();
    
    /* init for variable ECMM */
    _main_gen_init_sym_ECMM();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable SEG */
    _main_gen_init_sym_SEG();
    
}
