/*
 *
 * This file and its contents are the property of The MathWorks, Inc.
 * 
 * This file contains confidential proprietary information.
 * The reproduction, distribution, utilization or the communication
 * of this file or any part thereof is strictly prohibited.
 * Offenders will be held liable for the payment of damages.
 *
 * Copyright 1999-2011 The MathWorks, Inc.
 *
 */
 
// Here is the list of functions which may need to be stubbed.
// 
// Here's how the stubber works: 
// 
// For each function in the list below, if you don't do anything
// it'll take the worst possible case, which is that the function 
// writes through the arguments as if they were pointers (even
// pointers cast to int).  
//
// External functions are assumed to not store their arguments
// in static / global data.
//
// External functions are also assumed to have no effect (read,
// write) on global variables.
//
// Any external functions which do not respect these two assumptions
// will need to be stubbed explicitely.
// 
// Here's an example:   int f(int)
// In the worst case, the stubber will assume that the function
// may behave something like this: 
// 
// 
//      int f(char *x)
//      {
//         strcpy(x, "the quick brown fox, etc.");
//
//         return &(x[2]);
//      }
// 
// This has a bad effect on both the analysis time, and on the
// the resulting selectivity rate.
// 
// 
// However, if you know that the function is in fact very tame,
// like this:
//      int f(char *x)
//      {
//        return strlen(x);
//      }
// 
// The stubber can provide a stub which will reflect this, and 
// have both fast analysis time and high selectivity.
// 
// I've provided below the pragma directives recognized by the
// verifier. All you need to to do is remove the initial //
// to activate the pragmas which are appropriate.
// 
// The NO_WRITE pragma indicates that the function does not
// write to or through its arguments.
// 
// The NO ESCAPE pragma indicates that the function does not
// allow access to the argument to escape through
// the return value.
// 
// In the first example above, neither pragmas apply.
// In the second example above, both pragmas apply.
//


#include "pst_user_stubs.h"


// Pragmas for function Rte_Read_BmwMsgSlot68Bas0Repn2BusFrChA_FltCodEnad_Logl
//
// #pragma POLYSPACE_PURE "Rte_Read_BmwMsgSlot68Bas0Repn2BusFrChA_FltCodEnad_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Read_BmwMsgSlot68Bas0Repn2BusFrChA_FltCodEnad_Logl"
// #pragma POLYSPACE_WORST "Rte_Read_BmwMsgSlot68Bas0Repn2BusFrChA_FltCodEnad_Logl"
//
// __PST__UINT8 Rte_Read_BmwMsgSlot68Bas0Repn2BusFrChA_FltCodEnad_Logl(__PST__g__27 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynDampgFacReq_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynDampgFacReq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynDampgFacReq_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynDampgFacReq_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynDampgFacReq_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEffortFacReq_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEffortFacReq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEffortFacReq_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEffortFacReq_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEffortFacReq_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEnaRqst_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEnaRqst_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEnaRqst_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEnaRqst_Logl"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEnaRqst_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynErrIfActv_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynErrIfActv_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynErrIfActv_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynErrIfActv_Logl"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynErrIfActv_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfr_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfr_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfr_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfr_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfrVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfrVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfrVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfrVld_Logl"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfrVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynRtnFacReq_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynRtnFacReq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynRtnFacReq_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynRtnFacReq_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynRtnFacReq_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwEpsDeactvnCtrl_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwEpsDeactvnCtrl_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwEpsDeactvnCtrl_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwEpsDeactvnCtrl_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwEpsDeactvnCtrl_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrl_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrl_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrl_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrl_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrl_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfr_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfr_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfr_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfr_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfrVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfrVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfrVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfrVld_Logl"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfrVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActr_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActr_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActr_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActr_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfr_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfr_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfr_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfr_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfr_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfrVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfrVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfrVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfrVld_Logl"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfrVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReq_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReq_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReq_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReq_Val(__PST__FLOAT32 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReqVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReqVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReqVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReqVld_Logl"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReqVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReq_Val
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReq_Val"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReq_Val"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReq_Val"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReq_Val(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReqVld_Logl
//
// #pragma POLYSPACE_PURE "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReqVld_Logl"
// #pragma POLYSPACE_CLEAN "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReqVld_Logl"
// #pragma POLYSPACE_WORST "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReqVld_Logl"
//
// __PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReqVld_Logl(__PST__UINT8 P_0)
// {
//    ...
// }


// Pragmas for function Rte_Call_BmwMsgSlot68Bas0Repn2BusFrChA_SetNtcSts_Oper
//
// #pragma POLYSPACE_PURE "Rte_Call_BmwMsgSlot68Bas0Repn2BusFrChA_SetNtcSts_Oper"
// #pragma POLYSPACE_CLEAN "Rte_Call_BmwMsgSlot68Bas0Repn2BusFrChA_SetNtcSts_Oper"
// #pragma POLYSPACE_WORST "Rte_Call_BmwMsgSlot68Bas0Repn2BusFrChA_SetNtcSts_Oper"
//
// __PST__UINT8 Rte_Call_BmwMsgSlot68Bas0Repn2BusFrChA_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
// {
//    ...
// }


// Pragmas for function Rte_Prm_BmwMsgSlot68Bas0Repn2BusFrChA_BmwMsgSlot108Bas0Repn2BusFrChABmwSteerPolarity_Val
//
// #pragma POLYSPACE_PURE "Rte_Prm_BmwMsgSlot68Bas0Repn2BusFrChA_BmwMsgSlot108Bas0Repn2BusFrChABmwSteerPolarity_Val"
// #pragma POLYSPACE_CLEAN "Rte_Prm_BmwMsgSlot68Bas0Repn2BusFrChA_BmwMsgSlot108Bas0Repn2BusFrChABmwSteerPolarity_Val"
// #pragma POLYSPACE_WORST "Rte_Prm_BmwMsgSlot68Bas0Repn2BusFrChA_BmwMsgSlot108Bas0Repn2BusFrChABmwSteerPolarity_Val"
//
// __PST__SINT8 Rte_Prm_BmwMsgSlot68Bas0Repn2BusFrChA_BmwMsgSlot108Bas0Repn2BusFrChABmwSteerPolarity_Val(__PST__VOID)
// {
//    ...
// }


// Pragmas for function E2EPW_Read_sigGroup_TAR_QTA_STRMOM_DV_sigGroup_TAR_QTA_STRMOM_DV
//
// #pragma POLYSPACE_PURE "E2EPW_Read_sigGroup_TAR_QTA_STRMOM_DV_sigGroup_TAR_QTA_STRMOM_DV"
// #pragma POLYSPACE_CLEAN "E2EPW_Read_sigGroup_TAR_QTA_STRMOM_DV_sigGroup_TAR_QTA_STRMOM_DV"
// #pragma POLYSPACE_WORST "E2EPW_Read_sigGroup_TAR_QTA_STRMOM_DV_sigGroup_TAR_QTA_STRMOM_DV"
//
// __PST__UINT32 E2EPW_Read_sigGroup_TAR_QTA_STRMOM_DV_sigGroup_TAR_QTA_STRMOM_DV(__PST__g__35 P_0)
// {
//    ...
// }


// Pragmas for function E2EPW_Read_sigGroup_TAR_STMOM_DV_ACT_sigGroup_TAR_STMOM_DV_ACT
//
// #pragma POLYSPACE_PURE "E2EPW_Read_sigGroup_TAR_STMOM_DV_ACT_sigGroup_TAR_STMOM_DV_ACT"
// #pragma POLYSPACE_CLEAN "E2EPW_Read_sigGroup_TAR_STMOM_DV_ACT_sigGroup_TAR_STMOM_DV_ACT"
// #pragma POLYSPACE_WORST "E2EPW_Read_sigGroup_TAR_STMOM_DV_ACT_sigGroup_TAR_STMOM_DV_ACT"
//
// __PST__UINT32 E2EPW_Read_sigGroup_TAR_STMOM_DV_ACT_sigGroup_TAR_STMOM_DV_ACT(__PST__g__39 P_0)
// {
//    ...
// }

