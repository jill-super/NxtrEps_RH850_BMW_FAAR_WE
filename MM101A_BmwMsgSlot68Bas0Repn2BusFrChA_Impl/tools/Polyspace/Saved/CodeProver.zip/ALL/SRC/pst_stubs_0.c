#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */


/* Definition of variables init procedures */


/* Definition of functions */

/*
 * Rte_Read_BmwMsgSlot68Bas0Repn2BusFrChA_FltCodEnad_Logl
 */


__PST__UINT8 Rte_Read_BmwMsgSlot68Bas0Repn2BusFrChA_FltCodEnad_Logl(__PST__g__27 P_0)
{
    /* parameter 0 */

    if (P_0 != 0)
    if (pst_random_int)
    {
        while (pst_random_int)
        {
            P_0[pst_random_int] = pst_random_g_6;
        }
        P_0[0] = pst_random_g_6;
    }

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynDampgFacReq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynDampgFacReq_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynDampgFacReq_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEffortFacReq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEffortFacReq_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEffortFacReq_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEnaRqst_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEnaRqst_Logl"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynEnaRqst_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynErrIfActv_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynErrIfActv_Logl"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynErrIfActv_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfr_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfr_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfr_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfrVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfrVld_Logl"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynFacQlfrVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynRtnFacReq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynRtnFacReq_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwDrvgDynRtnFacReq_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwEpsDeactvnCtrl_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwEpsDeactvnCtrl_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwEpsDeactvnCtrl_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrl_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrl_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrl_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfr_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfr_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfr_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfrVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfrVld_Logl"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarHwTqOvrlQlfrVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActr_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActr_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActr_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfr_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfr_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfr_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfrVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfrVld_Logl"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTarSteerTqDrvrActrQlfrVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReq_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReq_Val(__PST__FLOAT32 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReqVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReqVld_Logl"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgScaReqVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReq_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReq_Val"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReq_Val(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReqVld_Logl
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReqVld_Logl"


__PST__UINT8 Rte_Write_BmwMsgSlot68Bas0Repn2BusFrChA_BmwTrfcJamAssiDampgStReqVld_Logl(__PST__UINT8 P_0)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Call_BmwMsgSlot68Bas0Repn2BusFrChA_SetNtcSts_Oper
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Call_BmwMsgSlot68Bas0Repn2BusFrChA_SetNtcSts_Oper"


__PST__UINT8 Rte_Call_BmwMsgSlot68Bas0Repn2BusFrChA_SetNtcSts_Oper(__PST__UINT16 P_0, __PST__UINT8 P_1, __PST__UINT8 P_2, __PST__UINT16 P_3)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__UINT8 real_random_for_return  = 0;
        __PST__UINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * Rte_Prm_BmwMsgSlot68Bas0Repn2BusFrChA_BmwMsgSlot108Bas0Repn2BusFrChABmwSteerPolarity_Val
 */

#pragma POLYSPACE_POLYMORPHIC "Rte_Prm_BmwMsgSlot68Bas0Repn2BusFrChA_BmwMsgSlot108Bas0Repn2BusFrChABmwSteerPolarity_Val"


__PST__SINT8 Rte_Prm_BmwMsgSlot68Bas0Repn2BusFrChA_BmwMsgSlot108Bas0Repn2BusFrChABmwSteerPolarity_Val(__PST__VOID)
{
    /* function is pure */

    /* random return value */

    {
        volatile __PST__SINT8 real_random_for_return  = 0;
        __PST__SINT8 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * E2EPW_Read_sigGroup_TAR_QTA_STRMOM_DV_sigGroup_TAR_QTA_STRMOM_DV
 */


__PST__UINT32 E2EPW_Read_sigGroup_TAR_QTA_STRMOM_DV_sigGroup_TAR_QTA_STRMOM_DV(__PST__g__35 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}

/*
 * E2EPW_Read_sigGroup_TAR_STMOM_DV_ACT_sigGroup_TAR_STMOM_DV_ACT
 */


__PST__UINT32 E2EPW_Read_sigGroup_TAR_STMOM_DV_ACT_sigGroup_TAR_STMOM_DV_ACT(__PST__g__39 P_0)
{
    /* parameter 0 */

    {
        __PST__CHAR *p_addr = (__PST__CHAR *)&P_0;
        while (pst_random_int)
        {
            p_addr += pst_random_int;
            if (pst_random_int)
            {
                p_addr = *(__PST__CHAR **)p_addr;
            }
            *p_addr = (__PST__CHAR)pst_random_char;
        }
    }

    /* random return value */

    {
        volatile __PST__UINT32 real_random_for_return  = 0;
        __PST__UINT32 random_for_return = real_random_for_return;
        return random_for_return;
    }
}



/*
 * main entry point
 */

void __PST__MAIN__ENTRY__POINT__(void)
{
    { /* call of function main */
        __PST__VOID main(__PST__VOID);        
        
        main();
    }
    
}

