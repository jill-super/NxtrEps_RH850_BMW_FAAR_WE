#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__FLOAT32 pst_random_g_10;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__FLOAT32 _main_gen_init_g10(void);

extern struct Rte_CDS_BmwMsgSlot68Bas0Repn2BusFrChA _main_gen_init_g25(void);

__PST__FLOAT32 _main_gen_init_g10(void)
{
    __PST__FLOAT32 x;
    /* base type */
    x = pst_random_g_10;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct Rte_CDS_BmwMsgSlot68Bas0Repn2BusFrChA _main_gen_init_g25(void)
{
    static struct Rte_CDS_BmwMsgSlot68Bas0Repn2BusFrChA x;
    /* struct/union type */
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_2[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g10();
        }
        x.Pim_BmwDrvgDynDampgFacReqPrev = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g6();
        }
        x.Pim_BmwDrvgDynDampgFacReqVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_6[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g10();
        }
        x.Pim_BmwDrvgDynEffortFacReqPrev = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g6();
        }
        x.Pim_BmwDrvgDynEffortFacReqVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g6();
        }
        x.Pim_BmwDrvgDynEnaReqPrev = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g6();
        }
        x.Pim_BmwDrvgDynErrIfActvPrev = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g6();
        }
        x.Pim_BmwDrvgDynFacQlfrPrev = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g6();
        }
        x.Pim_BmwDrvgDynFacQlfrVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_18[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g10();
        }
        x.Pim_BmwDrvgDynRtnFacReqPrev = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g6();
        }
        x.Pim_BmwDrvgDynRtnFacReqVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g6();
        }
        x.Pim_BmwEpsDeactvnCtrlPrev = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g6();
        }
        x.Pim_BmwEpsDeactvnCtrlVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_26[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g10();
        }
        x.Pim_BmwTarHwTqOvrlPrev = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g6();
        }
        x.Pim_BmwTarHwTqOvrlQlfPrev = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g6();
        }
        x.Pim_BmwTarHwTqOvrlQlfrVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g6();
        }
        x.Pim_BmwTarHwTqOvrlVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_34[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g10();
        }
        x.Pim_BmwTarSteerTqDrvrActrPrev = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_37;
        for (_i_main_gen_tmp_37 = 0; _i_main_gen_tmp_37 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_37++)
        {
            _main_gen_tmp_36[_i_main_gen_tmp_37] = _main_gen_init_g6();
        }
        x.Pim_BmwTarSteerTqDrvrActrQlfrPrev = PST_TRUE() ? 0 : &_main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_38[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_39;
        for (_i_main_gen_tmp_39 = 0; _i_main_gen_tmp_39 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_39++)
        {
            _main_gen_tmp_38[_i_main_gen_tmp_39] = _main_gen_init_g6();
        }
        x.Pim_BmwTarSteerTqDrvrActrQlfrVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_38[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_41;
        for (_i_main_gen_tmp_41 = 0; _i_main_gen_tmp_41 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_41++)
        {
            _main_gen_tmp_40[_i_main_gen_tmp_41] = _main_gen_init_g6();
        }
        x.Pim_BmwTarSteerTqDrvrActrVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__FLOAT32 _main_gen_tmp_42[ARRAY_NBELEM(__PST__FLOAT32)];
        __PST__UINT32 _i_main_gen_tmp_43;
        for (_i_main_gen_tmp_43 = 0; _i_main_gen_tmp_43 < ARRAY_NBELEM(__PST__FLOAT32); _i_main_gen_tmp_43++)
        {
            _main_gen_tmp_42[_i_main_gen_tmp_43] = _main_gen_init_g10();
        }
        x.Pim_BmwTrfcJamAssiDampgScaReqPrev = PST_TRUE() ? 0 : &_main_gen_tmp_42[ARRAY_NBELEM(__PST__FLOAT32) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_45;
        for (_i_main_gen_tmp_45 = 0; _i_main_gen_tmp_45 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_45++)
        {
            _main_gen_tmp_44[_i_main_gen_tmp_45] = _main_gen_init_g6();
        }
        x.Pim_BmwTrfcJamAssiDampgScaReqVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_46[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_47;
        for (_i_main_gen_tmp_47 = 0; _i_main_gen_tmp_47 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_47++)
        {
            _main_gen_tmp_46[_i_main_gen_tmp_47] = _main_gen_init_g6();
        }
        x.Pim_BmwTrfcJamAssiDampgStReqPrev = PST_TRUE() ? 0 : &_main_gen_tmp_46[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_48[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_49;
        for (_i_main_gen_tmp_49 = 0; _i_main_gen_tmp_49 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_49++)
        {
            _main_gen_tmp_48[_i_main_gen_tmp_49] = _main_gen_init_g6();
        }
        x.Pim_BmwTrfcJamAssiDampgStReqVldPrev = PST_TRUE() ? 0 : &_main_gen_tmp_48[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_50[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_51;
        for (_i_main_gen_tmp_51 = 0; _i_main_gen_tmp_51 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_51++)
        {
            _main_gen_tmp_50[_i_main_gen_tmp_51] = _main_gen_init_g6();
        }
        x.Pim_CtrDeacEpsFnsFaild = PST_TRUE() ? 0 : &_main_gen_tmp_50[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_52[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_53;
        for (_i_main_gen_tmp_53 = 0; _i_main_gen_tmp_53 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_53++)
        {
            _main_gen_tmp_52[_i_main_gen_tmp_53] = _main_gen_init_g6();
        }
        x.Pim_CtrDeacEpsFnsPassd = PST_TRUE() ? 0 : &_main_gen_tmp_52[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_54[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_55;
        for (_i_main_gen_tmp_55 = 0; _i_main_gen_tmp_55 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_55++)
        {
            _main_gen_tmp_54[_i_main_gen_tmp_55] = _main_gen_init_g6();
        }
        x.Pim_FactAssStmomFtaxFaild = PST_TRUE() ? 0 : &_main_gen_tmp_54[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_56[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_57;
        for (_i_main_gen_tmp_57 = 0; _i_main_gen_tmp_57 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_57++)
        {
            _main_gen_tmp_56[_i_main_gen_tmp_57] = _main_gen_init_g6();
        }
        x.Pim_FactAssStmomFtaxPassd = PST_TRUE() ? 0 : &_main_gen_tmp_56[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_58[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_59;
        for (_i_main_gen_tmp_59 = 0; _i_main_gen_tmp_59 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_59++)
        {
            _main_gen_tmp_58[_i_main_gen_tmp_59] = _main_gen_init_g6();
        }
        x.Pim_FactCtrrStmomFtaxFaild = PST_TRUE() ? 0 : &_main_gen_tmp_58[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_60[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_61;
        for (_i_main_gen_tmp_61 = 0; _i_main_gen_tmp_61 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_61++)
        {
            _main_gen_tmp_60[_i_main_gen_tmp_61] = _main_gen_init_g6();
        }
        x.Pim_FactCtrrStmomFtaxPassd = PST_TRUE() ? 0 : &_main_gen_tmp_60[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_62[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_63;
        for (_i_main_gen_tmp_63 = 0; _i_main_gen_tmp_63 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_63++)
        {
            _main_gen_tmp_62[_i_main_gen_tmp_63] = _main_gen_init_g6();
        }
        x.Pim_FactDmpngAddonStmomFtaxFaild = PST_TRUE() ? 0 : &_main_gen_tmp_62[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_64[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_65;
        for (_i_main_gen_tmp_65 = 0; _i_main_gen_tmp_65 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_65++)
        {
            _main_gen_tmp_64[_i_main_gen_tmp_65] = _main_gen_init_g6();
        }
        x.Pim_FactDmpngAddonStmomFtaxPassd = PST_TRUE() ? 0 : &_main_gen_tmp_64[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_66[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_67;
        for (_i_main_gen_tmp_67 = 0; _i_main_gen_tmp_67 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_67++)
        {
            _main_gen_tmp_66[_i_main_gen_tmp_67] = _main_gen_init_g6();
        }
        x.Pim_FactDmpngStmomFtaxFaild = PST_TRUE() ? 0 : &_main_gen_tmp_66[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_68[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_69;
        for (_i_main_gen_tmp_69 = 0; _i_main_gen_tmp_69 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_69++)
        {
            _main_gen_tmp_68[_i_main_gen_tmp_69] = _main_gen_init_g6();
        }
        x.Pim_FactDmpngStmomFtaxPassd = PST_TRUE() ? 0 : &_main_gen_tmp_68[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_70[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_71;
        for (_i_main_gen_tmp_71 = 0; _i_main_gen_tmp_71 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_71++)
        {
            _main_gen_tmp_70[_i_main_gen_tmp_71] = _main_gen_init_g6();
        }
        x.Pim_QuTarDmpngAddonStmomFtaxFaild = PST_TRUE() ? 0 : &_main_gen_tmp_70[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_72[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_73;
        for (_i_main_gen_tmp_73 = 0; _i_main_gen_tmp_73 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_73++)
        {
            _main_gen_tmp_72[_i_main_gen_tmp_73] = _main_gen_init_g6();
        }
        x.Pim_QuTarDmpngAddonStmomFtaxPassd = PST_TRUE() ? 0 : &_main_gen_tmp_72[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_74[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_75;
        for (_i_main_gen_tmp_75 = 0; _i_main_gen_tmp_75 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_75++)
        {
            _main_gen_tmp_74[_i_main_gen_tmp_75] = _main_gen_init_g6();
        }
        x.Pim_QuTarFactStmomFtaxFaild = PST_TRUE() ? 0 : &_main_gen_tmp_74[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_76[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_77;
        for (_i_main_gen_tmp_77 = 0; _i_main_gen_tmp_77 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_77++)
        {
            _main_gen_tmp_76[_i_main_gen_tmp_77] = _main_gen_init_g6();
        }
        x.Pim_QuTarFactStmomFtaxPassd = PST_TRUE() ? 0 : &_main_gen_tmp_76[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_78[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_79;
        for (_i_main_gen_tmp_79 = 0; _i_main_gen_tmp_79 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_79++)
        {
            _main_gen_tmp_78[_i_main_gen_tmp_79] = _main_gen_init_g6();
        }
        x.Pim_QuTarQtaStmomDvFaild = PST_TRUE() ? 0 : &_main_gen_tmp_78[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_80[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_81;
        for (_i_main_gen_tmp_81 = 0; _i_main_gen_tmp_81 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_81++)
        {
            _main_gen_tmp_80[_i_main_gen_tmp_81] = _main_gen_init_g6();
        }
        x.Pim_QuTarQtaStmomDvPassd = PST_TRUE() ? 0 : &_main_gen_tmp_80[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_82[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_83;
        for (_i_main_gen_tmp_83 = 0; _i_main_gen_tmp_83 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_83++)
        {
            _main_gen_tmp_82[_i_main_gen_tmp_83] = _main_gen_init_g6();
        }
        x.Pim_QuTarStmomDvActFaild = PST_TRUE() ? 0 : &_main_gen_tmp_82[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_84[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_85;
        for (_i_main_gen_tmp_85 = 0; _i_main_gen_tmp_85 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_85++)
        {
            _main_gen_tmp_84[_i_main_gen_tmp_85] = _main_gen_init_g6();
        }
        x.Pim_QuTarStmomDvActPassd = PST_TRUE() ? 0 : &_main_gen_tmp_84[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_86[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_87;
        for (_i_main_gen_tmp_87 = 0; _i_main_gen_tmp_87 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_87++)
        {
            _main_gen_tmp_86[_i_main_gen_tmp_87] = _main_gen_init_g6();
        }
        x.Pim_TarQtaStmomDvFaild = PST_TRUE() ? 0 : &_main_gen_tmp_86[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_88[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_89;
        for (_i_main_gen_tmp_89 = 0; _i_main_gen_tmp_89 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_89++)
        {
            _main_gen_tmp_88[_i_main_gen_tmp_89] = _main_gen_init_g6();
        }
        x.Pim_TarQtaStmomDvPassd = PST_TRUE() ? 0 : &_main_gen_tmp_88[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_90[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_91;
        for (_i_main_gen_tmp_91 = 0; _i_main_gen_tmp_91 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_91++)
        {
            _main_gen_tmp_90[_i_main_gen_tmp_91] = _main_gen_init_g6();
        }
        x.Pim_TarQtaStrmomDvAliveCntFaild = PST_TRUE() ? 0 : &_main_gen_tmp_90[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_92[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_93;
        for (_i_main_gen_tmp_93 = 0; _i_main_gen_tmp_93 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_93++)
        {
            _main_gen_tmp_92[_i_main_gen_tmp_93] = _main_gen_init_g6();
        }
        x.Pim_TarQtaStrmomDvAliveCntPassd = PST_TRUE() ? 0 : &_main_gen_tmp_92[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_94[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_95;
        for (_i_main_gen_tmp_95 = 0; _i_main_gen_tmp_95 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_95++)
        {
            _main_gen_tmp_94[_i_main_gen_tmp_95] = _main_gen_init_g6();
        }
        x.Pim_TarQtaStrmomDvArcVld = PST_TRUE() ? 0 : &_main_gen_tmp_94[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_96[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_97;
        for (_i_main_gen_tmp_97 = 0; _i_main_gen_tmp_97 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_97++)
        {
            _main_gen_tmp_96[_i_main_gen_tmp_97] = _main_gen_init_g6();
        }
        x.Pim_TarQtaStrmomDvCRCFaild = PST_TRUE() ? 0 : &_main_gen_tmp_96[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_98[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_99;
        for (_i_main_gen_tmp_99 = 0; _i_main_gen_tmp_99 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_99++)
        {
            _main_gen_tmp_98[_i_main_gen_tmp_99] = _main_gen_init_g6();
        }
        x.Pim_TarQtaStrmomDvCRCPassd = PST_TRUE() ? 0 : &_main_gen_tmp_98[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_100[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_101;
        for (_i_main_gen_tmp_101 = 0; _i_main_gen_tmp_101 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_101++)
        {
            _main_gen_tmp_100[_i_main_gen_tmp_101] = _main_gen_init_g6();
        }
        x.Pim_TarQtaStrmomDvMissFaild = PST_TRUE() ? 0 : &_main_gen_tmp_100[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_102[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_103;
        for (_i_main_gen_tmp_103 = 0; _i_main_gen_tmp_103 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_103++)
        {
            _main_gen_tmp_102[_i_main_gen_tmp_103] = _main_gen_init_g6();
        }
        x.Pim_TarQtaStrmomDvMissPassd = PST_TRUE() ? 0 : &_main_gen_tmp_102[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_104[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_105;
        for (_i_main_gen_tmp_105 = 0; _i_main_gen_tmp_105 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_105++)
        {
            _main_gen_tmp_104[_i_main_gen_tmp_105] = _main_gen_init_g6();
        }
        x.Pim_TarQtaStrmomDvMsgProcd = PST_TRUE() ? 0 : &_main_gen_tmp_104[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_106[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_107;
        for (_i_main_gen_tmp_107 = 0; _i_main_gen_tmp_107 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_107++)
        {
            _main_gen_tmp_106[_i_main_gen_tmp_107] = _main_gen_init_g6();
        }
        x.Pim_TarStmomDvActAliveCntFaild = PST_TRUE() ? 0 : &_main_gen_tmp_106[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_108[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_109;
        for (_i_main_gen_tmp_109 = 0; _i_main_gen_tmp_109 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_109++)
        {
            _main_gen_tmp_108[_i_main_gen_tmp_109] = _main_gen_init_g6();
        }
        x.Pim_TarStmomDvActAliveCntPassd = PST_TRUE() ? 0 : &_main_gen_tmp_108[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_110[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_111;
        for (_i_main_gen_tmp_111 = 0; _i_main_gen_tmp_111 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_111++)
        {
            _main_gen_tmp_110[_i_main_gen_tmp_111] = _main_gen_init_g6();
        }
        x.Pim_TarStmomDvActArcVld = PST_TRUE() ? 0 : &_main_gen_tmp_110[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_112[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_113;
        for (_i_main_gen_tmp_113 = 0; _i_main_gen_tmp_113 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_113++)
        {
            _main_gen_tmp_112[_i_main_gen_tmp_113] = _main_gen_init_g6();
        }
        x.Pim_TarStmomDvActCrcFaild = PST_TRUE() ? 0 : &_main_gen_tmp_112[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_114[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_115;
        for (_i_main_gen_tmp_115 = 0; _i_main_gen_tmp_115 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_115++)
        {
            _main_gen_tmp_114[_i_main_gen_tmp_115] = _main_gen_init_g6();
        }
        x.Pim_TarStmomDvActCrcPassd = PST_TRUE() ? 0 : &_main_gen_tmp_114[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_116[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_117;
        for (_i_main_gen_tmp_117 = 0; _i_main_gen_tmp_117 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_117++)
        {
            _main_gen_tmp_116[_i_main_gen_tmp_117] = _main_gen_init_g6();
        }
        x.Pim_TarStmomDvActFaild = PST_TRUE() ? 0 : &_main_gen_tmp_116[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_118[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_119;
        for (_i_main_gen_tmp_119 = 0; _i_main_gen_tmp_119 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_119++)
        {
            _main_gen_tmp_118[_i_main_gen_tmp_119] = _main_gen_init_g6();
        }
        x.Pim_TarStmomDvActMissFaild = PST_TRUE() ? 0 : &_main_gen_tmp_118[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_120[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_121;
        for (_i_main_gen_tmp_121 = 0; _i_main_gen_tmp_121 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_121++)
        {
            _main_gen_tmp_120[_i_main_gen_tmp_121] = _main_gen_init_g6();
        }
        x.Pim_TarStmomDvActMissPassd = PST_TRUE() ? 0 : &_main_gen_tmp_120[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_122[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_123;
        for (_i_main_gen_tmp_123 = 0; _i_main_gen_tmp_123 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_123++)
        {
            _main_gen_tmp_122[_i_main_gen_tmp_123] = _main_gen_init_g6();
        }
        x.Pim_TarStmomDvActMsgProcd = PST_TRUE() ? 0 : &_main_gen_tmp_122[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    /* pointer */
    {
        static __PST__UINT8 _main_gen_tmp_124[ARRAY_NBELEM(__PST__UINT8)];
        __PST__UINT32 _i_main_gen_tmp_125;
        for (_i_main_gen_tmp_125 = 0; _i_main_gen_tmp_125 < ARRAY_NBELEM(__PST__UINT8); _i_main_gen_tmp_125++)
        {
            _main_gen_tmp_124[_i_main_gen_tmp_125] = _main_gen_init_g6();
        }
        x.Pim_TarStmomDvActPassd = PST_TRUE() ? 0 : &_main_gen_tmp_124[ARRAY_NBELEM(__PST__UINT8) / 2];
    }
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_Rte_Inst_BmwMsgSlot68Bas0Repn2BusFrChA(void)
{
    extern __PST__g__22 Rte_Inst_BmwMsgSlot68Bas0Repn2BusFrChA;
    
    /* initialization with random value */
    {
        /* pointer */
        {
            static struct Rte_CDS_BmwMsgSlot68Bas0Repn2BusFrChA _main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_BmwMsgSlot68Bas0Repn2BusFrChA)];
            __PST__UINT32 _i_main_gen_tmp_1;
            for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(struct Rte_CDS_BmwMsgSlot68Bas0Repn2BusFrChA); _i_main_gen_tmp_1++)
            {
                _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g25();
            }
            Rte_Inst_BmwMsgSlot68Bas0Repn2BusFrChA = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(struct Rte_CDS_BmwMsgSlot68Bas0Repn2BusFrChA) / 2];
        }
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable Rte_Inst_BmwMsgSlot68Bas0Repn2BusFrChA */
    _main_gen_init_sym_Rte_Inst_BmwMsgSlot68Bas0Repn2BusFrChA();
    
}
