#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_SetMcuDiagcIdnData(void)
{
    extern __PST__VOID SetMcuDiagcIdnData(__PST__UINT32, __PST__UINT32);

    __PST__UINT32 __arg__0;
    __PST__UINT32 __arg__1;
    
    __arg__0 = _main_gen_init_g8();
    __arg__1 = _main_gen_init_g8();
    
    /* call it */
    SetMcuDiagcIdnData(__arg__0, __arg__1);
}

static void _main_gen_call_GetMcuDiagcIdnData(void)
{
    extern __PST__VOID GetMcuDiagcIdnData(__PST__g__19);

    __PST__g__19 __arg__0;
    
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g8();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    GetMcuDiagcIdnData(__arg__0);
}

static void _main_gen_call_ProcUkwnExcpnErr(void)
{
    extern __PST__VOID ProcUkwnExcpnErr(__PST__UINT32);

    __PST__UINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g8();
    
    /* call it */
    ProcUkwnExcpnErr(__arg__0);
}

static void _main_gen_call_ProcMpuExcpnErr(void)
{
    extern __PST__VOID ProcMpuExcpnErr(__PST__UINT32);

    __PST__UINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g8();
    
    /* call it */
    ProcMpuExcpnErr(__arg__0);
}

static void _main_gen_call_ProcPrvlgdInstrExcpnErr(void)
{
    extern __PST__VOID ProcPrvlgdInstrExcpnErr(__PST__UINT32);

    __PST__UINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g8();
    
    /* call it */
    ProcPrvlgdInstrExcpnErr(__arg__0);
}

static void _main_gen_call_ProcPrmntOsErr(void)
{
    extern __PST__VOID ProcPrmntOsErr(__PST__UINT32);

    __PST__UINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g8();
    
    /* call it */
    ProcPrmntOsErr(__arg__0);
}

static void _main_gen_call_ProcNonCritOsErr(void)
{
    extern __PST__VOID ProcNonCritOsErr(__PST__UINT32);

    __PST__UINT32 __arg__0;
    
    __arg__0 = _main_gen_init_g8();
    
    /* call it */
    ProcNonCritOsErr(__arg__0);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function FeNmiPeg */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiPeg(__PST__VOID);

            FeNmiPeg();
        }
        
        /* call of function FeNmiDmaTrf */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiDmaTrf(__PST__VOID);

            FeNmiDmaTrf();
        }
        
        /* call of function FeNmiDmaRegAcsProtnErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiDmaRegAcsProtnErr(__PST__VOID);

            FeNmiDmaRegAcsProtnErr();
        }
        
        /* call of function FeNmiEcmMstChkrCmp */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiEcmMstChkrCmp(__PST__VOID);

            FeNmiEcmMstChkrCmp();
        }
        
        /* call of function FeNmiWdg */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiWdg(__PST__VOID);

            FeNmiWdg();
        }
        
        /* call of function SetMcuDiagcIdnData */
        if (PST_TRUE())
        {
            _main_gen_call_SetMcuDiagcIdnData();
        }
        
        /* call of function GetMcuDiagcIdnData */
        if (PST_TRUE())
        {
            _main_gen_call_GetMcuDiagcIdnData();
        }
        
        /* call of function ProcUkwnExcpnErr */
        if (PST_TRUE())
        {
            _main_gen_call_ProcUkwnExcpnErr();
        }
        
        /* call of function ProcMpuExcpnErr */
        if (PST_TRUE())
        {
            _main_gen_call_ProcMpuExcpnErr();
        }
        
        /* call of function ProcPrvlgdInstrExcpnErr */
        if (PST_TRUE())
        {
            _main_gen_call_ProcPrvlgdInstrExcpnErr();
        }
        
        /* call of function ProcPrmntOsErr */
        if (PST_TRUE())
        {
            _main_gen_call_ProcPrmntOsErr();
        }
        
        /* call of function ProcNonCritOsErr */
        if (PST_TRUE())
        {
            _main_gen_call_ProcNonCritOsErr();
        }
        
        /* call of function FeNmiClkMonr0RtLowrLimFlt */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr0RtLowrLimFlt(__PST__VOID);

            FeNmiClkMonr0RtLowrLimFlt();
        }
        
        /* call of function FeNmiClkMonr0RtUpprLimFlt */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr0RtUpprLimFlt(__PST__VOID);

            FeNmiClkMonr0RtUpprLimFlt();
        }
        
        /* call of function FeNmiClkMonr1RtLowrLimFlt */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr1RtLowrLimFlt(__PST__VOID);

            FeNmiClkMonr1RtLowrLimFlt();
        }
        
        /* call of function FeNmiClkMonr1RtUpprLimFlt */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr1RtUpprLimFlt(__PST__VOID);

            FeNmiClkMonr1RtUpprLimFlt();
        }
        
        /* call of function FeNmiClkMonr2RtLowrLimFlt */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr2RtLowrLimFlt(__PST__VOID);

            FeNmiClkMonr2RtLowrLimFlt();
        }
        
        /* call of function FeNmiClkMonr2RtUpprLimFlt */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr2RtUpprLimFlt(__PST__VOID);

            FeNmiClkMonr2RtUpprLimFlt();
        }
        
        /* call of function FeNmiClkMonr3RtLowrLimFlt */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr3RtLowrLimFlt(__PST__VOID);

            FeNmiClkMonr3RtLowrLimFlt();
        }
        
        /* call of function FeNmiClkMonr3RtUpprLimFlt */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiClkMonr3RtUpprLimFlt(__PST__VOID);

            FeNmiClkMonr3RtUpprLimFlt();
        }
        
        /* call of function FeNmiOperModErrSngChipInactv */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiOperModErrSngChipInactv(__PST__VOID);

            FeNmiOperModErrSngChipInactv();
        }
        
        /* call of function FeNmiOperModErrFlsProgmModStrtd */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiOperModErrFlsProgmModStrtd(__PST__VOID);

            FeNmiOperModErrFlsProgmModStrtd();
        }
        
        /* call of function FeNmiOperModErrTestModStrtd */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiOperModErrTestModStrtd(__PST__VOID);

            FeNmiOperModErrTestModStrtd();
        }
        
        /* call of function FeNmiDtsEccSngBitErr */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID FeNmiDtsEccSngBitErr(__PST__VOID);

            FeNmiDtsEccSngBitErr();
        }
        
        /* call of function Rte_Stub */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID Rte_Stub(__PST__VOID);

            Rte_Stub();
        }
        
    }
}
