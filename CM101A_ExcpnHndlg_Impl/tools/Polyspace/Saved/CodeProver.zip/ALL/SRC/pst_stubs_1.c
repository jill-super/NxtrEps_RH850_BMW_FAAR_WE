#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern struct __PST__g__472 _main_gen_init_g472(void);

extern struct __PST__g__470 _main_gen_init_g470(void);

extern __PST__g__465 _main_gen_init_g465(void);

extern union __PST__g__366 _main_gen_init_g366(void);

extern union __PST__g__356 _main_gen_init_g356(void);

extern __PST__g__342 _main_gen_init_g342(void);

extern union __PST__g__332 _main_gen_init_g332(void);

extern __PST__g__325 _main_gen_init_g325(void);

extern union __PST__g__320 _main_gen_init_g320(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern struct __PST__g__318 _main_gen_init_g318(void);

extern union __PST__g__316 _main_gen_init_g316(void);

extern __PST__g__293 _main_gen_init_g293(void);

extern union __PST__g__283 _main_gen_init_g283(void);

extern union __PST__g__278 _main_gen_init_g278(void);

extern __PST__g__262 _main_gen_init_g262(void);

extern union __PST__g__260 _main_gen_init_g260(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern union __PST__g__258 _main_gen_init_g258(void);

extern __PST__g__253 _main_gen_init_g253(void);

extern union __PST__g__250 _main_gen_init_g250(void);

extern union __PST__g__248 _main_gen_init_g248(void);

extern union __PST__g__246 _main_gen_init_g246(void);

extern union __PST__g__244 _main_gen_init_g244(void);

extern __PST__g__242 _main_gen_init_g242(void);

extern struct __PST__g__69 _main_gen_init_g69(void);

extern union __PST__g__67 _main_gen_init_g67(void);

extern __PST__UINT32 _main_gen_init_g8(void);

extern struct __PST__g__62 _main_gen_init_g62(void);

extern union __PST__g__60 _main_gen_init_g60(void);

extern __PST__g__31 _main_gen_init_g31(void);

struct __PST__g__62 _main_gen_init_g62(void)
{
    static struct __PST__g__62 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DEBUGMODE = bitf;
    }
    return x;
}

union __PST__g__60 _main_gen_init_g60(void)
{
    static union __PST__g__60 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g62();
    return x;
}

struct __PST__g__69 _main_gen_init_g69(void)
{
    static struct __PST__g__69 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DEBUGMODEB = bitf;
    }
    return x;
}

union __PST__g__67 _main_gen_init_g67(void)
{
    static union __PST__g__67 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g69();
    return x;
}

__PST__g__31 _main_gen_init_g31(void)
{
    __PST__g__31 x;
    /* struct/union type */
    x.BSEQ0ST = _main_gen_init_g60();
    x.BSEQ0STB = _main_gen_init_g67();
    return x;
}

union __PST__g__244 _main_gen_init_g244(void)
{
    static union __PST__g__244 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__246 _main_gen_init_g246(void)
{
    static union __PST__g__246 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__248 _main_gen_init_g248(void)
{
    static union __PST__g__248 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__250 _main_gen_init_g250(void)
{
    static union __PST__g__250 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__242 _main_gen_init_g242(void)
{
    __PST__g__242 x;
    /* struct/union type */
    x.DAT0 = _main_gen_init_g244();
    x.DAT1 = _main_gen_init_g246();
    x.DAT2 = _main_gen_init_g248();
    x.DAT3 = _main_gen_init_g250();
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

union __PST__g__258 _main_gen_init_g258(void)
{
    static union __PST__g__258 x;
    /* struct/union type */
    x.UINT16 = _main_gen_init_g7();
    return x;
}

union __PST__g__260 _main_gen_init_g260(void)
{
    static union __PST__g__260 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__253 _main_gen_init_g253(void)
{
    __PST__g__253 x;
    /* struct/union type */
    x.FLAG = _main_gen_init_g258();
    x.ADDR = _main_gen_init_g260();
    return x;
}

union __PST__g__278 _main_gen_init_g278(void)
{
    static union __PST__g__278 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__283 _main_gen_init_g283(void)
{
    static union __PST__g__283 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__262 _main_gen_init_g262(void)
{
    __PST__g__262 x;
    /* struct/union type */
    x.CF1STERSTR_VCI = _main_gen_init_g278();
    x.CF1STEADR0_VCI = _main_gen_init_g283();
    x.CF1STERSTR_PE1 = _main_gen_init_g278();
    x.CF1STEADR0_PE1 = _main_gen_init_g283();
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

struct __PST__g__318 _main_gen_init_g318(void)
{
    static struct __PST__g__318 x;
    /* struct/union type */
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF0 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF1 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF2 = bitf;
    }
    {
        __PST__UINT8 bitf;
        bitf = _main_gen_init_g6();
        unchecked_assert(bitf <= 1);
        x.DEDF3 = bitf;
    }
    return x;
}

union __PST__g__316 _main_gen_init_g316(void)
{
    static union __PST__g__316 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g318();
    return x;
}

union __PST__g__320 _main_gen_init_g320(void)
{
    static union __PST__g__320 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__293 _main_gen_init_g293(void)
{
    __PST__g__293 x;
    /* struct/union type */
    x.LR1STERSTR_PE1 = _main_gen_init_g316();
    x.LR1STEADR0_PE1 = _main_gen_init_g320();
    x.LR1STEADR1_PE1 = _main_gen_init_g320();
    x.LR1STEADR2_PE1 = _main_gen_init_g320();
    x.LR1STEADR3_PE1 = _main_gen_init_g320();
    return x;
}

union __PST__g__332 _main_gen_init_g332(void)
{
    static union __PST__g__332 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__325 _main_gen_init_g325(void)
{
    __PST__g__325 x;
    /* struct/union type */
    x.ESSTR0 = _main_gen_init_g332();
    return x;
}

union __PST__g__356 _main_gen_init_g356(void)
{
    static union __PST__g__356 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__366 _main_gen_init_g366(void)
{
    static union __PST__g__366 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__342 _main_gen_init_g342(void)
{
    __PST__g__342 x;
    /* struct/union type */
    x.DMACER = _main_gen_init_g356();
    x.DTSER2 = _main_gen_init_g366();
    return x;
}

struct __PST__g__472 _main_gen_init_g472(void)
{
    static struct __PST__g__472 x;
    /* struct/union type */
    x.FailedSupervisionRefCycles = _main_gen_init_g7();
    x.DeadlineViolationCnt = _main_gen_init_g7();
    x.ProgramFlowViolationCnt = _main_gen_init_g7();
    return x;
}

struct __PST__g__470 _main_gen_init_g470(void)
{
    static struct __PST__g__470 x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__472 _main_gen_tmp_5[ARRAY_NBELEM(struct __PST__g__472)];
        __PST__UINT32 _i_main_gen_tmp_6;
        for (_i_main_gen_tmp_6 = 0; _i_main_gen_tmp_6 < ARRAY_NBELEM(struct __PST__g__472); _i_main_gen_tmp_6++)
        {
            _main_gen_tmp_5[_i_main_gen_tmp_6] = _main_gen_init_g472();
        }
        x.EntityStatusGRef = PST_TRUE() ? 0 : &_main_gen_tmp_5[ARRAY_NBELEM(struct __PST__g__472) / 2];
    }
    return x;
}

__PST__g__465 _main_gen_init_g465(void)
{
    __PST__g__465 x;
    /* struct/union type */
    /* pointer */
    {
        static struct __PST__g__470 _main_gen_tmp_3[ARRAY_NBELEM(struct __PST__g__470)];
        __PST__UINT32 _i_main_gen_tmp_4;
        for (_i_main_gen_tmp_4 = 0; _i_main_gen_tmp_4 < ARRAY_NBELEM(struct __PST__g__470); _i_main_gen_tmp_4++)
        {
            _main_gen_tmp_3[_i_main_gen_tmp_4] = _main_gen_init_g470();
        }
        x.WdgMSupervisedEntityRef = PST_TRUE() ? 0 : &_main_gen_tmp_3[ARRAY_NBELEM(struct __PST__g__470) / 2];
    }
    x.NrOfSupervisedEntities = _main_gen_init_g6();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_ExcpnHndlg_Pim_McuDiagcData(void)
{
    extern __PST__g__30 ExcpnHndlg_Pim_McuDiagcData;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < 4; _main_gen_tmp_2_0++)
            {
                /* base type */
                ExcpnHndlg_Pim_McuDiagcData[_main_gen_tmp_2_0] = pst_random_g_8;
            }
        }
    }
}

static void _main_gen_init_sym_SYS(void)
{
    extern __PST__g__31 SYS;
    
    /* initialization with random value */
    {
        SYS = _main_gen_init_g31();
    }
}

static void _main_gen_init_sym_BRAM(void)
{
    extern __PST__g__242 BRAM;
    
    /* initialization with random value */
    {
        BRAM = _main_gen_init_g242();
    }
}

static void _main_gen_init_sym_SEG(void)
{
    extern __PST__g__253 SEG;
    
    /* initialization with random value */
    {
        SEG = _main_gen_init_g253();
    }
}

static void _main_gen_init_sym_ECCFLI(void)
{
    extern __PST__g__262 ECCFLI;
    
    /* initialization with random value */
    {
        ECCFLI = _main_gen_init_g262();
    }
}

static void _main_gen_init_sym_ECCCPU1(void)
{
    extern __PST__g__293 ECCCPU1;
    
    /* initialization with random value */
    {
        ECCCPU1 = _main_gen_init_g293();
    }
}

static void _main_gen_init_sym_ECMM(void)
{
    extern __PST__g__325 ECMM;
    
    /* initialization with random value */
    {
        ECMM = _main_gen_init_g325();
    }
}

static void _main_gen_init_sym_DMASS(void)
{
    extern __PST__g__342 DMASS;
    
    /* initialization with random value */
    {
        DMASS = _main_gen_init_g342();
    }
}

static void _main_gen_init_sym_WdgMConfig_Mode0(void)
{
    extern __PST__g__465 WdgMConfig_Mode0;
    
    /* initialization with random value */
    {
        WdgMConfig_Mode0 = _main_gen_init_g465();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Srv_McuDiagcData_SetRamBlockStatus_Return(void)
{
    extern __PST__UINT8 ExcpnHndlg_Srv_McuDiagcData_SetRamBlockStatus_Return;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Srv_McuDiagcData_SetRamBlockStatus_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 ExcpnHndlg_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_ChkForStrtUpTest_ExecStrtUpTest(void)
{
    extern __PST__UINT8 ExcpnHndlg_Cli_ChkForStrtUpTest_ExecStrtUpTest;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_ChkForStrtUpTest_ExecStrtUpTest = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_ExcpnHndlg_Cli_GetMcuDiagcSpplData_McuDiagcData1(void)
{
    extern __PST__UINT32 ExcpnHndlg_Cli_GetMcuDiagcSpplData_McuDiagcData1;
    
    /* initialization with random value */
    {
        ExcpnHndlg_Cli_GetMcuDiagcSpplData_McuDiagcData1 = _main_gen_init_g8();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable ExcpnHndlg_Pim_McuDiagcData */
    _main_gen_init_sym_ExcpnHndlg_Pim_McuDiagcData();
    
    /* init for variable SYS */
    _main_gen_init_sym_SYS();
    
    /* init for variable BRAM */
    _main_gen_init_sym_BRAM();
    
    /* init for variable SEG */
    _main_gen_init_sym_SEG();
    
    /* init for variable ECCFLI */
    _main_gen_init_sym_ECCFLI();
    
    /* init for variable ECCCPU1 */
    _main_gen_init_sym_ECCCPU1();
    
    /* init for variable ECMM */
    _main_gen_init_sym_ECMM();
    
    /* init for variable DMASS */
    _main_gen_init_sym_DMASS();
    
    /* init for variable WdgMConfig_Mode0 */
    _main_gen_init_sym_WdgMConfig_Mode0();
    
    /* init for variable ExcpnHndlg_Srv_McuDiagcData_SetRamBlockStatus_BlockChanged : useless (never read) */

    /* init for variable ExcpnHndlg_Srv_McuDiagcData_SetRamBlockStatus_Return */
    _main_gen_init_sym_ExcpnHndlg_Srv_McuDiagcData_SetRamBlockStatus_Return();
    
    /* init for variable ExcpnHndlg_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable ExcpnHndlg_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable ExcpnHndlg_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable ExcpnHndlg_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable ExcpnHndlg_Srv_SetNtcSts_Return */
    _main_gen_init_sym_ExcpnHndlg_Srv_SetNtcSts_Return();
    
    /* init for variable ExcpnHndlg_Cli_ChkForStrtUpTest_ExecStrtUpTest */
    _main_gen_init_sym_ExcpnHndlg_Cli_ChkForStrtUpTest_ExecStrtUpTest();
    
    /* init for variable ExcpnHndlg_Cli_GetMcuDiagcSpplData_McuDiagcData1 */
    _main_gen_init_sym_ExcpnHndlg_Cli_GetMcuDiagcSpplData_McuDiagcData1();
    
}
