package com.vector.cfg.dom.diagnostics.groovy.events;

import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;

/**
 * An {@link IDemEvent} instance represents a diagnostic event.
 *
 * <div class="extdoc" id="IDemEvent"><!--Label:sec:IDemEvent-->An {@link IDemEvent} instance represents a diagnostic event and and provides usecase centric functionalities to
 * modify and query diagnostic events.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDemEvent extends IHasModelObject {

    @PublishedField
    EWwhObdDtcClass CLASS_A = EWwhObdDtcClass.CLASS_A;

    @PublishedField
    EWwhObdDtcClass CLASS_B1 = EWwhObdDtcClass.CLASS_B1;

    @PublishedField
    EWwhObdDtcClass CLASS_B2 = EWwhObdDtcClass.CLASS_B2;

    @PublishedField
    EWwhObdDtcClass CLASS_C = EWwhObdDtcClass.CLASS_C;

    @PublishedField
    EWwhObdDtcClass NO_CLASS = EWwhObdDtcClass.CLASS_NOCLASS;

    @PublishedMethod
    boolean isObdRelevant();

    @PublishedMethod
    boolean isObd2();

    @PublishedMethod
    boolean isWwhObd();

    @PublishedMethod
    BigInteger getDtc();

    /**
     * {@link #getMdfObject()} returns the {@link MIContainer} represented by this {@link IDemEvent}. <div class="extdoc" id="getMdfObject"><!--Label:IDemEvent.getMdfObject-->
     * <h5>Accessing a DemEvent's MIContainer</h5>{@link #getMdfObject()} returns the {@link MIContainer} represented by this {@link IDemEvent}.</div>
     *
     * @return the {@link MIContainer} represented by this {@link IDemEvent}
     */
    @Override
    @PublishedMethod
    MIContainer getMdfObject();
}
