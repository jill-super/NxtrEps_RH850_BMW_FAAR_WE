package com.vector.cfg.consistency.contribution.helper;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.consistency.contribution.IValidator;

/**
 *
 *
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */

/**
 * The EValidatorConsistencyVersion defines the consistency versions of validators (implementing {@link IValidator}).
 *
 * <div class="extdoc" data-target-doc="ConsistencyDocumentation" id="ValidatorConsistencyVersionHistory">
 *
 * <p>
 * The {@link IValidator} API has its own version schema. So we are able to introduce new features or semantic changes in new versions.
 *
 * The version can be passed when creating validator instances. Making use of this option means that you benefit from stable interfaces until you decide to switch to new
 * features in the consistency. You make this decision whenever you want to. We strongly recommend to make usage of this benefit.
 * </p>
 *
 * <p>
 * When you switch to a new version you must verify that your code still works properly. The sections below document the changes in the different versions.
 * </p>
 *
 * <h2>Version 1</h2> {@link EConsistencyValidator.VERSION_1}:
 * <ul>
 * <li>The original version of the first {@link IValidator} implementations.</li>
 * </ul>
 *
 * <h2>Version 2</h2> {@link EConsistencyValidator.VERSION_2}:
 * <ul>
 * <li>Newest version for future features.</li>
 * </ul>
 * </div>
 *
 */

@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EValidatorConsistencyVersion {

    /**
     * @deprecated It is recommended to use VERSION_2!
     *
     * <p>
     * This is the original version of the first {@link IValidator} implementations. It is applied to all validators that have not explicitly been created with a version.
     * </p>
     */
    @Deprecated
    VERSION_1,

    /**
     * This is the first version supporting the new validator consistency versioning concept. Please use this version.
     */
    VERSION_2,

    ;

    @KeepSecretFromPublishedApi
    public static EValidatorConsistencyVersion getNewest() {
        return VERSION_2;
    }

}
