package com.vector.cfg.gen.core.utils.exceptions;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.exceptions.IExceptionValidationResultProcessor;
import com.vector.cfg.gen.core.moduleinterface.IDeployablePackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageException;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GenExceptionValidationProcessor implements IExceptionValidationResultProcessor {
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenExceptionValidationProcessor.class);

    private final IDeployablePackage pack;

    GenExceptionValidationProcessor(IDeployablePackage pack) {
        this.pack = checkNotNull(pack);

        if (!(pack instanceof IGeneratorPackage)) {
            throw new UnsupportedOperationException("Type currently not supported!");
        }
    }

    /**
     * Creates an {@link IExceptionValidationResultProcessor} for the passed {@link IDeployablePackage}.
     *
     * @param pack the {@link IDeployablePackage} (normally the {@link IGeneratorPackage}).
     * @return the i exception validation result processor
     */
    @PublishedMethod
    public static IExceptionValidationResultProcessor create(IDeployablePackage pack) {
        return new GenExceptionValidationProcessor(pack);
    }

    /**
     * {@inheritDoc}
     *
     * @throws Exception
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    public List<IGeneratorResult> wrapExceptionIntoValidationResults(Exception ex) throws Exception {
        if (ex instanceof GeneratorPackageException) {
            return handleGenPackageEx((GeneratorPackageException) ex);
        }

        if (ex instanceof ModelException) {
            return handleModelEx((ModelException) ex);
        }

        throw ex;
    }

    private List<IGeneratorResult> handleGenPackageEx(GeneratorPackageException ex) {
        if (logger.isDebugEnabled()) {
            logger.debug("GeneratorPackageException caught", ex);
        }

        return ex.getGeneratorResultList();
    }

    private List<IGeneratorResult> handleModelEx(ModelException modelEx) {

        if (logger.isDebugEnabled()) {
            logger.debug("ModelException caught", modelEx);
        }

        final List<IGeneratorResult> resultList;

        resultList = ModelExceptionProcessor.wrapExceptionIntoGeneratorResults(modelEx, (IGeneratorPackage) pack);

        return resultList;
    }

}
