package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * <div class="extdoc" id="PublishedField"> Indicates that the annotated field is part of an published type (see {@link PublishedApi} <!--LaTeX: or chapter
 * \vref{sec:PublishedApi}--> for more details), which must not be changed in the development without an approval for the breaking change!
 *
 * <h4>Constant Fields</h4> A constant field is a <code>final</code> field of primitive type or type <code>String</code> that is initialized with a constant value. This value
 * must not be changed without an approval for the breaking change. With the option <code>constantValueChangesAllowed</code> this check can be disabled (e.g. for Version fields,
 * which change there values every release).
 * <p>
 * For Example:
 *
 * <pre>
 * <code class="Java" id="Disable constant value check">
 * &#64;PublishedField(constantValueChangesAllowed=true)
 * public static final String CONSTANT_STRING = "constantString";
 * </code>
 * </pre>
 *
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @see PublishedApi
 */
@Documented
@Retention(RetentionPolicy.CLASS)
@Target(ElementType.FIELD)
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public @interface PublishedField {

    boolean constantValueChangesAllowed() default false;
}
