package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationVariant;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucModuleConfiguration;

/**
 * BswmdModel ConfigurationVariant information retrieved by the {@link GIModuleConfiguration}.
 *
 * Abstraction interface for ConfigurationVariants.
 *
 * <div class="extdoc" id="PBSelectable"> The class {@link GIConfigVariantInfo} provides the information, if a {@link GIModuleConfiguration} is post-build selectable. (
 * {@link GIConfigVariantInfo#isPostBuildSelectable()}).
 *
 *
 * <pre>
 * <code class="Java" id="Test if a Module has enabled post-build selectable">
 *
 * GIModuleConfiguration moduleBswmdModel=...;
 *
 * GIConfigVariantInfo variantInfo = moduleBswmdModel.getConfigVariantInfo();
 *
 * if(variantInfo.isPostBuildSelectable()){
 *     // Do post-build selectable specific code
 *     //....
 * }
 * </code>
 * </pre>
 *
 * </div>
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIConfigVariantInfo {
    // CHECKSTYLE:ON
    /**
     * Return <code>true</code>, if the PB-L ConfigurationVariant is PRE-COMPILE. Otherwise, false.
     * <p>
     * <h2>Remark:</h2>The semantic actually is {@link IEcucModuleConfiguration#getConfigurationVariant()} == {@link EEcucConfigurationVariant#VARIANT_PRE_COMPILE}. For details
     * read the JavaDoc there.
     * </p>
     *
     * @return
     */
    @PublishedMethod
    boolean isPreCompile();

    /**
     * Return <code>true</code>, if the PB-L ConfigurationVariant is LINK-TIME. Otherwise, false.
     * <p>
     * <h2>Remark:</h2>The semantic actually is {@link IEcucModuleConfiguration#getConfigurationVariant()} == {@link EEcucConfigurationVariant#VARIANT_LINK_TIME}. For details
     * read the JavaDoc there.
     * </p>
     *
     * @return
     */
    @PublishedMethod
    boolean isLinkTime();

    /**
     * Return <code>true</code>, if the PB-L ConfigurationVariant is POST-BUILD-LOADABLE.
     * <p>
     * <h2>Remark:</h2>The semantic actually is {@link IEcucModuleConfiguration#getConfigurationVariant()} == {@link EEcucConfigurationVariant#VARIANT_POST_BUILD_LOADABLE}. For
     * details read the JavaDoc there.
     * </p>
     *
     * @return
     */
    @PublishedMethod
    boolean isPostBuildLoadable();

    /**
     * Return true, if the module implements post-build selectable. This is equal to calling {@link IEcucModuleConfiguration#supportsPostBuildVariance()}.
     *
     * @return
     */
    @PublishedMethod
    boolean isPostBuildSelectable();

}
