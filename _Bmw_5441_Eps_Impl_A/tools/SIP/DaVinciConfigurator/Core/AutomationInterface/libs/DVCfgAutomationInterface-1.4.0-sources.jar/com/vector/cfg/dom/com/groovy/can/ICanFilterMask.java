package com.vector.cfg.dom.com.groovy.can;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;

/**
 * An {@link ICanFilterMask} instance represents a CanFilterMask {@link MIContainer} providing support for use cases exceeding those supported by the model API.
 * <div class="extdoc" id="ICanFilterMask"><!--Label:ICanFilterMask-->An {@link ICanFilterMask} instance represents a CanFilterMask {@link MIContainer} providing support for use
 * cases exceeding those supported by the model API.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICanFilterMask extends IHasModelObject {

    /**
     * {@link #getFilterType()} returns this {@link ICanFilterMask}'s filter type.<div class="extdoc" id="getFilterType"><!--Label:ICanFilterMask.getFilterType-->
     * <h5>Accessing a CanFilterMask's Filter Type</h5>{@link #getFilterType()} returns this {@link ICanFilterMask}'s filter type.</div>
     *
     * @return this {@link ICanFilterMask}'s filter type
     */
    @PublishedMethod
    ECanAcceptanceFilterType getFilterType();

    /**
     * Alias for {@link #setFilterType(ECanAcceptanceFilterType)}.
     *
     * @param filterType
     * @return this {@link ICanFilterMask} instance (for chaining API calls)
     */
    @PublishedMethod
    ICanFilterMask filterType(@Nonnull ECanAcceptanceFilterType filterType);

    /**
     * Using {@link #setFilterType(ECanAcceptanceFilterType)} this {@link ICanFilterMask}'s filter type can be
     * specified.<div class="extdoc" id="setFilterType"><!--Label:ICanFilterMask.setFilterType-->
     * <h5>Specifying a CanFilterMask's Filter Type</h5>Using {@link #setFilterType(ECanAcceptanceFilterType)} this {@link ICanFilterMask}'s filter type can be specified.</div>
     *
     * @return this {@link ICanFilterMask}'s filter type
     */
    @PublishedMethod
    void setFilterType(@Nonnull ECanAcceptanceFilterType filterType);

    /**
     * {@link #getFilter()} returns this {@link ICanFilterMask}'s filter value.<div class="extdoc" id="getFilter"><!--Label:ICanFilterMask.getFilter-->
     * <h5>Accessing a CanFilterMask's Filter Value</h5>{@link #getFilter()} returns this {@link ICanFilterMask}'s filter value. A CanFilterMask's filter value is a
     * {@link String} containing the characters '0', '1' and 'X' (don't care). For determining if a given Can ID passes the filter it is matched bit for bit against the
     * {@link String}'s characters. The character at index 0 is matched against the most significant bit. The character at index <code>length() - 1</code> is matched against the
     * least significant bit. The length of the {@link String} corresponds to the CanFilterMask's filter type.</div>
     *
     * @return this {@link ICanFilterMask}'s filter value
     */
    @PublishedMethod
    String getFilter();

    /**
     * Alias for {@link #setFilter(String)}.
     *
     * @param filter
     * @return this {@link ICanFilterMask} instance (for chaining API calls)
     */
    @PublishedMethod
    ICanFilterMask filter(String filter);

    /**
     * Using {@link #setFilter(String)} this {@link ICanFilterMask}'s filter value can be specified.<div class="extdoc" id="setFilter"><!--Label:ICanFilterMask.setFilter-->
     * <h5>Specifying a CanFilterMask's Filter Value</h5>Using {@link #setFilter(String)} this {@link ICanFilterMask}'s filter value can be specified.</div> See
     * {@link #getFilter()} for a valid filter {@link String} values.
     *
     * @return this {@link ICanFilterMask}'s filter type
     */
    @PublishedMethod
    void setFilter(String filter);

    /**
     * {@link #getMdfObject()} returns the {@link MIContainer} represented by this {@link ICanFilterMask}.
     * <div class="extdoc" id="getMdfObject"><!--Label:ICanFilterMask.getMdfObject-->
     * <h5>Accessing a CanFilterMask's MIContainer</h5>{@link #getMdfObject()} returns the {@link MIContainer} represented by this {@link ICanFilterMask}.</div>
     *
     * @return the {@link MIContainer} represented by this {@link ICanFilterMask}
     */
    @Override
    @PublishedMethod
    MIContainer getMdfObject();

}
