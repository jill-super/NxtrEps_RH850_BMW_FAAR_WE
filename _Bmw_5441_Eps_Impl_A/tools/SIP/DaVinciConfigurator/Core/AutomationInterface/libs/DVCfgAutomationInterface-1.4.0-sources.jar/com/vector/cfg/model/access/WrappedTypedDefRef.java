package com.vector.cfg.model.access;

import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The <code>WrappedTypedDefRef</code> class represents an AUTOSAR definition reference with a type of the autosar model.
 * <p>
 * The {@link WrappedTypedDefRef} could additionally to a {@link TypedDefRef} save a WRAPPER class type for the MDF model. This is used to return the correct wrapper types by
 * APIs like the BswmdModel.
 * </p>
 *
 * <p>
 * DefRefs are constant; their values cannot be changed after they are created. This class is immutable!
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@Immutable
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class WrappedTypedDefRef<DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE, WRAPPER_TYPE> extends
        TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> {

    private static final long serialVersionUID = -7926072730975848555L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(WrappedTypedDefRef.class);

    private final Class<WRAPPER_TYPE> wrapperClass;

    WrappedTypedDefRef(
            String packagesPartOfDefRef,
            String moduleDefRef,
            @Nullable final String wholeDefRefString,
            Class<DEF_TYPE> modelDefinitionClass,
            Class<CONFIG_TYPE> modelConfigClass,
            Class<VALUE_TYPE> valueClass,
            Class<WRAPPER_TYPE> wrapperClass,
            @Nullable TypeInfo additionalInfos) {
        super(packagesPartOfDefRef, moduleDefRef, wholeDefRefString, modelDefinitionClass, modelConfigClass, valueClass, additionalInfos);

        if (wrapperClass == null) {
            throw new IllegalArgumentException("wrapperClass is null.");
        }
        this.wrapperClass = wrapperClass;

    }

    WrappedTypedDefRef(
            IDefRefWildcard packageWildcard,
            String moduleDefRef,
            Class<DEF_TYPE> modelDefinitionClass,
            Class<CONFIG_TYPE> modelConfigClass,
            Class<VALUE_TYPE> valueClass,
            Class<WRAPPER_TYPE> wrapperClass,
            @Nullable TypeInfo additionalInfos) {
        super(packageWildcard, moduleDefRef, modelDefinitionClass, modelConfigClass, valueClass, additionalInfos);

        if (wrapperClass == null) {
            throw new IllegalArgumentException("wrapperClass is null.");
        }
        this.wrapperClass = wrapperClass;
    }

    /**
     * Casts the passed {@link WrappedTypedDefRef} to a {@link TypedDefRef}, with the same generic types.
     *
     * @param <DEF> the generic type
     * @param <CFG> the generic type
     * @param <VAL> the generic type
     * @param defref The {@link WrappedTypedDefRef} to cast.
     * @return the casted element as {@link TypedDefRef}.
     */
    @PublishedMethod
    public static <DEF extends MIParamConfMultiplicity, CFG extends MIHasDefinition, VAL> TypedDefRef<DEF, CFG, VAL> castToTypedDefRef(
            WrappedTypedDefRef<DEF, CFG, VAL, ?> defref) {
        return defref;
    }

    /**
     * Casts this {@link WrappedTypedDefRef} to a {@link TypedDefRef}, with the same generic types.
     *
     * @param <DEF> the generic type
     * @param <CFG> the generic type
     * @param <VAL> the generic type
     * @return This {@link WrappedTypedDefRef} as element casted to {@link TypedDefRef}.
     */
    @PublishedMethod
    public TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> castToTypedDefRef() {
        return castToTypedDefRef(this);

    }

    /*
     * Public methods
     */

    /**
     * Returns the class object of the configuration elements, which have this definition.
     *
     * @return the class object of the configuration objects
     */
    @PublishedMethod
    public Class<WRAPPER_TYPE> getModelWrapperClass() {
        return wrapperClass;
    }

}
