package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIModelAccess;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.IGeneratorModelAccess;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.view.config.IModelView;

/**
 * Internal interface for {@link IGeneratorModelAccess} implementations.
 * <p>
 * <b>Attention:</b> DO NOT USE THIS INTERFACE. THIS INTERFACE IS INTERNALLY USED!!!
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IInternalGeneratorModelAccess extends GIModelAccess {

    /**
     * Switch view.
     */
    @PublishedMethod
    void switchView();

    /**
     * Restore view.
     */
    @PublishedMethod
    void restoreView();

    /**
     * The method {@link #getCreationModelView()} returns the {@link IModelView} of this {@link IInternalGeneratorModelAccess}, which was active during the creation of this
     * BswmdModel.
     *
     *
     * @return the creation model view of the BswmdModel
     *
     * <p>
     * The method will never return <code>null</code>.
     * </p>
     */
    @PublishedMethod
    IModelView getCreationModelView();

    /**
     * Assert that the current active {@link IModelView} is the bound / Creation Model view.
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the active view is not the bound/creation ModelView</li>
     * </ul>
     */
    @PublishedMethod
    void assertIsBoundViewActive();

    /**
     * Stores the relation between generator model object and MDF model object. This method shall be used model internal only!
     *
     * @param bswmdModelObject the bswmd model object
     * @param mdfObject the mdf object
     */
    @PublishedMethod
    void setRelatedElement(GIModelObject bswmdModelObject, MIHasDefinition mdfObject);

    /**
     * Returns the generator model object which is related to the specified MDF object or <code>null</code> if there is no related object.
     *
     * @param mdfObject is the MDF configuration object
     * @return the corresponding {@link GIModelObject}.
     */
    @PublishedMethod
    @Nullable
    GIModelObject getRelatedElement(MIHasDefinition mdfObject);

    /**
     * Gets the model verifier.
     *
     * @return the model verifier
     */
    @PublishedMethod
    GIModelVerifier getModelVerifier();

    /**
     * Invalidates the cache of the BswmdModel.
     *
     */
    @PublishedMethod
    void invalidateCache();

    /**
     * Verify if the cache is still valid, and invalidates the cache, if it was marked for invalidation.
     *
     * After a call to this method, you could use the internal caches.
     *
     */
    @PublishedMethod
    void checkCacheAndInvalidateIfNecessary();
}
