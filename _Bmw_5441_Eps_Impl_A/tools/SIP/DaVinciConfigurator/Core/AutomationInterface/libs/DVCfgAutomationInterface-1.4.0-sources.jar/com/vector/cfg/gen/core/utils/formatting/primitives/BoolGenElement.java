package com.vector.cfg.gen.core.utils.formatting.primitives;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.param.GBoolean;
import com.vector.cfg.gen.core.utils.formatting.IGenElement;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractPrimitiveElement;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The format element for Boolean objects
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class BoolGenElement extends AbstractPrimitiveElement<BoolGenElement> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(BoolGenElement.class);

    private Boolean boolObj;

    private boolean formatTypeWasSet = false;

    private EBoolFormatType formatType;

    private GBoolean bswmdModelObj;

    /**
     * Constructor for BoolGenElement.
     *
     */
    private BoolGenElement() {
        formatType = EBoolFormatType.STD_ON_OFF;

    }

    /**
     * Constructor for BoolGenElement.
     *
     * @param boolObj
     */
    BoolGenElement(boolean boolObj) {
        this(new Boolean(boolObj));
    }

    BoolGenElement(Boolean boolObj) {
        this();
        if (boolObj == null) {
            throw new IllegalArgumentException("boolObj is null");
        }

        this.boolObj = boolObj;

    }

    /**
     * Constructor for BoolGenElement.
     *
     * @param gBoolean
     */
    BoolGenElement(GBoolean gBoolean) {
        this();

        if (gBoolean == null) {
            throw new IllegalArgumentException("gBoolean is null");
        }

        bswmdModelObj = gBoolean;

        if (!bswmdModelObj.existsMDF()) {

            reportBswmdParamterNotExistsError(bswmdModelObj);

            this.boolObj = false;

        } else {
            this.boolObj = gBoolean.getValue();
        }
    }

    /**
     * Selects the STD_ON, STD_OFF format for the Boolean value. This means a true will generate a STD_ON, and a false will generate a STD_OFF.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     */
    @PublishedMethod
    public BoolGenElement asStdOnOff() {
        ensureObjectIsMutable();
        if (formatTypeWasSet) {
            throw new IllegalStateException("The boolean format type was already set! It is not allowed to change the format.");
        }

        formatType = EBoolFormatType.STD_ON_OFF;
        formatTypeWasSet = true;
        return this;
    }

    /**
     * Selects the TRUE, FALSE format for the Boolean value. This means a true will generate a TRUE, and a false will generate a FALSE.
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     */
    @PublishedMethod
    public BoolGenElement asTrueFalse() {
        ensureObjectIsMutable();
        if (formatTypeWasSet) {
            throw new IllegalStateException("The boolean format type was already set! It is not allowed to change the format.");
        }

        formatType = EBoolFormatType.TRUE_FALSE;
        formatTypeWasSet = true;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void generatePrimitiveInternal(StringBuilder builder, IGenFormatter formatter, int indent) {

        formatInternal(builder, boolObj, formatType);

    }

    /**
     * Format the passed {@link Boolean}, with the {@link EBoolFormatType}.
     *
     * @param boolObj the value
     * @param formatType the format type
     * @return the formatted string
     */
    @PublishedMethod
    public static String format(Boolean boolObj, EBoolFormatType formatType) {
        final StringBuilder builder = new StringBuilder();

        formatInternal(builder, boolObj, formatType);

        return builder.toString();
    }

    private static void formatInternal(StringBuilder builder, Boolean boolObj, EBoolFormatType formatType) {

        switch (formatType) {
        case STD_ON_OFF:
            if (boolObj) {
                builder.append("STD_ON");
            } else {
                builder.append("STD_OFF");
            }
            break;
        case TRUE_FALSE:
            if (boolObj) {
                builder.append("TRUE");
            } else {
                builder.append("FALSE");
            }
            break;
        default:
            throw new IllegalArgumentException("Illegal BoolFormatType found for format operation!");

        }
    }

    /**
     * The Format options of a {@link BoolGenElement}.
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    public enum EBoolFormatType {
        TRUE_FALSE,
        STD_ON_OFF,;
    }
}
