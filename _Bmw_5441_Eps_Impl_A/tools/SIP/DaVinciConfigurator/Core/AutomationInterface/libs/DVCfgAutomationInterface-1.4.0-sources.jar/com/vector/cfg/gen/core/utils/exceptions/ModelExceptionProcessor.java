package com.vector.cfg.gen.core.utils.exceptions;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import com.google.common.base.Optional;
import com.google.common.collect.Lists;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelException;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasValidationOrigin;
import com.vector.cfg.gen.core.moduleinterface.platform.GenPlatformServiceException;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.model.exceptions.ModelCeAlreadyRemovedException;
import com.vector.cfg.model.exceptions.ModelCeHasNoDefinitionException;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.model.exceptions.ModelVariantException;
import com.vector.cfg.model.exceptions.MultipleVariantObjectsException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaException;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.davinci.util.base.VUtil;

/**
 *
 * Utility class to process and transform {@link ModelException}s into a {@link IGeneratorResult} and report them to the framework.
 *
 * <p>
 * Example: The {@link ModelExceptionProcessor} inserts model exception into a {@link IValidationResultSink}.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IGeneratorPackage
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class ModelExceptionProcessor {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(ModelExceptionProcessor.class);

    private ModelExceptionProcessor() {
    }

    /**
     * The modelException is inserted in the resultSink.
     * <p>
     * The method returns immediately and you can proceed.
     * </p>
     *
     * @param ex The {@link ModelException} to report
     * @param generatorPackage The {@link IGeneratorPackage} which has issued the exception
     *
     * @exception IllegalArgumentException
     * <ul>
     *
     * <li>if the generatorPackageRef is null</li>
     * <li>if the ex is null</li>
     * </ul>
     *
     * @exception ModelException The passed modelException is rethrown, when if can't be inserted into the resultSink.
     */
    @PublishedMethod
    public static void addExceptionToResultSink(IGeneratorPackageReferable generatorPackageRef, ModelException ex) {
        if (generatorPackageRef == null) {
            throw new IllegalArgumentException("generatorPackageRef is null");
        }

        final IGeneratorResultSink resultSink = generatorPackageRef.getGeneratorPackage().getGenerationProcessor().getResultSink();
        addExceptionToResultSink(resultSink, ex, generatorPackageRef);
    }

    /**
     * The modelException is inserted in the resultSink.
     * <p>
     * The method returns immediately and you can proceed.
     * </p>
     *
     * @param resultSink The resultSink of the exception
     * @param ex The {@link ModelException} to report
     * @param generatorPackage The {@link IGeneratorPackage} which has issued the exception
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the resultSink is null</li>
     * <li>if the ex is null</li>
     * <li>if the generatorPackageRef is null</li>
     * </ul>
     *
     * @exception ModelException The passed modelException is rethrown, when if can't be inserted into the resultSink.
     */
    @PublishedMethod
    public static void addExceptionToResultSink(IValidationResultSink resultSink, ModelException ex, IGeneratorPackageReferable generatorPackageRef) {
        if (resultSink == null) {
            throw new IllegalArgumentException("resultSink is null");
        }

        final List<IGeneratorResult> resultList = wrapExceptionIntoGeneratorResults(ex, generatorPackageRef);
        for (final IGeneratorResult result : resultList) {
            resultSink.reportValidationResult(result);
        }
    }

    /**
     * The {@link ModelException} is wrapped into a {@link IGeneratorResult} objects.
     *
     * <p>
     * The method returns immediately and you can proceed.
     * </p>
     *
     * @param ex The {@link ModelException} to report
     * @param generatorPackageRef The {@link IGeneratorPackage} which has issued the exception
     * @return A list of {@link IGeneratorResult}s
     *
     * @exception ModelException The passed modelException is rethrown, when if can't be inserted into the resultSink.
     */
    @PublishedMethod
    public static List<IGeneratorResult> wrapExceptionIntoGeneratorResults(ModelException ex, IGeneratorPackageReferable generatorPackageRef) {
        if (generatorPackageRef == null) {
            throw new IllegalArgumentException("generatorPackageRef is null");
        }

        final IGeneratorPackage generatorPackage = generatorPackageRef.getGeneratorPackage();
        if (generatorPackage == null) {
            throw new IllegalArgumentException("generatorPackage is null");
        }

        return wrapExceptionIntoGeneratorResults(generatorPackage.getProjectContext(), ex, generatorPackage);
    }

    /**
     * The {@link ModelException} is wrapped into a {@link IGeneratorResult} objects.
     *
     * <p>
     * The method returns immediately and you can proceed.
     * </p>
     *
     * @param projectContext
     * @param ex The {@link ModelException} to report
     * @param origin The origin for the generated validation results.
     * @return A list of {@link IGeneratorResult}s
     *
     * @exception ModelException The passed modelException is rethrown, when if can't be inserted into the resultSink.
     */
    @KeepSecretFromPublishedApi
    public static List<IValidationResult> wrapExceptionIntoValidationResults(IProjectContext projectContext, IHasValidationOrigin origin, ModelException ex) {
        return VUtil.uncheckedCast(wrapExceptionIntoGeneratorResults(projectContext, ex, origin));
    }

    /**
     * The {@link ModelException} is wrapped into a {@link IGeneratorResult} objects.
     *
     * <p>
     * The method returns immediately and you can proceed.
     * </p>
     *
     * @param projectContext
     * @param ex The {@link ModelException} to report
     * @param origin The origin for the generated validation results.
     * @return A list of {@link IGeneratorResult}s
     *
     * @exception ModelException The passed modelException is rethrown, when if can't be inserted into the resultSink.
     */
    @KeepSecretFromPublishedApi
    private static List<IGeneratorResult> wrapExceptionIntoGeneratorResults(IProjectContext projectContext, ModelException ex, IHasValidationOrigin origin) {
        if (ex == null) {
            throw new IllegalArgumentException("ex is null");
        }
        if (ex instanceof GenPlatformServiceException && ex.getCause() instanceof ModelException) {
            ex = (ModelException) ex.getCause();
        }

        if (ex instanceof McaException) {
            return ModelCheckedAccessExceptionProcessor.wrapExceptionIntoGeneratorResults(projectContext, (McaException) ex, origin);
        }

        if (ex instanceof ModelCeHasNoDefinitionException) {
            return processHasNoDefinitionException(projectContext, (ModelCeHasNoDefinitionException) ex, origin);
        }

        if (ex instanceof ModelVariantException) {
            return processVariantException(projectContext, (ModelVariantException) ex, origin);
        }

        if (ex instanceof ModelCeAlreadyRemovedException) {
            return processAlreadyRemovedException(projectContext, (ModelCeAlreadyRemovedException) ex, origin);
        }

        if (ex instanceof BswmdModelException) {
            return processBswmdModelException(projectContext, (BswmdModelException) ex);
        }

        if (ex.getCause() instanceof ModelException) {
            try {
                return wrapExceptionIntoGeneratorResults(projectContext, (ModelException) ex.getCause(), origin);
            } catch (final ModelException thrownFrommSecondCall) {
                //Ignore the inner exception, because the outer one is thrown anyway and also contains more information then the inner one
                throw ex; //throw outer exception.
            }
        }

        // Can't process this type of ModelException
        throw ex;
    }

    /**
     * Process {@link ModelVariantException}s.
     *
     * <p>
     * EVAL00111243: AR4-597: Adapt the ModelExceptionProcessor to catch ModelVariantExceptions and convert it into a ValidationResult.
     * </p>
     *
     * @param ex the ex
     * @param generatorPackageRef the generator package ref
     * @return the list
     */
    private static List<IGeneratorResult> processVariantException(IProjectContext projectContext, ModelVariantException ex, IHasValidationOrigin origin) {
        final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(
                CommonGeneratorResultIds.getModelVariantVisibilityErrorId(origin), ex.getMessage());

        if (!ex.getSource().isPresent()) {
            // Without an element it make no sense to process the element though rethrow it
            throw ex;
        }

        builder.addErrorObject(ex.getSource().get());

        if (ex instanceof MultipleVariantObjectsException) {
            final MultipleVariantObjectsException mulVarEx = (MultipleVariantObjectsException) ex;

            if (mulVarEx.getAffectedObjects() != null) {
                final List<MIObject> list = new ArrayList<>(mulVarEx.getAffectedObjects());
                list.remove(ex.getSource().get());
                builder.addErrorMdfObjectList(list);
            }

        }

        final Optional<IModelView> modelViewDuringException = ex.getActiveModelViewDuringException();
        if (modelViewDuringException.isPresent()) {
            final IModelView modelView = modelViewDuringException.get();
            builder.addModelViewContext(modelView);
        }

        final IGeneratorResult result = builder.buildResult();
        ModelCheckedAccessExceptionProcessor.assignExceptionToGeneratorResult(result, ex);
        return Collections.singletonList(result);
    }

    /**
     * @param ex
     * @param generatorPackageRef
     * @return
     */
    private static List<IGeneratorResult> processHasNoDefinitionException(IProjectContext projectContext, ModelCeHasNoDefinitionException ex, IHasValidationOrigin origin) {

        final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(
                CommonGeneratorResultIds.getDefinitionMissingForCEErrorId(origin), ex.getMessage());

        builder.addErrorObject(ex.getCe());
        final IGeneratorResult result = builder.buildResult();
        ModelCheckedAccessExceptionProcessor.assignExceptionToGeneratorResult(result, ex);
        return Collections.singletonList(result);
    }

    private static List<IGeneratorResult> processAlreadyRemovedException(IProjectContext projectContext, ModelCeAlreadyRemovedException ex, IHasValidationOrigin origin) {

        final GeneratorResultBuilder builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getModelAccessFailureId(origin),
                ex.getMessage());

        final IGeneratorResult result = builder.buildResult();
        ModelCheckedAccessExceptionProcessor.assignExceptionToGeneratorResult(result, ex);
        return Collections.singletonList(result);
    }

    private static List<IGeneratorResult> processBswmdModelException(IProjectContext projectContext, BswmdModelException ex) {

        final List<IValidationResult> results = ex.getResults();

        final List<IGeneratorResult> genRes = Lists.newArrayList();
        for (final IValidationResult res : results) {
            if (res instanceof IGeneratorResult) {
                final IGeneratorResult genResult = (IGeneratorResult) res;
                ModelCheckedAccessExceptionProcessor.assignExceptionToGeneratorResult(genResult, ex);
                genRes.add(genResult);
            } else {
                throw new AssertionError("BswmdModel returned a non GeneratorResult!");
            }
        }

        return genRes;
    }

}