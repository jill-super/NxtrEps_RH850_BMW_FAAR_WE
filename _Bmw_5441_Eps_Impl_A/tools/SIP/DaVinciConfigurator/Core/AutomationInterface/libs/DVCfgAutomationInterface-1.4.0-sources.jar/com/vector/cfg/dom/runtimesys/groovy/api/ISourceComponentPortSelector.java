package com.vector.cfg.dom.runtimesys.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.dom.runtimesys.assistant.connection.EConnectorCreationType;

/**
 * The {@link ISourceComponentPortSelector} Api allows the definition of predicates for component port selection. it mainly consists of the {@link IComponentPortSelector} Api
 * but has enhancements for selecting source component ports for auto-mapping of ports.
 *
 * <div class="extdoc" id="ISourceComponentPortSelector">
 * <p>
 * Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and' predicates.
 * </p>
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISourceComponentPortSelector extends IComponentPortSelector {

    /**
     * Add a predicate which matches component ports which are service or application ports of service components.
     */
    @PublishedMethod
    void serviceMapping();

    @KeepSecretFromPublishedApi
    EConnectorCreationType getConnectionCreationType();

}
