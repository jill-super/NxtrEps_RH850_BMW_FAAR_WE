package com.vector.cfg.model.cedescriptor;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.cedescriptor.aspect.IAspectSetter;
import com.vector.cfg.model.mdf.MIObject;

/**
 *
 * Builder for creating IDescriptor objects.
 *
 * First call all relevant set methods and finish with the create method.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IDescriptorBuilder {

    /**
     * creates the descriptor.
     *
     * @return the descriptor
     */
    @PublishedMethod
    IDescriptor create();

    /**
     * sets the IDefRefAspect. If already set or descriptor already created, then an IllegalStateException is thrown.
     *
     * @param defRef
     * @return The builder
     * @throws IllegalStateException If the defRef is already set
     */
    @PublishedMethod
    IDescriptorBuilder setDefRef(DefRef defRef);

    /**
     * sets the IMdfFeatureAspect. If already set or descriptor already created, then an IllegalStateException is thrown.
     *
     * @param feature
     * @return The builder
     * @throws IllegalStateException If the feature is already set
     */
    @PublishedMethod
    IDescriptorBuilder setMdfFeature(String feature);

    /**
     * sets the IMdfObjectAspect. If already set or descriptor already created, then an IllegalStateException is thrown.
     *
     * @param mdfObject
     * @return The builder
     * @throws IllegalStateException If the mdfObject is already set
     */
    @PublishedMethod
    <T extends MIObject> IDescriptorBuilder setMdfObject(T mdfObject);

    /**
     * sets the IAutosarMetaDefAspect. If already set or descriptor already created, then an IllegalStateException is thrown.
     *
     * @param metaClass
     * @return The builder
     * @throws IllegalStateException If the feature is already set
     */
    @PublishedMethod
    <T extends MIObject> IDescriptorBuilder setMdfMetaClass(Class<T> metaClass);

    /**
     * sets a non standard IDescriptorAspect. If one of the predefined aspects is set via this method, an IllegalArgumentException is thrown. If an aspect is
     * set twice, then an IllegalStateException is thrown.
     *
     * @param aspectClass
     * @param aspect
     * @return The builder
     * @throws IllegalArgumentException If a predefined aspect passed as parameter
     * @throws IllegalStateException If an aspect is set twice
     */
    @PublishedMethod
    <T extends IDescriptorAspect> IDescriptorBuilder setAspect(Class<T> aspectClass, T aspect);

    /**
     * gets a specific IDescriptorAspectSetter, which could be used to set the corresponding aspect.
     *
     * @param aspectClass
     * @return The setter
     */
    @PublishedMethod
    <T extends IAspectSetter<? extends IDescriptorAspect>> T getSetter(Class<T> c);

}
