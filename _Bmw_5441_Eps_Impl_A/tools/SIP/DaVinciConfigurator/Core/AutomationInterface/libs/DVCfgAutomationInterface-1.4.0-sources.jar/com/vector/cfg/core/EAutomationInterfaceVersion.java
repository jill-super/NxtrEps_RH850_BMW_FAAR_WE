package com.vector.cfg.core;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import javax.annotation.concurrent.GuardedBy;
import javax.annotation.concurrent.ThreadSafe;

import org.eclipse.osgi.service.resolver.VersionRange;
import org.osgi.framework.Bundle;
import org.osgi.framework.Version;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedApiVersionInfo;
import com.vector.annotations.publishedapi.VersionType;
import com.vector.cfg.core.internal.Activator;

/**
 * The enum {@link EAutomationInterfaceVersion} describes the compatibility of the Cfg5 to the Automation interface clients.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public enum EAutomationInterfaceVersion {

    VERSION_1_0_0("1.0.0", "[1.0.0 , 1.1)", "Cfg5.13 - AR4-16"),
    VERSION_1_1_0("1.1.0", "[1.0.0 , 1.2)", "Cfg5.14 - AR4-17"),
    VERSION_1_2_0("1.2.0", "[1.0.0 , 1.3)", "Cfg5.15 - AR4-18"),
    VERSION_1_3_0("1.3.0", "[1.0.0 , 1.4)", "Cfg5.16 S-5 - AR4-19"),
    VERSION_1_4_0("1.4.0", "[1.0.0 , 1.5)", "Cfg5.16 - AR4-19"),
    ;

    /**
     * AutomationInterfaceVersionRange specifies the compatibility of Cfg Core Versions to external components automation scripts.
     *
     * <p>
     * This VersionRanges is used to determine which Automation scripts are compatible to the current Cfg5Core. The CFG_AUTOMATION_INTERFACE_VERSION_RANGE_STRING specifies the
     * current version. The VeersionRange should start at the last BreakingChange (e.g. MajorVersion 3.0.0) and end at the current Major.Minor Version incl. all patches<br />
     * Example: Current Version 1.4.0 => Range: [1.0.0,1.5)
     * </p>
     *
     */
    @PublishedApiVersionInfo(domainType = DomainType.AUTOMATION_IF, versionType = VersionType.VERSION_RANGE)
    public static final String CFG_AUTOMATION_INTERFACE_VERSION_RANGE_STRING = "[1.0.0 , 1.5)";

    /**
     * AutomationInterfaceVersion specifies the current version of the Cfg Core to external components automation scripts.
     *
     *
     * <p>
     * The AutomationInterfaceVersion version shall be incremented, when any PublishedAPI classes are changed. <br/>
     * <ul>
     * <li>Additions to classes => Increment Minor version</li>
     * <li>BreakingChanges to classes => Increment Major version</li>
     * </ul>
     * </p>
     *
     *
     * <p>
     * The following version history is a mapping from Cfg-Core version to Cfg5 releases / MICROSAR releases:
     * <ul>
     * <li><b>1.0.0</b>: Cfg5.13 - AR4-R16</li>
     * <li><b>1.1.0</b>: Cfg5.14 - AR4-R17</li>
     * <li><b>1.2.0</b>: Cfg5.15 - AR4-R18</li>
     * <li><b>1.3.0</b>: Cfg5.16 S-5 - AR4-19</li>
     * <li><b>1.4.0</b>: Cfg5.16 - AR4-R19</li>
     * </ul>
     * </p>
     *
     */
    @PublishedApiVersionInfo(domainType = DomainType.AUTOMATION_IF, versionType = VersionType.VERSION)
    public static final String CFG_AUTOMATION_INTERFACE_VERSION_STRING = "1.4.0";

    /* End JavaListing */

    @GuardedBy("Class Obj")
    private static EAutomationInterfaceVersion currentVersion;

    /**
     * Return the current {@link EAutomationInterfaceVersion} of this DaVinci Configurator at runtime.
     *
     * @return the current version.
     */
    public static EAutomationInterfaceVersion getCurrentVersion() {
        return initAndGetCurrentVersion();
    }

    private static EAutomationInterfaceVersion initAndGetCurrentVersion() {
        synchronized (EAutomationInterfaceVersion.class) {
            if (currentVersion != null) {
                return currentVersion;
            }
            final Optional<EAutomationInterfaceVersion> versionOf = versionOf(CFG_AUTOMATION_INTERFACE_VERSION_STRING);
            if (!versionOf.isPresent()) {
                throw new IncompatibleClassChangeError("The Current AutomationInterface " + CFG_AUTOMATION_INTERFACE_VERSION_STRING
                        + " has no corresponding EAutomationInterfaceVersion object. You have to create an enum literal for each version increment.");
            }

            verifyManifestMfVersion(versionOf.get().getVersion());
            currentVersion = versionOf.get();
            return currentVersion;
        }

    }

    private static void verifyManifestMfVersion(Version currentVersionOfCoreFeature) {
        final Bundle bundle = Activator.getContext().getBundle();
        final Version manifestMdfVersion = bundle.getVersion();

        if (manifestMdfVersion.getMajor() == currentVersionOfCoreFeature.getMajor()) {
            if (manifestMdfVersion.getMinor() == currentVersionOfCoreFeature.getMinor()) {
                if (manifestMdfVersion.getMicro() == currentVersionOfCoreFeature.getMicro()) {
                    // Both versions are equal => Valid
                    return;
                }
            }
        }
        /*
        throw new IncompatibleClassChangeError("The Manifest.MF Eclipse version " + manifestMdfVersion + " of " + bundle.getSymbolicName()
                + " is NOT equal to the AutomationInterfaceVersion " + currentVersionOfCoreFeature
                + ". Both versions must be the same in Major.Minor.Path. You have to synchronize these versions!");
                */

    }

    /**
     * Parses the passed versionStr and returns an {@link EAutomationInterfaceVersion}, if exists.
     *
     * @param versionStr the version to parse.
     * @return the {@link EAutomationInterfaceVersion} literal of the parsed version.
     */

    public static Optional<EAutomationInterfaceVersion> versionOf(String versionStr) {
        checkNotNull(versionStr);
        final String versionStrTemp = versionStr.trim();
        for (final EAutomationInterfaceVersion ver : values()) {

            if (versionStrTemp.equals(ver.getVersionString())) {
                return Optional.of(ver);
            }
        }
        return Optional.absent();
    }

    /*
     * Instance fields and methods
     */

    /**
     * Specifies the compatibility of Cfg Core Versions.
     *
     * @See IGeneratorPackage for the Corresponding Version
     */
    private final VersionRange versionRange;

    private final Version version;

    private final String versionString;

    private final String versionRangeString;

    private final String description;

    EAutomationInterfaceVersion(String versionStr, String versionRangeStr, String description) {
        versionString = versionStr;
        this.versionRangeString = versionRangeStr;
        this.description = description;

        this.versionRange = new VersionRange(versionRangeStr);
        version = org.osgi.framework.Version.parseVersion(versionStr);
        checkArgument(versionRange.includes(version));
    }

    /**
     * Returns the version as String.
     *
     * @return the version string
     */

    public String getVersionString() {
        return versionString;
    }

    public Version getVersion() {
        return version;
    }

    /**
     * Returns the versionRange as String.
     *
     * @return Returns the versionRange.
     */

    public String getVersionRangeString() {
        return versionRangeString;
    }

    /**
     * Return the compatible Core version range as {@link VersionRange} object.
     */

    public VersionRange getCompatibleCoreVersionRange() {
        return versionRange;
    }

    /**
     * Returns the description of the Version, to display for the user.
     * <p>
     * Normally this shall contain the Cfg5 version and the MICROSAR release.
     *
     *
     * @return Returns the description.
     */

    public String getDescription() {
        return description;
    }

    @Override
    public String toString() {
        return getDescription() + " (AutomationInterfaceVersion: " + getVersionString() + ")";
    }

    public String toStringWithRange() {
        return getDescription() + " (AutomationInterfaceVersion: " + getVersionString() + " Compatible range: " + getVersionRangeString() + ")";
    }
}
