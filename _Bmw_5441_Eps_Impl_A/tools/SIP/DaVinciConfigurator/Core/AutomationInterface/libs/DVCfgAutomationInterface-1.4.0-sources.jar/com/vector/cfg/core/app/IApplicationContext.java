package com.vector.cfg.core.app;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;
import java.util.Locale;

import org.osgi.framework.Version;

import com.google.inject.BindingAnnotation;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.internal.settings.LicenseManager;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.servicecontext.IServiceContext;
import com.vector.cfg.util.supervisor.IStateSupervisor;
import com.vector.cfg.util.version.IVersion;

/**
 * The application context provides all project independent services and access to the application state.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public interface IApplicationContext extends IStateSupervisor<IApplicationState>, IServiceContext {

    /**
     * This method will create a new ProjectContext.
     *
     * @return
     */
    IProjectContext createProjectContext();

    /**
     * Call this method to delete the ProjectContext.
     */
    void removeProjectContext();

    /**
     * Get the current {@link IProjectContext} instance.
     *
     * @return the project context.
     */
    IProjectContext getProjectContext();

    /**
     * Get the current application mode. Defaults to EApplicationMode.HEADLESS.
     *
     * @return
     */
    EApplicationMode getMode();

    /**
     * Set the current application mode. Needs to be set only if running in GUI mode, since the default is HEADLESS.
     */
    void setMode(EApplicationMode mode);

    /**
     * Init application settings.
     */
    void initializeApplicationSettings(Object settings);

    /**
     * Init generator settings.
     */
    void initializeGeneratorSettings(Object settings);

    /**
     * Enable {@link IApplicationContext} requires application settings.
     * <p>
     * This will enable that {@link IApplicationContext#getApplicationSettings()} will block until the {@link LicenseManager} was correctly initialized.
     * </p>
     *
     */
    void setRequiresApplicationSettings();

    /**
     * Enable {@link IApplicationContext} requires application settings.
     * <p>
     * This will enable that {@link IApplicationContext#getGeneratorSettings()} will block until the {@link LicenseManager} was correctly initialized.
     * </p>
     *
     */
    void setRequiresGeneratorSettings();

    /**
     * Get the current application settings.
     *
     * <p>
     * If the {@link #setRequiresApplicationSettings()} was set, this method will block until the {@link #initializeApplicationSettings(Object)} was called.
     * </p>
     */
    Object getApplicationSettings();

    /**
     * Get the current application settings.
     *
     * <p>
     * If the {@link #setRequiresGeneratorSettings()} was set, this method will block until the {@link #initializeGeneratorSettings(Object)} was called.
     * </p>
     */
    Object getGeneratorSettings();

    /**
     * Sets the current eclipse context of the running application.
     *
     * @param context
     */
    void setEclipseApplicationContext(org.eclipse.equinox.app.IApplicationContext context);

    /**
     * Gets the eclipse application context.
     *
     * @return the eclipse application context
     */
    org.eclipse.equinox.app.IApplicationContext getEclipseApplicationContext();

    /**
     * Get a formatted version string for displaying it within the application info.
     *
     * @return the application version string
     */
    String getApplicationVersion(Version version);

    /**
     * Get a formatted application display name that contains the beta flag info if required.
     *
     * @return the application name
     */
    String getApplicationName(String name, String ext);

    /**
     * Get the application beta flag.
     *
     * @return the beta flag of the application
     */
    boolean isBeta();

    /**
     * Get the 'Hotfix' build flag.
     */
    boolean isHotfix();

    /**
     * If set, the application should save as much memory as possible.
     */
    boolean isMemoryEcoMode();

    /**
     * Get the locale, that was active at the point the {@code IApplicationContext} was created.
     *
     * Always use this locale, since this stays constant even if the user changes the system locale during runtime. In this case he needs to restart the application.
     *
     * @return
     */
    Locale getLocale();

    /**
     * DvCfg Lib features enabled.
     *
     * @return true, if application is a DvCfg Lib, false, else.
     */
    boolean isDvCfgLibEnabled();

    /**
     * Support of using the MSR4 diagnostics configuration in a MSR3 delivery (see EVAL00100516 for details).
     *
     * @return true, if application is in MSR4 diagnostics in MSR3 mode; false, else.
     */
    boolean isASR4DiagnosticsInMSR3();

    /**
     * Get the SWC schema version number used to support using the MSR4 diagnostics configuration in a MSR3 delivery (see EVAL00100516 for details).
     *
     * @return the AUTOSAR schema version for generated SWCs for the ARS4 diagnostics in MSR3 feature.
     */
    IVersion getASR4DiagnosticsInMSR3SWCVersion();

    @Retention(RUNTIME)
    @Target({ ElementType.FIELD, ElementType.PARAMETER, ElementType.METHOD, ElementType.TYPE })
    @BindingAnnotation
    public @interface ApplicationContextService {

    }

    /**
     * Returns true, if the {@link IApplicationContext}, was already initialized. So the Injector inside was created. If the {@link IApplicationContext} is disposed, the method
     * will return <code>false</code>
     *
     * @return true, if initialized.
     *
     */
    boolean isInitialized();

}
