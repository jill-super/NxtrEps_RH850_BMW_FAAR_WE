package com.vector.cfg.consistency.contribution.helper.solvingactions.generic;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * This class is an {@link ISolvingAction} that sets a reference parameter when executed.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class SASetReference extends SASetNumTextRef<MIReferenceValue> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SASetReference.class);

    private final MIReferrable targetValue;

    /**
     * Constructor for SASetReference.
     *
     * @param param the reference parameter to be adjusted
     * @param targetValue the target value
     */
    @PublishedMethod
    public SASetReference(MIReferenceValue param, MIReferrable targetValue) {
        super(param, MixedText.newBuilder().append(targetValue).flushResult());
        this.targetValue = targetValue;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void run() {
        ModelUtil.getModelAccess(getParam()).setReferenceValue(getParam(), targetValue);
    }
}
