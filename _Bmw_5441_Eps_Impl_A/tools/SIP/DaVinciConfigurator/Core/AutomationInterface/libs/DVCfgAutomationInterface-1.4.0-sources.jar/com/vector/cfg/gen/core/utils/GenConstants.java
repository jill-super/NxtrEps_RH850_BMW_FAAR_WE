package com.vector.cfg.gen.core.utils;

import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;

/**
 * Generation Constants, like integer min max values.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GenConstants {

    private GenConstants() {

    }

    /**
     * <code>VECTOR_DEFAULT_GEN_PACKAGE</code> The VECTOR_DEFAULT_GEN_PACKAGE the default java package prefix for Vector internal generators.
     */
    @PublishedField
    public static final String VECTOR_DEFAULT_GEN_PACKAGE = "com.vector.cfg.gen";

    /*
     * C-Code
     */
    @PublishedField
    public static final String C_INCLUDE = "#include";

    @PublishedField
    public static final String C_DEFINE = "#define";

    @PublishedField
    public static final String C_VOID = "void";

    @PublishedField
    public static final String C_VOLATILE = "volatile";

    @PublishedField
    public static final String C_EXTERN = "extern";

    @PublishedField
    public static final String C_TYPEDEF = "typedef";

    @PublishedField
    public static final String C_NULL_PTR = "NULL_PTR";

    @PublishedField
    public static final String C_TRUE = "TRUE";

    @PublishedField
    public static final String C_FALSE = "FALSE";

    @PublishedField
    public static final String C_IF = "#if";

    @PublishedField
    public static final String C_IFDEF = "#ifdef";

    @PublishedField
    public static final String C_IFNDEF = "#ifndef";

    @PublishedField
    public static final String C_ELIF = "#elif";

    @PublishedField
    public static final String C_ELSE = "#else";

    @PublishedField
    public static final String C_ENDIF = "#endif";

    /* JavaListing GenConstants "Extract of the GenConstants class"*/
    @PublishedField
    public static final String C_STD_ON = "STD_ON";

    @PublishedField
    public static final String C_STD_OFF = "STD_OFF";

    @PublishedField
    public static final String C_E_OK = "E_OK";

    @PublishedField
    public static final String C_E_NOT_OK = "E_NOT_OK";

    /*
     * String Constants
     */

    /**
     * <code>LINE_SEPARATOR</code> The LINE_SEPARATOR of the current system.
     */
    @PublishedField
    public static final String LINE_SEPARATOR = System.getProperty("line.separator");

    /**
     * <code>EMPTY_STRING</code> An empty string.
     */
    @PublishedField
    public static final String EMPTY_STRING = "";

    /*
     * Boolean
     */
    @PublishedField
    public static final String TRUE_STRING = "true";

    @PublishedField
    public static final String FALSE_STRING = "false";
    /* End JavaListing */

    /*
     * Number
     */
    /*
     * ZERO
     */
    @PublishedField
    public static final BigInteger ZERO_BIGINT = BigInteger.valueOf(0);

    @PublishedField
    public static final long ZERO = 0;

    @PublishedField
    public static final String ZERO_STRING = "0";

    @PublishedField
    public static final double ZERO_DOUBLE = 0.0;

    /*
     * UINT8
     */
    @PublishedField
    public static final BigInteger MIN_UINT8_BIGINT = ZERO_BIGINT;

    @PublishedField
    public static final BigInteger MAX_UINT8_BIGINT = BigInteger.valueOf(255);

    @PublishedField
    public static final long MIN_UINT8 = 0;

    @PublishedField
    public static final long MAX_UINT8 = 255;

    @PublishedField
    public static final String MIN_UINT8_STRING = "0";

    @PublishedField
    public static final String MAX_UINT8_STRING = "255";

    /*
     * SINT8
     */
    @PublishedField
    public static final BigInteger MIN_SINT8_BIGINT = BigInteger.valueOf(Byte.MIN_VALUE);

    @PublishedField
    public static final BigInteger MAX_SINT8_BIGINT = BigInteger.valueOf(Byte.MAX_VALUE);

    @PublishedField
    public static final long MIN_SINT8 = Byte.MIN_VALUE;

    @PublishedField
    public static final long MAX_SINT8 = Byte.MAX_VALUE;

    @PublishedField
    public static final String MIN_SINT8_STRING = "-128";

    @PublishedField
    public static final String MAX_SINT8_STRING = "127";

    /*
     * UINT16
     */
    @PublishedField
    public static final BigInteger MIN_UINT16_BIGINT = BigInteger.valueOf(0);

    @PublishedField
    public static final BigInteger MAX_UINT16_BIGINT = BigInteger.valueOf(65535);

    @PublishedField
    public static final long MIN_UINT16 = 0;

    @PublishedField
    public static final long MAX_UINT16 = 65535;

    @PublishedField
    public static final String MIN_UINT16_STRING = "0";

    @PublishedField
    public static final String MAX_UINT16_STRING = "65535";

    /*
     * SINT16
     */
    @PublishedField
    public static final BigInteger MIN_SINT16_BIGINT = BigInteger.valueOf(Short.MIN_VALUE);

    @PublishedField
    public static final BigInteger MAX_SINT16_BIGINT = BigInteger.valueOf(Short.MAX_VALUE);

    @PublishedField
    public static final long MIN_SINT16 = Short.MIN_VALUE;

    @PublishedField
    public static final long MAX_SINT16 = Short.MAX_VALUE;

    @PublishedField
    public static final String MIN_SINT16_STRING = "-32768";

    @PublishedField
    public static final String MAX_SINT16_STRING = "32767";

    /*
     * UINT32
     */
    @PublishedField
    public static final BigInteger MIN_UINT32_BIGINT = BigInteger.valueOf(0);

    @PublishedField
    public static final BigInteger MAX_UINT32_BIGINT = BigInteger.valueOf(4294967295L);

    @PublishedField
    public static final long MIN_UINT32 = 0;

    @PublishedField
    public static final long MAX_UINT32 = 4294967295L; // This is 2^32-1

    @PublishedField
    public static final String MIN_UINT32_STRING = "0";

    @PublishedField
    public static final String MAX_UINT32_STRING = "4294967295"; // This is 2^32-1

    /*
     * SINT32
     */
    @PublishedField
    public static final BigInteger MIN_SINT32_BIGINT = BigInteger.valueOf(Integer.MIN_VALUE);

    @PublishedField
    public static final BigInteger MAX_SINT32_BIGINT = BigInteger.valueOf(Integer.MAX_VALUE);

    @PublishedField
    public static final long MIN_SINT32 = Integer.MIN_VALUE;

    @PublishedField
    public static final long MAX_SINT32 = Integer.MAX_VALUE;

    @PublishedField
    public static final String MIN_SINT32_STRING = Long.valueOf(Integer.MIN_VALUE).toString();

    @PublishedField
    public static final String MAX_SINT32_STRING = Long.valueOf(Integer.MAX_VALUE).toString();

    /*
     * UINT64
     */
    @PublishedField
    public static final BigInteger MIN_UINT64_BIGINT = BigInteger.valueOf(0);

    @PublishedField
    public static final BigInteger MAX_UINT64_BIGINT = new BigInteger("18446744073709551615");

    @PublishedField
    public static final String MIN_UINT64_STRING = "0";

    @PublishedField
    public static final String MAX_UINT64_STRING = "18446744073709551615"; // This is 2^64-1

    /*
     * SINT64
     */
    @PublishedField
    public static final BigInteger MIN_SINT64_BIGINT = BigInteger.valueOf(Long.MIN_VALUE);

    @PublishedField
    public static final BigInteger MAX_SINT64_BIGINT = BigInteger.valueOf(Long.MAX_VALUE);

    @PublishedField
    public static final long MIN_SINT64 = Long.MIN_VALUE;

    @PublishedField
    public static final long MAX_SINT64 = Long.MAX_VALUE;

    @PublishedField
    public static final String MIN_SINT64_STRING = Long.valueOf(Long.MIN_VALUE).toString();

    @PublishedField
    public static final String MAX_SINT64_STRING = Long.valueOf(Long.MAX_VALUE).toString();

}
