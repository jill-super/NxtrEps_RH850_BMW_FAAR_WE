package com.vector.cfg.dom.modemgt.groovy.api;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.dom.modemgt.groovy.bswm.BswMAutoConfigException;
import com.vector.cfg.dom.modemgt.groovy.bswm.IBswMAutoConfigurationApi;
import com.vector.cfg.dom.modemgt.groovy.bswm.IBswMAutoConfigurationDomain;
import com.vector.cfg.dom.modemgt.groovy.bswm.IBswMAutoConfigurationFeature;
import com.vector.cfg.dom.modemgt.groovy.bswm.IBswMAutoConfigurationParameter;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IModeManagementApi} provides high convenience support for mode management related use cases.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IModeManagementApi {

    /**
     * {@link #bswMAutoConfig(String, Closure)} provides access to the BswM auto configuration API.
     * <div class="extdoc" id="bswMAutoConfig"><!--Label:IModeManagementApi.bswMAutoConfig-->
     * <h5>Executing the BswM Auto Configuration</h5>{@link IModeManagementApi#bswMAutoConfig(String, Closure)} delegates the given code to the {@link IBswMAutoConfigurationApi}
     * of the given BswM auto configuration domain.
     *
     * </div>
     *
     * <p>
     * The method will open an <code>ITransaction</code> if one isn't already running.
     * </p>
     *
     * @param bswMAutoCfgDomainId the identifier of the BswM auto configuration domain (e.g. "ECU State Handling", "Communication Control", ...)
     * @param code the code configuring the given BswM auto configuration domain via the appropriate {@link IBswMAutoConfigurationApi}
     * @return the result calculated by the given code
     * @throws BswMAutoConfigException
     * <ul>
     * <li>if no matching BswM generator is part of the current SIP</li>
     * <li>if the auto configuration fails</li>
     * </ul>
     */
    @PublishedMethod
    <T> T bswMAutoConfig(String bswMAutoCfgDomainId, @VDelegatesToWithClosureParam(IBswMAutoConfigurationApi.class) Closure<T> code);

    /**
     * {@link #getBswMAutoConfigDomains()} provides read-access to all available BswM auto configuration domains.
     * <div class="extdoc" id="getBswMAutoConfigDomains"><!--Label:IModeManagementApi.getBswMAutoConfigDomains-->
     * <h5>Inspecting BswM Auto Configuration Domains</h5> The {@link #getBswMAutoConfigDomains()} method of the {@link IModeManagementApi} interface provides read-access to all
     * available BswM auto configuration domains. Available features and parameters can be inspected for various properties. See javadoc of {@link IBswMAutoConfigurationDomain},
     * {@link IBswMAutoConfigurationFeature} and {@link IBswMAutoConfigurationParameter} for details. </div>
     *
     * @throws IllegalArgumentException if there is no feature with the given identifier
     * @throws IllegalStateException if the feature with the given identifier is disabled
     */
    @PublishedMethod
    List<IBswMAutoConfigurationDomain> getBswMAutoConfigDomains();

    /**
     * Convenience access to an {@link IBswMAutoConfigurationDomain} with a given identifier.
     *
     * @param bswMAutoCfgDomainId the identifier of the desired {@link IBswMAutoConfigurationDomain}
     * @return the {@link IBswMAutoConfigurationDomain} with the given identifier
     * @throws IllegalArgumentException if there is no {@link IBswMAutoConfigurationDomain} with the given identifier
     */
    @PublishedMethod
    IBswMAutoConfigurationDomain bswMAutoConfigDomain(String bswMAutoCfgDomainId);

    /**
     * Convenience access to an {@link IBswMAutoConfigurationDomain} with a given identifier.
     *
     * @param bswMAutoCfgDomainId the identifier of the desired {@link IBswMAutoConfigurationDomain}
     * @param code the code inspecting the corresponding {@link IBswMAutoConfigurationDomain}
     * @return the result calculated by the given code
     * @throws IllegalArgumentException if there is no {@link IBswMAutoConfigurationDomain} with the given identifier
     */
    @PublishedMethod
    <T> T bswMAutoConfigDomain(String bswMAutoCfgDomainId, @VDelegatesToWithClosureParam(IBswMAutoConfigurationDomain.class) Closure<T> code);

}
