package com.vector.cfg.gen.core.moduleinterface.exceptions;

import java.util.Arrays;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;

/**
 * Thrown to indicate that the calculation process of the GeneratorPackage has failed.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @author virtu
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class CalculationFailedException extends GeneratorPackageException {

    private static final long serialVersionUID = 7554206824112621134L;

    /**
     * Constructs a new CalculationFailedException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genPackage The GeneratorPackage which has caused this exception.
     * @param genResult The GeneratorResult.
     *
     */
    @PublishedMethod
    public CalculationFailedException(IGeneratorResult genResult) {
        super(genResult);
    }

    /**
     * Constructs a new CalculationFailedException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genResult The GeneratorResult.
     * @param innerEx The cause (which is saved for later retrieval by the {@link #getCause()} method). (A <tt>null</tt> value is permitted, and indicates that
     * the cause is nonexistent or unknown.)
     */
    @PublishedMethod
    public CalculationFailedException(IGeneratorResult genResult, Throwable innerEx) {
        super(genResult, innerEx);
    }

    /**
     * Constructs a new CalculationFailedException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genResultList The List of GeneratorResults. For each item a Error will be reported in the Configurator.
     * @param innerEx The cause (which is saved for later retrieval by the {@link #getCause()} method). (A <tt>null</tt> value is permitted, and indicates that
     * the cause is nonexistent or unknown.)
     */
    @PublishedMethod
    public CalculationFailedException(List<? extends IGeneratorResult> genResultList, Throwable innerEx) {
        super(genResultList, innerEx);
    }

    /**
     * Constructs a new CalculationFailedException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genResultList The List of GeneratorResults. For each item a Error will be reported in the Configurator.
     */
    @PublishedMethod
    public CalculationFailedException(List<? extends IGeneratorResult> genResultList) {
        super(genResultList);
    }

    /**
     * Constructs a new CalculationFailedException for a GeneratorPackage
     * <p>
     * <b>Attention:</b> The IGeneratorResult must at least have severity {@link EValidationSeverityType#ERROR ERROR}!
     * </p>
     *
     * @param genResultList The List of GeneratorResults. For each item a Error will be reported in the Configurator.
     *
     */
    @PublishedMethod
    public CalculationFailedException(IGeneratorResult... genResultList) {
        super(Arrays.asList(genResultList));
    }
}
