package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.taskmapping.IEvent;
import com.vector.cfg.model.sysdesc.api.taskmapping.ITaskMapping;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IEventSelection"><!--Label:IEventSelection-->{@link IEventSelection} represents a selection of {@link IEvent}s and the possible operations on these
 * events.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IEventSelection {

    /**
     * <div class="extdoc" id="mapToTask"><!--Label:IEventSelection.mapToTask-->{@link #mapToTask(Closure)} tries to perform a task mapping for the selection of events
     * (triggers). Inside the closure the task mapping can be controlled, e.g. selecting the task to which the events should be mapped to and order the event's positions. Does
     * not consider events (triggers) which do not reference an executable entity (function).</div>
     *
     * <p>
     * The event selection will produce trace, info and warning logs. To see them, activate the '{@link com.vector.cfg.dom.runtimesys.groovy.api.IEventSelection}' logger with
     * the appropriate log level.
     * </p>
     *
     * @param code The code to provide select a task and order the task mappings.
     * @return A list of created task mappings.
     * @throws Throws a {@link SelectionException} if more than one or none task is selected inside the closure.
     */
    @PublishedMethod
    List<? extends ITaskMapping> mapToTask(@Nonnull @VDelegatesToWithClosureParam(ITaskMapper.class) Closure<?> code);

    /**
     * Allows access to the single events in the {@link IEventSelection}.
     *
     * @return The collection of selected events.
     */
    @PublishedMethod
    Collection<? extends IEvent> getEvents();

}
