package com.vector.cfg.gen.core.bswmdmodel.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Thrown to indicate that a requested model object does not exist.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class BswmdModelWrongQuantityException extends BswmdModelException {

    private static final long serialVersionUID = 1606544419978457169L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(BswmdModelWrongQuantityException.class);

    private final GIModelObject obj;

    /**
     * Constructor for BswmdModelNotExistsException.
     *
     * @param result the result
     * @param parent the parent
     * @param obj the obj
     */
    @PublishedMethod
    public BswmdModelWrongQuantityException(IValidationResult result, GIModelObject parent, GIModelObject obj) {
        super(result, parent);
        this.obj = obj;
    }

    /**
     * Gets the element, which has too few or too many siblings.
     *
     * @return the element
     */
    @PublishedMethod
    public GIModelObject getElement() {
        return obj;
    }

}
