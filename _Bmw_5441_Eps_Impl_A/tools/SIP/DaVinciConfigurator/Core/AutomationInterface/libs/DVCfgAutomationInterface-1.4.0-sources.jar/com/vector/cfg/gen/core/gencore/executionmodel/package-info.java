/**
 * Generation Process execution model defines, what to call during generation.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.gencore.executionmodel;