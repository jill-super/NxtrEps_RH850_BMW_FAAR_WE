package com.vector.cfg.model.access;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.IModelObject;

/**
 * {@link IHasModelObject} provides access to the underlying {@link IModelObject} of this wrapper instance.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasModelObject {

    /**
     * Returns the underlying {@link IModelObject} of this wrapper instance.
     *
     * <p>
     * The method will never return <code>null</code>.
     * </p>
     *
     * @return The {@link IModelObject} of this {@link IHasModelObject}.
     */
    @Nonnull
    @PublishedMethod
    IModelObject getMdfObject();

    /**
     * Converts the {@link #getMdfObject()} object to the passed type. This is mainly used for Groovy type conversion.
     *
     * @param <T> the type to cast to
     * @param clazz the clazz
     * @return the {@link #getMdfObject()} object casted to clazz, or <code>null</code>, if the types are incompatible.
     */
    @PublishedMethod
    @Nullable
    default <T> T asType(Class<T> clazz) {
        if (IModelObject.class.isAssignableFrom(clazz)) {
            return clazz.cast(getMdfObject());
        }
        return null;
    }

}
