/**
 * This package contains interfaces and classes for an automation client to interact with the consistency component.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
package com.vector.cfg.consistency.groovy.api;