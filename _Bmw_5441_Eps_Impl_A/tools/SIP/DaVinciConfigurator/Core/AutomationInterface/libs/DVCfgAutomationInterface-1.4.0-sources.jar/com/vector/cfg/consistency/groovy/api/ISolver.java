package com.vector.cfg.consistency.groovy.api;

import java.util.function.Consumer;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.ISolvingActionSummaryResult;
import com.vector.cfg.consistency.ui.ISolvingActionUI;
import com.vector.cfg.consistency.ui.IValidationResultUI;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * This interface is used to solve multiple results within one transaction.
 *
 * <div class="extdoc" id="solveTransactionHint"> Solving validation-results with solving-actions always creates a transaction implicitly. An {@link IllegalStateException} will
 * be thrown if this is done within an explicitly opened <code>transaction</code>.
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface ISolver {

    /**
     * Solve with the passed solving actions in one transaction.
     * <p/>
     * <strong>Please read the important note about invalidation in</strong> {@link ISolvingActionUI#solve()}
     *
     * @param solvingActions the solving-actions
     * @return the ISolvingActionSummaryResult
     */
    @PublishedMethod
    ISolvingActionSummaryResult solveSolvingActions(ISolvingActionUI... solvingActions);

    /**
     * <div class="extdoc" id="solveAllWithPreferredSolvingAction">{@link ISolver#solveAllWithPreferredSolvingAction()} solves all validation-results with its preferred solving-
     * action of each validation-result (solving-action return by {@link IValidationResultUI#getPreferredSolvingAction()}). Validation-results without a preferred solving-action
     * are skipped.
     *
     * This method first waits for background-validation-idle in order to have reproducible results.</div>
     *
     * @return the {@link ISolvingActionSummaryResult}
     */
    @PublishedMethod
    ISolvingActionSummaryResult solveAllWithPreferredSolvingAction();

    /**
     * <div class="extdoc" id="solve"> {@link ISolver#solve(Closure)} allows to solve multiple validation-results within one transaction.<br/>
     * You should always use this method to solve multiple validation-results at once instead of calling {@link ISolvingActionUI#solve()} in a loop. This is very important,
     * because solving one validation-result, may cause invalidation of another one. And calling {@link ISolvingActionUI#solve()} of an invalidated validation-result throws an
     * {@link IllegalStateException}. Also, invalidated validation-results may get recalculated and you would miss the recalculated validation-results with the loop approach.
     * But with {@link ISolver#solve(Closure)} you can solve invalidated->recalculated results as well as results which didn't exist at the time of the call (but have been
     * caused by solving some other validation-result).
     * <p/>
     * {@link ISolver#solve(Closure)} first waits for background-validation-idle in order to have reproducible results.
     * <p/>
     * The closure may contain multiple statements like:
     *
     * <code class="Java">result{specify result predicate}.withAction{select solving action}</code>
     *
     * All statements together will be used as a mapper from any solvable validation-result to a particular solving-action. The order of these statements does not affect the
     * solving action execution order. The statement order might only be relevant if multiple statements match on a particular result, but would select a different
     * solving-action. In that case, the first statement that successfully selects a solving-action wins.
     *
     * </div>
     *
     * <pre>
     * <code class="Java" id="idNotReferencedBecauseAnExecutableDemoTestExists">
    validation{
        assert validationResults.size() == 4
    
        solver.solve{
           result{isId("Tp", 12)}
                .withAction{containsString("next bigger valid value")}
            // Call result() and pass a closure that works as filter based on methods of IValidationResultUI.
            // On the returned call withAction() and pass a closure that selects a solving-action based on methods of IValidationResultForSolvingActionSelect
    
            // multiple such calls can be placed in one solve() call.
            result{isId("Com", 34)}.withAction{containsString("recalculate")}
        }
    
        assert validationResults.size() == 1
        // Three Tp12 and zero Com34 (didn't exist) results solved. One other left
    }
     * </code>
     * </pre>
     *
     * <div class="extdoc" id="solveReturn">{@link ISolver#solve(Closure)} returns an {@link ISolvingActionSummaryResult}.</div>
     *
     * @param client a closure that configures the {@link IResultFilterSolvingActionMapperBuilder}
     * @return the {@link ISolvingActionSummaryResult}
     * @throws SolverException in the case of an error.
     */
    @PublishedMethod
    ISolvingActionSummaryResult solve(@VDelegatesToWithClosureParam(IResultFilterSolvingActionMapperBuilder.class) Closure<?> clientBuilderConfigurer);

    /**
     * {@link #solve(Consumer)} allows to solve multiple validation results within one transaction.<br/>
     * This is the java pendant to {@link #solve(Closure)}.
     *
     * @param clientBuilderConfigurer a consumer that configures the received {@link IResultFilterSolvingActionMapperBuilder}
     * @return the {@link ISolvingActionSummaryResult}
     * @throws SolverException in the case of an error.
     */
    @PublishedMethod
    ISolvingActionSummaryResult solve(Consumer<IResultFilterSolvingActionMapperBuilder> clientBuilderConfigurer);

}
