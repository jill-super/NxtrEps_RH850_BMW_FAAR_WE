package com.vector.cfg.consistency.ui;

import java.util.Collection;
import java.util.Optional;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.contribution.IUISolvingAction;
import com.vector.cfg.consistency.services.IAcknowledgementManager;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.mdf.IModelObject;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.IViewedModelObject;
import com.vector.cfg.util.text.mixedtext.IMixedText;

/**
 * An {@link IValidationResultUI} describes an inconsistency in the data model.
 * <p>
 * This interface is not intended to be implemented by clients.<br/>
 * Only the consistency will create {@link IValidationResultUI} instances.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF, DomainType.AUTOMATION_IF_INTERNAL_ADDONS })
public interface IValidationResultUI extends IVariantContextInfoUI {
    /**
     * This method returns an AutoSolvingAction or null, which is used for executing during the validation phase of the uow.
     *
     * @return
     */
    @PublishedMethod
    ISolvingActionUI getAutoSolvingAction();

    /**
     * This method returns the preferred SolvingAction or null, which is used for the "solve all" mechanism of the validation view. Either this method or
     * {@link #getPreferredUISolvingAction()} may return a solving action, but not both.
     *
     * @return
     */
    @PublishedMethod
    ISolvingActionUI getPreferredSolvingAction();

    /**
     * This method returns the {@link IValidationResultId}.
     *
     * @return the id
     */
    @PublishedMethod
    IValidationResultId getId();

    /**
     * This is a convenience method to check if the result is of a particular id.
     *
     * @param origin the case sensitive origin
     * @param number the number
     * @return true, if the id matches
     */
    @PublishedMethod
    boolean isId(String origin, int number);

    /**
     * <div class="extdoc" id="getDescription">{@link IValidationResultUI#getDescription()} returns an {@link IMixedText} that describes the inconsistency.</div>
     *
     * @return the {@link IMixedText}
     */
    @PublishedMethod
    IMixedText getDescription();

    /**
     * This method returns the severity of the inconsistency.
     *
     * @return
     */
    @PublishedMethod
    EValidationSeverityType getSeverity();

    /**
     * This method returns all solving actions in a validator defined order.
     *
     * @return all solving actions
     */
    @PublishedMethod
    Collection<ISolvingActionUI> getSolvingActions();

    /**
     * This method returns the UI-SolvingAction collection. <BR>
     *
     * @return
     */
    @PublishedMethod
    Collection<IUISolvingAction> getUISolvingActions();

    /**
     * Gets the preferred UI solving action or null. Either this method or {@link #getPreferredSolvingAction()} may return a solving action, but not both.
     *
     * @return the preferred solving action
     */
    @PublishedMethod
    @ReworkThisAtNextBreakingChange //Don't publish this and rename to getPreferredGUISolvingAction
    IUISolvingAction getPreferredUISolvingAction();

    /**
     * This method returns the dependent CEs belonging to the validation result. The content of this collection is used technically for invalidation. Relevant for the user is
     * {@link #getErroneousCEs()}.
     *
     * @return
     */
    @PublishedMethod
    Collection<IDescriptor> getDependentCEs();

    /**
     * Returns the descriptors of error annotated elements.
     *
     * <div class="extdoc" id="getErroneousCEs">{@link IValidationResultUI#getErroneousCEs()} returns a collection of {@link IDescriptor}, each describing a CE that gets an
     * error annotation in the GUI.
     * <p>
     * To check for a certain model element is affected by the result please use the methods, which return <code>true</code>, if a model is affected by the validation-result:
     * <ul>
     * <li>{@link IValidationResultUI#matchErroneousCE(MIObject)}</li>
     * <li>{@link IValidationResultUI#matchErroneousCE(IHasModelObject)}</li>
     * <li>{@link IValidationResultUI#matchErroneousCE(MIHasDefinition, DefRef)}</li>
     * </ul>
     * </p>
     * </div>
     *
     * @return
     */
    @PublishedMethod
    Collection<IDescriptor> getErroneousCEs();

    /**
     * This method returns an IRule instance which reflects information from the contribution point, and it gives access to the IProjectContext.
     *
     * @return
     */
    @PublishedMethod
    IValidatorUI getRule();

    /**
     * This method returns the reduced-severity state.
     *
     * @return
     */
    @PublishedMethod
    boolean isReducedSeverity();

    /**
     * <div class="extdoc" id="getSolvingActionByGroupId"> A so called solving-action-group-ID identifies a solving-action uniquely within one validation-result. In other words,
     * two solving-actions, which do semantically the same, from two validation-results of the same result-ID (origin + number), belong to the same solving-action-group. This
     * semantical group may have an optional solving-action-group-ID, that can be used for solving-action identification within one validation-result.
     * <p/>
     * Keep in mind that the solving-action-group-ID is only unique within one validation-result-ID, and that the group-ID assignment is optional for a validator implementation.
     * <p/>
     * In order to find out the solving-action-group-IDs, press <code>CTRL+SHIFT+F9</code> with a selected validation-result to copy detailed information about that result
     * including solving-action-group-IDs (if assigned) to the clipboard.
     * <p/>
     * If group-IDs are assigned, it is much safer to use these for solving-action identification than description-text matching, because a description-text may change.</div>
     *
     * @param id the id
     * @return the solving action by group id or null
     */
    @PublishedMethod
    ISolvingActionUI getSolvingActionByGroupId(int id);

    /**
     * Gets a solving action group by group id or null if no solving action is assigned to a group with this id. A solving action group (id) is unique within one validation
     * result.
     *
     * @param id the id
     * @return the solving action by group id or null
     */
    @PublishedMethod
    ISolvingActionGroupUI getSolvingActionGroupByGroupId(int id);

    /**
     * Gets the optional acknowledgement. See also {@link IAcknowledgementManager}.
     *
     * @return the optional acknowledgement
     */
    @PublishedMethod
    Optional<String> getAcknowledgement();

    /**
     * Gets the optional cause/Throwable.
     *
     * @return the optional cause/Throwable
     */
    @PublishedMethod
    Optional<Throwable> getCause();

    /**
     * This method checks if this result annotates the passed CE.
     *
     * @param object the object
     * @return <code>true</code>, if the passed model object is annotated by this validation-result
     */
    @PublishedMethod
    boolean matchErroneousCE(MIObject object);

    /**
     * This method checks if this result annotates the passed CE.
     *
     * @param object the object
     * @return <code>true</code>, if the passed model object is annotated by this validation-result
     */
    @PublishedMethod
    default boolean matchErroneousCE(IHasModelObject object) {
        final IModelObject modelObject = object.getMdfObject();
        if (modelObject instanceof MIObject) {
            return matchErroneousCE((MIObject) modelObject);
        }
        return false;
    }

    /**
     * This method checks if this result annotates the passed CE including a model view. The CE will match, if the following condition is true:
     *
     * <pre>
     * <code>IValidationResultUI.matchErroneousCE(theObject) &&
     * (
     *   IValidationResultUI.isGeneralVariantContext() ||
     *   IValidationResultUI.getPredefinedVariantContexts().contains(theView)
     * )</code>
     * </pre>
     *
     * @param object the object
     * @return <code>true</code>, if the passed model object is annotated by this validation-result
     */
    @PublishedMethod
    default boolean matchErroneousCE(IViewedModelObject object) {
        final MIObject mdfObject = object.getMdfObject();
        final IModelView modelView = object.getCreationModelView();
        return matchErroneousCE(mdfObject) && isResultValidInModelView(modelView);
    }

    /**
     * This method checks if this result is valid in the model view. The model view will match, if the following condition is true:
     *
     * <pre>
     * <code>
     *   IValidationResultUI.isGeneralVariantContext() ||
     *   IValidationResultUI.getPredefinedVariantContexts().contains(theView)
     * </code>
     * </pre>
     *
     * @param modelView the modelView to check
     * @return <code>true</code>, if the passed model object is valid in the model view
     */
    @PublishedMethod
    default boolean isResultValidInModelView(IModelView modelView) {
        return isGeneralVariantContext() || getPredefinedVariantContexts().contains(modelView);
    }

    /**
     * This method checks if this result annotates an object with the passed {@link DefRef}, or denotes the passed {@link DefRef} as erroneous.<br/>
     * The match can be limited to the be a (direct or indirect) child of the optional parentObject parameter.
     *
     * @param parentObject the optional parent object
     * @param definition the definition
     * @return the match result
     */
    @PublishedMethod
    boolean matchErroneousCE(@Nullable MIHasDefinition optionalParentObject, DefRef definition);

    /**
     * Checks if a result is an on-demand result. On-demand results are visualized with a gear-wheel in the GUI.
     *
     * @return true, if it is an on-demand-result
     */
    @PublishedMethod
    boolean isOnDemandResult();

    /**
     * This method checks if the result is still active (hasn't been invalidated yet).
     *
     * @return true, if this result hasn't been invalidated.
     */
    @PublishedMethod
    boolean isActive();
}
