package com.vector.cfg.automation.api.domain;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IDomainApiEntryPoint} is the entry point for accessing different domain interfaces. <div class="extdoc" id="IDomainApiEntryPoint"><!--Label:IDomainApiEntryPoint-->The
 * domain API is the entry point for accessing the different domain interfaces. It is available in opened projects in the form of the {@link IDomainApi} interface.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDomainApiEntryPoint {

    /**
     * {@link #getDomain()} allows accessing the {@link IDomainApi} like a property.
     * <div class="extdoc" id="getDomain"><!--Label:IDomainApiEntryPoint.getDomain-->{@link #getDomain()} allows accessing the {@link IDomainApi} like a property.</div>
     *
     * @return the {@link IDomainApi}
     */
    @PublishedMethod
    IDomainApi getDomain();

    /**
     * {@link #domain(Closure)} allows accessing the {@link IDomainApi} in a scope-like way.
     * <div class="extdoc" id="domain"><!--Label:IDomainApiEntryPoint.domain-->{@link #domain(Closure)} allows accessing the {@link IDomainApi} in a scope-like way.</div>
     *
     * @param code the code (a {@link Closure}) working with the {@link IDomainApi}
     * @return the result produced by the given {@link Closure}
     */
    @PublishedMethod
    <T> T domain(@Nonnull @VDelegatesToWithClosureParam(IDomainApi.class) Closure<T> code);

}
