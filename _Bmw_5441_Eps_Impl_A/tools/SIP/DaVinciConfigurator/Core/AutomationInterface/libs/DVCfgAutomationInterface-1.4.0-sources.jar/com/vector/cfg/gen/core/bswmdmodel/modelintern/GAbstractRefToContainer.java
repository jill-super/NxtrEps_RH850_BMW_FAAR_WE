package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIReference;
import com.vector.cfg.gen.core.bswmdmodel.GIReferenceToContainer;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucContainerDefinition;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;

/**
 *
 * The abstract base class for bswmd model references.
 *
 * <p>
 * Attention: Please use {@link GIReference} interface in client code.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class GAbstractRefToContainer extends GAbstractRef<MIContainer> implements GIReferenceToContainer {

    /**
     * Constructor.
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GAbstractRefToContainer(DefRef defRef, MIReferenceValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, boolean onlyOneElement) {
        super(defRef, parameter, modelAccess, parent, onlyOneElement);
    }

    /**
     * Constructor.
     */
    @PublishedMethod
    public GAbstractRefToContainer(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MIReferenceValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIReferenceValue getMdfObject() {
        return (MIReferenceValue) super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIContainer getRefTargetMdf() {
        try {
            switchView();

            final MIReferrable target = super.getRefTargetMdf();

            getModelVerifier().assertReferenceTargetHasCorrectType(this, target, MIContainer.class);
            return (MIContainer) target;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public GIContainer getRefTarget() {
        try {
            switchView();

            final MIContainer target = getRefTargetMdf();

            final GIModelObject bswmdContainerByMdfContainer = getGenModelAccessInternal().getGenModelObjectByMDFObject(target);
            return (GIContainer) bswmdContainerByMdfContainer;

        } finally {
            restoreView();
        }
    }

    @KeepSecretFromPublishedApi
    protected void getPossibleRefTargetsInternal(final List<GIContainer> possibleTargets, final IEcucContainerDefinition targetDefinition) {
        if (targetDefinition != null && targetDefinition.getDef() != null) {
            final List<MIHasDefinition> allWithDefinition = getGenModelAccessInternal().getMdfModelAccess().getAllWithDefinition(DefRef.create(targetDefinition.getDef()));
            if (allWithDefinition != null && !allWithDefinition.isEmpty()) {
                allWithDefinition.forEach(def -> {
                    final GIModelObject genModelObjectByMDFObject = getGenModelAccessInternal().getGenModelObjectByMDFObject(def);
                    if (genModelObjectByMDFObject != null) {
                        possibleTargets.add((GIContainer) genModelObjectByMDFObject);
                    }
                });
            }
        }
    }

}
