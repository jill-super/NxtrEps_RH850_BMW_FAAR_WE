package com.vector.cfg.gen.core.bswmdmodel.groovy.api;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIModelFactory;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIModuleConfiguration;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.groovy.api.IMdfModelApi;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * {@link IBswmdModelApiEntryPoint} provides methods which allow retrieving BswmdModel objects in different ways .
 *
 * <div class="extdoc" id="Common"><!--Label:IBswmdModelApiEntryPoint-->
 * <p>
 * The <code>bswmdModel()</code> methods provide entry points to start navigation through the ActiveEcuc. Client code can use the {@link Closure} overloads to navigate into the
 * content of the found bswmd objects. Inside the called closure the related bswmd object is available as closure parameter.
 * </p>
 * <p>
 * The following types of entry points are provided here:
 * <ul>
 * <li>{@link #bswmdModel(WrappedTypedDefRef)} searches all objects with the specified definition and returns the BswmdModel instances.</li>
 * <li>{@link #bswmdModel(Class)} searches all objects with the specified class and returns the BswmdModel instances. Finds the same elements as above.</li>
 * <li>{@link #bswmdModel(MIHasDefinition, WrappedTypedDefRef)} returns the BswmdModel instance for the provided MDF model instance.</li>
 * <li>{@link #bswmdModel(Class, String)} searches all objects with the specified class and the matching path, see {@link IMdfModelApi#mdfModel(String)} or chapter
 * <!--LaTeX:\vref{sec:mdfModel_String}--> for details.</li>
 * </ul>
 * </p>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswmdModelApiEntryPoint {

    /**
     * Return the BswmdModelFactory of the running script task. This could be used to access low level access methods of the generated BswmdModel.
     *
     * @return the bswmd model factory
     */
    @PublishedMethod
    GIModelFactory getBswmdModelFactory();

    /**
     * Calls the closure for each single bswmd object found with the specified {@link DefRef}.
     *
     *
     * @param <BSWMD> the bswmd model instance type
     * @param defRef an definition to search for
     * @param code to execute for each element
     * @return The found object list
     */
    @PublishedMethod
    <BSWMD extends GIModelObject> List<BSWMD> bswmdModel(@DelegatesTo.Target WrappedTypedDefRef<?, ?, ?, BSWMD> defRef,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 3) @ClosureParams(value = FromString.class, options = "BSWMD") Closure<?> code);

    /**
     * Returns the bswmd objects found with the specified DefRef, or empty if no elements were found.
     *
     * @param <BSWMD> the bswmd model instance type
     * @param defRef an definition to search for
     * @return The found object list
     */
    @PublishedMethod
    <BSWMD extends GIModelObject> List<BSWMD> bswmdModel(WrappedTypedDefRef<?, ?, ?, BSWMD> defRef);

    /**
     * Calls the closure for each single bswmd object found for specified bswmd model class.
     *
     * <p>
     * Note: classes of non generated types, like {@link GIContainer}, will always return an empyt list.
     * </p>
     *
     * @param <BSWMD> the bswmd model instance type
     * @param bswmdModelClass the model class to search for
     * @param code to execute for each element
     * @return The found object list
     */
    @PublishedMethod
    <BSWMD extends GIModelObject> List<BSWMD> bswmdModel(@DelegatesTo.Target Class<BSWMD> bswmdModelClass,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(value = FromString.class, options = "BSWMD") Closure<?> code);

    /**
     * Returns the bswmd objects found with the specified bswmd model class, or empty if no elements were found.
     *
     * <p>
     * Note: classes of non generated types, like {@link GIContainer}, will always return an empyt list.
     * </p>
     *
     * @param <BSWMD> the bswmd model instance type
     * @param bswmdModelClass the model class to search for
     * @return The found object list
     */
    @PublishedMethod
    <BSWMD extends GIModelObject> List<BSWMD> bswmdModel(Class<BSWMD> bswmdModelClass);

    /**
     * Searches for model elements as specified in {@link IMdfModelApi#mdfModel(String)}.
     *
     *
     * <p>
     * The bswmdModelClass is either a GIXXX class like. GIContainer, or a generated classes like Dio.
     *
     * <pre>
     * <code class="Groovy" id=Usage">
     * def dioGeneral = bswmdModel(DioGeneral, "/ActiveEcuc/MyDio/MyDioGeneral").single
     * </code>
     * </pre>
     *
     *
     * </p>
     *
     * <p>
     * This method limits the search to the ActiveEcuC.
     * </p>
     *
     * @param <BSWMD> the (expected) model object type
     * @param path to search for see {@link IMdfModelApi#mdfModel(String)} for details
     * @return The found objects
     */
    @PublishedMethod
    <BSWMD extends GIModelObject> List<BSWMD> bswmdModel(Class<BSWMD> bswmdModelClass, String path);

    /**
     * Searches for model elements as specified in {@link IMdfModelApi#mdfModel(String)}.
     * <p>
     * The bswmdModelClass is either a GIXXX class like. GIContainer, or a generated class like Dio.
     * </p>
     *
     * <pre>
     * <code class="Groovy" id=Usage">
     * def dioGeneral = bswmdModel(DioGeneral, "/ActiveEcuc/MyDio/MyDioGeneral").single
     * </code>
     * </pre>
     *
     * <p>
     * This method does limit the search to the ActiveEcuC.
     * </p>
     *
     * @param <BSWMD> the (expected) model object type
     * @param code to execute for each element
     * @param path to search for
     * @return The found objects
     */
    @PublishedMethod
    <BSWMD extends GIModelObject> List<BSWMD> bswmdModel(@DelegatesTo.Target Class<BSWMD> bswmdModelClass, String path,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(value = FromString.class, options = "BSWMD") Closure<?> code);

    /**
     * Returns the found bswmd object from the passed MDF model object. The defRef must be the correct {@link DefRef} type of the passed model object. The defRef is used to
     * provide compile checks and code completion.
     *
     *
     * @param <CFG> the MDF model type
     * @param <BSWMD> the bswmd model instance type
     * @param obj the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    <CFG extends MIHasDefinition, BSWMD extends GIModelObject> BSWMD bswmdModel(
            CFG obj,
            WrappedTypedDefRef<?, CFG, ?, BSWMD> defRef);

    /**
     * Returns the found bswmd object from the passed {@link MIContainer} MDF model element.
     *
     * <p>
     * This allows you to access the BswmdModel by MDF model objects in a generic way, without knowing a {@link DefRef}. This is handy, if you want traverse an unknown Ecu
     * configuration structure.
     * </p>
     *
     * <p>
     * <b>Note: If you know a {@link DefRef} please use the other methods like {@link #bswmdModel(MIHasDefinition, WrappedTypedDefRef)} instead!</b>
     * </p>
     *
     * @param obj the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     * @see #bswmdModel(MIModuleConfiguration)
     * @see #bswmdModel(MIHasDefinition, WrappedTypedDefRef)
     */
    @PublishedMethod
    GIContainer bswmdModel(MIContainer obj);

    /**
     * Returns the found module configuration bswmd object from the passed {@link MIModuleConfiguration} MDF model element.
     *
     * <p>
     * This allows you to access the BswmdModel by MDF model objects in a generic way, without knowing a {@link DefRef}. This is handy, if you want traverse an unknown Ecu
     * configuration structure.
     * </p>
     *
     * <p>
     * <b>Note: If you know a {@link DefRef} please use the other methods like {@link #bswmdModel(MIHasDefinition, WrappedTypedDefRef)} instead!</b>
     * </p>
     *
     * @param obj the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found module configuration bswmd object
     * @see #bswmdModel(MIContainer)
     * @see #bswmdModel(MIHasDefinition, WrappedTypedDefRef)
     */
    @PublishedMethod
    GIModuleConfiguration bswmdModel(MIModuleConfiguration obj);

    /**
     * Calls the closure on the found single bswmd object from the passed MDF model object.
     *
     *
     * @param <CFG> the MDF model type
     * @param <BSWMD> the bswmd model instance type
     * @param obj the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    <CFG extends MIHasDefinition, BSWMD extends GIModelObject> BSWMD bswmdModel(
            CFG obj,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 3) @ClosureParams(value = FromString.class, options = "BSWMD") WrappedTypedDefRef<?, CFG, ?, BSWMD> defRef,
            Closure<?> code);

    /**
     * Returns the found bswmd object from the passed {@link IHasModelObject} domain model object.
     *
     * <div class="extdoc" id="BswmdModelAndDomainModels"> You can switch from domain models to the BswmdModel, if the domain model is backed by ActiveEcuC elements. Please read
     * the documentation of the different domain models, for whether this is possible for a certain domain model.
     *
     * To switch from a domain model to the BswmdModel, you can call one of the methods for {@link IHasModelObject}s like,
     * {@link #bswmdModel(IHasModelObject, WrappedTypedDefRef)}. But you need a {@link DefRef} to get the type safe BswmdModel object. The domain model documents, which DefRef
     * must be used for the certain domain model object.
     *
     * <pre>
     * <code class="Groovy" id="Switch from a domain model object to the corresponding BswmdModel object">
     * // Domain model object of the communication domain
     * ICanController canDomainModel = ...
     *
     * def canControllerBswmd = canDomainModel.bswmdModel(CanController.DefRef)
     *
     * // Or use a closure
     * canDomainModel.bswmdModel(CanController.DefRef){ canControllerBswmd ->
     *   //Use the bswmd object
     * }
     * </code>
     * </pre>
     *
     * </div>
     *
     * @param <CFG> the MDF model type
     * @param <BSWMD> the bswmd model instance type
     * @param obj the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     */
    @PublishedMethod
    <CFG extends MIHasDefinition, BSWMD extends GIModelObject> BSWMD bswmdModel(
            IHasModelObject obj,
            WrappedTypedDefRef<?, CFG, ?, BSWMD> defRef);

    /**
     * Calls the closure on the found single bswmd object from the passed {@link IHasModelObject} domain model object.
     *
     * <p>
     * See {@link #bswmdModel(IHasModelObject, WrappedTypedDefRef)} for more details.
     * </p>
     *
     * @param <CFG> the MDF model type
     * @param <BSWMD> the bswmd model instance type
     * @param obj the MDF model object to use
     * @param defRef an definition of the passed MDF object.
     * @return The found bswmd object
     * @see #bswmdModel(IHasModelObject, WrappedTypedDefRef)
     */
    @PublishedMethod
    <CFG extends MIHasDefinition, BSWMD extends GIModelObject> BSWMD bswmdModel(
            IHasModelObject obj,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 3) @ClosureParams(value = FromString.class, options = "BSWMD") WrappedTypedDefRef<?, CFG, ?, BSWMD> defRef,
            Closure<?> code);

}
