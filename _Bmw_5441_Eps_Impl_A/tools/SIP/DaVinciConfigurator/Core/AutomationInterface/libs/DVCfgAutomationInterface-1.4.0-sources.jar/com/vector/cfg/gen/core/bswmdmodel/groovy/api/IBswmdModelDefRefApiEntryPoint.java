package com.vector.cfg.gen.core.bswmdmodel.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;

/**
 * {@link IBswmdModelApiEntryPoint} provides methods to retrieve generated {@link DefRef} instances from the SIP without knowing the correct Java/Groovy imports. This is mainly
 * useful in script files, where no IDE helps with the imports.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswmdModelDefRefApiEntryPoint {

    /**
     * Returns the {@link IBswmdModelDefRefsApi} to retrieve generated {@link DefRef}s from the SIP.
     *
     * @return the sip DefRef API
     */
    @PublishedMethod
    IBswmdModelDefRefsApi getSipDefRef();

}
