package com.vector.cfg.gen.core.bswmdmodel;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.bswmdmodel.untyped.GUntypedModelFactory;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasValidationOrigin;
import com.vector.cfg.gen.core.utils.auxiliary.ValidatorResultOriginBuilder;
import com.vector.cfg.model.view.IModelViewManagerCoreInternal;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <div class="extdoc" id="Creation">
 * <h4>With Untyped ModelFactory</h4>{@link GModelFactory} provides creation helper method for {@link GIModelFactory GIModelFactories}, which has no other binding to any
 * generated BswmdModel. If you need only untyped instance, you could simple call the {@link #createFactory(IGeneratorPackageReferable)} method to get a new ModelFactory for a
 * generator.
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GModelFactory {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GModelFactory.class);

    /**
     * Creates a new {@link GIModelFactory} instance, which could be used to instantiate many BswmdModels, in different variants.
     *
     * @param genPackRef the gen pack ref
     * @return the GI model factory
     */
    @PublishedMethod
    public static GIModelFactory createFactory(IGeneratorPackageReferable genPackRef) {
        final IModelViewManagerCoreInternal viewMgr = genPackRef.getGeneratorPackage().getProjectContext().getService(IModelViewManagerCoreInternal.class);

        return new GUntypedModelFactory(viewMgr, genPackRef);
    }

    /**
     * Creates a new {@link GIModelFactory} instance, which could be used to instantiate many BswmdModels, in different variants.
     *
     * <div class="extdoc" id="CreationNonGeneratorPackage">
     * <h4>Untyped BswmdModel without an IGeneratorPackage (e.g. old automation use case)</h4> The BswmdModel also supports the use case without a generator. The method
     * <code>createFactory (IProjectContext, IHasValidationOrigin)</code> can create a ModelFactory with no binding to a generator ( {@link IGeneratorPackage}). Such a model
     * could be used for example in the Automation interface.
     * <p>
     * Note: The {@link IHasValidationOrigin} instance is used for {@link IValidationResult} creation, when an incorrect access is made in the BswmdModel.
     * </p>
     *
     * <p>
     * You could create an {@link IHasValidationOrigin} by using the {@link ValidatorResultOriginBuilder}.
     * </p>
     *
     * <pre>
     * <code class="Java" id="Create a GIModelFactory without a generator">
     *  IHasValidationOrigin origin = ValidatorResultOriginBuilder.createOrigin("MyMsn","MyComponent");
     *
     *  GIModelFactory modelFactory = GModelFactory.createFactory(getProjectContext(), origin);
     *
     *  //Use the modelFactory as the "normal" factory.
     * </code>
     * </pre>
     *
     * </div>
     *
     * @param projectContext the {@link IProjectContext}
     * @param validationResultOrigin The Validation resultOrigin.
     * @return the GI model factory
     */
    @PublishedMethod
    public static GIModelFactory createFactory(IProjectContext projectContext, IHasValidationOrigin validationResultOrigin) {
        final IModelViewManagerCoreInternal viewMgr = projectContext.getService(IModelViewManagerCoreInternal.class);
        return new GUntypedModelFactory(viewMgr, projectContext, validationResultOrigin);
    }

    private GModelFactory() {

    }
}
