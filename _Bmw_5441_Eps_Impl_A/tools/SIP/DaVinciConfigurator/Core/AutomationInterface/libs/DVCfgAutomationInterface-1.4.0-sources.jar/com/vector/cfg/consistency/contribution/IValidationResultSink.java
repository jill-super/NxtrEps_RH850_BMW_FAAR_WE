package com.vector.cfg.consistency.contribution;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.<BR>
 * <BR>
 * This interface represents something to which new ValidationResults have to be passed.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@NotThreadSafe
public interface IValidationResultSink {

    /**
     * You have to pass new ValidationResults to this method to publish them.
     */
    @PublishedMethod
    void reportValidationResult(IValidationResult result);
}
