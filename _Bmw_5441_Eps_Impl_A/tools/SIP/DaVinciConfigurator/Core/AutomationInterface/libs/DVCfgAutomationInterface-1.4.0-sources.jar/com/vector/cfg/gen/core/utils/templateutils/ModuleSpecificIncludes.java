package com.vector.cfg.gen.core.utils.templateutils;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.util.IProjectContext;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class ModuleSpecificIncludes {
    @SuppressWarnings("unused")
    // projectContext is added for expandability
    private final IProjectContext projectContext;

    private final IGeneratorPackage generatorPackage;

    @PublishedMethod
    public ModuleSpecificIncludes(IGeneratorPackage generatorPackage) {
        this.projectContext = generatorPackage.getProjectContext();
        this.generatorPackage = generatorPackage;
    }

    /**
     * Generic description. <br>
     * #define <MSN>_<START oder STOP>_SEC_<MemMapSektion> <br>
     * /* PRQA S 5087 1 * / /* MD_MSR_19.1 * / <br>
     * #include "MemMap.h" <br>
     * <br>
     * Sample:<br>
     * #define COMM_START_SEC_CONST_32BIT <br>
     * /* PRQA S 5087 1 * / /* MD_MSR_19.1 * / <br>
     * #include "MemMap.h" <br>
     *
     * @param isStart if true -> START is set, else STOP
     * @param memMapSektion Name of the MEmMapSektion
     * @return statement
     */
    @PublishedMethod
    public String memMapSektion(boolean isStart, String memMapSektion) {
        final String firstLine = String.format("#define %s_%s_SEC_%s", generatorPackage.getMSN().toUpperCase(), (isStart) ? "START" : "STOP", memMapSektion);
        return String.format("%s\n/* PRQA S 5087 1 */ /* MD_MSR_19.1 */\n#include \"MemMap.h\"", firstLine);
    }
}
