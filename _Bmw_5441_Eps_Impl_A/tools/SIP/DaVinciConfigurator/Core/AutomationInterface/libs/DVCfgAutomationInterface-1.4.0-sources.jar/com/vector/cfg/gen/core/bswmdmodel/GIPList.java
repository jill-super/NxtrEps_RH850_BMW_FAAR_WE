package com.vector.cfg.gen.core.bswmdmodel;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;

/**
 * Interface which represents a collection for {@link GIParamOrRef} with upper multiplicity > 1.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
//CHECKSTYLE:OFF Class Naming problem
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface GIPList<VALUE extends GIModelObject> extends GIList<VALUE> {
    //CHECKSTYLE:ON

}
