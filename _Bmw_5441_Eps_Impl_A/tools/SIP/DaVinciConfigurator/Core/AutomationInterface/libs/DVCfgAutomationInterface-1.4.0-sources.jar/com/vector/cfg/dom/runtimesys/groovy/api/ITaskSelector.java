package com.vector.cfg.dom.runtimesys.groovy.api;

import java.math.BigInteger;
import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link ITaskSelector} Api allows the definition of predicates for task selection.
 * <p>
 * <div class="extdoc" id="ITaskSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and' predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ITaskSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(ITaskSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(ITaskSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(ITaskSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches tasks with the given task name.</div>
     *
     * @param name A task name.
     */
    @PublishedMethod
    void name(@Nonnull String name);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches tasks with the given task name pattern.</div>
     *
     * @param namePattern A task name pattern.
     */
    @PublishedMethod
    void name(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="core">{@link #core(String)} matches tasks running on a core with the given name / number (whether a core name or a core number is used, depends on
     * the OS, if core number is used the String to be matched is 'Core&lt;number&gt;', e.g. 'Core1').</div>
     *
     * @param coreNameOrNumber A core name or number, depends on the OS.
     */
    @PublishedMethod
    void core(@Nonnull String coreNameOrNumber);

    /**
     * <div class="extdoc" id="corePattern">{@link #core(Pattern)} matches tasks running on a core with the given name pattern / number pattern (whether a core name or a core
     * number is used, depends on the OS, if core number is used the String to be matched is 'Core&lt;number&gt;', e.g. 'Core1').</div>
     *
     * @param coreNameOrNumber A core name or number pattern, depends on the OS.
     */
    @PublishedMethod
    void core(@Nonnull Pattern coreNameOrNumber);

    /**
     * <div class="extdoc" id="application">{@link #application(String)} matches tasks which belong to an application with the given name.</div>
     *
     * @param applicationName An OS application name.
     */
    @PublishedMethod
    void application(@Nonnull String applicationName);

    /**
     * <div class="extdoc" id="applicationPattern">{@link #application(Pattern)} matches tasks which belong to an application whose name matches the given name pattern.</div>
     *
     * @param applicationNamePattern An OS application name pattern.
     */
    @PublishedMethod
    void application(@Nonnull Pattern applicationNamePattern);

    // ----------------------------
    /**
     * <div class="extdoc" id="numberOfTaskMappings">{@link #numberOfTaskMappings(int)} matches tasks which already have the given number of task mappings. The predicate can
     * also be used to search for empty tasks with '0' as argument.</div>
     *
     * @param taskMappings The number of already existing task mappings on the task.
     */
    @PublishedMethod
    void numberOfTaskMappings(int taskMappings);

    /**
     * <div class="extdoc" id="priority">{@link #priority(BigInteger)} matches tasks with the given priority value.</div>
     *
     * @param priority The priority value.
     */
    @PublishedMethod
    void priority(@Nonnull BigInteger priority);

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches tasks for which the given closure results to true.</div>
     *
     * @param code The closure to select tasks.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(MIContainer.class) Closure<Boolean> code);

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<MIContainer> getSelectedTasks();

}
