package com.vector.cfg.automation.api.project;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.project.IProject;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.model.mdf.model.autosar.base.MIARPackage;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.version.IVersion;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;

/**
 * The Interface IProjectHandlingRawApi provides methods to handle raw AUTOSAR models.
 *
 * <div class="extdoc" id="Common"> Sometimes it could be helpful to create an empty AUTOSAR model or load single ARXML file. This is called raw mode
 * ({@link IProjectHandlingRawApi}).
 *
 * <p>
 * You could for example create an empty AUTOSAR model add elements and then export the snippet as an ARXML file.
 * </p>
 *
 * <p>
 * In raw mode most of the provided services and APIs will disabled, like:
 * <ul>
 * <li>Ecuc access</li>
 * <li>BswmdModel support</li>
 * <li>Generation</li>
 * <li>Validation</li>
 * <li>Workflow</li>
 * <li>Domain API</li>
 * <li>ChangeInspector</li>
 * <li>and more</li>
 *
 * </ul>
 *
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IProjectHandlingRawApi {

    /**
     * <div class="extdoc" id="emptyAutosarModel"> The {@link #emptyAutosarModel(String, Closure)} method creates a new empty AUTOSAR model, only containing one
     * {@link MIARPackage} created by this method with the path {@link AsrPath}.
     *
     * The passed AUTOSAR version defines the version of the AUTOSAR model, the version is specified in the format <code>&quot;4.2.1&quot; or  &quot;4.0.3&quot;, ...</code>
     *
     * </div>
     *
     * @param version the AUTOSAR version to create like &quot;4.2.1&quot;, see {@link IVersion} for details.
     * @param rootPackage the rootPackage to create in the empty model
     * @param code the code (a {@link Closure}) to be executed on the opened {@link IProject} and the create MIARPackage
     */
    @PublishedMethod
    <T> T emptyAutosarModel(String autosarVersion, AsrPath rootPackage,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, value = IProject.class) @VClassClosureParams({ IProject.class, MIARPackage.class }) Closure<T> code);
}