package com.vector.cfg.dom.modemgt.groovy.bswm;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.ScriptConverters;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;

/**
 * Interface for assigning a value to an BswM auto configuration parameter.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswMAutoConfigurationParameterSetter {

    /**
     * Assigns a {@code boolean} value to an BswM auto configuration parameter.
     *
     * @param value the value to be assigned to the BswM auto configuration parameter
     * @throws IllegalArgumentException if the underlying BswM auto configuration parameter is not of Boolean type
     */
    @PublishedMethod
    void to(boolean value);

    /**
     * Assigns a {@link BigInteger} value to an BswM auto configuration parameter.
     *
     * @param value the value to be assigned to the BswM auto configuration parameter
     * @throws IllegalArgumentException if the underlying BswM auto configuration parameter is not of type {@link BigInteger}
     * @see ScriptConverters#TO_BIG_INTEGER
     */
    @PublishedMethod
    void to(BigInteger value);

    /**
     * Assigns a {@link BigDecimal} value to an BswM auto configuration parameter.
     *
     * @param value the value to be assigned to the BswM auto configuration parameter
     * @throws IllegalArgumentException if the underlying BswM auto configuration parameter is not of type {@link BigDecimal}
     * @see ScriptConverters#TO_BIG_DECIMAL
     */
    @PublishedMethod
    void to(BigDecimal value);

    /**
     * Assigns a {@link String} value to an BswM auto configuration parameter.
     *
     * @param value the value to be assigned to the BswM auto configuration parameter
     * @throws IllegalArgumentException if the underlying BswM auto configuration parameter is not of type {@link String}
     */
    @PublishedMethod
    void to(String value);

    /**
     * Assigns an {@link MIReferrable} value to an BswM auto configuration parameter.
     *
     * @param value the value to be assigned to the BswM auto configuration parameter
     * @throws IllegalArgumentException if the underlying BswM auto configuration parameter is no reference parameter
     */
    @PublishedMethod
    void to(MIReferrable value);

}
