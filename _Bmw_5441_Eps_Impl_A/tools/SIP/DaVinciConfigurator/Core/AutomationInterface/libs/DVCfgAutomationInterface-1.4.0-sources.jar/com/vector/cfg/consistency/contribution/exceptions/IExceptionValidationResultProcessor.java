package com.vector.cfg.consistency.contribution.exceptions;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.model.exceptions.ModelException;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
@ReworkThisAtNextBreakingChange("Merge logic with  throws IExceptionValidationResultProcessorInternal")
public interface IExceptionValidationResultProcessor {

    /**
     * The {@link ModelException} is wrapped into a {@link IGeneratorResult} objects.
     *
     * <p>
     * The method returns immediately and you can proceed.
     * </p>
     *
     * @param ex The {@link ModelException} to report
     * @param validationResultIdMsn The Module which has issued the exception
     * @return A list of {@link IGeneratorResult}s
     *
     * @exception Exception The passed modelException is rethrown, when if can't be inserted into the resultSink.
     */
    @PublishedMethod
    <T extends IValidationResult> List<T> wrapExceptionIntoValidationResults(Exception ex) throws Exception;

}
