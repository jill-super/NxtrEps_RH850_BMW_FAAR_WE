package com.vector.cfg.gen.core.bswmdmodel.param;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractRef;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucForeignRefDefinition;
import com.vector.cfg.model.access.ecuconfiguration.reference.IEcucForeignReferenceParameter;
import com.vector.cfg.model.access.ecuconfiguration.reference.IEcucSimpleReferenceParameter;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrableARRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIForeignReferenceParamDef;

/**
 * ForeignReference parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GForeignReference extends GAbstractRef<MIReferrable> {

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public GForeignReference(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MIReferenceValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);

    }

    @Override
    @PublishedMethod
    protected void initRef() {
        final MIReferenceValue mdfObjLoc = getMdfObject();
        if (mdfObjLoc != null) {
            final MIReferrableARRef value = mdfObjLoc.getValue();
            if (value != null) {
                setPath(value.getValue());
                setTarget(value.getRefTarget());
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MIReferenceValue getMdfObjectUnsafe() {
        return (MIReferenceValue) super.getMdfObjectUnsafe();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIReferenceValue getMdfObject() {
        return (MIReferenceValue) super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIForeignReferenceParamDef getDefinition() {
        return (MIForeignReferenceParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucForeignRefDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucForeignReferenceParameter getEcuConfiguration() {

        final IEcucSimpleReferenceParameter cfg = getGeneratorModelAccess().getEcuConfigurationAccess().cfg(getMdfObject());
        return (IEcucForeignReferenceParameter) cfg;
    }

}
