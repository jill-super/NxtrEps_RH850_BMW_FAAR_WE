package com.vector.cfg.gen.core.utils.formatting;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The base interface of hierarchic arranged GenElements (e.g. array, structs), which support the generation of data with formating information.
 * <p>
 * Attention: This interface is not intended to be implemented by the user!
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IHierarchicGenElement extends IGenElement, IListGenElement {

    /**
     * Adds a comment text after the block open symbol (e.g. "{" ) of the {@link IHierarchicGenElement}. <br />
     * The style is following : <br/>
     * <code><ul> ElementValue &#47;*  commentParam  *&#47; </ul></code>
     *
     * <p>
     * Subsequent calls to {@link #afterBlockOpenComment(String)} are appended to one comment.
     * </p>
     *
     * @param commentParam The comment
     * @return The IHierarchicGenElement
     *
     * @throws IllegalArgumentException<ul>
     * <li>if commentParam is null.</li>
     * </ul>
     *
     */
    @PublishedMethod
    IHierarchicGenElement afterBlockOpenComment(String commentParam);

    /**
     * Adds a comment text before the block close symbol (e.g. "}" ) of the {@link IHierarchicGenElement}. <br />
     * The style is following : <br/>
     * <code><ul>&#47;*  commentParam  *&#47; ElementValue  </ul></code>
     *
     * <p>
     * Subsequent calls to {@link #beforeBlockCloseComment(String)} are appended to one comment.
     * </p>
     *
     * @param commentParam The comment
     * @return The GenElement
     *
     * @throws IllegalArgumentException<ul>
     * <li>if commentParam is null.</li>
     * </ul>
     *
     */
    @PublishedMethod
    IHierarchicGenElement beforeBlockCloseComment(String commentParam);
}
