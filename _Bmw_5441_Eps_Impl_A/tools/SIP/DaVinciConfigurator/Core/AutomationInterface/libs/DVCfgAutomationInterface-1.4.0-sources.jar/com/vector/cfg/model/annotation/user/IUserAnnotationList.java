package com.vector.cfg.model.annotation.user;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.state.ICeState;

/**
 * {@link IUserAnnotationList} represents a list of {@link IUserAnnotation}s with access method to retrieve annotations. See
 * {@link IUserAnnotation#getUserAnnotations(com.vector.cfg.model.mdf.ar4x.genericstructure.generaltemplateclasses.documentation.annotation.MIHasAnnotation)} for creation.
 *
 *
 * <div class="extdoc" id="Notes">
 * <p>
 * The {@link IUserAnnotationList} is not updated, when the underlying model changes. You have to retrieve a new instance of {@link IUserAnnotationList} to reflect changes.
 * </p>
 * <p>
 * The {@link IUserAnnotationList} is read only list and does not permit any modify operations defined in {@link java.util.List}, but certain operations like
 * {@link #createAndAdd(String)} will affect the list content. If you delete a contained {@link IUserAnnotation} the list will not be updated.
 * </p>
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see IUserAnnotation
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface IUserAnnotationList extends List<IUserAnnotation> {

    /**
     * Creates a new user annotation and appends it to this {@link IUserAnnotationList}. The new object is finally returned.
     *
     * <p>
     * Note: this method will also modify the underlying MDF model.
     * </p>
     *
     *
     * @param label the label of the annotation
     * @return the created element
     */
    @PublishedMethod
    IUserAnnotation createAndAdd(String label);

    /**
     * Returns all {@link IUserAnnotation} with the passed label.
     *
     * @param label the label
     * @return the filtered list
     */
    @PublishedMethod
    @Nonnull
    List<IUserAnnotation> allWithLabel(String label);

    /**
     * Returns the first {@link IUserAnnotation} retrieved with {@link #allWithLabel(String)}, or <code>null</code> if nothing was found.
     *
     * @param label the label
     * @return the filtered list
     */
    @PublishedMethod
    @Nullable
    IUserAnnotation byLabel(String label);

    /**
     * Returns the first {@link IUserAnnotation} retrieved with {@link #allWithLabel(String)}, or creates a new one with {@link #createAndAdd(String)}.
     *
     * @param label the label
     * @return the filtered list
     */
    @PublishedMethod
    @Nonnull
    IUserAnnotation byLabelOrCreate(String label);

    /**
     * Returns <code>true</code>, if there is at least one {@link IUserAnnotation} with the passed label.
     *
     * @param label the label
     * @return <code>true</code>, if existing, otherwise <code>false</code>
     */
    @PublishedMethod
    boolean exists(String label);

    /**
     * Returns the first {@link IUserAnnotation} retrieved with {@link #byLabel(String)}, or <code>null</code> if nothing was found.
     *
     * @param label the label
     * @return the found annotation
     * @see #byLabel(String)
     */
    @Nullable
    @PublishedMethod
    IUserAnnotation getAt(String label);

    /**
     * Returns <code>true</code> if an annotation can be added/removed below this object (see {@link ICeState#isAnnotationChangeable()}).
     *
     * @return
     */
    @PublishedMethod
    boolean isAnnotationCreateable();
}
