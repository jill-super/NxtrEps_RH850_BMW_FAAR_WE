package com.vector.cfg.gen.core.genusage.groovy.api;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.genusage.groovy.api.swct.IGenerationSwctApi;
import com.vector.cfg.gen.core.genusage.groovy.exceptions.GenerationProcessException;
import com.vector.cfg.gen.core.genusage.result.model.IGenerationResultModel;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IGenerationApi} is the entry point to the generation APIs and provide functionality for the generation process.
 *
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface IGenerationApi {

    /**
     * Opens a block to configure the Software Component Templates and Contract Phase Headers (Swct) generation.
     *
     * @param <T> return type of the code block
     * @param code the code to execution with the Swct API.
     * @return the returned value of the code block.
     * @see IGenerationSwctApi
     */
    @PublishedMethod
    <T> T swct(@VDelegatesToWithClosureParam(IGenerationSwctApi.class) Closure<T> code);

    /**
     * Returns the Software Component Templates and Contract Phase Headers (Swct) generation API.
     *
     * @return {@link IGenerationSwctApi}
     *
     */
    @PublishedMethod
    IGenerationSwctApi getSwct();

    /**
     * Opens an empty settings block. This block contains settings related to generation or validation.
     *
     * @param code Content of the block
     * @return
     */
    @PublishedMethod
    IGenerationSettingsApi settings(
            @VDelegatesToWithClosureParam(IGenerationSettingsApi.class) Closure<?> code);

    /**
     * Opens a settings block which already pre configured with the project settings from the dpa file. This block contains settings related to generation or validation.
     *
     * @param code Content of the block
     * @return
     */
    @PublishedMethod
    IGenerationSettingsApi settingsFromProject(
            @VDelegatesToWithClosureParam(IGenerationSettingsApi.class) Closure<?> code);

    /**
     * Returns the recently created settings object.
     *
     * @return The recently created settings object
     */
    @PublishedMethod
    IGenerationSettingsApi getSettings();

    /**
     * Starts the generation.<br/>
     * This method takes a settings object as an argument.<br/>
     * So it is possible to reuse a settings object.
     *
     * @param settings IGenerationSettingsApi object
     * @return The result of the generation process.
     * @exception GenerationProcessException if the generation has failed due to an unexpected exception.
     */
    @PublishedMethod
    IGenerationResultModel generate(IGenerationSettingsApi settings);

    /**
     * Starts the generation.<br/>
     * The last Settings block is used for generation or if no Settings block has been defined the standard project settings from the project file are used.
     *
     * @return The result of the generation process.
     * @exception GenerationProcessException if the generation has failed due to an unexpected exception.
     */
    @PublishedMethod
    IGenerationResultModel generate();

    /**
     * Starts the validation.<br/>
     * The last Settings block is used for generation or if no Settings block has been defined the standard project settings from the project file are used.
     *
     * @param settings IGenerationSettingsApi object
     * @return The result of the generation process.
     * @exception GenerationProcessException if the validation has failed due to an unexpected exception.
     */
    @PublishedMethod
    IGenerationResultModel validate(IGenerationSettingsApi settings);

    /**
     * Starts the validation.<br/>
     * The last Settings block is used for generation or if no Settings block has been defined the standard project settings from the project file are used.
     *
     * @return The result of the generation process.
     * @exception GenerationProcessException if the validation has failed due to an unexpected exception.
     */
    @PublishedMethod
    IGenerationResultModel validate();
}
