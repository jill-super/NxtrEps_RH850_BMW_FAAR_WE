package com.vector.cfg.gen.core.moduleinterface.auxiliary;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;

/**
 * The Class {@link IHasSetGeneratorPackage} provides a setter semantic for {@link IGeneratorPackage}s. E.g. A {@link IGeneratorResult} is a
 * {@link IHasSetGeneratorPackage}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasSetGeneratorPackage {

    /**
     * Sets the corresponding GeneratorPackage.
     * <p>
     * <b>Attention</b>: DO NOT USE THIS METHOD! This method is only for internal use! This method is not intended to be called by clients. It will called by
     * the framework.
     * </p>
     *
     * @param generatorPackage The {@link IGeneratorPackage} to set from the Framework.
     *
     * @exception IllegalArgumentException <ul>
     * <li>if generatorPackage is null</li>
     * </ul>
     */
    @PublishedMethod
    void setGeneratorPackage(IGeneratorPackage generatorPackage);
}
