package com.vector.cfg.gen.core.utils.auxiliary;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.gen.core.bswmdmodel.GModelFactory;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.auxiliary.IHasValidationOrigin;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The {@link ValidatorResultOriginBuilder} is used to create {@link IHasValidationOrigin}, which are needed for a BswmdModel without any
 * {@link IGeneratorPackage}. Like calls to {@link GModelFactory#createFactory(com.vector.cfg.util.IProjectContext, IHasValidationOrigin)} needs a
 * {@link IHasValidationOrigin}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see IHasValidationOrigin
 * @see GModelFactory
 * @see IValidationResultId
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class ValidatorResultOriginBuilder {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(ValidatorResultOriginBuilder.class);

    /**
     * Creates a new {@link IHasValidationOrigin}, used for example the the BswmdModel, when no {@link IGeneratorPackage} is available.
     *
     * @param origin the origin of the component. Mostly the MSN. See {@link IValidationResultId#getOrigin()}
     * @param name A descriptive name of the component. This could be used in the {@link IValidationResultId#getMessage()} text.
     * @return the new ValidatioNresultOrigin.
     */
    @PublishedMethod
    public static IHasValidationOrigin createOrigin(final String origin, final String name) {
        checkNotNull(origin);
        checkArgument(!origin.isEmpty());
        checkNotNull(name);
        checkArgument(!name.isEmpty());

        return new IHasValidationOrigin() {

            @Override
            public String getOrigin() {
                return origin;
            }

            @Override
            public String getGeneratorName() {
                return name;
            }
        };
    }

    private ValidatorResultOriginBuilder() {

    }
}
