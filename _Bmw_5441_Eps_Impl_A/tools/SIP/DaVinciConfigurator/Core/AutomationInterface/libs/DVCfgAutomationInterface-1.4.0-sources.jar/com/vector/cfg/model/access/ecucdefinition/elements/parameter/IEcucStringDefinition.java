package com.vector.cfg.model.access.ecucdefinition.elements.parameter;

import java.math.BigInteger;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIStringParamDef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucStringDefinition extends IEcucParameterDefinition {

    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    MIStringParamDef getDef();

    /**
     * returns the optional default value. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<String> getDefault();

    /**
     * returns the optional minimal length. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<BigInteger> getMinLength();

    /**
     * returns the optional max length. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<BigInteger> getMaxLength();

    /**
     * returns the optional validation regex. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<String> getValidationRegex();
}
