package com.vector.cfg.gen.core.bswmdmodel;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.view.IModelViewManagerCoreInternal;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.variant.IPredefinedVariantView;
import com.vector.cfg.model.view.config.variant.IUnfilteredView;
import com.vector.cfg.util.IProjectContext;

/**
 * <div class="extdoc" id="Common"> A {@link GIModelFactory} provides methods to instantiate both model types (BswmdModel and DefRef API) seamlessly.
 * <p>
 * The general use case for the client is to create <b>ONE</b> factory at the start of the generation process and calling
 * <code>GIModelFactory.getInstance(Class, MIHasDefinition)</code> for each {@link IPredefinedVariantView} and each {@link GIModuleConfiguration}, and then discard the factory.
 * </p>
 *
 * <p>
 * <b>Attention:</b> DO NOT reuse the factory instance over Generation execution runs!
 * </p>
 * </div>
 *
 * <div class="extdoc" id="PostBuildSelectable"> A {@link GIModelFactory} also supports multi variant bsmwd models for the Post-build selectable access for e.g. code generation
 * in a Generator. The {@link GIModelFactory} caches the active view during the Model creation and delegates to the correct GeneratorModelAccess class for each active variant.
 * This allows the navigate to different views via {@link GIModelObject}.
 *
 *
 * </div>
 *
 *
 * <div class="extdoc" id="GeneratedModelFactory"><!--LaTeX:\label{subsec:GeneratedModelFactory}-->
 * <h4>With DefinitionTyped (generated) ModelFactory</h4> Every DefinitionTyped BswmdModel has its own factory &lt;Module&gt;ModelFactory which provides a method
 * <code>get&lt;Module&gt;ModuleConfig()</code> to get a module configuration.
 *
 * <pre>
 * <code class="Java" id="Creates a new module configuration instance with a DefinitionTyped ModelFactory">
 * final CanIfModelFactory factory = CanIfModelFactory.createFactory(generatorPackage);
 *
 * final CanIf canIfModule = factory.getCanIfModuleConfig();
 * </code>
 * </pre>
 *
 * </div>
 *
 * <div class="extdoc" id="GeneratedModelFactory_Container"> A DefinitionTyped ModelFactory can be used for each type of elements (module configurations, container, parameter)
 * and will create definition typed element if possible before it creates untyped elements. So when you request a <code>CanIfModelFactory</code> to create a
 * <code>CanIfContainer</code> you will get an instance of <code>CanIfContainer</code>, but if you request a <code>ComContainer</code> and this container is not generated in the
 * CanIf model you will get an instance of <code>GIContainer</code>.
 *
 * </div>
 *
 * <div class="extdoc" id="GeneratedModelFactory_Without_Generator">
 * <h4>DefinitionTyped ModelFactory without generator (e.g. old automation use case)</h4> You can use the generated ModelFactories also without a generator according to the
 * untyped factories. So an automation client can instantiate a BswmdModel although the client has no IGeneratorPackage.
 *
 * </div>
 *
 *
 * <p>
 * Note: You could use the method {@link GModelFactory#createFactory(com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable)} to create a {@link GIModelFactory} for
 * an "untyped" bswmd model.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIModelFactory {
    // CHECKSTYLE:ON

    /**
     * Returns a bswmd model instance for the passed {@link MIHasDefinition} (mdfCfgElement). The element will be casted to type giModelClazz.
     *
     * <p>
     * Note: The used {@link IModelView} is the current active {@link IModelView}, from the {@link IModelViewManagerCoreInternal#getCurrentlyActiveView()}!
     * </p>
     *
     * @param <T> the generic type
     * @param giModelClazz the class of the bswmd model element.
     * @param mdfCfgElement the MDF configuration element.
     * @return single instance for the passed {@link MIHasDefinition}.
     */
    @PublishedMethod
    <T extends GIModelObject> T getInstance(Class<T> giModelClazz, MIHasDefinition mdfCfgElement);

    /**
     * Returns a bswmd model instance for the passed {@link MIHasDefinition} (mdfCfgElement). The element will be casted to type giModelClazz.
     *
     * @param <T> the generic type
     * @param giModelClazz the class of the bswmd model element.
     * @param mdfCfgElement the MDF configuration element.
     * @param the View which is used for the bswmdModel element and all sub requests.
     * @return single instance for the passed {@link MIHasDefinition}.
     */
    @PublishedMethod
    <T extends GIModelObject> T getInstance(Class<T> giModelClazz, MIHasDefinition mdfCfgElement, IModelView viewToBindToElement);

    /**
     * <div class="extdoc" id="getAllInstancesForAllPostBuildVariants">The method <code>getAllInstancesForAllPostBuildVariants()</code> returns all instances of the
     * {@link DefRef} in the project, for each Post-build selectable variant in the project. The returned type in the BswmdModel instance of the passed class (giModelClazz).
     *
     * <p>
     * If the project has no variant, the {@link IUnfilteredView} is used.
     * </p>
     *
     * </div>
     *
     * @param <T> the generic type
     * @param giModelClazz The BswmdModel class.
     * @param defRefOfRequestedElement the {@link DefRef} of requested elements.
     * @return the all instances of type {@link DefRef} for all post build variants, or {@link IUnfilteredView}.
     */
    @PublishedMethod
    <T extends GIModelObject> List<T> getAllInstancesForAllPostBuildVariants(Class<T> giModelClazz, DefRef defRefOfRequestedElement);

    /**
     * The method <code>getAllInstancesForCurrentActiveView()</code> returns all instances of the {@link DefRef} in the project, for the current active view. The returned type
     * in the BswmdModel instance of the passed class (giModelClazz).
     *
     * @param <T> the generic type
     * @param giModelClazz The BswmdModel class.
     * @param defRefOfRequestedElement the {@link DefRef} of requested elements.
     * @return the all instances of type {@link DefRef}.
     */
    @PublishedMethod
    <T extends GIModelObject> List<T> getAllInstancesForCurrentActiveView(WrappedTypedDefRef<?, ?, ?, T> defRefOfRequestedElement);

    /**
     * <div class="extdoc" id="getAllInstancesForAllPostBuildVariants_WithMdfElement"> The method <code>getAllInstancesForAllPostBuildVariants(Class, MIHasDefinition)</code>
     * returns all instances of the {@link MIHasDefinition mdfCfgElement}, for each Post-build selectable variant in the project. The returned type in the BswmdModel instance of
     * the passed class (giModelClazz). You get al list containing a BswmdModel instance of the {@link IModelView} in which the passed MDF element (mdfCfgElement) is visible.
     *
     * </div>
     * <p>
     * If the project has no variant, the {@link IUnfilteredView} is used.
     * </p>
     *
     * @param <T> the generic type
     * @param <R> the generic type
     * @param giModelClazz The BswmdModel class.
     * @param mdfCfgElement the MDF configuration element.
     * @return the all instances of type mdfCfgElement for all post build variants, or {@link IUnfilteredView}.
     */
    @PublishedMethod
    <T extends GIModelObject> List<T> getAllInstancesForAllPostBuildVariants(Class<T> giModelClazz, MIHasDefinition mdfCfgElement);

    /**
     * Gets the project context.
     *
     * @return the project context
     */
    @PublishedMethod
    IProjectContext getProjectContext();

}
