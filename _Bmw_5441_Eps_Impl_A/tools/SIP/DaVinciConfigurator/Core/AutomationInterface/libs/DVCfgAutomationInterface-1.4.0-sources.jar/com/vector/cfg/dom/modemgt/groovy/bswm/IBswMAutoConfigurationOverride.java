package com.vector.cfg.dom.modemgt.groovy.bswm;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;

/**
 * {@link IBswMAutoConfigurationOverride} is for deciding on what is to become of previously applied manual adaptations to the BswM auto configuration content on subsequent auto
 * confugration runs.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IBswMAutoConfigurationOverride {

    /**
     * {@link #isAddition()} returns {@code true} if the manual adaption consists of an element having been added to the BswM auto configuration content. Access the element
     * using {@link #getElement()}.
     *
     * @return {@code true} if the manual adaption consists of an element having been added to the BswM auto configuration content
     */
    @PublishedMethod
    boolean isAddition();

    /**
     * {@link #isRemoval()} returns {@code true} if the manual adaption consists of an element having been removed from the BswM auto configuration content. Access the element
     * using {@link #getElement()}.
     *
     * @return {@code true} if the manual adaption consists of an element having been removed from the BswM auto configuration content
     */
    @PublishedMethod
    boolean isRemoval();

    /**
     * {@link #isModification()} returns {@code true} if the manual adaption consists of an {@link MIParameterValue}'s value having been modified in the BswM auto configuration
     * content. Access the {@link MIParameterValue} using {@link #getElement()}.
     *
     * @return {@code true} if the manual adaption consists of an {@link MIParameterValue}'s value having been modified in the BswM auto configuration content
     */
    @PublishedMethod
    boolean isModification();

    /**
     * {@link #getElement()} returns the element to which the manual adaptation has been applied.
     *
     * @return the element to which the manual adaptation has been applied
     */
    @PublishedMethod
    MIHasDefinition getElement();

    /**
     * Applicable for modifications only ({@link #isModification()} returns {@code true}). {@link #getUserValue()} returns the value which the BswM auto configuration
     * {@link MIParameterValue} has been changed to.
     *
     * @return the value which the BswM auto configuration {@link MIParameterValue} has been changed to
     */
    @PublishedMethod
    Object getUserValue();

    /**
     * Alias of {@link #keepOverride()} allowing notation without brackets in groovy.
     *
     * @return {@code null}
     */
    @PublishedMethod
    Void getKeepOverride();

    /**
     * Call this if the corresponding manual adaptation shall remain part of the configuration. Must only be called once.
     *
     * @throws IllegalStateException if {@link #keepOverride()} or {@link #discardOverride()} has already been called
     */
    @PublishedMethod
    void keepOverride();

    /**
     * Alias of {@link #discardOverride()} allowing notation without brackets in groovy.
     *
     * @return {@code null}
     */
    @PublishedMethod
    Void getDiscardOverride();

    /**
     * Call this if the corresponding manual adaptation is obsolete and shall be overwritten by the BswM auto configuration. Must only be called once.
     *
     * @throws IllegalStateException if {@link #keepOverride()} or {@link #discardOverride()} has already been called
     */
    @PublishedMethod
    void discardOverride();

}
