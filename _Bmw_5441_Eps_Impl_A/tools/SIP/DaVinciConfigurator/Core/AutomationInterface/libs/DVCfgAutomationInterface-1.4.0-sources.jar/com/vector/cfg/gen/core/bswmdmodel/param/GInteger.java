package com.vector.cfg.gen.core.bswmdmodel.param;

import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIIntParameter;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.BswmdModelInternalElementFactory;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractParam;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.gen.core.utils.formatting.primitives.IntGenElement;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucIntegerDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucIntegerParameter;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.varianthandling.attributevaluevariationpoints.MINumericalValueVariationPoint;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIIntegerParamDef;

/**
 * Integer parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GInteger extends GAbstractParam<BigInteger> implements GIIntParameter {

    private BigInteger value;

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public GInteger(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MINumericalValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MINumericalValue getMdfObject() {
        return (MINumericalValue) super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MINumericalValue getMdfObjectUnsafe() {
        return (MINumericalValue) super.getMdfObjectUnsafe();
    }

    private MINumericalValueVariationPoint getValueVariationPoint() {
        try {
            switchView();

            if (getMdfObject() != null) {
                return getMdfObject().getValue();
            }
            return null;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @ReworkThisAtNextBreakingChange("Remove method - implemented in base type")
    public boolean hasValue() {
        return super.hasValue();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public BigInteger getBigIntegerValue() {
        if (isValueChecked()) {
            return value;
        }
        try {
            switchView();

            getModelVerifier().assertParameterValueNotNull(this, getValueVariationPoint());
            getModelVerifier().assertParameterHasLegalValue(this, "Integer");

            final MINumericalValue mdfParam = getMdfObject();
            value = getGeneratorModelAccess().getMdfModelAccess().getAsInteger(mdfParam);

            setValueChecked();
            return value;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Long getValue() {
        try {
            switchView();

            final BigInteger valueLoc = getBigIntegerValue();

            getModelVerifier().assertIntegerParameterValueInLongRange(this, valueLoc);

            return valueLoc.longValue();

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Long getValueOrDefault(Long defaultValue) {
        if (hasValue()) {
            return getValue();
        }

        return defaultValue;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public BigInteger getValueMdf() {
        return getBigIntegerValue();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IntGenElement formatValue() {
        return F.formatInt(this);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(BigInteger valueOf) {

        BswmdModelInternalElementFactory.setValueMdf(this, () -> getGeneratorModelAccess().getMdfModelAccess().setAsInteger(getMdfObject(), valueOf));

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(long valueLoc) {

        BswmdModelInternalElementFactory.setValueMdf(this, () -> getGeneratorModelAccess().getMdfModelAccess().setAsInteger(getMdfObject(), valueLoc));
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValue(long newValue) {
        this.setValueMdf(newValue);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIIntegerParamDef getDefinition() {
        return (MIIntegerParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucIntegerDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucIntegerParameter getEcuConfiguration() {

        final IEcucParameter cfg = super.getEcuConfiguration();
        return (IEcucIntegerParameter) cfg;
    }

}
