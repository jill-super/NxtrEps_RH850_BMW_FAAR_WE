package com.vector.cfg.dom.modemgt.groovy.bswm;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link BswMAutoConfigException} is thrown by the {@link IBswMAutoConfigurationApi} when auto configuration fails.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public class BswMAutoConfigException extends RuntimeException {

    private static final long serialVersionUID = -5614784695439030070L;

    @PublishedMethod
    public BswMAutoConfigException(String message) {
        super(message);
    }

    @PublishedMethod
    public BswMAutoConfigException(String message, Throwable e) {
        super(message, e);
    }

}
