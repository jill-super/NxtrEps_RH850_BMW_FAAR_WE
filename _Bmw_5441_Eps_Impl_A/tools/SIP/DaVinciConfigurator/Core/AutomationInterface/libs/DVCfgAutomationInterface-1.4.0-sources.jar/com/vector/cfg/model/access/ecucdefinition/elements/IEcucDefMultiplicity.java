package com.vector.cfg.model.access.ecucdefinition.elements;

import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.IModelAccess;

@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucDefMultiplicity {

    /**
     * Returns the lower multiplicity of the specified object. This never returns <code>null</code>. It implements the AUTOSAR standard semantic for
     * multiplicity: If the requested multiplicity value is not defined in the model, this method returns 1.
     *
     * @return The objects multiplicity value but never <code>null</code>
     */
    @PublishedMethod
    BigInteger getLower();

    /**
     * Returns the upper multiplicity of the specified object. This never returns <code>null</code>. It implements the AUTOSAR standard semantic for
     * multiplicity: If the requested multiplicity value is not defined in the model, this method returns 1.
     * <p>
     * If the upper multiplicity is infinite, this method returns {@link IModelAccess#UNLIMITED_INTEGER}.
     * </p>
     *
     * @return The objects multiplicity value but never <code>null</code>
     */
    @PublishedMethod
    BigInteger getUpper();

    /**
     * Returns <code>true</code> if the upper multiplicity is infinite.
     *
     * @return
     */
    @PublishedMethod
    boolean isUpperMultiplicityInfinite();

    /**
     * Implements the Vector standard semantic for unused parameters. It implements the AUTOSAR standard semantic for multiplicity: If the requested
     * multiplicity value is not defined in the model, this method returns <code>false</code>.
     *
     * @return <code>true</code> if upper multiplicity is zero.
     */
    @PublishedMethod
    boolean isUnused();

    /**
     * It implements the AUTOSAR standard semantic for multiplicity: If the requested multiplicity value is not defined in the model, this method returns
     * <code>false</code>.
     *
     * @return <code>true</code> if the lower multiplicity is zero and the upper multiplicity is one..
     */
    @PublishedMethod
    boolean is0To1();

    /**
     * It implements the AUTOSAR standard semantic for multiplicity: If the requested multiplicity value is not defined in the model, this method returns
     * <code>false</code>.
     *
     * @return <code>true</code> if the lower multiplicity is zero and the upper multiplicity is infinite.
     */
    @PublishedMethod
    boolean is0ToN();

    /**
     * It implements the AUTOSAR standard semantic for multiplicity: If the requested multiplicity value is not defined in the model, this method returns
     * <code>true</code>.
     *
     * @return <code>true</code> if lower multiplicity is one and the upper multiplicity is one.
     */
    @PublishedMethod
    boolean is1To1();

    /**
     * It implements the AUTOSAR standard semantic for multiplicity: If the requested multiplicity value is not defined in the model, this method returns
     * <code>false</code>.
     *
     * @return <code>true</code> if the lower multiplicity is one and the upper multiplicity is infinite.
     */
    @PublishedMethod
    boolean is1ToN();

    /**
     * It implements the AUTOSAR standard semantic for multiplicity: If the requested multiplicity value is not defined in the model, this method returns
     * <code>true</code>.
     *
     * @return <code>true</code> if lower multiplicity is one or greater.
     */
    @PublishedMethod
    boolean isMandatory();

    /**
     * It implements the AUTOSAR standard semantic for multiplicity: If the requested multiplicity value is not defined in the model, this method returns
     * <code>false</code>.
     *
     * @return <code>true</code> if upper multiplicity is greater than one.
     */
    @PublishedMethod
    boolean isMultiple();

    /**
     * It implements the AUTOSAR standard semantic for multiplicity: If the requested multiplicity value is not defined in the model, this method returns
     * <code>true</code>.
     *
     * @return <code>true</code> if lower and upper multiplicity have equal values.
     */
    @PublishedMethod
    boolean isLowerEqualUpper();

}
