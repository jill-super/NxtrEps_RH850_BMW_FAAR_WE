package com.vector.cfg.gen.core.gencore.executionmodel;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.gencore.swct.ISwctComponentUsage;
import com.vector.cfg.gen.core.moduleinterface.IGenerator;
import com.vector.cfg.gen.core.moduleinterface.multipleModuleGenerators.IModule;
import com.vector.cfg.model.access.AsrPath;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;

/**
 * This class represents one specific usage (execution) of a generator.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGeneratorUsage {

    /**
     * Returns the wrapped {@link IGenerator}.
     *
     * @return the internal i generator
     */
    @PublishedMethod
    IGenerator getInternalIGenerator();

    /**
     * Returns the msn from the generator.
     *
     * @return the msn
     */
    @PublishedMethod
    String getMSN();

    /**
     * Returns the name of the generator.
     *
     * @return the name
     */
    @PublishedMethod
    String getName();

    /**
     * Returns the description of the generator.
     *
     * @return the description
     */
    @PublishedMethod
    String getDescription();

    /**
     * Returns the {@link IModule} of an generator to get e.g. the according DefRef.
     *
     * @return the IModule
     */
    @PublishedMethod
    IModule getModule();

    /**
     * Selects a module instance for execution.<br/>
     * If there are multiple module configuration instances associated with an generator this method can be used to select specific ones.<br/>
     *
     * It is possible to pass full qualified path (E.g. "/ActiveEcuC/CanInst1") or only the short name of the module configuration (E.g. "CanInst1"). <br/>
     * Previous selections are not cleared by this method. <br/>
     *
     * If no module configurations are selected, all available are executed.
     *
     * @param moduleConfig the path of the module config
     */
    @PublishedMethod
    void selectModuleInstance(String moduleConfig);

    /**
     * Selects a module instance for execution.<br/>
     * If there are multiple module configuration instances associated with an generator this method can be used to select specific ones.<br/>
     *
     * It is possible to pass full qualified path (E.g. AsrPath.create("/ActiveEcuC/CanInst1") ). <br/>
     * Previous selections are not cleared by this method. <br/>
     *
     * If no module configurations are selected, all available are executed.
     *
     * @param moduleConfig the AsrPath of the module config
     */
    @PublishedMethod
    void selectModuleInstance(AsrPath moduleConfig);

    /**
     * Selects a module instance for execution.<br/>
     * If there are multiple module configuration instances associated with an generator this method can be used to select specific ones.<br/>
     * Previous selections are not cleared by this method. <br/>
     *
     * If no module configurations are selected, all available are executed.
     *
     * @param moduleConfig the MIModuleConfiguration module config
     */
    @PublishedMethod
    void selectModuleInstance(MIModuleConfiguration moduleConfig);

    /**
     * Selects a module instance for execution.<br/>
     * If there are multiple module configuration instances associated with an generator this method can be used to select specific ones.<br/>
     * Previous selections are not cleared by this method. <br/>
     *
     * If no module configurations are selected, all available are executed.
     *
     * @param moduleConfig the IHasModelObject module config
     */
    @PublishedMethod
    void selectModuleInstance(IHasModelObject moduleConfig);

    /**
     * Clears all selected module instances previously selected.
     */
    @PublishedMethod
    void deselectAllModuleInstances();

    /**
     * Returns the selected module instances.
     *
     * @return the selected module instances
     */
    @PublishedMethod
    List<MIModuleConfiguration> getSelectedModuleInstances();

    /**
     * Returns all available module instances regardless if they are selected.
     *
     * @return the available module instances
     */
    @PublishedMethod
    List<MIModuleConfiguration> getAvailableModuleInstances();

    /**
     * This method selects the current {@link IGeneratorUsage} to be executed. <br/>
     * Already selected generators are not removed by this method. <br/>
     * This is analogue to IGenerationSettingsApi.selectGenerator(...)
     */
    @PublishedMethod
    void select();

    /**
     * This method deselects this {@link ISwctComponentUsage}. <br/>
     * Already deselected generators will not issue an error. <br/>
     * This is analogue to IGenerationSettingsApi.deselectGenerator(...)
     */
    @PublishedMethod
    void deselect();

    /**
     * Returns <code>true</code>, if this component is selected.
     *
     * @return true, if is selected
     */
    @PublishedMethod
    boolean isSelected();

    /**
     * Returns the generator argument string which is used for example by the Rte generator.
     *
     * @return
     */
    @PublishedMethod
    String getArgument();

    /**
     * Set the generator argument string which is used for example by the Rte generator.
     *
     * @param arg The string argument
     */
    @PublishedMethod
    void setArgument(String arg);

    /**
     * Sets the current Object to read only. If read only is enabled, changes on this object result in an {@link IllegalStateException}. <br/>
     * The read only state is applied recursively to all child settings.
     */
    @KeepSecretFromPublishedApi
    void setReadOnly();
}
