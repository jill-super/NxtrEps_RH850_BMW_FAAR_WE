package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelReferenceTargetException;
import com.vector.cfg.gen.core.utils.formatting.primitives.StringGenElement;
import com.vector.cfg.gen.core.utils.templateutils.SymbolicNameUtil;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucSymbolicNameRefDefinition;
import com.vector.cfg.model.exceptions.ModelCeHasNoDefinitionException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.query.modelcheckedaccess.exceptions.McaInvalidRequestException;

/**
 * Base interface of bswmd model references which point to a {@link GIContainer} and also have a parameter in the definition which is marked as SymbolcNameReference.
 *
 * <div class="extdoc" id="Common"> SymbolicNameReferences have the same methods as {@link GIReferenceToContainer} and the additional methods
 * <code>getRefTargetParameterMdf()</code>, which returns the target parameter as {@link MIObject} The method {@link #getRefTargetParameter()} return a BswmdModel object, if the
 * type is known at model generation time, the type will be the generated type. Otherwise the return type is {@link GIParameter}.
 * <p>
 * <b>Note: </b>It is always allowed to call <code>getRefTargetParameter()</code>, also for references pointing to external types.
 * </p>
 * </div>
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GISymbolicNameReference extends GIReferenceToContainer {
    // CHECKSTYLE:ON

    /**
     * Returns <code>true</code> if the SymbolicNameReference could be resolved and points to a target parameter object.
     *
     * @return true, if the target parameters exists, otherwise false.
     */
    @PublishedMethod
    boolean hasRefTargetParameter();

    /**
     * Returns the resolved target parameter of the target Object marked by SymbolicNameValue as MDF model object.
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the reference does not exist</li>
     * </ul>
     * @exception BswmdModelReferenceTargetException
     * <ul>
     * <li>if the target container of the reference is null or has an invalid value</li>
     * <li>if the target parameter of the reference is null or has an invalid value</li>
     * </ul>
     *
     */
    @PublishedMethod
    MIParameterValue getRefTargetParameterMdf();

    /**
     * Returns the resolved target parameter of the target Object marked by SymbolicNameValue as BswmdModelObject.
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the reference does not exist</li>
     * </ul>
     * @exception BswmdModelReferenceTargetException
     * <ul>
     * <li>if the target container of the reference is null or has an invalid value</li>
     * <li>if the target parameter of the reference is null or has an invalid value</li>
     * </ul>
     *
     */
    @PublishedMethod
    <T> GIParameter<T> getRefTargetParameter();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    IEcucSymbolicNameRefDefinition getEcucDefinition();

    /**
     * Returns the SymbolicNameValue for the refTarget. Calls internal the method {@link SymbolicNameUtil}.generateSymName(...).
     *
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if container has no definition.</li>
     * </ul>
     * @exception McaInvalidRequestException
     * <ul>
     * <li>if there is no parameter which has the SymbolicNameValue flag set in its definition.</li>
     * </ul>
     * @exception McaParameterXXXException
     * <ul>
     * <li>if the request mca.parameter(xxx).asInt().getValue() has a failure.</li>
     * </ul>
     */
    @PublishedMethod
    StringGenElement getRefTargetAsSymbolicName();

}
