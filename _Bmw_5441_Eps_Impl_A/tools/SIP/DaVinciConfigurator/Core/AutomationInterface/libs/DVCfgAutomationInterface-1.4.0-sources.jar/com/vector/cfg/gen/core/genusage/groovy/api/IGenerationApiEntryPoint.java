package com.vector.cfg.gen.core.genusage.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IGenerationApiEntryPoint} is the entry point to the generation APIs and provide functionality for the generation process.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGenerationApiEntryPoint {

    /**
     * Opens a block to configure a generation or validation process.
     *
     * @param code
     */
    @PublishedMethod
    void generation(@VDelegatesToWithClosureParam(IGenerationApi.class) Closure<?> code);

    /**
     * Returns the generation block.
     *
     * @return IGenerationApi
     */
    @PublishedMethod
    IGenerationApi getGeneration();

}
