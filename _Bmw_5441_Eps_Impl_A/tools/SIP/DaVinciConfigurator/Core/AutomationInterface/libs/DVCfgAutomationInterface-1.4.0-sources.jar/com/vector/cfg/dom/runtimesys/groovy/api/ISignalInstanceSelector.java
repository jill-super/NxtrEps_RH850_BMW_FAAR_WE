package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.com.EDirection;
import com.vector.cfg.model.sysdesc.api.com.IAbstractSignalInstance;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link ISignalInstanceSelector} Api allows the definition of predicates for signal selection.
 * <p>
 * <div class="extdoc" id="ISignalInstanceSelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISignalInstanceSelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceSelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(ISignalInstanceSelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches signal instances for which the given closure results to true.</div>
     *
     * @param code The closure to select signal instances.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(IAbstractSignalInstance.class) Closure<Boolean> code);

    /**
     * <div class="extdoc" id="unmapped">{@link #unmapped()} matches signal instances which are not data-mapped.</div>
     */
    @PublishedMethod
    void unmapped();

    /**
     * <div class="extdoc" id="mapped">{@link #mapped()} matches signal instances which are data-mapped.</div>
     */
    @PublishedMethod
    void mapped();

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches signal instances with the given name.</div>
     *
     * @param name A signal instance name.
     */
    @PublishedMethod
    void name(String name);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches signal instances with the given name pattern.</div>
     *
     * @param namePattern A signal instance name pattern.
     */
    @PublishedMethod
    void name(Pattern namePattern);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches signal instances with the given autosar path.</div>
     *
     * @param asrPath A signal instance autosar path.
     */
    @PublishedMethod
    void asrPath(String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches signal instances with the given autosar path pattern.</div>
     *
     * @param asrPathPattern A signal instance autosar path pattern.
     */
    @PublishedMethod
    void asrPath(Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="iSignal">{@link #iSignal(String)} matches signal instances which are referenced at least by one ISignal/ISignalGroup with the given name.</div>
     *
     * @param iSignalName An ISignal name.
     */
    @PublishedMethod
    void iSignal(String iSignalName);

    /**
     * <div class="extdoc" id="iSignalPattern">{@link #iSignal(Pattern)} matches signal instances which are referenced at least by one ISignal/ISignalGroup with the given name
     * pattern.</div>
     *
     * @param iSignalNamePattern An ISignal name pattern.
     */
    @PublishedMethod
    void iSignal(Pattern iSignalNamePattern);

    /**
     * <div class="extdoc" id="iSignalAsrPath">{@link #iSignalAsrPath(String)} matches signal instances which are referenced at least by one ISignal/ISignalGroup with the given
     * autosar path.</div>
     *
     * @param iSignalAsrPath An ISignal autosar path.
     */
    @PublishedMethod
    void iSignalAsrPath(String iSignalAsrPath);

    /**
     * <div class="extdoc" id="iSignalAsrPathPattern">{@link #iSignalAsrPath(Pattern)} matches signal instances which are referenced at least by one ISignal/ISignalGroup with
     * the given autosar path pattern.</div>
     *
     * @param iSignalAsrPathPattern An ISignal autosar path pattern.
     */
    @PublishedMethod
    void iSignalAsrPath(Pattern iSignalAsrPathPattern);

    /**
     * <div class="extdoc" id="physicalChannel">{@link #physicalChannel(String)} matches signal instances which are referenced by at least an ISignal/ISignalGroup for which an
     * ISignalTriggering exists for a PhysicalChannel with the given name.</div>
     *
     * @param channelName A PhysicalChannel name.
     */
    @PublishedMethod
    void physicalChannel(String channelName);

    /**
     * <div class="extdoc" id="physicalChannelPattern">{@link #physicalChannel(Pattern)} matches signal instances which are referenced by at least an ISignal/ISignalGroup for
     * which an ISignalTriggering exists for a PhysicalChannel with the given name pattern.</div>
     *
     * @param channelPattern A PhysicalChannel name pattern.
     */
    @PublishedMethod
    void physicalChannel(Pattern channelPattern);

    /**
     * <div class="extdoc" id="physicalChannelAsrPath">{@link #physicalChannelAsrPath(String)} matches signal instances which are referenced by at least an ISignal/ISignalGroup
     * for which an ISignalTriggering exists for a PhysicalChannel with the given autosar path.</div>
     *
     * @param channelAsrPath A PhysicalChannel autosar path.
     */
    @PublishedMethod
    void physicalChannelAsrPath(String channelAsrPath);

    /**
     * <div class="extdoc" id="physicalChannelAsrPathPattern">{@link #physicalChannelAsrPath(Pattern)} matches signal instances which are referenced by at least an
     * ISignal/ISignalGroup for which an ISignalTriggering exists for a PhysicalChannel with the given autosar path pattern.</div>
     *
     * @param channelAsrPathPattern A PhysicalChannel autosar path pattern.
     */
    @PublishedMethod
    void physicalChannelAsrPath(Pattern channelAsrPathPattern);

    /**
     * <div class="extdoc" id="communicationCluster">{@link #communicationCluster(String)} matches signal instances which are referenced by at least an ISignal/ISignalGroup
     * which is sent via a PhysicalChannel of a CommunicationCluster with the given name.</div>
     *
     * @param clusterName A CommunicationCluster name.
     */
    @PublishedMethod
    void communicationCluster(String clusterName);

    /**
     * <div class="extdoc" id="communicationClusterPattern">{@link #communicationCluster(Pattern)} matches signal instances which are referenced by at least an
     * ISignal/ISignalGroup which is sent via a PhysicalChannel of a CommunicationCluster with the given name pattern.</div>
     *
     * @param clusterPattern A CommunicationCluster name pattern.
     */
    @PublishedMethod
    void communicationCluster(Pattern clusterPattern);

    /**
     * <div class="extdoc" id="communicationClusterAsrPath">{@link #communicationClusterAsrPath(String)} matches signal instances which are referenced by at least an
     * ISignal/ISignalGroup which is sent via a PhysicalChannel of a CommunicationCluster with the given autosar path.</div>
     *
     * @param clusterAsrPath A CommunicationChannel autosar path.
     */
    @PublishedMethod
    void communicationClusterAsrPath(String clusterAsrPath);

    /**
     * <div class="extdoc" id="communicationClusterAsrPathPattern">{@link #communicationClusterAsrPath(Pattern)} matches signal instances which are referenced by at least an
     * ISignal/ISignalGroup which is sent via a PhysicalChannel of a CommunicationCluster with the given autosar path pattern.</div>
     *
     * @param clusterAsrPathPattern A CommunicationCluster autosar path pattern.
     */
    @PublishedMethod
    void communicationClusterAsrPath(Pattern clusterAsrPathPattern);

    /**
     * <div class="extdoc" id="pdu">{@link #pdu(String)} matches signal instances which are referenced by at least an ISignal/ISignalGroup for which an ISignalToIPduMapping
     * exists for a Pdu with the given name.</div>
     *
     * @param pduName A Pdu name.
     */
    @PublishedMethod
    void pdu(String pduName);

    /**
     * <div class="extdoc" id="pduPattern">{@link #pdu(Pattern)} matches signal instances which are referenced by at least an ISignal/ISignalGroup for which an
     * ISignalToIPduMapping exists for a Pdu with the given name pattern.</div>
     *
     * @param pduPattern A Pdu name pattern.
     */
    @PublishedMethod
    void pdu(Pattern pduPattern);

    /**
     * <div class="extdoc" id="pduAsrPath">{@link #pduAsrPath(String)} matches signal instances which are referenced by at least an ISignal/ISignalGroup for which an
     * ISignalToIPduMapping exists for a Pdu with the given autosar path.</div>
     *
     * @param pduAsrPath A Pdu autosar path.
     */
    @PublishedMethod
    void pduAsrPath(String pduAsrPath);

    /**
     * <div class="extdoc" id="pduAsrPathPattern">{@link #pduAsrPath(Pattern)} matches signal instances which are referenced by at least an ISignal/ISignalGroup for which an
     * ISignalToIPduMapping exists for a Pdu with the given autosar path pattern.</div>
     *
     * @param pduPathPattern A Pdu autosar path pattern.
     */
    @PublishedMethod
    void pduAsrPath(Pattern pduPathPattern);

    /**
     * <div class="extdoc" id="frame">{@link #frame(String)} matches signal instances which are referenced by at least an ISignal/ISignalGroup which is sent via a Pdu for that a
     * PduToFrameMapping exists for a Frame with the given name.</div>
     *
     * @param frameName A Frame name.
     */
    @PublishedMethod
    void frame(String frameName);

    /**
     * <div class="extdoc" id="framePattern">{@link #frame(Pattern)} matches signal instances which are referenced by at least an ISignal/ISignalGroup which is sent via a Pdu
     * for that a PduToFrameMapping exists for a Frame with the given name pattern.</div>
     *
     * @param framePattern A Frame name pattern.
     */
    @PublishedMethod
    void frame(Pattern framePattern);

    /**
     * <div class="extdoc" id="frameAsrPath">{@link #frameAsrPath(String)} matches signal instances which are referenced by at least an ISignal/ISignalGroup which is sent via a
     * Pdu for that a PduToFrameMapping exists for a Frame with the given autosar path.</div>
     *
     * @param frameAsrPath A Frame autosar path.
     */
    @PublishedMethod
    void frameAsrPath(String frameAsrPath);

    /**
     * <div class="extdoc" id="frameAsrPathPattern">{@link #frameAsrPath(Pattern)} matches signal instances which are referenced by at least an ISignal/ISignalGroup which is
     * sent via a Pdu for that a PduToFrameMapping exists for a Frame with the given autosar path pattern.</div>
     *
     * @param framePathPattern A Frame autosar path pattern.
     */
    @PublishedMethod
    void frameAsrPath(Pattern framePathPattern);

    /**
     * <div class="extdoc" id="signalGroup">{@link #signalGroup()} matches signal instances which are a signal group instance.</div>
     */
    @PublishedMethod
    void signalGroup();

    /**
     * <div class="extdoc" id="groupSignal">{@link #groupSignal()} matches signal instances which are a group signal.</div>
     */
    @PublishedMethod
    void groupSignal();

    /**
     * <div class="extdoc" id="transformed">{@link #transformed()} matches signal instances which are transformation signals.</div>
     */
    @PublishedMethod
    void transformed();

    /**
     * <div class="extdoc" id="tx">{@link #tx()} matches signal instances whose direction is compatible to {@link EDirection.Tx}.</div>
     */
    @PublishedMethod
    void tx();

    /**
     * <div class="extdoc" id="rx">{@link #rx()} matches signal instances whose direction is compatible to {@link EDirection.Rx}.</div>
     */
    @PublishedMethod
    void rx();

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<IAbstractSignalInstance> getSelectedSignalInstances();
}
