/**
 * DaVinci Configurator Project interface and basic type defintions like Project states and phases.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.core.project;