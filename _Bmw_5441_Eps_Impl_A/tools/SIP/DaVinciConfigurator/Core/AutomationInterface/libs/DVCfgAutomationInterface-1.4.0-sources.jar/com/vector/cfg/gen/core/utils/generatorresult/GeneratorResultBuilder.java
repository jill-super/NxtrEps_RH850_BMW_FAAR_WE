package com.vector.cfg.gen.core.utils.generatorresult;

import java.util.Collection;
import java.util.List;
import java.util.Set;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.EValidationSeverityType;
import com.vector.cfg.consistency.ISolvingActionContainer;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.IValidationSeverityResultId;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.helper.validationresults.AbstractResultBuilder;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.utils.generatorresult.internal.GeneratorResult;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.cedescriptor.IDescriptorFactory;
import com.vector.cfg.model.view.config.variant.IInvariantView;
import com.vector.cfg.model.view.config.variant.IPredefinedVariantView;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 * A builder for {@link IGeneratorResult GeneratorResults}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GeneratorResultBuilder extends AbstractResultBuilder<GeneratorResultBuilder> implements IGeneratorResultBuilder<GeneratorResultBuilder> {

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GeneratorResultBuilder.class);

    /**
     * Constructor for GeneratorResultBuilder.
     *
     * @param resultId
     * @param severityType
     * @param descriptionBuilder
     * @param description
     */
    private GeneratorResultBuilder(IValidationResultId resultId, EValidationSeverityType severityType, IMixedTextBuilder descriptionBuilder, IMixedText description) {
        super(resultId, severityType, descriptionBuilder, description);

    }

    /**
     * Creates a new {@link GeneratorResultBuilder} object, which can be used to build a GeneratorResult.
     *
     * <p>
     * The descriptionPattern parameter is a {@link MixedText} pattern.<br />
     * See {@link MixedText#format(String, Object...)} with the parameters descriptionPattern and patternArguments for more details.
     * </p>
     *
     * @param resultId The IValidationResultId of the GeneratorResult
     * @param severityType The Severity of the result
     * @param formatPattern The description pattern for {@link IMixedTextBuilder#appendFormat(String, Object...)}
     * @param patternArguments The arguments for the descriptionPattern
     * @return A new builder
     *
     * @see GeneratorResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * <li>if formatPattern is null</li>
     * <li>if patternArguments is null</li>
     * </ul>
     */
    @PublishedMethod
    public static GeneratorResultBuilder newBuilder(IValidationResultId resultId, EValidationSeverityType severityType, String formatPattern, Object... patternArguments) {
        if (formatPattern == null) {
            throw new IllegalArgumentException("formatPattern is null");
        }
        if (patternArguments == null) {
            throw new IllegalArgumentException("patternArguments is null");
        }
        return newBuilder(resultId, severityType, MixedText.newStrictBuilder().appendFormat(formatPattern, patternArguments).flushResult());
    }

    /**
     * Creates a new {@link GeneratorResultBuilder} object, which can be used to build a GeneratorResult.
     *
     * <p>
     * The descriptionPattern parameter is a {@link MixedText} pattern.<br />
     * See {@link MixedText#format(String, Object...)} with the parameters descriptionPattern and patternArguments for more details.
     * </p>
     *
     * @param resultId The IValidationSeverityResultId of the GeneratorResult
     * @param formatPattern The description pattern for {@link IMixedTextBuilder#appendFormat(String, Object...)}
     * @param patternArguments The arguments for the descriptionPattern
     * @return A new builder
     *
     * @see GeneratorResultBuilder#buildResult()
     * @see IMixedTextBuilder
     * @see IMixedText
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if formatPattern is null</li>
     * <li>if patternArguments is null</li>
     * </ul>
     */
    @PublishedMethod
    public static GeneratorResultBuilder newBuilder(IValidationSeverityResultId resultId, String formatPattern, Object... patternArguments) {
        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (formatPattern == null) {
            throw new IllegalArgumentException("formatPattern is null");
        }
        if (patternArguments == null) {
            throw new IllegalArgumentException("patternArguments is null");
        }
        return newBuilder(resultId, resultId.getSeverity(), MixedText.newStrictBuilder().appendFormat(formatPattern, patternArguments).flushResult());
    }

    /**
     * Creates a new {@link GeneratorResultBuilder} object, which can be used to build a GeneratorResult.
     *
     * @param resultId The IValidationResultId of the GeneratorResult
     * @param severityType The Severity of the result
     * @param description The detailed description text of the result
     * @return A new builder
     *
     * @see GeneratorResultBuilder#buildResult()
     * @see MixedText#newBuilder()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * <li>if description is null</li>
     * </ul>
     */
    @PublishedMethod
    public static GeneratorResultBuilder newBuilder(IValidationResultId resultId, EValidationSeverityType severityType, IMixedText description) {

        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (severityType == null) {
            throw new IllegalArgumentException("severityType is null");
        }
        if (description == null) {
            throw new IllegalArgumentException("description is null");
        }

        return new GeneratorResultBuilder(resultId, severityType, null, description);

    }

    /**
     * Creates a new {@link GeneratorResultBuilder} object, which can be used to build a GeneratorResult.
     *
     * @param resultId The IValidationSeverityResultId of the GeneratorResult
     * @param description The detailed description text of the result in IMixedTextFormat
     * @return A new builder
     *
     * @see GeneratorResultBuilder#buildResult()
     * @see MixedText#newBuilder()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if description is null</li>
     * </ul>
     */
    @PublishedMethod
    public static GeneratorResultBuilder newBuilder(IValidationSeverityResultId resultId, IMixedText description) {

        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (description == null) {
            throw new IllegalArgumentException("description is null");
        }

        return newBuilder(resultId, resultId.getSeverity(), description);

    }

    /**
     * Creates a new {@link GeneratorResultBuilder} object, which can be used to build a GeneratorResult.
     *
     * @param resultId The IValidationSeverityResultId of the GeneratorResult
     * @param description The detailed description text of the result
     * @return A new builder
     *
     * @see GeneratorResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if description is null</li>
     * </ul>
     */
    @PublishedMethod
    public static GeneratorResultBuilder newBuilder(IValidationSeverityResultId resultId, String description) {
        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (description == null) {
            throw new IllegalArgumentException("description is null");
        }

        return newBuilder(resultId, resultId.getSeverity(), MixedText.fromConstantString(description));

    }

    /**
     * Creates a new {@link GeneratorResultBuilder} object, which can be used to build a GeneratorResult.
     *
     *
     * @param resultId The IValidationResultId of the GeneratorResult
     * @param severityType The Severity of the result
     * @param description The description
     * @return A new builder
     *
     * @see GeneratorResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * <li>if description is null</li>
     * </ul>
     */
    @PublishedMethod
    public static GeneratorResultBuilder newBuilder(IValidationResultId resultId, EValidationSeverityType severityType, String description) {
        if (description == null) {
            throw new IllegalArgumentException("description is null");
        }
        return newBuilder(resultId, severityType, MixedText.fromConstantString(description));
    }

    /**
     * Creates a new {@link GeneratorResultBuilder} object, which can be used to build a GeneratorResult.
     *
     * <p>
     * This method should only be used, if you want to construct the description text programmatically with an {@link IMixedTextBuilder}, otherwise you should call the other
     * newBuilder() methods.
     * </p>
     *
     * <p>
     * <b>Attention:</b> You have to use the {@link #getMixedTextBuilder()} method to set the description text of this result, otherwise the {@link #buildResult()} method will
     * throw an {@link IllegalArgumentException}.
     * </p>
     *
     * @param resultId The IValidationSeverityResultId of the GeneratorResult
     * @return A new builder
     *
     * @see GeneratorResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * </ul>
     */
    @PublishedMethod
    public static GeneratorResultBuilder newBuilder(IValidationSeverityResultId resultId) {
        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }

        return newBuilder(resultId, resultId.getSeverity());

    }

    /**
     * Creates a new {@link GeneratorResultBuilder} object, which can be used to build a GeneratorResult.
     *
     * <p>
     * This method should only be used, if you want to construct the description text programmatically with an {@link IMixedTextBuilder}, otherwise you should call the other
     * newBuilder() methods.
     * </p>
     *
     * <p>
     * <b>Attention:</b> You have to use the {@link #getMixedTextBuilder()} method to set the description text of this result, otherwise the {@link #buildResult()} method will
     * throw an {@link IllegalArgumentException}.
     * </p>
     *
     * @param resultId The IValidationSeverityResultId of the GeneratorResult
     * @param severityType The Severity of the result
     * @return A new builder
     *
     * @see GeneratorResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * </ul>
     */
    @PublishedMethod
    public static GeneratorResultBuilder newBuilder(IValidationSeverityResultId resultId, EValidationSeverityType severityType) {
        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (severityType == null) {
            throw new IllegalArgumentException("severityType is null");
        }

        return new GeneratorResultBuilder(resultId, severityType, MixedText.newStrictBuilder(), null);

    }

    /**
     * Creates a new {@link GeneratorResultBuilder} object, which can be used to build a GeneratorResult.
     *
     * @param resultId The IValidationResultId of the GeneratorResult
     * @param severityType The Severity of the result
     * @return A new builder
     *
     * @see GeneratorResultBuilder#buildResult()
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if resultId is null</li>
     * <li>if severityType is null</li>
     * </ul>
     */
    @PublishedMethod
    public static GeneratorResultBuilder newBuilder(IValidationResultId resultId, EValidationSeverityType severityType) {
        if (resultId == null) {
            throw new IllegalArgumentException("resultId is null");
        }
        if (severityType == null) {
            throw new IllegalArgumentException("severityType is null");
        }

        return new GeneratorResultBuilder(resultId, severityType, MixedText.newStrictBuilder(), null);

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public GeneratorResultBuilder addErrorObject(GIModelObject erroneousBswmdObject) {
        if (erroneousBswmdObject == null) {
            throw new IllegalArgumentException("erroneousBswmdObject is null");
        }
        addImplicitModelViewByElement(erroneousBswmdObject);

        return addErrorObject(erroneousBswmdObject.getMdfObject());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <R extends GIModelObject> GeneratorResultBuilder addErrorBswmdObjectList(Collection<R> erroneousBswmdCollection) {
        if (erroneousBswmdCollection == null) {
            throw new IllegalArgumentException("erroneousBswmdCollection is null");
        }

        for (final GIModelObject obj : erroneousBswmdCollection) {
            addImplicitModelViewByElement(obj);
            final IDescriptorFactory descriptorFactory = ModelUtil.getService(obj.getMdfObject(), IDescriptorFactory.class);
            addErrorDescriptor(descriptorFactory.createBuilder(obj.getMdfObject()).create());
        }

        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public GeneratorResultBuilder addDependentObject(GIModelObject dependentBswmdModelObject) {
        if (dependentBswmdModelObject == null) {
            throw new IllegalArgumentException("dependentBswmdModelObject is null");
        }

        addImplicitModelViewByElement(dependentBswmdModelObject);
        addDependentObject(dependentBswmdModelObject.getMdfObject());
        return this;

    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public <R extends GIModelObject> GeneratorResultBuilder addDependentBswmdObjectList(Collection<R> bswmdObjectCollection) {
        if (bswmdObjectCollection == null) {
            throw new IllegalArgumentException("bswmdObjectCollection is null");
        }

        for (final GIModelObject obj : bswmdObjectCollection) {
            addImplicitModelViewByElement(obj);
            final IDescriptorFactory descriptorFactory = ModelUtil.getService(obj.getMdfObject(), IDescriptorFactory.class);
            addDependentDescriptor(descriptorFactory.createBuilder(obj.getMdfObject()).create());
        }

        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public GeneratorResultBuilder addErrorMissingObject(GIModelObject parentBswmdObject, DefRef missingCeDefRef) {
        if (parentBswmdObject == null) {
            throw new IllegalArgumentException("parentBswmdObject is null");
        }
        if (missingCeDefRef == null) {
            throw new IllegalArgumentException("missingCeDefRef is null");
        }
        addImplicitModelViewByElement(parentBswmdObject);
        return addErrorMissingObject(parentBswmdObject.getMdfObject(), missingCeDefRef);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public GeneratorResultBuilder addDependentMissingObject(GIModelObject parentBswmdObject, DefRef missingCeDefRef) {
        if (parentBswmdObject == null) {
            throw new IllegalArgumentException("parentBswmdObject is null");
        }
        if (missingCeDefRef == null) {
            throw new IllegalArgumentException("missingCeDefRef is null");
        }
        addImplicitModelViewByElement(parentBswmdObject);
        return addDependentMissingObject(parentBswmdObject.getMdfObject(), missingCeDefRef);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IGeneratorResult buildResult() {
        return (IGeneratorResult) super.buildResult();
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @KeepSecretFromPublishedApi
    protected GeneratorResultBuilder getThis() {
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @KeepSecretFromPublishedApi
    protected IGeneratorResult buildResultInternal(IValidationResultId resultId, EValidationSeverityType severityType, IMixedText description, List<IDescriptor> erroneousCEs,
            List<IDescriptor> dependentCEs, ISolvingActionContainer<ISolvingAction> solvingActionContainer, Throwable innerException,
            Set<IPredefinedVariantView> predefinedVariantSet, Set<IInvariantView> invariantViewSet, Object distinguishingObjectParam) {
        return new GeneratorResult(resultId, severityType, description, erroneousCEs, dependentCEs, solvingActionContainer, innerException,
                predefinedVariantSet, invariantViewSet, distinguishingObjectParam);
    }
}
