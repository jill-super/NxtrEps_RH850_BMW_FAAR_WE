package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * The class {@link GPackageProviderClassKey} is used by the generated packageProvider class in the BswmdModel. The class represents the Key in the Maps inside
 * of the PackagerProviders to link to generated class and non generated classes which are referenced by field names.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
// @CHECKSTYLE:OFF Class could not be final, because inner class are subclasses of this type.
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@Immutable
public class GPackageProviderClassKey {
    // @CHECKSTYLE:ON
    @PublishedMethod
    public static GPackageProviderClassKey of(Class<?> clazz) {
        return of(clazz, null);
    }

    @PublishedMethod
    public static GPackageProviderClassKey of(Class<?> clazz, String name) {
        if (clazz == null) {
            throw new IllegalArgumentException();
        }
        if (name == null) {
            return new SingleClassKey(clazz);
        }
        return new ClassAndNameKey(clazz, name);
    }

    private GPackageProviderClassKey() {

    }

    @Immutable
    private static final class SingleClassKey extends GPackageProviderClassKey {

        private final Class<?> clazz;

        SingleClassKey(Class<?> clazz) {
            this.clazz = clazz;

        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((clazz == null) ? 0 : clazz.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final SingleClassKey other = (SingleClassKey) obj;
            if (clazz == null) {
                if (other.clazz != null) {
                    return false;
                }
            } else if (!clazz.equals(other.clazz)) {
                return false;
            }
            return true;
        }

    }

    @Immutable
    private static final class ClassAndNameKey extends GPackageProviderClassKey {

        private final Class<?> clazz;

        private final String name;

        ClassAndNameKey(Class<?> clazz, String name) {
            this.clazz = clazz;
            this.name = name;
        }

        @Override
        public int hashCode() {
            final int prime = 31;
            int result = 1;
            result = prime * result + ((clazz == null) ? 0 : clazz.hashCode());
            result = prime * result + ((name == null) ? 0 : name.hashCode());
            return result;
        }

        @Override
        public boolean equals(Object obj) {
            if (this == obj) {
                return true;
            }
            if (obj == null) {
                return false;
            }
            if (getClass() != obj.getClass()) {
                return false;
            }
            final ClassAndNameKey other = (ClassAndNameKey) obj;
            if (clazz == null) {
                if (other.clazz != null) {
                    return false;
                }
            } else if (!clazz.equals(other.clazz)) {
                return false;
            }
            if (name == null) {
                if (other.name != null) {
                    return false;
                }
            } else if (!name.equals(other.name)) {
                return false;
            }
            return true;
        }

    }

}
