package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.Collection;
import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.component.IComponent;
import com.vector.cfg.model.sysdesc.api.component.IComponentType;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * <div class="extdoc" id="IComponentTypeSelection"><!--Label:IComponentTypeSelection-->{@link IComponentTypeSelection} represents a selection of {@link IComponentType}s and the
 * possible operations on these component types.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IComponentTypeSelection {

    /**
     * <p>
     * <div class="extdoc" id="createPrototypeWithName"><!--Label:IComponentTypeSelection.createPrototypeWithName-->{@link #createPrototypeWithName(Closure)} creates a
     * SwComponentPrototype in the FlatExtract for each selected component type. Inside the given closure a naming rule for the new components can be defined. The default name
     * for a component is the name of the component type.</div>
     * </p>
     *
     * <p>
     * The component type selection will produce trace, info and warning logs. To see them, activate the 'com.vector.cfg.dom.runtimesys.groovy.api.IComponentTypeSelection'
     * logger with the appropriate log level.
     * </p>
     *
     * @return A list of the newly created components.
     */
    @PublishedMethod
    List<? extends IComponent> createPrototypeWith(@Nonnull @VDelegatesToWithClosureParam(IComponentPrototypeCreator.class) Closure<?> code);

    /**
     * <div class="extdoc" id="createPrototype"><!--Label:IComponentTypeSelection.createPrototype-->{@link #createPrototype()} creates a SwComponentPrototype in the FlatExtract
     * for each selected component type. The names of the created SwComponentPrototypes are derived from the selected component types.</div>
     *
     * @return A list of the newly created components.
     */
    @PublishedMethod
    List<? extends IComponent> createPrototype();

    /**
     * Allows access to the single component types in the {@link IComponentTypeSelection}.
     *
     * @return The collection of selected component types.
     */
    @PublishedMethod
    <T extends IComponentType> Collection<T> getComponentTypes();

}
