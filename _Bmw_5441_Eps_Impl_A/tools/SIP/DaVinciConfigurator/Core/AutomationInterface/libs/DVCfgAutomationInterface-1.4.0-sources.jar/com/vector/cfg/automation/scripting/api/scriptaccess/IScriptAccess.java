package com.vector.cfg.automation.scripting.api.scriptaccess;

import java.util.List;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.IScriptTaskUserDefinedArgument;
import com.vector.cfg.automation.scripting.base.IScript;
import com.vector.cfg.automation.scripting.base.IScriptTask;
import com.vector.cfg.automation.scripting.base.IScriptTaskType;
import com.vector.cfg.automation.scripting.base.ScriptingException;
import com.vector.cfg.automation.scripting.base.services.ScriptQueryException;

/**
 * {@link IScriptAccess} provides API to retrieve existing {@link IScript}s and call other {@link IScriptTask} from the running {@link IScriptTask}.
 *
 * <div class="extdoc" id="Common"> Sometimes it can be helpful to call other script tasks from inside your task. The <code>scripts{}</code> block or <code>getScripts()</code>
 * method provides API to retrieve existing {@link IScript}s and call other {@link IScriptTask}s from your running {@link IScriptTask}.
 *
 * <p>
 * <b>Note:</b> If you <b>just want to reuse code</b> of your own scripts in an automation script project, create a normal method containing the code and call it, instead of
 * calling the task. The method is typesafe, has code completion support and is <b>much faster</b> than calling a script task.
 * </p>
 *
 * <h5>Calling script tasks</h5> To call a task you need the name of the task and the {@link IScriptTaskType}. The {@link IScriptTaskType} determines the argument types and the
 * return type of the script task. Then you can use <code>scripts.</code>{@link #callScriptTask(String, Object...)} to call the script.
 * <p>
 * You could also use {@link #callScriptTaskWithUserArgs(String, String, Object...)}, if you want to pass user defined arguments.
 * </p>
 *
 * </div>
 *
 *
 * <div class="extdoc" id="CallWithTaskArguments">
 * <h5>Calling script tasks with task arguments</h5> If the {@link IScriptTaskType} requires task arguments, you have to pass the arguments to the <code>callScriptTask()</code>
 * methods. The return value of the method is the returned value of the called script task.
 *
 * </div>
 *
 *
 * <p>
 * Note: All operations in {@link IScriptAccess} are blocking operation, and will waiting until all scripts are loaded! Or it is otherwise noted.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptAccess {

    /**
     * Returns all loaded {@link IScript} in the system. This can be used for fine grained access to the scripts and their script tasks.
     *
     * @return the all loaded scripts
     */
    @PublishedMethod
    List<IScript> getAllLoadedScripts();

    /**
     * Searches for the task with the name and executes the task code.
     *
     * <p>
     * The signature of this method is defined by the {@link IScriptTaskType}, see {@link IScriptTask#getTaskType()}. So the args <code>Object[]</code> must contain instance of
     * the types defined in the {@link IScriptTaskType} of this {@link IScriptTask}, otherwise the script is not callable.
     * </p>
     *
     * @param taskName the name of the task either absolute as script task handle, or just the name of the task
     * @param arguments the args which are passed the the {@link IScriptTask}.
     * @return the returned object from the script task.
     *
     * @exception ScriptingException
     * <ul>
     * <li>if the the execution of the task has failed.</li>
     * </ul>
     * @exception ScriptQueryException
     * <ul>
     * <li>A script task with the name can not be found, or is otherwise invalid</li>
     * </ul>
     */
    @PublishedMethod
    @Nullable
    Object callScriptTask(@Nonnull String taskName, Object... arguments);

    /**
     * Searches for the task with the name and executes the task code.
     *
     * <p>
     * The signature of this method is defined by the {@link IScriptTaskType}, see {@link IScriptTask#getTaskType()}. So the args <code>Object[]</code> must contain instance of
     * the types defined in the {@link IScriptTaskType} of this {@link IScriptTask}, otherwise the script is not callable.
     * </p>
     *
     * @param taskName the name of the task either absolute as script task handle, or just the name of the task
     * @param userDefinedArguments the user defined arguments, see {@link IScriptTaskUserDefinedArgument} for details.
     * @param arguments the args which are passed the the {@link IScriptTask}.
     * @return the returned object from the script task.
     * @exception ScriptingException
     * <ul>
     * <li>if the the execution of the task has failed.</li>
     * </ul>
     * @exception ScriptQueryException
     * <ul>
     * <li>A script task with the name can not be found, or is otherwise invalid</li>
     * </ul>
     */
    @PublishedMethod
    @Nullable
    Object callScriptTaskWithUserArgs(@Nonnull String taskName, @Nonnull String userDefinedArguments, Object... arguments);

    /**
     * Searches for the task with the name and returns it.
     *
     * @param taskName the task name
     * @return the found script task
     * @exception ScriptQueryException
     * <ul>
     * <li>A script task with the name can not be found, or is otherwise invalid</li>
     * </ul>
     */
    @PublishedMethod
    IScriptTask scriptTaskByName(@Nonnull String taskName);

    /**
     * Searches for the task with the name and returns it, or <code>null</code>, if not found.
     *
     * @param taskName the task name
     * @return the found script task or <code>null</code>
     */
    @PublishedMethod
    @Nullable
    IScriptTask scriptTaskByNameOrNull(@Nonnull String taskName);

}
