package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * {@link KeepSecretFromPublishedApi} hides the marked method or constructor for the {@link PublishedApi}, that a Java client is not able to call the marked element.
 *
 * <p>
 * A change of an element marked with {@link KeepSecretFromPublishedApi} will not lead to a breaking change or any other API change.
 * </p>
 * <p>
 * An additional {@link PublishedMethod} annotation is not allowed.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see PublishedApi
 */
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.METHOD, ElementType.CONSTRUCTOR })
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public @interface KeepSecretFromPublishedApi {

}
