package com.vector.cfg.core.project;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;

/**
 * This enumeration represents the project's configuration phase.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */

@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@ThreadSafe
public enum EConfigurationPhase {
    /**
     * Configuration phase PreCompile.
     */
    PRE_COMPILE("PreCompile"),
    /**
     * Configuration phase LinkTime.
     */
    LINK_TIME("LinkTime"),
    /**
     * Configuration phase PostBuild.
     */
    POST_BUILD("PostBuild");

    private final String name;

    EConfigurationPhase(final String name) {
        this.name = name;
    }

    @Override
    public String toString() {
        return name;
    }

    /**
     * Converts a given string into a EConfigurationPhase.
     *
     * @param identifier - a string representing a phase identifier.
     * @return the according EConfigurationPhase to the given string.
     */
    @KeepSecretFromPublishedApi
    public static EConfigurationPhase toId(final String identifier) {
        for (final EConfigurationPhase e : EConfigurationPhase.values()) {
            if (e.name.equals(identifier)) {
                return e;
            }
        }
        return null;
    }
}
