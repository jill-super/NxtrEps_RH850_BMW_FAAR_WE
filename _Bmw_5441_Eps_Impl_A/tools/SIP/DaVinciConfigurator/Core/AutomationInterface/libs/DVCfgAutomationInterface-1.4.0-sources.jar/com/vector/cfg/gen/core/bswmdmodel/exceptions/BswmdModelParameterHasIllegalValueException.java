package com.vector.cfg.gen.core.bswmdmodel.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Thrown to indicate that the model object has an illegal value for the parameter type.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class BswmdModelParameterHasIllegalValueException extends BswmdModelException {

    private static final long serialVersionUID = -980917635519275859L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(BswmdModelParameterHasIllegalValueException.class);

    private final GIParameter<?> parameter;

    private final String value;

    /**
     * Constructor for BswmdModelHasNoValueException.
     *
     * @param genResult the gen result
     * @param parameter the parameter
     * @param value the value
     */
    @PublishedMethod
    public BswmdModelParameterHasIllegalValueException(IValidationResult genResult, GIParameter<?> parameter, String value) {
        super(genResult, parameter.getParent());
        this.parameter = parameter;
        this.value = value;
    }

    /**
     * Returns the parameter model object.
     *
     * @return the parameter
     */
    @PublishedMethod
    public GIParameter<?> getParameter() {
        return parameter;
    }

    /**
     * Returns the raw MDF value.
     *
     * @return String value
     */
    @PublishedMethod
    public String getValue() {
        return value;
    }

}
