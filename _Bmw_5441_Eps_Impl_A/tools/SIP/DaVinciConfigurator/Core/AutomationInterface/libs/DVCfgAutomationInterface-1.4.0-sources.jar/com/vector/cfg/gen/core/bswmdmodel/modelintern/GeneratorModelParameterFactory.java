package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.GIEcucAddInfoParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.gen.core.bswmdmodel.GIMultilineStringParameter;
import com.vector.cfg.gen.core.bswmdmodel.param.GBoolean;
import com.vector.cfg.gen.core.bswmdmodel.param.GChoiceReference;
import com.vector.cfg.gen.core.bswmdmodel.param.GEcucAddInfo;
import com.vector.cfg.gen.core.bswmdmodel.param.GFloat;
import com.vector.cfg.gen.core.bswmdmodel.param.GForeignReference;
import com.vector.cfg.gen.core.bswmdmodel.param.GFunctionName;
import com.vector.cfg.gen.core.bswmdmodel.param.GInstanceReference;
import com.vector.cfg.gen.core.bswmdmodel.param.GInteger;
import com.vector.cfg.gen.core.bswmdmodel.param.GLinkerSymbol;
import com.vector.cfg.gen.core.bswmdmodel.param.GMultilineString;
import com.vector.cfg.gen.core.bswmdmodel.param.GReference;
import com.vector.cfg.gen.core.bswmdmodel.param.GString;
import com.vector.cfg.gen.core.bswmdmodel.param.GSymbolicNameReference;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIInstanceReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;

/**
 * Factory for bswmd model parameter and references.
 *
 * <p>
 * <b>Attention:</b> DO NOT USE THIS CLASS. THIS CLASS IS INTERNALLY USED!!!
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class GeneratorModelParameterFactory {

    @PublishedField
    public static final ICreateGIModelObjectFunction<GIEcucAddInfoParameter> ADDINFO_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createAddInfo(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GIEcucAddInfoParameter> ADDINFO_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createAddInfo(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GBoolean> BOOLEAN_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createBoolean(defRef,
            (MIParameterValue) cfgElement,
            modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GBoolean> BOOLEAN_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createBoolean(defRef,
            (MIParameterValue) cfgElement,
            modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GChoiceReference> CHOICE_REF_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createChoiceReference(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GChoiceReference> CHOICE_REF_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createChoiceReference(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GFloat> FLOAT_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createFloat(defRef, (MIParameterValue) cfgElement,
            modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GFloat> FLOAT_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createFloat(defRef, (MIParameterValue) cfgElement,
            modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GForeignReference> FOREIGN_REF_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createForeignReference(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GForeignReference> FOREIGN_REF_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createForeignReference(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GFunctionName> FUNC_NAME_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createFunctionName(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GFunctionName> FUNC_NAME_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createFunctionName(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GInstanceReference> INSTANCE_REF_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createInstanceReference(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GInstanceReference> INSTANCE_REF_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createInstanceReference(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GInteger> INTEGER_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createInteger(defRef,
            (MIParameterValue) cfgElement,
            modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GInteger> INTEGER_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createInteger(defRef,
            (MIParameterValue) cfgElement,
            modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GLinkerSymbol> LINKER_SYM_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createLinkerSymbol(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GLinkerSymbol> LINKER_SYM_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createLinkerSymbol(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GIMultilineStringParameter> MULTILINE_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createMultilineString(
            defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GIMultilineStringParameter> MULTILINE_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createMultilineString(defRef,
            (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GReference> REF_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createReference(defRef,
            (MIParameterValue) cfgElement,
            modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GReference> REF_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createReference(defRef,
            (MIParameterValue) cfgElement,
            modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GString> STRING_CREATOR_SINGLE = (defRef, cfgElement, modelAccess, parent) -> createString(defRef,
            (MIParameterValue) cfgElement,
            modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GString> STRING_CREATOR_MANY = (defRef, cfgElement, modelAccess, parent) -> createString(defRef, (MIParameterValue) cfgElement,
            modelAccess, (GIContainer) parent, false);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GSymbolicNameReference> SYMBOLIC_NAME_REF_CREATOR_SINGLE = (defRef, cfgElement, modelAccess,
            parent) -> createSymbolicNameReference(defRef, (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, true);

    @PublishedField
    public static final ICreateGIModelObjectFunction<GSymbolicNameReference> SYMBOLIC_NAME_REF_CREATOR_MANY = (defRef, cfgElement, modelAccess,
            parent) -> createSymbolicNameReference(defRef, (MIParameterValue) cfgElement, modelAccess, (GIContainer) parent, false);

    /**
     * Constructor is private because this factory only provides static methods.
     */
    private GeneratorModelParameterFactory() {
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g function name
     */
    @PublishedMethod
    public static GFunctionName createFunctionName(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent,
            boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GFunctionName(modelAccess, defRef, (MITextualValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GFunctionName) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g linker symbol
     */
    @PublishedMethod
    public static GLinkerSymbol createLinkerSymbol(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent,
            boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GLinkerSymbol(modelAccess, defRef, (MITextualValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GLinkerSymbol) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g string
     */
    @PublishedMethod
    public static GString createString(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GString(modelAccess, defRef, (MITextualValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GString) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g boolean
     */
    @PublishedMethod
    public static GBoolean createBoolean(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GBoolean(modelAccess, defRef, (MINumericalValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GBoolean) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g float
     */
    @PublishedMethod
    public static GFloat createFloat(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GFloat(modelAccess, defRef, (MINumericalValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GFloat) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g integer
     */
    @PublishedMethod
    public static GInteger createInteger(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GInteger(modelAccess, defRef, (MINumericalValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GInteger) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g symbolic name reference
     */
    @PublishedMethod
    public static GSymbolicNameReference createSymbolicNameReference(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent,
            boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GSymbolicNameReference(modelAccess, defRef, (MIReferenceValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GSymbolicNameReference) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g reference
     */
    @PublishedMethod
    public static GReference createReference(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GReference(modelAccess, defRef, (MIReferenceValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GReference) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g choice reference
     */
    @PublishedMethod
    public static GChoiceReference createChoiceReference(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent,
            boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GChoiceReference(modelAccess, defRef, (MIReferenceValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GChoiceReference) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g foreign reference
     */
    @PublishedMethod
    public static GForeignReference createForeignReference(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent,
            boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GForeignReference(modelAccess, defRef, (MIReferenceValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GForeignReference) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g instance reference
     */
    @PublishedMethod
    public static GInstanceReference createInstanceReference(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent,
            boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GInstanceReference(modelAccess, defRef, (MIInstanceReferenceValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GInstanceReference) bswmdParam;
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g add info
     */
    @PublishedMethod
    public static GIEcucAddInfoParameter createAddInfo(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent,
            boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GEcucAddInfo(modelAccess, defRef, parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GIEcucAddInfoParameter) bswmdParam;
    }

    private static void addToCache(MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIModelObject bswmdParam) {
        if (parameter != null) {
            modelAccess.setRelatedElement(bswmdParam, parameter);
        }
    }

    /**
     * Creates a new GeneratorModelParameter object.
     *
     * @param defRef the def ref
     * @param parameter the parameter
     * @param modelAccess the model access
     * @param parent the parent
     * @param onlyOneElement the only one element
     * @return the g add info
     */
    @PublishedMethod
    public static GIMultilineStringParameter createMultilineString(DefRef defRef, MIParameterValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent,
            boolean onlyOneElement) {
        GIModelObject bswmdParam = modelAccess.getRelatedElement(parameter);
        if (bswmdParam == null) {
            bswmdParam = new GMultilineString(modelAccess, defRef, (MITextualValue) parameter, parent, onlyOneElement);
            addToCache(parameter, modelAccess, bswmdParam);
        }
        return (GIMultilineStringParameter) bswmdParam;
    }

}
