package com.vector.annotations.publishedapi;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Classes annotated with {@link PublishedAllowBreakingChange} are allowed to have a breaking change. This will break all users of this API.
 * 
 * <p>
 * Do NOT use this, unless you know what you are doing!
 * </p>
 * 
 * 
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @since 1.0
 */
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.ANNOTATION_TYPE, ElementType.TYPE })
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public @interface PublishedAllowBreakingChange {

}
