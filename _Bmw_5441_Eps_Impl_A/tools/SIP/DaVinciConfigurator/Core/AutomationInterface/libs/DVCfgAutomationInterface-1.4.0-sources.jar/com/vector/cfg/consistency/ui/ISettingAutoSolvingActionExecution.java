package com.vector.cfg.consistency.ui;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * This interface is used to query/modify the auto solving action execution setting.
 *
 * <div class="extdoc" id="common"> Auto-solving-action execution is a feature to simplify configuration by automatically adjusting dependent data after a change was made by the
 * user. This feature runs synchronous to the user change and may have impact on UI responsiveness. If UI response time is not acceptable, this should be reported to Vector.
 *
 * Using {@link #setEnabled(boolean)}, auto-solving-action execution can be disabled to find out if this is the cause and as an interim workaround.
 *
 * If auto-solving-action execution is disabled, data might get out of sync after a user change, E.g. Vtt dual target sync, BSW Internal Behavior, ... . In that case, these have
 * to be solved manually with the corresponding validaton-result's solving action.
 *
 * This setting is stored as user-independent project setting.
 *
 * This setting can only be changed if {@link #isChangeable()} returns true (false e.g. due to read-only project), otherwise an {@link IllegalStateException} is thrown. </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@ThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISettingAutoSolvingActionExecution {

    /**
     * Checks if auto solving action execution is enabled.
     *
     * @return true, if auto solving action execution is enabled
     */
    @PublishedMethod
    boolean isEnabled();

    /**
     * Enables/Disables auto solving action execution. See {@link ISettingAutoSolvingActionExecution}
     *
     * @exception IllegalStateException if {@link #isChangeable()} returns false
     * @param enable the new value
     */
    @PublishedMethod
    void setEnabled(boolean enable);

    /**
     * Checks if the auto solving action execution setting can be changed.
     *
     * @return false if the project settings store is read only, or if the setting is in transition.
     */
    @PublishedMethod
    boolean isChangeable();
}
