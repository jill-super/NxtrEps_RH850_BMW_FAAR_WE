package com.vector.cfg.model.access.ecucdefinition.elements.parameter;

import java.math.BigDecimal;

import javax.annotation.concurrent.NotThreadSafe;

import com.google.common.base.Optional;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFloatParamDef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucFloatDefinition extends IEcucParameterDefinition {

    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    MIFloatParamDef getDef();

    /**
     * returns the optional default value. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<BigDecimal> getDefault();

    /**
     * returns the optional min value. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<BigDecimal> getMinValue();

    /**
     * returns the optional max value. Never returns <code>null</code>.
     *
     */
    @PublishedMethod
    Optional<BigDecimal> getMaxValue();
}
