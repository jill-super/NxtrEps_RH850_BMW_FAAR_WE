package com.vector.cfg.gen.core.bswmdmodel;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.TypedDefRef;
import com.vector.cfg.model.access.WrappedTypedDefRef;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;

/**
 * Internal BswmdModel interface for common access method for Parameters on containers and modules.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIHasParameterAccessFunctions {
    // CHECKSTYLE:ON

    /*----------------------------------------------------------------
     * existsParameter() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns <code>true</code> if the specified parameter exists.
     *
     * @param defRef The {@link DefRef} of the requested parameter.
     * @return
     */
    @PublishedMethod
    boolean existsParameter(DefRef defRef);

    /*----------------------------------------------------------------
     * getParameters() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns all parameters with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested parameter.
     * @return
     */
    @PublishedMethod
    List<GIParameter<?>> getParameters(DefRef defRef);

    /**
     * Returns all parameters with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested parameter.
     * @return
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE> List<GIParameter<VALUE>> getParameters(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns all parameters with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link WrappedTypedDefRef} of the requested element.
     * @return a List of Parameters which has the definition {@link WrappedTypedDefRef}.
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE, WRAPPER extends GIParameter<VALUE>, T extends WRAPPER> List<T> getParameters(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

    /*----------------------------------------------------------------
     * existsReference() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns <code>true</code> if the specified reference exists.
     *
     * @param defRef The {@link DefRef} of the requested parameter.
     * @return
     */
    @PublishedMethod
    boolean existsReference(DefRef defRef);

    /*----------------------------------------------------------------
     * getReferences() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns all references with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested reference.
     * @return
     */
    @PublishedMethod
    List<GIReference<?>> getReferences(DefRef defRef);

    /**
     * Returns all parameters with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link DefRef} of the requested reference.
     * @return
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE extends MIReferrable> List<GIReference<VALUE>> getReferences(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns all references with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link WrappedTypedDefRef} of the requested reference.
     * @return a List of References which has the definition.
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIParameterValue, VALUE extends MIReferrable, WRAPPER extends GIReference<VALUE>, T extends WRAPPER> List<T> getReferences(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

    /*----------------------------------------------------------------
     * getReferencesToContainer() section
     * ----------------------------------------------------------------
     */

    /**
     * Returns all references with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef
     * @return
     */
    @PublishedMethod
    List<GIReferenceToContainer> getReferencesToContainer(DefRef defRef);

    /**
     * Returns all parameters with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef
     * @return
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE> List<GIReferenceToContainer> getReferencesToContainer(TypedDefRef<DEF, CFG, VALUE> defRef);

    /**
     * Returns all references pointing to containers with the specified definition-name in the same order as they are stored in the MDF model.
     *
     * @param defRef The {@link WrappedTypedDefRef} of the requested element
     * @return a List of References which has the definition.
     */
    @PublishedMethod
    <DEF extends MIConfigParameter, CFG extends MIReferenceValue, VALUE, WRAPPER extends GIReferenceToContainer, T extends WRAPPER> List<T> getReferencesToContainer(
            WrappedTypedDefRef<DEF, CFG, VALUE, WRAPPER> defRef);

}
