/**
 * Port mapping related automation scripting object model for the runtime system domain.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.dom.runtimesys.api.assistant.connection;