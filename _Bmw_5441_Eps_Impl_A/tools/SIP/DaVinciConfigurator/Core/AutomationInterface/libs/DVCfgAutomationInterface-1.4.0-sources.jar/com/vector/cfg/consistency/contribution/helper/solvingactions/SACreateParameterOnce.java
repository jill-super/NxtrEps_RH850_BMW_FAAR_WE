package com.vector.cfg.consistency.contribution.helper.solvingactions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * This SA behaves like SACreateParamter, but assures that the parameter in not created more than once
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class SACreateParameterOnce extends SACreateParameter {
    /**
     * Constructor for SACreateParameterOnce.
     *
     * @param parent the parent Container
     * @param paramDef the parameter DefRef
     */
    @PublishedMethod
    public SACreateParameterOnce(MIContainer parent, DefRef paramDef) {
        super(parent, paramDef);
    }

    /**
     * Constructor for SACreateParameterOnce.
     *
     * @param parent the parent Container
     * @param paramDef the parameter DefRef
     * @param override the description
     */
    @PublishedMethod
    public SACreateParameterOnce(MIContainer parent, DefRef paramDef, String description) {
        super(parent, paramDef, description);
    }

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SACreateParameterOnce.class);

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public void run() {
        final IModelAccess ma = ModelUtil.getService(parent, IModelAccess.class);
        if (ma.getChildByDefinition(parent, paramDef) == null) {
            super.run();
        }
    }
}
