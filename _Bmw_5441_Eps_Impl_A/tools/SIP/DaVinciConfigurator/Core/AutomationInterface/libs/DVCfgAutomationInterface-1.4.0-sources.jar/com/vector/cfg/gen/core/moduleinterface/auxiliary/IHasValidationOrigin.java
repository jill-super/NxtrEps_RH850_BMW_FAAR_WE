package com.vector.cfg.gen.core.moduleinterface.auxiliary;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;

/**
 * The Class {@link IHasValidationOrigin} provides a getter semantic for the origin of a {@link IValidationResultId}. E.g. A {@link IGeneratorPackage} is a
 * {@link IHasValidationOrigin}.
 *
 * <p>
 * You could create an {@link IHasValidationOrigin} by using the {@link ValidatorResultOriginBuilder} class.
 * </p>
 *
 * <pre>
 * <code class="Java" id="Create a IHasValidationOrigin with the class ValidatorResultOriginBuilder">
 *  IHasValidationOrigin origin = ValidatorResultOriginBuilder.createOrigin("MyMsn","MyComponent");
 *
 * </code>
 * </pre>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface IHasValidationOrigin {

    /**
     * Gets the Origin of the component.
     *
     * <p>
     * See {@link IValidationResultId#getOrigin()}
     * </p>
     *
     * @return ModuleShortName
     */
    @PublishedMethod
    String getOrigin();

    /**
     * Returns a name of the component which could be used in {@link IValidationResultId#getMessage()} text passages.
     *
     * @return GeneratorName
     */
    @PublishedMethod
    String getGeneratorName();

}
