/**
 * The mode management domain API is specifically designed to support mode management related use cases.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.dom.modemgt.groovy.api;