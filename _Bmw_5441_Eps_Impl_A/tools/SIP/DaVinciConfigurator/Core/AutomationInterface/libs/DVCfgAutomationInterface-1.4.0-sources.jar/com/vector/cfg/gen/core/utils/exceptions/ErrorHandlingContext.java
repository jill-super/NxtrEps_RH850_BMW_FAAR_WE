package com.vector.cfg.gen.core.utils.exceptions;

import java.util.ArrayList;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.consistency.contribution.exceptions.AbstractErrorHandlingContext;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackageReferable;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResult;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorResultSink;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageException;
import com.vector.cfg.gen.core.moduleinterface.exceptions.GeneratorPackageWrapperException;
import com.vector.cfg.gen.core.moduleinterface.exceptions.ValidationFailedException;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultSinkWrapper;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultUtil;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The ErrorHandlingContext class abstract the execution of which which can cause {@link GeneratorPackageException}s or {@link ModelException}s and the corresponding catch
 * blocks.
 *
 * <p>
 * The {@link ErrorHandlingContext} will normally report the {@link IGeneratorResult}s to the {@link IGeneratorResultSink}. If you want a exception thrown after the process you
 * can call {@link #testForErrorAndThrowException()}.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @see {@link GeneratorPackageException}
 * @see ModelException
 * @see IGeneratorResultSink
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class ErrorHandlingContext extends AbstractErrorHandlingContext implements IGeneratorPackageReferable {

    private static final ILogger logger = Logger.INSTANCE.createLogger(ErrorHandlingContext.class);

    /*
     * Private members
     */
    private final List<GeneratorPackageException> exList = new ArrayList<>();

    private final IGeneratorPackage generatorPackage;

    private final IGeneratorResultSink resultSink;

    /**
     * Instantiates a new error handling context.
     *
     * @param generatorPackageRef the generator package ref
     * @param resultSink the result sink
     */
    private ErrorHandlingContext(IGeneratorPackageReferable generatorPackageRef, IValidationResultSink resultSink) {
        super(resultSink);
        this.generatorPackage = generatorPackageRef.getGeneratorPackage();
        this.resultSink = GeneratorResultSinkWrapper.wrap(resultSink);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public IGeneratorPackage getGeneratorPackage() {
        return generatorPackage;
    }

    /**
     * Creates a new {@link ErrorHandlingContext} for the corresponding {@link IGeneratorPackage}. You can create multiple {@link ErrorHandlingContext} object, there is no
     * limitation.
     *
     * <p>
     * <b>Attention:</b> You can not use this create method in a Live-Validation. Calls to this create method are only permitted during the generation process.
     * </p>
     *
     * @param generatorPackageRef the generator package
     * @return the error handling context
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if you make a call to this method when the generation process is not running. E.g. In Live-Validation.</li>
     * </ul>
     *
     */
    @PublishedMethod
    public static ErrorHandlingContext create(IGeneratorPackageReferable generatorPackageRef) {
        return new ErrorHandlingContext(generatorPackageRef, GeneratorResultUtil.getResultSink(generatorPackageRef));
    }

    /**
     * Creates a new {@link ErrorHandlingContext} for the corresponding {@link IGeneratorPackage}. You can create multiple {@link ErrorHandlingContext} object, there is no
     * limitation.
     *
     * <p>
     * <b>Attention:</b> You can use this create method in a Live-Validation. Other create methods like {@link ErrorHandlingContext#create(IGeneratorPackage)} are not permitted
     * during live validation.
     * </p>
     *
     * @param generatorPackageRef the generator package
     * @param resultSink The current resultSink
     * @return the error handling context
     */
    @PublishedMethod
    public static ErrorHandlingContext create(IGeneratorPackageReferable generatorPackageRef, IValidationResultSink resultSink) {
        return new ErrorHandlingContext(generatorPackageRef, resultSink);
    }

    /**
     * Gets the result sink.
     *
     * @return the result sink
     */
    @Override
    @PublishedMethod
    protected IGeneratorResultSink getResultSink() {
        return resultSink;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    protected boolean tryToHandleOccuredException(Exception ex) {
        if (ex instanceof GeneratorPackageException) {
            handleGenPackageEx((GeneratorPackageException) ex);
            return true;
        }

        if (ex instanceof ModelException) {
            return handleModelEx((ModelException) ex);
        }

        return false;
    }

    private void handleGenPackageEx(GeneratorPackageException ex) {
        if (logger.isDebugEnabled()) {
            logger.debug("GeneratorPackageException caught", ex);
        }

        getResultSink().reportGeneratorException(ex);
        exList.add(ex);

    }

    private boolean handleModelEx(ModelException modelEx) {

        if (logger.isDebugEnabled()) {
            logger.debug("ModelException caught", modelEx);
        }

        final List<IGeneratorResult> resultList;
        try {
            resultList = ModelExceptionProcessor.wrapExceptionIntoGeneratorResults(modelEx, generatorPackage);
        } catch (final ModelException innerModelEx) {
            return false;
        }

        // Convert the Exception into a IGeneratorResult
        final ValidationFailedException valEx = new ValidationFailedException(resultList, modelEx);

        getResultSink().reportGeneratorException(valEx);
        exList.add(valEx);
        return true;
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    protected void processTestForErrorAndThrowExInternal() {
        if (!exList.isEmpty()) {
            throw new GeneratorPackageWrapperException(exList);
        }
    }

}
