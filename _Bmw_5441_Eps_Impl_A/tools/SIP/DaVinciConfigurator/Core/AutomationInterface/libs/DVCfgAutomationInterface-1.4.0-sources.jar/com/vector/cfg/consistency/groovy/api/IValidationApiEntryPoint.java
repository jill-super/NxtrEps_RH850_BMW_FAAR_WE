package com.vector.cfg.consistency.groovy.api;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;

/**
 * Methods of this interface are callable in every code block with an active project in context.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IValidationApiEntryPoint {

    /**
     * Gets the {@link IValidationApi}.
     *
     * @return the {@link IValidationApi}
     */
    @PublishedMethod
    IValidationApi getValidation();

    /**
     * Calls the passed {@link Closure} with {@link DelegatesTo} {@link IValidationApi}.
     *
     * @param <T> the generic type
     * @param code the code
     * @return the return value code
     */
    @PublishedMethod
    <T> T validation(@VDelegatesToWithClosureParam(IValidationApi.class) Closure<T> code);
}
