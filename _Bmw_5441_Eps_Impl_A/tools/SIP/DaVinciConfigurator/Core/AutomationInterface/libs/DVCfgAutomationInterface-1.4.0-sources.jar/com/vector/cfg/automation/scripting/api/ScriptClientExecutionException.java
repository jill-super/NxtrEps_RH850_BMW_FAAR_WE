package com.vector.cfg.automation.scripting.api;

import java.util.Optional;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.IScriptTask;
import com.vector.cfg.automation.scripting.base.ScriptingException.IScriptingClientExecutionException;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * <div class="extdoc" id="Common"> The script task can throw an {@link ScriptClientExecutionException} to abort the execution of an {@link IScriptTask}, and display a
 * meaningful message to the user.
 *
 * </div>
 *
 *
 * <div class="extdoc" id="ReservedReturnCodes">
 * <h5>Reserved Return Codes</h5> The returns codes <code>0-20</code> are reversed for internal use of the DaVinci Configurator, and are not allowed to be used by a client
 * script. Also negative returns codes are not permitted.
 *
 * </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see ScriptExecutionException
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public class ScriptClientExecutionException extends ScriptExecutionException implements IScriptingClientExecutionException {
    private static final int RESERVED_RETURN_CODE_MAX = 20;

    private static final long serialVersionUID = -3650747009786491426L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(ScriptClientExecutionException.class);

    private final Integer returnCode;

    @PublishedMethod
    public ScriptClientExecutionException(String message, Throwable cause) {
        this(null, message, cause);

    }

    /**
     * Instantiates a new {@link ScriptClientExecutionException}.
     *
     * @param message the message
     */
    @PublishedMethod
    public ScriptClientExecutionException(String message) {
        this(null, message);
    }

    /**
     * Instantiates a new {@link ScriptClientExecutionException}.
     *
     * @param cause the cause
     */
    @PublishedMethod
    public ScriptClientExecutionException(Throwable cause) {
        this(null, null, cause);
    }

    /**
     * Instantiates a new {@link ScriptClientExecutionException}.
     *
     * <div class="extdoc" id="WithReturnCode">
     * <h5>Exception with Console Return Code</h5> An {@link ScriptClientExecutionException} with an return code of type {@link Integer} will also abort the execution of the
     * {@link IScriptTask}.
     * <p>
     * But it <i>also changes the return code</i> of the console application, if the {@link IScriptTask} was executed in the console application. This could be used when the
     * console application of the DaVinci Configurator is called for other scripts or batch files.
     * </p>
     *
     * </div>
     *
     * @param consoleReturnCode the console return code
     * @param message the message
     */
    @PublishedMethod
    public ScriptClientExecutionException(Integer consoleReturnCode, String message) {
        this(consoleReturnCode, message, null);
    }

    /**
     * Instantiates a new {@link ScriptClientExecutionException}. For details see {@link #ScriptClientExecutionException(Integer, String)}.
     *
     * @param consoleReturnCode the console return code
     * @param message the message
     * @param cause the cause
     */
    @PublishedMethod
    public ScriptClientExecutionException(Integer consoleReturnCode, String message, Throwable cause) {
        super(message, cause);
        returnCode = consoleReturnCode;
        if (returnCode != null) {
            if (returnCode.intValue() == 0) {
                throw new IllegalArgumentException("The ReturnCode 0 is not allowed, because the Exception will abort the execution.");
            }
            if (returnCode.intValue() < 0) {
                throw new IllegalArgumentException("Negative ReturnCodes are not allowed.");
            }
            if (returnCode.intValue() >= 1 && returnCode.intValue() <= RESERVED_RETURN_CODE_MAX) {
                throw new IllegalArgumentException("The ReturnCodes 0-20 are reserved internal codes and are not allowed for client scripts.");
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void buildMessage(StringBuilder builder) {
        buildMessageHeader(builder);
        //Do NOT print the stackframe information for this exception type
        buildWhatWentWrong(builder);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void buildMessageHeader(StringBuilder builder) {
        builder.append("Execution of script task \"");
        builder.append(getExecutedContext().getScriptTask().getQualifiedName());
        builder.append("\" reported an error:");
        builder.append(nlStr());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public Optional<Integer> getConsoleReturnCode() {
        return Optional.ofNullable(returnCode);
    }

}
