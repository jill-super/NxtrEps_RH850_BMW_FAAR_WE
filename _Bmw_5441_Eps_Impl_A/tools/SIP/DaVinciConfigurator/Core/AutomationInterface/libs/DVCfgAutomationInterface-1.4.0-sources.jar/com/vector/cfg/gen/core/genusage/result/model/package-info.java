/**
 * Generation Result model to query information about a executed or running generation process
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.genusage.result.model;