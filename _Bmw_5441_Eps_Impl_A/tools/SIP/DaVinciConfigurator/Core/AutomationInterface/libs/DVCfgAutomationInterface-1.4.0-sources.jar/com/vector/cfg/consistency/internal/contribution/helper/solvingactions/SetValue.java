package com.vector.cfg.consistency.internal.contribution.helper.solvingactions;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.consistency.contribution.helper.solvingactions.generic.SASetNumTextRef;
import com.vector.cfg.model.access.IFormulaExpressionAccess;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.access.ModelUtil;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.formulalanguage.MIFormulaExpression;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.operations.IPublishedInformationModelOperations;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
public class SetValue<NUM_TEXT_TYPE extends MIParameterValue> extends SASetNumTextRef<NUM_TEXT_TYPE> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SetValue.class);

    private final NUM_TEXT_TYPE parameter;

    private final Object value;

    private boolean isPublishedInformation;

    /**
     * Constructor for SetValue.
     *
     * @param parameter
     * @param value
     */
    public SetValue(NUM_TEXT_TYPE parameter, Object value) {
        this(parameter, value, false);
    }

    protected SetValue(NUM_TEXT_TYPE parameter, Object value, boolean isPublishedInformation) {
        super(parameter, MixedText.newBuilder().append(value).flushResult());
        this.parameter = parameter;
        this.value = value;
        this.isPublishedInformation = isPublishedInformation;

        if (!(parameter instanceof MITextualValue) && !(parameter instanceof MINumericalValue)) {
            throw new IllegalArgumentException("parameter must be textual or numerical value");
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    public void run() {
        final Runnable runnable = () -> {
            if (parameter instanceof MITextualValue) {
                ((MITextualValue) parameter).setValue(value.toString());
            } else if (parameter instanceof MINumericalValue) {
                final IModelAccess modelAccess = ModelUtil.getModelAccess(parameter);
                if (value instanceof Boolean) {
                    modelAccess.setAsBoolean((MINumericalValue) parameter, (Boolean) value);
                } else if (value instanceof BigInteger) {
                    modelAccess.setAsInteger((MINumericalValue) parameter, (BigInteger) value);
                } else if (value instanceof BigDecimal) {
                    modelAccess.setAsFloat((MINumericalValue) parameter, (BigDecimal) value);
                }
            }
        };
        if (isPublishedInformation) {
            ModelUtil.getProjectContext(parameter).getService(IPublishedInformationModelOperations.class).executeInPublishedInformationChangeValueContext(runnable);
        } else {
            runnable.run();
        }
    }

    protected static Boolean getAsBoolean(MIFormulaExpression fe) {
        if (fe == null) {
            return null;
        }
        final IFormulaExpressionAccess formulaExpressionAccess = ModelUtil.getService(fe, IFormulaExpressionAccess.class);
        return formulaExpressionAccess.getAsBoolean(fe);
    }

    protected static BigInteger getAsInteger(MIFormulaExpression fe) {
        if (fe == null) {
            return null;
        }
        final IFormulaExpressionAccess formulaExpressionAccess = ModelUtil.getService(fe, IFormulaExpressionAccess.class);
        return formulaExpressionAccess.getAsInteger(fe);
    }

    protected static BigInteger getAsIntegerNoThrow(MIFormulaExpression fe) {
        try {
            return getAsInteger(fe);
        } catch (final NumberFormatException nfe) {
            return null;
        }
    }

    protected static BigDecimal getAsFloat(MIFormulaExpression fe) {
        if (fe == null) {
            return null;
        }
        final IFormulaExpressionAccess formulaExpressionAccess = ModelUtil.getService(fe, IFormulaExpressionAccess.class);
        return formulaExpressionAccess.getAsFloat(fe);
    }

    protected static BigDecimal getAsFloatNoThrow(MIFormulaExpression fe) {
        try {
            return getAsFloat(fe);
        } catch (final NumberFormatException nfe) {
            return null;
        }
    }
}
