package com.vector.cfg.gen.core.utils.formatting.formatter;

import java.util.ArrayList;
import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.GenConstants;
import com.vector.cfg.gen.core.utils.formatting.EFormatType;
import com.vector.cfg.gen.core.utils.formatting.IGenElement;
import com.vector.cfg.gen.core.utils.formatting.IListGenElement;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractPrimitiveElement;
import com.vector.cfg.gen.core.utils.formatting.structures.GenArray;

/**
 * See {@link EFormatType#TABLE_FORMAT} for more details.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class TableFormatter extends AbstractFormatter {

    private final int startIndentationLevel;

    private int builderLength = 0;

    private final List<Integer> columnLengths = new ArrayList<>();

    private final List<String> columnHeader = new ArrayList<>();

    private int elementCount;

    private boolean headerOutput = false;

    private static final int COMMA_AND_SPACE_LENGTH = 2;

    /**
     * Instantiates a new table formatter.
     *
     * @param startIndentationLevel the start indentation level
     */
    @PublishedMethod
    public TableFormatter(int startIndentationLevel) {
        this.startIndentationLevel = startIndentationLevel;
    }

    /**
     * Instantiates a new table formatter.
     */
    @PublishedMethod
    public TableFormatter() {
        this(0);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreBlockStart(StringBuilder builder, int indent) {
        if (!isLastEntryANewLine(builder) && builder.length() != builderLength) {
            builder.append(GenConstants.LINE_SEPARATOR);
        }
        for (int x = 0; x < (indent + startIndentationLevel); x++) {
            builder.append("  ");
        }

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostBlockStart(StringBuilder builder, int indent) {

        if (!headerOutput && columnHeader.size() > 0 && columnHeader.size() <= columnLengths.size()) {

            builder.append(GenConstants.LINE_SEPARATOR);

            appendSpaces(builder, 3);

            int column = 0;
            for (final String header : columnHeader) {

                builder.append(header);

                appendSpaces(builder, columnLengths.get(column) - header.length() + COMMA_AND_SPACE_LENGTH);

                column++;
            }

            builder.append(GenConstants.LINE_SEPARATOR);
            headerOutput = true;
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreBlockEnd(StringBuilder builder, int indent) {

        if (isLastEntryANewLine(builder)) {
            for (int x = 0; x < (indent + startIndentationLevel); x++) {
                builder.append("  ");
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostBlockEnd(StringBuilder builder, int indent) {
        if (!isLastEntryANewLine(builder)) {
            builder.append(GenConstants.LINE_SEPARATOR);
        }

        elementCount = 0;

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreElement(StringBuilder builder, int indent) {
        if (isLastEntryANewLine(builder)) {
            for (int x = 0; x < (indent + startIndentationLevel); x++) {
                builder.append(" ");
            }
        }

        builderLength = builder.length();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostElement(StringBuilder builder, int indent) {

        final int elementLength = builder.length() - builderLength - COMMA_AND_SPACE_LENGTH;

        if (columnLengths.size() >= elementCount) {

            appendSpaces(builder, (columnLengths.get(elementCount) - elementLength));
        }
        elementCount++;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostHeader(StringBuilder builder, int indent, IListGenElement element) {
        builderLength = builder.length();

    }

    /**
     * Setter method for columnLenghts.
     *
     * @param genArray The GenArray to format.
     */
    @PublishedMethod
    public void setColumnLenghts(GenArray genArray) {

        if (isTableCompliant(genArray)) {
            calcColumnLengths(genArray);
        } else {
            throwIllegalArgumentException();
        }

    }

    /**
     * Setter method for columnHeader.
     *
     * @param columnHeaderList The columnHeaders to set.
     * @param genArray The GenArray to format.
     */
    @PublishedMethod
    public void setColumnHeader(List<String> columnHeaderList, GenArray genArray) {

        if (isTableCompliant(genArray)) {
            for (final String header : columnHeaderList) {
                this.columnHeader.add("/*" + header + "*/");
            }
        } else {
            throwIllegalArgumentException();
        }

    }

    /**
     * Method to throw a IllegalArgumentException if the GenArray is not table compliant.
     *
     */
    private void throwIllegalArgumentException() {
        throw new IllegalArgumentException("The GenArray to generate is not table compliant. Please check if the GenArray is a two dimensional array, "
                + "consists of one or more inner GenArrays and this inner GenArrays only consists of AbstractPrimitiveElements (String, Bool, Int, Float, Enum).");
    }

    /**
     * Method to append spaces to the builder specified by count.
     *
     * @param builder
     * @param count
     */
    private void appendSpaces(StringBuilder builder, int count) {
        for (int x = 0; x < count; x++) {
            builder.append(" ");
        }
    }

    /**
     * Table compliant means, that the GenArray is a two dimensional array and consists of one or more inner GenArrays. This inner GenArrays only consists of
     * {@link AbstractPrimitiveElement}s (String, Bool, Int, Float, Enum).
     *
     * @return true, if the GenArray is table compliant.
     */
    private boolean isTableCompliant(GenArray genArray) {

        for (final IGenElement element : genArray.getContent()) {

            if (element instanceof GenArray) {

                for (final IGenElement innerElement : ((GenArray) element).getContent()) {

                    if (!(innerElement instanceof AbstractPrimitiveElement<?>)) {
                        return false;
                    }
                }
            } else {
                return false;
            }
        }

        return true;
    }

    /**
     * If a GenArray is "table compliant" (see {@link isTableCompliant}), the max. column lengths will be calculated.
     *
     * @return The column lengths as list of integer.
     */
    private void calcColumnLengths(GenArray genArray) {

        for (final IGenElement element : genArray.getContent()) {

            if (element instanceof GenArray) {

                int column = 0;
                for (final IGenElement innerElement : ((GenArray) element).getContent()) {

                    if (innerElement instanceof AbstractPrimitiveElement<?>) {

                        final int innerElementLength = innerElement.generate().length();

                        if (this.columnLengths.size() < (column + 1)) {

                            this.columnLengths.add(innerElementLength);
                        } else if (this.columnLengths.get(column) < innerElementLength) {

                            this.columnLengths.set(column, innerElementLength);
                        }

                        column++;
                    }
                }
            }
        }

        //Recalc if a header exits
        if (this.columnLengths.size() == this.columnHeader.size()) {
            int column = 0;
            for (final Integer columnLength : this.columnLengths) {

                final String header = this.columnHeader.get(column);
                if (header != null) {

                    if (columnLength < header.length()) {
                        this.columnLengths.set(column, header.length());
                    }
                }
                column++;
            }
        }
    }
}
