package com.vector.cfg.consistency.contribution.helper.solvingactions;

import java.math.BigDecimal;
import java.math.BigInteger;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.internal.contribution.helper.solvingactions.SetValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFloatParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIIntegerParamDef;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class SetMaximumValue extends SetValue<MINumericalValue> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SetMaximumValue.class);

    /**
     * Constructor for SetDefaultValue.
     *
     * @param parameter
     * @param defaultValue
     */
    @PublishedMethod
    public SetMaximumValue(MINumericalValue parameter, Object defaultValue) {
        super(parameter, defaultValue);
        setTargetValueInfo(MixedText.newBuilder().append("maximum value").flushResult());
    }

    @PublishedMethod
    public static SetMaximumValue create(MIParameterValue parameter) {
        SetMaximumValue ret = null;
        try {
            final MIConfigParameter configParameter = parameter.getDefinitionRef().getRefTarget();
            if (configParameter instanceof MIFloatParamDef) {
                final BigDecimal val = getAsFloat(((MIFloatParamDef) configParameter).getMax());
                if (val != null) {
                    ret = new SetMaximumValue((MINumericalValue) parameter, val);
                }
            } else if (configParameter instanceof MIIntegerParamDef) {
                final BigInteger val = getAsInteger(((MIIntegerParamDef) configParameter).getMax());
                if (val != null) {
                    ret = new SetMaximumValue((MINumericalValue) parameter, val);
                }
            }
        } catch (final Throwable e) {
            ret = null;
        }
        return ret;
    }
}
