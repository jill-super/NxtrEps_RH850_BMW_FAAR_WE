package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Repeatable;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * The {@link @UsesPublishedApiFrom} marks a method, field or class using {@link PublishedApi} from a newer version than the minimal API version. This will disable the compile
 * error, when using newer API.
 *
 * <p>
 * Client side code shall use the the field of the version class, instead of literal strings. <br/>
 * Sample usage with default domain GENERATORS:
 *
 * <pre>
 * <code class="Java" id="UsesPublishedApiFrom annotation sample">
 *
 *  &#064;UsesPublishedApiFrom(version = GeneratorApiVersion.VERSION_GENERATORS_R14)
 *  public void myMethod(){
 *  }
 * </code>
 * </pre>
 *
 *
 * <br/>
 * Sample with explicit {@link DomainType}:
 *
 * <pre>
 * <code class="Java" id="UsesPublishedApiFrom annotation sample with explicit DomainType">
 *
 *  &#064;UsesPublishedApiFrom(version = GeneratorApiVersion.VERSION_GENERATORS_R14, domainType = GeneratorApiVersion.DOMAIN_GENERATORS)
 *  public void myMethod(){
 *  }
 * </code>
 * </pre>
 *
 *
 * <br/>
 * Sample with disabled runtime check (Please use this flag only if you have a performance critical code section. AFTER you have measured it!):
 *
 * <pre>
 * <code class="Java" id="UsesPublishedApiFrom annotation sample with disabled Runtime check">
 *
 *  &#064;UsesPublishedApiFrom(version = GeneratorApiVersion.VERSION_GENERATORS_R14, disableRuntimeVersionCheck=false)
 *  public void myMethod(){
 *  }
 * </code>
 * </pre>
 *
 * </p>
 *
 * <p>
 * A client side element could have multiple annotation of the type {@link UsesPublishedApiFrom}, but NOT for the same {@link DomainType}. It is a compile time error to use
 * multiple annotation with the same {@link DomainType} on one element.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@Documented
@Retention(RetentionPolicy.CLASS)
@Target({ ElementType.TYPE, ElementType.CONSTRUCTOR, ElementType.METHOD, ElementType.ANNOTATION_TYPE })
@Repeatable(value = UsesPublishedApiFromContainer.class)
public @interface UsesPublishedApiFrom {

    /**
     * The version of the {@link PublishedApi} to use.
     * <p>
     * Note: the version shall correspond to the selected {@link DomainType}, see {@link #domainType()}.
     * </p>
     *
     * <p>
     * Client side code shall use the the field of the corresponding version class, instead of literal strings:
     *
     * <pre>
     * <code class="Java" id="UsesPublishedApiFrom annotation sample">
     *
     * 	&#064;UsesPublishedApiFrom(version = GeneratorApiVersion.VERSION_GENERATORS_R14, domain = GeneratorApiVersion.DOMAIN_GENERATORS)
     * 	public void myMethod(){
     * 	}
     * </code>
     * </pre>
     *
     * </p>
     *
     * @return the string
     */
    @PublishedMethod
    String version();

    /**
     * The {@link DomainType} to use, as string. The default is {@link DomainType#GENERATORS}, if nothing is specified.
     *
     * <p>
     * Client side code shall use the the domain field of the corresponding version class, instead of literal strings:
     *
     * <pre>
     * <code class="Java" id="UsesPublishedApiFrom annotation sample">
     *
     *  &#064;UsesPublishedApiFrom(version = GeneratorApiVersion.VERSION_GENERATORS_R14, domain = GeneratorApiVersion.DOMAIN_GENERATORS)
     *  public void myMethod(){
     *  }
     * </code>
     * </pre>
     *
     * </p>
     *
     * @return the domainType to verify against.
     */
    @PublishedMethod
    String domainType() default "GENERATORS";

    /**
     * If <code>true</code>, the runtime version check is disabled, otherwise the runtime version check is enabled.
     *
     * <p>
     * The ApiVersioning compiler addon will generate a RuntimeVersion check into all methods, were this flag is <code>false</code>. This check will guarantee, that the method
     * is not used without a proper version check.
     * </p>
     *
     * <p>
     * Please use this flag only if you have a performance critical code section. AFTER you have measured it!
     * </p>
     *
     * @return true, if the runtime version check is disabled.
     */
    @PublishedMethod
    boolean disableRuntimeVersionCheck() default false;
}
