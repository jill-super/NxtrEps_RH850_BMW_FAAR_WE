package com.vector.cfg.gen.core.utils.formatting.structures;

import static com.google.common.base.Preconditions.checkArgument;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractGenElement;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractPrimitiveElement;
import com.vector.cfg.gen.core.utils.formatting.structures.GenDefineList.DefineElement;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The Format class for define lists.
 *
 * <p>
 * Example: <br/>
 * <code><pre>
 * #define CHL_1
 * #define My_CHL2
 * #define CHL_503
 * </pre></code>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GenDefineList extends AbstractGenList<GenDefineList, DefineElement> {

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GenDefineList.class);

    @PublishedField
    public static final GenDefineList EMPTY_LIST = create().setImmutable();

    private boolean autoAllign = true;

    private int manualAllignment;

    private int defineIndent;

    /**
     * Instantiates a new {@link GenDefineList}.
     */
    @PublishedMethod
    protected GenDefineList() {
        super();

    }

    /**
     * Creates a new {@link GenDefineList}.
     *
     * @return the new {@link GenDefineList}.
     */
    @PublishedMethod
    public static GenDefineList create() {
        final GenDefineList genDefineList = createInternal();

        return genDefineList;

    }

    private static GenDefineList createInternal() {
        return new GenDefineList();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected DefineElement createNewListElement(AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> elem1,
            AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> elem2) {
        return new DefineElement(elem1, elem2);
    }

    /**
     * Enables/Disable the AutoAllignment feature, this means the values of the Defines are aligned in the same column.
     * <p>
     * The default is <code>true</code>.
     *
     * @return the gen define list
     */
    @PublishedMethod
    public GenDefineList allignAutomatically(boolean autoAllignment) {
        ensureObjectIsMutable();
        checkArgument(manualAllignment == 0);
        autoAllign = autoAllignment;
        return this;
    }

    /**
     * Alligns the defines values manually at the column specified by chars count.
     *
     * <p>
     * Note: The #define tag and alle formatter spaces are not counted in the indentation value!
     * </p>
     *
     * @param chars the chars
     * @return the gen define list
     */
    @PublishedMethod
    public GenDefineList allignManually(int chars) {
        ensureObjectIsMutable();
        checkArgument(chars > 0);
        autoAllign = false;
        manualAllignment = chars;
        return this;
    }

    /**
     * Insert an indent between # and the define-keyword specified by chars count.
     * <p>
     * Example:
     * </p>
     *
     * <pre>
     * <code>
     * myElem.indentDefine(4)
     * // Will generate in c code
     *
     * #    define name
     * </code>
     * </pre>
     *
     * @param chars the chars
     * @return the gen define list
     */
    @PublishedMethod
    public GenDefineList indentDefine(int chars) {
        ensureObjectIsMutable();
        checkArgument(chars >= 0);
        defineIndent = chars;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void generateInternal(StringBuilder builder, IGenFormatter formatter, int indent, boolean isRootElement) {

        generateHeader(builder, formatter, indent, this);

        generatePrefixComment(builder);

        /*
         * Determine Allignment
         */
        final int largestDefine;
        if (manualAllignment > 0) {
            largestDefine = manualAllignment;
        } else {
            if (autoAllign) {
                largestDefine = determineLargestDefine();
            } else {
                largestDefine = 1;
            }
        }

        for (final DefineElement element : getGenList()) {

            formatter.formatPreElement(builder, indent);

            builder.append("#");

            for (int i = 0; i < defineIndent; i++) {
                builder.append(" ");
            }

            builder.append("define ");

            final int lenBeforeDefine = builder.length();
            element.define.generate(builder, formatter, indent, false);

            int len = builder.length() - lenBeforeDefine;
            if (len < 1) {
                len = 1;
            }
            if (len >= largestDefine) {
                len = largestDefine - 1;
            }

            if (element.value != null) {

                for (int x = 0; x < largestDefine - len; x++) {
                    builder.append(" ");
                }

                element.value.generate(builder, formatter, indent, false);
            }

            builder.append(" \r\n");

            formatter.formatPostElement(builder, indent);

        }

        generatePostfixComment(builder);

        generateFooter(builder, formatter, indent, this);
    }

    /**
     * @return
     *
     * @exception NullPointerException <ul>
     * <li>if the value is null</li>
     * </ul>
     */
    private int determineLargestDefine() {
        int largestDefine = 1;

        for (final DefineElement element : getGenList()) {
            final int len = element.define.generate().length();
            if (len > largestDefine) {
                largestDefine = len;
            }
        }
        return largestDefine + 1;
    }

    /**
     * Define element used by the GenDefineList
     * <p>
     * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
     * </p>
     *
     * @since 1.0
     */
    @PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
    public class DefineElement extends AbstractGenElement<DefineElement> {

        private final AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> define;

        private final AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> value;

        /**
         * Instantiates a new define element.
         *
         * @param def the def
         * @param val the val
         */
        @PublishedMethod
        public DefineElement(AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> def, AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> val) {
            define = def;
            value = val;
        }

        /**
         * Gets the define.
         *
         * @return the define
         */
        @PublishedMethod
        public AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> getDefine() {
            return define;
        }

        /**
         * Gets the value.
         *
         * @return the value
         */
        @PublishedMethod
        public AbstractPrimitiveElement<? extends AbstractPrimitiveElement<?>> getValue() {
            return value;
        }

        /**
         * {@inheritDoc}
         */
        @PublishedMethod
        @Override
        protected void generateInternal(StringBuilder builder, IGenFormatter formatter, int indent, boolean isRootElement) {
            throw new IllegalStateException("Method is not supported");

        }

    }

}
