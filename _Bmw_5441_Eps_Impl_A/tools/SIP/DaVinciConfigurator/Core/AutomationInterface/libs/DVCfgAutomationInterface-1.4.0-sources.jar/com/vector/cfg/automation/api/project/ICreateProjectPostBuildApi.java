package com.vector.cfg.automation.api.project;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link ICreateProjectPostBuildApi} provides means for specifying the new project's post build settings.
 * <div class="extdoc" id="ICreateProjectPostBuildApi"><!--Label:ICreateProjectPostBuildApi-->{@link ICreateProjectPostBuildApi} contains the API to specify the new project's
 * post build settings.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface ICreateProjectPostBuildApi {

    /**
     * Alias for {@link #setLoadable(boolean)}.
     */
    @PublishedMethod
    void loadable(boolean loadable);

    /**
     * Specified whether or not to support post build loadable for the new project.
     *
     * <div class="extdoc" id="setLoadable"><!--Label:ICreateProjectPostBuildApi.setLoadable-->
     * <h5>Post-build Loadable Support</h5> {@link #setLoadable(boolean)} sets whether or not to support Post-build loadable for the new project. This is an optional parameter
     * defaulting to {@code false} if the parameter is not provided explicitly.
     *
     * </div>
     *
     * @param loadable whether or not to support post build loadable for the new project
     */
    @PublishedMethod
    void setLoadable(boolean loadable);

    /**
     * Alias for {@link #setSelectable(boolean)}.
     */
    @PublishedMethod
    void selectable(boolean selectable);

    /**
     * Specified whether or not to support post build selectable for the new project.
     *
     * <div class="extdoc" id="setSelectable"><!--Label:ICreateProjectPostBuildApi.setSelectable-->
     * <h5>Post-Build Selectable Support</h5> {@link #setSelectable(boolean)} sets whether or not to support Post-build selectable for the new project. This is an optional
     * parameter defaulting to {@code false} if the parameter is not provided explicitly.
     *
     * </div>
     *
     * @param selectable whether or not to support post build selectable for the new project
     */
    @PublishedMethod
    void setSelectable(boolean selectable);

}
