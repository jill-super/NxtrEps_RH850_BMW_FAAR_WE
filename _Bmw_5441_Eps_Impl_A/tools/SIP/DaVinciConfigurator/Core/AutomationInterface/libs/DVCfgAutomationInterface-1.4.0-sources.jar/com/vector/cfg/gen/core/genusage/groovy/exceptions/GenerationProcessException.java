package com.vector.cfg.gen.core.genusage.groovy.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.genusage.groovy.api.IGenerationApi;
import com.vector.cfg.gen.core.genusage.groovy.api.swct.IGenerationSwctApi;

/**
 * {@link GenerationProcessException} indicates that a generation cal of the generation API has failed.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 * 
 * @see IGenerationApi
 * @see IGenerationSwctApi
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public class GenerationProcessException extends RuntimeException {
    private static final long serialVersionUID = -5011257900907708540L;

    @PublishedMethod
    public GenerationProcessException(String string) {
        super(string);
    }

    @PublishedMethod
    public GenerationProcessException(Throwable cause) {
        super(cause);

    }

    @PublishedMethod
    public GenerationProcessException(String message, Throwable cause) {
        super(message, cause);
    }

}
