package com.vector.cfg.consistency;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.util.activity.execresult.EExecutionResult;
import com.vector.cfg.util.activity.execresult.IExecutionResult;

/**
 * <div class="extdoc" id="Common">An {@link ISolvingActionSummaryResult} represents the execution of multiple results.</div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ISolvingActionSummaryResult extends IExecutionResult {
    /**
     * <div class="extdoc" id="getSubResults">Call {@link #getSubResults()} to get a list of {@link ISolvingActionExecutionResult}s.</div>
     *
     * @return the sub results
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    List<ISolvingActionExecutionResult> getSubResults();

    /**
     *
     * If there is no sub result, {@link EExecutionResult#ERROR} will be returned, because this should not occur.<br/>
     * If all sub results have the same severity, that severity is returned.<br/>
     * Otherwise (mixture of ok/error), {@link EExecutionResult#WARNING} will be returned, because some solving actions succeeded and some not.<br/>
     *
     *
     *
     */
    @Override
    @PublishedMethod
    EExecutionResult getExecutionResult();

    /**
     * <div class="extdoc" id="isOk">{@link ISolvingActionSummaryResult#isOk()} returns true if {@link #getExecutionResult()} is {@link EExecutionResult#SUCCESSFUL} or
     * {@link EExecutionResult#WARNING}, this is if at least one sub-result was ok.</div>
     *
     * @return if at least one sub-result was ok.
     */
    @Override
    @PublishedMethod
    boolean isOk();
}
