package com.vector.cfg.gen.core.bswmdmodel.param;

import java.util.ArrayList;
import java.util.List;

import com.google.common.base.Optional;
import com.google.common.collect.ImmutableList;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractRefToContainer;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucContainerDefinition;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucAbstractRef;
import com.vector.cfg.model.access.ecucdefinition.elements.reference.IEcucRefDefinition;
import com.vector.cfg.model.access.ecuconfiguration.reference.IEcucSimpleReferenceParameter;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrableARRef;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIConfigParameter;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIReferenceParamDef;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.davinci.util.base.VUtil;

/**
 * Reference parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GReference extends GAbstractRefToContainer {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GReference.class);

    private MIContainer value;

    /**
     * Constructor.
     *
     * @deprecated Do NOT use this constructor anymore!
     */
    @ReworkThisAtNextBreakingChange
    @KeepSecretFromPublishedApi
    @Deprecated
    public GReference(DefRef defRef, MIReferenceValue parameter, IInternalGeneratorModelAccess modelAccess, GIContainer parent, boolean onlyOneElement) {
        super(defRef, parameter, modelAccess, parent, onlyOneElement);
    }

    /**
     * Constructor.
     */
    @PublishedMethod
    public GReference(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MIReferenceValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);
    }

    @Override
    @PublishedMethod
    protected void initRef() {
        final MIReferenceValue mdfObjLoc = getMdfObject();
        if (mdfObjLoc != null) {
            final MIReferrableARRef valueLoc = mdfObjLoc.getValue();
            if (valueLoc != null) {
                setPath(valueLoc.getValue());
                setTarget(valueLoc.getRefTarget());
            }
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MIReferenceValue getMdfObjectUnsafe() {
        return (MIReferenceValue) super.getMdfObjectUnsafe();
    }

    @PublishedMethod
    @Override
    public MIContainer getRefTargetMdf() {
        if (isValueChecked()) {
            return value;
        }
        try {
            switchView();

            final MIReferrable target = super.getRefTargetMdf();

            getModelVerifier().assertReferenceTargetHasCorrectType(this, target, MIContainer.class);

            final MIContainer targetContainer = (MIContainer) target;
            getModelVerifier().assertReferenceTargetHasCorrectDefinition(this, targetContainer);

            value = targetContainer;
            setValueChecked();
            return value;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     *
     * <p>
     * Note: You could cast the return type to {@link IEcucRefDefinition}, if this element is a real Reference, instead of {@link GChoiceReference} or
     * {@link GSymbolicNameReference}.
     * </p>
     */
    @PublishedMethod
    @Override
    public IEcucAbstractRef getEcucDefinition() {
        final MIConfigParameter definition = getDefinition();
        if (definition instanceof MIReferenceParamDef) {
            return getGeneratorModelAccess().getEcucDefinitionAccess().def((MIReferenceParamDef) definition);
        }

        throw new AbstractMethodError(
                "Subtypes have to override this method with the correct specific type for the definition object, due to the issue that MDF Choice/SymName Ref def object do not derive from Reference Def.");
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucSimpleReferenceParameter getEcuConfiguration() {

        return getGeneratorModelAccess().getEcuConfigurationAccess().cfg(getMdfObject());
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public List<? extends GIContainer> getPossibleRefTargets() {

        final List<GIContainer> possibleTargets = new ArrayList<>();

        final Optional<IEcucContainerDefinition> targetDefinition = getGenModelAccessInternal().getEcucDefinitionAccess().def((MIReferenceParamDef) getDefinition())
                .getTargetDefinition();
        if (targetDefinition.isPresent()) {
            getPossibleRefTargetsInternal(possibleTargets, targetDefinition.get());
        }

        return VUtil.uncheckedCast(ImmutableList.copyOf(possibleTargets));
    }

}
