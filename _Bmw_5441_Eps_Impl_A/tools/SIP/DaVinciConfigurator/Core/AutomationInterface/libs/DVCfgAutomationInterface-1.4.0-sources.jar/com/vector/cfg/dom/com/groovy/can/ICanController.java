package com.vector.cfg.dom.com.groovy.can;

import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * An {@link ICanController} instance represents a CanController {@link MIContainer} providing support for use cases exceeding those supported by the model API.
 * <div class="extdoc" id="ICanController"><!--Label:ICanController-->An {@link ICanController} instance represents a CanController {@link MIContainer} providing support for use
 * cases exceeding those supported by the model API.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface ICanController extends IHasModelObject {

    /**
     * {@link #openAcceptanceFilters()} opens all of this {@link ICanController}'s acceptance filters.
     * <div class="extdoc" id="openAcceptanceFilters"><!--Label:ICanController.openAcceptanceFilters-->
     * <h5>Opening Acceptance Filters</h5>{@link #openAcceptanceFilters()} opens all of this {@link ICanController}'s acceptance filters.</div>
     *
     * @return this {@link ICanController} instance (for chaining API calls)
     */
    @PublishedMethod
    ICanController openAcceptanceFilters();

    /**
     * {@link #optimizeFilters(Closure)} optimizes this {@link ICanController}'s acceptance filter mask configurations.
     * <div class="extdoc" id="optimizeFilters"><!--Label:ICanController.optimizeFilters-->
     * <h5>Optimizing Acceptance Filters</h5>{@link #optimizeFilters(Closure)} optimizes this {@link ICanController}'s acceptance filter mask configurations. The given
     * {@link Closure} is delegated to the {@link IOptimizeAcceptanceFiltersApi} interface for parameterizing the optimization.</div>
     *
     * @return this {@link ICanController} instance (for chaining API calls)
     */
    @PublishedMethod
    ICanController optimizeFilters(@Nonnull @VDelegatesToWithClosureParam(IOptimizeAcceptanceFiltersApi.class) Closure<?> code);

    /**
     * {@link #createCanFilterMask()} creates a new {@link ICanFilterMask} for this {@link ICanController}.
     * <div class="extdoc" id="createCanFilterMask"><!--Label:ICanController.createCanFilterMask-->
     * <h5>Creating new CanFilterMasks</h5>{@link #createCanFilterMask()} creates a new {@link ICanFilterMask} for this {@link ICanController}.</div>
     *
     * @return the new {@link ICanFilterMask} (never {@code null})
     */
    @PublishedMethod
    ICanFilterMask createCanFilterMask();

    /**
     * {@link #getCanFilterMasks()} returns all of this {@link ICanController}'s {@link ICanFilterMask}s.
     * <div class="extdoc" id="getCanFilterMasks"><!--Label:ICanController.getCanFilterMasks-->
     * <h5>Accessing a CanController's CanFilterMasks</h5>{@link #getCanFilterMasks()} returns all of this {@link ICanController}'s {@link ICanFilterMask}s.</div>
     *
     * @return all {@link ICanFilterMask}s of this {@link ICanController}
     */
    @PublishedMethod
    List<ICanFilterMask> getCanFilterMasks();

    /**
     * {@link #getMdfObject()} returns the {@link MIContainer} represented by this {@link ICanController}.
     * <div class="extdoc" id="getMdfObject"><!--Label:ICanController.getMdfObject-->
     * <h5>Accessing a CanController's MIContainer</h5>{@link #getMdfObject()} returns the {@link MIContainer} represented by this {@link ICanController}.</div>
     *
     * @return the {@link MIContainer} represented by this {@link ICanController}
     */
    @Override
    @PublishedMethod
    MIContainer getMdfObject();
}
