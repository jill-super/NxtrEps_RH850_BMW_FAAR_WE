package com.vector.cfg.consistency.groovy.api;

import java.util.function.Predicate;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.ui.IValidationResultUI;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * This builder interface is used to specify which validation results should by solved with which solving action. <br/>
 * See documentation of the complete fluent API in {@link ISolver#solve(Closure)}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface IResultFilterSolvingActionMapperBuilder {

    /**
     * Pass a predicate-closure of {@link IValidationResultUI} to this method that specifies which results should be solved.<br/>
     * See documentation of the complete fluent API in {@link ISolver#solve(Closure)}.
     *
     * @param resultPredicate the result predicate
     * @return the {@link ISolvingActionSelect} that has to be used to specify which solving action has to be used to solve the results that match the predicate.
     */
    @PublishedMethod
    ISolvingActionSelect result(@VDelegatesToWithClosureParam(IValidationResultUI.class) Closure<Boolean> resultPredicate);

    /**
     * Pass a {@link Predicate} of {@link IValidationResultUI} to this method that returns whether a result should be solved.<br/>
     * See documentation of the complete fluent API in {@link ISolver#solve(Closure)}.
     *
     * @param resultPredicate the result predicate
     * @return the {@link ISolvingActionSelect} that has to be used to specify which solving action has to be used to solve the results that match the predicate.
     */
    @PublishedMethod
    ISolvingActionSelect result(Predicate<IValidationResultUI> resultPredicate);
}
