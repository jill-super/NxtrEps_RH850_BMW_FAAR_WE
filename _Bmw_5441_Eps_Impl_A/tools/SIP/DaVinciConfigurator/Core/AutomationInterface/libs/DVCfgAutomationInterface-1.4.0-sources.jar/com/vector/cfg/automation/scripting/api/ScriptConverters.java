package com.vector.cfg.automation.scripting.api;

import static com.vector.davinci.util.function.IConverter.converter;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.nio.file.Path;
import java.util.function.Function;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.base.AutomationContexts;
import com.vector.cfg.automation.scripting.base.paths.IAutomationPathsApi;
import com.vector.cfg.util.version.IVersion;
import com.vector.cfg.util.version.Version;

/**
 * {@link ScriptConverters} provides general purpose {@link Function}s performing value conversions used throughout the automation interface.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class ScriptConverters {

    @PublishedMethod
    private ScriptConverters() {
    }

    /**
     * Attempts to convert arbitrary {@link Object}s to {@link Path}s. <div class="extdoc" id="TO_PATH">
     * <h5>ScriptConverters.TO_PATH</h5><!--Label:ScriptConverters.TO_PATH-->Attempts to convert arbitrary {@link Object}s to {@link Path}s using<br>
     * {@link IAutomationPathsApi#resolvePath(Object)} <!--Ref:IAutomationPathsApi.resolvePath-->.
     *
     * </div>
     */
    @PublishedField
    public static final Function<Object, Path> TO_PATH = converter(object -> {

        return AutomationContexts.getCurrentContextOfThisThreadChecked().getPaths().resolvePath(object);

    });

    /**
     * Attempts to convert arbitrary {@link Object}s to {@link Path}s. <div class="extdoc" id="TO_SCRIPT_PATH">
     * <h5>ScriptConverters.TO_SCRIPT_PATH</h5><!--Label:ScriptConverters.TO_SCRIPT_PATH-->Attempts to convert arbitrary {@link Object}s to {@link Path}s using
     * {@link IAutomationPathsApi#resolveScriptPath(Object)} <!--Ref:IAutomationPathsApi.resolveScriptPath-->.
     *
     * </div>
     */
    @PublishedField
    public static final Function<Object, Path> TO_SCRIPT_PATH = converter(object -> {

        return AutomationContexts.getCurrentContextOfThisThreadChecked().getPaths().resolvePath(object);

    });

    /**
     * Attempts to convert arbitrary {@link Object}s to {@link IVersion}s. <div class="extdoc" id="TO_VERSION">
     * <h5>ScriptConverters.TO_VERSION</h5><!--Label:ScriptConverters.TO_VERSION-->Attempts to convert arbitrary {@link Object}s to {@link IVersion}s. The following conversions
     * are implemented:
     * <ul>
     * <li>For {@code null} or {@link IVersion} arguments the given argument is returned. No conversion is applied.</li>
     * <li>{@link String}s are converted using {@link Version#valueOf(String)}.</li>
     * <li>{@link Number}s are converted by converting the {@code int} obtained from {@link Number#intValue()} using {@link Version#valueOf(int)}.</li>
     * <li>All other {@link Object}s are converted by converting the {@link String} obtained from {@link Object#toString()}.</li>
     * </ul>
     * </div>
     *
     * For thrown {@link Exception}s see the used functions described above.
     */
    @PublishedField
    public static final Function<Object, IVersion> TO_VERSION = converter(object -> {

        if (object == null || object instanceof IVersion) {
            return (IVersion) object;
        }

        if (object instanceof String) {
            return Version.valueOf((String) object);
        }

        if (object instanceof Number) {
            return Version.valueOf(((Number) object).intValue());
        }

        return Version.valueOf(object.toString());

    });

    /**
     * Attempts to convert arbitrary {@link Object}s to {@link BigInteger}s. <div class="extdoc" id="TO_BIG_INTEGER">
     * <h5>ScriptConverters.TO_BIG_INTEGER</h5><!--Label:ScriptConverters.TO_BIG_INTEGER-->Attempts to convert arbitrary {@link Object}s to {@link BigInteger}s. The following
     * conversions are implemented:
     * <ul>
     * <li>For {@code null} or {@link BigInteger} arguments the given argument is returned. No conversion is applied.</li>
     * <li>{@link Integer}s, {@link Long}s, {@link Short}s and {@link Byte}s are converted using {@link BigInteger#valueOf(long)}.</li>
     * <li>All other types of objects are interpreted as {@link String}s ({@link Object#toString()}) and passed to {@link BigInteger#BigInteger(String)}.</li>
     * </ul>
     * </div>
     *
     * See {@link BigInteger#BigInteger(String)} for thrown exceptions.
     */
    @PublishedField
    public static final Function<Object, BigInteger> TO_BIG_INTEGER = converter(object -> {

        if (object == null || object instanceof BigInteger) {
            return (BigInteger) object;
        }

        if (object instanceof Integer) {
            return BigInteger.valueOf((Integer) object);
        }

        if (object instanceof Long) {
            return BigInteger.valueOf((Long) object);
        }

        if (object instanceof Short) {
            return BigInteger.valueOf((Short) object);
        }

        if (object instanceof Byte) {
            return BigInteger.valueOf((Byte) object);
        }

        return new BigInteger(object.toString());
    });

    /**
     * Attempts to convert arbitrary {@link Object}s to {@link BigDecimal}s. <div class="extdoc" id="TO_BIG_DECIMAL">
     * <h5>ScriptConverters.TO_BIG_DECIMAL</h5><!--Label:ScriptConverters.TO_BIG_DECIMAL-->Attempts to convert arbitrary {@link Object}s to {@link BigDecimal}s. The following
     * conversions are implemented:
     * <ul>
     * <li>For {@code null} or {@link BigDecimal} arguments the given argument is returned. No conversion is applied.</li>
     * <li>{@link Float}s and {@link Double}s, are converted using {@link BigDecimal#valueOf(double)}.</li>
     * <li>{@link Integer}s, {@link Long}s, {@link Short}s and {@link Byte}s are converted using {@link BigDecimal#valueOf(long)}.</li>
     * <li>All other types of objects are interpreted as {@link String}s ({@link Object#toString()}) and passed to {@link BigDecimal#BigDecimal(String)}.</li>
     * </ul>
     * </div>
     *
     * See {@link BigDecimal#BigDecimal(String)} for thrown exceptions.
     */
    @PublishedField
    public static final Function<Object, BigDecimal> TO_BIG_DECIMAL = converter(object -> {

        if (object == null || object instanceof BigDecimal) {
            return (BigDecimal) object;
        }

        if (object instanceof Float) {
            return BigDecimal.valueOf((Float) object);
        }

        if (object instanceof Double) {
            return BigDecimal.valueOf((Double) object);
        }

        if (object instanceof Integer) {
            return BigDecimal.valueOf((Integer) object);
        }

        if (object instanceof Long) {
            return BigDecimal.valueOf((Long) object);
        }

        if (object instanceof Short) {
            return BigDecimal.valueOf((Short) object);
        }

        if (object instanceof Byte) {
            return BigDecimal.valueOf((Byte) object);
        }

        return new BigDecimal(object.toString());
    });

}
