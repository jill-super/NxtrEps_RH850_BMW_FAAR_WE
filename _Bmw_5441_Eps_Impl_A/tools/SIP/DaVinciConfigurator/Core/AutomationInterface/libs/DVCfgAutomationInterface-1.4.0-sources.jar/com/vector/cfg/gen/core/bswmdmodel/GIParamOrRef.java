package com.vector.cfg.gen.core.bswmdmodel;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelNotExistsException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.view.config.IModelView;

/**
 * Base interface for all {@link GIParameter} and {@link GIReference} instances.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
//CHECKSTYLE:OFF Class Naming problem
public interface GIParamOrRef extends GIModelObject {
    // CHECKSTYLE:ON
    /**
     * Returns the parent of this {@link GIParamOrRef}.
     *
     * @return
     */
    @PublishedMethod
    @Override
    GIContainer getParent();

    /**
     * Returns the related configuration object in the MDF model.
     *
     * <p>
     * Attention: The returned {@link MIObject} could be invisible in the current active {@link IModelView}! You have to check the visibility in the client side code!
     * </p>
     *
     * @return
     *
     * @exception BswmdModelNotExistsException
     * <ul>
     * <li>if the parameter does not exist in the MDF model</li>
     * </ul>
     */
    @PublishedMethod
    @Override
    MIParameterValue getMdfObject();

    /**
     * Returns <code>true</code> if the parameter exists in the MDFModel.
     *
     * @return
     */
    @PublishedMethod
    boolean existsMDF();

    /**
     * Returns <code>true</code> if the parameter or reference has a value or refTarget and exists in the MDF model. Otherwise <code>false</code>.
     *
     * @return
     */
    @PublishedMethod
    boolean asBoolean();
}
