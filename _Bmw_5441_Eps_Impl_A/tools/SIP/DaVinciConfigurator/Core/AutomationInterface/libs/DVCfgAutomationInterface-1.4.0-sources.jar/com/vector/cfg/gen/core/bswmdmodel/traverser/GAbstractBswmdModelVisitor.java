package com.vector.cfg.gen.core.bswmdmodel.traverser;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.exceptions.IErrorHandlingContext;
import com.vector.cfg.gen.core.bswmdmodel.GIModelAccess;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class GAbstractBswmdModelVisitor implements GIVisitor {
    // private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractGeneratorModelTraverser.class);

    @SuppressWarnings("unused")
    private final GIModelAccess genMa;

    @PublishedMethod
    protected GAbstractBswmdModelVisitor(GIModelAccess genMa) {
        this.genMa = genMa;

    }

    /**
     * Creates the error handling context.
     *
     * <p>
     * Normally you would write:
     *
     * <pre>
     * <code>  return ErrorHandlingContext.create(getGeneratorPackage());</code>
     * </pre>
     *
     * </p>
     *
     * @return the i error handling context
     */
    @PublishedMethod
    protected abstract IErrorHandlingContext createErrorHandlingContext();

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public abstract void accept(GIModelObject modelElement);

}
