package com.vector.cfg.gen.core.bswmdmodel.exceptions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * Thrown to indicate that the model object has no value.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class BswmdModelParameterHasNoValueException extends BswmdModelException {

    private static final long serialVersionUID = -980917635519275859L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(BswmdModelParameterHasNoValueException.class);

    private final GIParameter<?> parameter;

    /**
     * Constructor for BswmdModelHasNoValueException.
     *
     * @param genResult the gen result
     * @param parameter the parameter
     */
    @PublishedMethod
    public BswmdModelParameterHasNoValueException(IValidationResult genResult, GIParameter<?> parameter) {
        super(genResult, parameter.getParent());
        this.parameter = parameter;
    }

    /**
     * Returns the parameter model object.
     *
     * @return the parameter
     */
    @PublishedMethod
    public GIParameter<?> getParameter() {
        return parameter;
    }

}
