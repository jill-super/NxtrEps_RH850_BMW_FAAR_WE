package com.vector.cfg.automation.api.project.extensions;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.project.IProject;
import com.vector.cfg.model.access.IHasModelObject;
import com.vector.cfg.model.access.ModelAccessUtil;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.view.config.IViewedModelObject;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.scripting.groovy.ClosureCalls;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * This class provides {@link IProject} extension methods for all model objects.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class ProjectExtensions {

    private ProjectExtensions() {
    }

    /**
     * Provide access to the related project of the specified model object.
     *
     * @param self the model object to retrieve the project from
     * @return the {@link IProject} of the passed model object
     */
    @PublishedMethod
    public static IProject project(MIObject self) {
        final IProjectContext pc = ModelAccessUtil.getProjectContext(self);
        final IProject project = pc.getInstance(IProject.class);
        return project;
    }

    /**
     * Provide access to the related project of the specified model object and execute code with this project as delegate.
     *
     * @param <T> the return type of the code block.
     * @param self the model object to retrieve the project from
     * @param code executed with {@link IProject} delegate.
     * @return the returned value of the {@link Closure} code block.
     */
    @PublishedMethod
    public static <T> T project(MIObject self, @VDelegatesToWithClosureParam(IProject.class) Closure<T> code) {
        final IProjectContext pc = ModelAccessUtil.getProjectContext(self);
        final IProject project = pc.getInstance(IProject.class);
        final T ret = ClosureCalls.callWithDelegateFirst(project, code);
        return ret;
    }

    /**
     * Provide access to the related project of the specified model object.
     *
     * @param self the model object to retrieve the project from
     * @return the {@link IProject} of the passed model object
     */
    @PublishedMethod
    public static IProject project(IViewedModelObject self) {
        final IProjectContext pc = ModelAccessUtil.getProjectContext(self.getMdfObject());
        final IProject project = pc.getInstance(IProject.class);
        return project;
    }

    /**
     * Provide access to the related project of the specified model object and execute code with this project as delegate.
     *
     *
     * @param <T> the return type of the code block.
     * @param self the model object to retrieve the project from
     * @param code executed with {@link IProject} delegate.
     * @return the returned value of the {@link Closure} code block.
     */
    @PublishedMethod
    public static <T> T project(IViewedModelObject self, @VDelegatesToWithClosureParam(IProject.class) Closure<T> code) {
        final IProjectContext pc = ModelAccessUtil.getProjectContext(self.getMdfObject());
        final IProject project = pc.getInstance(IProject.class);
        final T ret = ClosureCalls.callWithDelegateFirst(project, code);
        return ret;
    }

    /**
     * Provide access to the related project of the specified domain object.
     *
     * @param self the domain object to retrieve the project from
     * @return the {@link IProject} of the passed model object
     */
    @PublishedMethod
    public static IProject project(IHasModelObject self) {
        final IProjectContext pc = ModelAccessUtil.getProjectContext(self.getMdfObject());
        final IProject project = pc.getInstance(IProject.class);
        return project;
    }

    /**
     * Provide access to the related project of the specified domain object and execute code with this project as delegate.
     *
     *
     * @param <T> the return type of the code block.
     * @param self the domain object to retrieve the project from
     * @param code executed with {@link IProject} delegate.
     * @return the returned value of the {@link Closure} code block.
     */
    @PublishedMethod
    public static <T> T project(IHasModelObject self, @VDelegatesToWithClosureParam(IProject.class) Closure<T> code) {
        final IProjectContext pc = ModelAccessUtil.getProjectContext(self.getMdfObject());
        final IProject project = pc.getInstance(IProject.class);
        final T ret = ClosureCalls.callWithDelegateFirst(project, code);
        return ret;
    }

}
