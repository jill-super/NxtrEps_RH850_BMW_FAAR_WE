package com.vector.cfg.consistency.contribution.helper.solvingactions.generic;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.FormatSpec;
import com.vector.cfg.util.text.mixedtext.IFormatSpec;
import com.vector.cfg.util.text.mixedtext.IMixedText;
import com.vector.cfg.util.text.mixedtext.IMixedTextBuilder;
import com.vector.cfg.util.text.mixedtext.MixedText;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * This is the abstract base class for a setting a single parameter or reference value.<BR>
 * It produces a description like:<BR>
 * Set &lt;parameter> to &lt;targetValue> (&lt;targetValueInfo>) e.g. Set CanSendDelayTime to 500 (the recommended value)
 *
 * Formatting the SolvingAction text like this allows any further information for the target value<BR>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class SASetParam implements ISolvingAction {

    @PublishedMethod
    protected SASetParam() {
    }

    /**
     * Setter method for targetValueInfo.
     *
     * @param targetValueInfo The targetValueInfo to set.
     */
    @PublishedMethod
    public SASetParam setTargetValueInfo(IMixedText targetValueInfoo) {
        this.targetValueInfo = targetValueInfoo;
        return this;
    }

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(SASetParam.class);

    private IMixedText targetValueInfo;

    private static final IFormatSpec formatSpec = FormatSpec.getInternedFormatSpec(false, false);

    @PublishedMethod
    protected abstract IMixedText getParameter();

    @PublishedMethod
    protected abstract IMixedText getTargetValue();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public final String getDescription() {
        final IMixedText parameter = getParameter();

        final IMixedText targetValue = getTargetValue();

        // TODO don't resolve the IMixedText when the IMixedText supports appending of MixedTexts
        final IMixedTextBuilder b = MixedText.newBuilder();
        b.append("Set").append(parameter.getFormattedText(formatSpec)).append("to").append(targetValue.getFormattedText(formatSpec));
        if (targetValueInfo != null) {
            b.append("(").append(targetValueInfo).append(")");
        }
        return b.flushResult().getFormattedText(formatSpec);
    }
}
