package com.vector.cfg.model.access.ecucdefinition.elements.reference;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecucdefinition.elements.IEcucContainerDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIChoiceReferenceParamDef;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucChoiceRefDefinition extends IEcucAbstractRef {

    /**
     * returns an list of target definitions. Never returns <code>null</code>.
     *
     * @return
     */
    @PublishedMethod
    List<IEcucContainerDefinition> getTargetDefinitions();

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    @Override
    MIChoiceReferenceParamDef getDef();
}
