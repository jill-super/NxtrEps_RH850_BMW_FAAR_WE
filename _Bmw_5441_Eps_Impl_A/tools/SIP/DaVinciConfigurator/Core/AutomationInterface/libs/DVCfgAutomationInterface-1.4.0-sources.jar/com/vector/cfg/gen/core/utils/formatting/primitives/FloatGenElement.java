package com.vector.cfg.gen.core.utils.formatting.primitives;

import java.math.BigDecimal;
import java.text.MessageFormat;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIFloatParameter;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractPrimitiveElement;
import com.vector.cfg.gen.core.utils.frameworkinternal.GeneratorUtilFrameworkHelper;
import com.vector.cfg.gen.core.utils.generatorresult.CommonGeneratorResultIds;
import com.vector.cfg.gen.core.utils.generatorresult.GeneratorResultBuilder;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.math.MBigDecimal;

/**
 * The format element for Float/Double objects
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class FloatGenElement extends AbstractPrimitiveElement<FloatGenElement> {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(FloatGenElement.class);

    private MBigDecimal valueObj;

    private GIFloatParameter bswmdModelObj;

    private FloatGenElement() {

    }

    /**
     * Constructor for StringGenElement.
     *
     * @param doubleObj
     */
    FloatGenElement(Double doubleObj) {
        this();
        if (doubleObj == null) {
            throw new IllegalArgumentException("doubleObj is null");
        }
        this.valueObj = MBigDecimal.valueOf(doubleObj);

    }

    /**
     * Constructor for FloatGenValue.
     *
     * @param gFloat
     */
    FloatGenElement(GIFloatParameter gFloat) {
        this();
        if (gFloat == null) {
            throw new IllegalArgumentException("gFloat is null");
        }

        bswmdModelObj = gFloat;

        if (!bswmdModelObj.existsMDF()) {
            reportBswmdParamterNotExistsError(bswmdModelObj);

            this.valueObj = MBigDecimal.ZERO;

        } else {
            this.valueObj = MBigDecimal.valueOf(gFloat.getBigDecimalValue());
        }
    }

    /**
     * Constructor for FloatGenValue.
     *
     * @param bigDecimal
     */
    FloatGenElement(BigDecimal bigDecimal) {
        this();
        if (bigDecimal == null) {
            throw new IllegalArgumentException("bigDecimal is null");
        }

        this.valueObj = MBigDecimal.valueOf(bigDecimal);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void generatePrimitiveInternal(StringBuilder builder, IGenFormatter formatter, int indent) {
        formatInternal(builder);
    }

    @PublishedMethod
    public static String format(BigDecimal valueObj) {
        return new FloatGenElement(valueObj).generate();
    }

    private void formatInternal(StringBuilder builder) {

        if (valueObj.isNaN() || valueObj.isInfinite()) {
            issueInvalidFloatElementExpection();
        }

        builder.append(valueObj.toString());
    }

    private void issueInvalidFloatElementExpection() {

        final StringBuilder commentBuilder = new StringBuilder();
        if (getPrefixComment() != null) {
            commentBuilder.append(getPrefixComment());
            commentBuilder.append(" ");
        }
        if (getPostfixComment() != null) {
            commentBuilder.append(getPostfixComment());
        }

        /*
         * Report an error
         */
        final IGeneratorPackage pack = GeneratorUtilFrameworkHelper.getCurrentGeneratorPackage();
        if (pack == null) {
            throw new NumberFormatException(
                    MessageFormat
                            .format("These is no generatorPackage available to report the out of Range Error. The value {0} with comment ({1}) is not in the range of the specified float datatype.",
                                    valueObj.toString(), commentBuilder.toString()));

        }

        final GeneratorResultBuilder builder;

        if (bswmdModelObj != null) {
            /*
             * If a bswmdModelOBject is available create a IGeneratorResult warning
             */
            builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getGeneratedValueOutOufRange(pack),
                    "The value {0} of the parameter {1} is not in the range of the specified float datatype.", valueObj.toString(), bswmdModelObj);

            builder.addErrorObject(bswmdModelObj);
            builder.assignException(new RuntimeException("StackTrace of invalid FloatGenElement"));

        } else {
            /*
             * We have no bswmdModel context info so create a generic message
             */
            builder = GeneratorResultBuilder.newBuilder(CommonGeneratorResultIds.getGeneratedValueOutOufRange(pack),
                    "The value {0} with comment ({1}) is not in the range of the specified float datatype.", valueObj.toString(), commentBuilder.toString());

            builder.assignException(new RuntimeException("StackTrace of invalid FloatGenElement"));
        }

        comment(MessageFormat.format("ERROR: The value {0} is not in the range of the specified float datatype.", valueObj.toString(), commentBuilder.toString()));

        pack.getGenerationProcessor().getResultSink().reportGeneratorResult(builder.buildResult());

    }

}
