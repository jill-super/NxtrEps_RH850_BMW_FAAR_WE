package com.vector.cfg.consistency.contribution.helper;

import java.text.DecimalFormat;
import java.util.Collection;

import com.google.common.base.Predicate;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.IValidationResultId;
import com.vector.cfg.consistency.contribution.ISolvingAction;
import com.vector.cfg.consistency.contribution.helper.solvingactions.SolvingActions;
import com.vector.cfg.consistency.internal.resultprovisioning.ValidationResultWrapperExternal;
import com.vector.cfg.consistency.ui.IValidationResultUI;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.IModelAccess;
import com.vector.cfg.model.cedescriptor.IDescriptor;
import com.vector.cfg.model.cedescriptor.aspect.IDefRefAspect;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class ConsistencyUtil {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(ConsistencyUtil.class);

    private ConsistencyUtil() {
    }

    /**
     * Creates the solving action.
     *
     * <p>
     * Please use the method {@link SolvingActions#createSolvingActionWrapper(String, Runnable)} instead!
     * </p>
     *
     * @param description the description
     * @param r the r
     * @return the i solving action
     */
    @Deprecated
    @KeepSecretFromPublishedApi
    public static ISolvingAction createSolvingAction(final String description, final Runnable r) {
        return new ISolvingAction() {

            @Override
            @PublishedMethod
            public void run() {
                r.run();
            }

            @Override
            @PublishedMethod
            public String getDescription() {
                return description;
            }
        };
    }

    /**
     * Checks if the passed IValidationResult is relevant for the filter. Means the {@link Predicate#apply(Object)} yields to true for one of the ErroneousCEs in the
     * {@link IValidationResultUI}
     *
     * @param filter the filter
     * @param validationResult the validation result
     * @return true, if any ErroneousCEs has passed the filter.
     */
    @KeepSecretFromPublishedApi
    public static boolean isConsistencyResultRelevantForFilter(Predicate<MIObject> filter, IValidationResultUI validationResult) {
        final ValidationResultWrapperExternal result = (ValidationResultWrapperExternal) validationResult;
        return result.isRelevantForFilter(filter);
    }

    /**
     * Checks if the passed IValidationResult is relevant for the passed module {@link DefRef}.
     *
     * @param moduleDefRef DefRef of the module.
     * @param result validation result
     * @return true, if any ErroneousCEs is a child of the passed ModuleDefRef
     */
    @KeepSecretFromPublishedApi
    public static boolean isConsistencyResultRelevantForModuleDefRef(DefRef moduleDefRef, IValidationResultUI result, IModelAccess ma) {
        return isConsistencyResultRelevantForDefRef(moduleDefRef, result, ma, true);
    }

    /**
     * Checks if the passed IValidationResult is relevant for the passed {@link DefRef}.
     *
     * @param defRefToCheck the def ref to check
     * @param result validation result
     * @param ma the IModelAccess
     * @param isModuleDefRef if isModuleDefRef is used errors are evaluated recursively
     * @return true, if any ErroneousCEs is definition of the passed ModuleDefRef
     */
    @KeepSecretFromPublishedApi
    public static boolean isConsistencyResultRelevantForDefRef(DefRef defRefToCheck, IValidationResultUI result, IModelAccess ma, boolean isModuleDefRef) {
        if (defRefToCheck == null) {
            throw new IllegalArgumentException("DefRef must not be null");
        }
        if (isModuleDefRef && !defRefToCheck.isModuleDefinitionDefRef()) {
            throw new IllegalArgumentException("You can only pass ModuleDefintion DefRefs! " + defRefToCheck);
        }
        if (result == null) {
            throw new IllegalArgumentException("IValidationResult must not be null");
        }

        final Collection<IDescriptor> errorneousCeList = result.getErroneousCEs();

        for (final IDescriptor ce : errorneousCeList) {
            final IDefRefAspect resultDefRefAspect = ce.getAspect(IDefRefAspect.class);
            if (resultDefRefAspect != null) {

                DefRef resultDefRef = resultDefRefAspect.getDefRef();

                if (isModuleDefRef) {
                    resultDefRef = resultDefRef.getModuleDefinitionDefRef();
                }

                // if(general.isDefinitionOf(Refinement)
                if (defRefToCheck.isDefinitionOf(resultDefRef, ma)) {
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Returns the string representation of a Result ID.
     * <p>
     * The normal string representation is formated as follows:
     * <ol>
     * <li>Origin</li>
     * <li>Id</li>
     * </ol>
     * Note, that id is formated as a 5-digit number, however it can be longer, if the integer has more than 5 digits. Also note, that the formating only applies, if the ID is
     * an integer greater or equal to zero.
     * <p>
     * Examples:
     * <ul>
     * <li>Origin of <em>ECUC</em> and ID of <em>3</em> formats to <em>ECUC00003</em>.</li>
     * <li>Origin of <em>PDUR</em> and ID of <em>260479</em> formats to <em>PDUR260479</em>.</li>
     * <li>Origin of <em>DEM</em> and ID of <em>-4</em> formats to an empty string.</li>
     * </ul>
     *
     */
    @KeepSecretFromPublishedApi
    public static String formatIdFromResult(final IValidationResultId resultId) {
        final int id = resultId.getId();
        if (id >= 0) {
            return resultId.getOrigin() + new DecimalFormat("00000").format(resultId.getId());
        }
        return "";
    }

}
