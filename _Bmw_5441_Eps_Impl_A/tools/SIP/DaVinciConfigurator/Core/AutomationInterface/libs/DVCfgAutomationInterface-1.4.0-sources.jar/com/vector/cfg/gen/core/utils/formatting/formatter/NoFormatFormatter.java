package com.vector.cfg.gen.core.utils.formatting.formatter;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.formatting.EFormatType;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * See {@link EFormatType} for more details.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class NoFormatFormatter extends AbstractFormatter {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(NoFormatFormatter.class);

    /**
     * Instantiates a new no format formatter.
     */
    @PublishedMethod
    public NoFormatFormatter() {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreElement(StringBuilder builder, int indent) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostElement(StringBuilder builder, int indent) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreBlockStart(StringBuilder builder, int indent) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostBlockStart(StringBuilder builder, int indent) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPreBlockEnd(StringBuilder builder, int indent) {

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void formatPostBlockEnd(StringBuilder builder, int indent) {

    }

}
