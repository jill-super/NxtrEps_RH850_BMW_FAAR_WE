package com.vector.cfg.consistency.contribution.exceptions;

import static com.google.common.base.Preconditions.checkNotNull;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.consistency.contribution.IValidationResultSink;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class ConsistencyErrorHandlingContext extends AbstractErrorHandlingContext {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(ConsistencyErrorHandlingContext.class);

    private final IExceptionValidationResultProcessor exceptionProcessor;

    /**
     * Constructor for ConsistencyErrorHandlingContext.
     *
     * @param resultSink
     */
    private ConsistencyErrorHandlingContext(IExceptionValidationResultProcessor exceptionProcessor, IValidationResultSink resultSink) {
        super(resultSink);
        this.exceptionProcessor = checkNotNull(exceptionProcessor);

    }

    /**
     * Creates a new {@link ConsistencyErrorHandlingContext}. You can create multiple {@link ErrorHandlingContext} object, there is no limitation.
     *
     * <p>
     * <b>Attention:</b> You can use this create method in a Live-Validation.
     * </p>
     *
     * @param generatorPackageRef the generator package
     * @return the error handling context
     *
     * @exception IllegalStateException <ul>
     * <li>if you make a call to this method when the generation process is not running. E.g. In Live-Validation.</li>
     * </ul>
     *
     */
    @PublishedMethod
    public static ConsistencyErrorHandlingContext create(IExceptionValidationResultProcessor exceptionProcessor, IValidationResultSink resultSink) {
        return new ConsistencyErrorHandlingContext(exceptionProcessor, resultSink);
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    protected boolean tryToHandleOccuredException(Exception ex) {
        try {
            final List<IValidationResult> results = exceptionProcessor.wrapExceptionIntoValidationResults(ex);

            for (final IValidationResult res : results) {
                getResultSink().reportValidationResult(res);
            }
            return true;
        } catch (final Exception ex1) {
            return false;
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    protected void processTestForErrorAndThrowExInternal() {
        throw new UnsupportedOperationException();
    }

}
