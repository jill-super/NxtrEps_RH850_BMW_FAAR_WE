package com.vector.cfg.dom.com.groovy.can;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;

/**
 * {@link ECanAcceptanceFilterType} lists the possible values for an {@link ICanFilterMask}'s filter
 * type.<div class="extdoc" id="ECanAcceptanceFilterType"><!--Label:ECanAcceptanceFilterType-->
 * <h5>Filter Types</h5>{@link ECanAcceptanceFilterType} lists the possible values for an {@link ICanFilterMask}'s filter type.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public enum ECanAcceptanceFilterType {

    /**
     * {@link #STANDARD} results in a standard Can acceptance filter value with length 11.
     * <div class="extdoc" id="STANDARD"><!--Label:ECanAcceptanceFilterType.STANDARD-->{@link #STANDARD} results in a standard Can acceptance filter value with length 11.</div>
     */
    STANDARD,

    /**
     * {@link #EXTENDED} results in an extended Can acceptance filter value with length 29.
     * <div class="extdoc" id="EXTENDED"><!--Label:ECanAcceptanceFilterType.EXTENDED-->{@link #EXTENDED} results in an extended Can acceptance filter value with length 29.</div>
     */
    EXTENDED,

    /**
     * {@link #MIXED} results in a mixed Can acceptance filter value with length 29. <div class="extdoc" id="MIXED"><!--Label:ECanAcceptanceFilterType.MIXED-->{@link #MIXED}
     * results in a mixed Can acceptance filter value with length 29.</div>
     */
    MIXED

}
