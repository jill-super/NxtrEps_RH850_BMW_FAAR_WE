package com.vector.cfg.automation.api.project;

import java.nio.file.Path;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.ScriptConverters;

/**
 * {@link ICreateProjectVirtualTargetApi} provides means for specifying the new project's vVIRTUALtarget settings.
 *
 * <div class="extdoc" id="ICreateProjectVirtualTargetApi"><!--ICreateProjectVirtualTargetApi-->The {@link ICreateProjectVirtualTargetApi} contains the methods for specifying
 * the new project's vVIRTUALtarget settings. The vVIRTUALtarget support may not be available depending on the purchased license.
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface ICreateProjectVirtualTargetApi {

    /**
     * Alias for {@link #setCreateVirtualTargetProjectFile(boolean)}.
     *
     * @param createVirtualTargetProjectFile whether or not to create a vVIRTUALtarget project file for the new project
     */
    @PublishedMethod
    void createVirtualTargetProjectFile(boolean createVirtualTargetProjectFile);

    /**
     * Specifies whether or not to create a vVIRTUALtarget project file for the new project.
     *
     * <div class="extdoc" id="setCreateVirtualTargetProjectFile"><!--Label:ICreateProjectVirtualTargetApi.setCreateVirtualTargetProjectFile-->
     * <h5>Create vVIRTUALtarget project file</h5> {@link #setCreateVirtualTargetProjectFile(boolean)} specifies whether or not to create a vVIRTUALtarget project file for the
     * new project. This is an optional parameter defaulting to {@code true}. However the vVIRTUALtarget project file is only created when
     * {@link ICreateProjectTargetApi#vVIRTUALtargetSupport(boolean)} evaluates to {@code true}.
     *
     * </div>
     *
     * @param createVirtualTargetProjectFile whether or not to create a vVIRTUALtarget project file for the new project
     */
    @PublishedMethod
    void setCreateVirtualTargetProjectFile(boolean createVirtualTargetProjectFile);

    /**
     * Alias for {@link #setVirtualTargetExecutable(Object)}.
     *
     * @param virtualTargetExecutable the vVIRTUALtarget executable (VttCmd.exe)
     */
    @PublishedMethod
    void virtualTargetExecutable(@Nonnull Object virtualTargetExecutable);

    /**
     * Sets the vVIRTUALtarget executable (VttCmd.exe) for the new project.
     *
     *
     * <div class="extdoc" id="setVirtualTargetExecutable"><!--Label:ICreateProjectVirtualTargetApi.setVirtualTargetExecutable-->
     * <h5>vVIRTUALtarget Executable</h5> Set the vVIRTUALtarget executable (VttCmd.exe) for the new project with {@link #setVirtualTargetExecutable(Object)}. This is an
     * optional parameter defaulting to the location of the currently registered installation (if there is any) if the parameter is not provided explicitly.
     * <p>
     * The value given here is converted to {@link Path} using {@link ScriptConverters#TO_SCRIPT_PATH} <!--Ref:ScriptConverters.TO_SCRIPT_PATH-->.
     * <p>
     *
     * </div>
     *
     * @param virtualTargetExecutable the vVIRTUALtarget executable (VttCmd.exe) for the new project
     */
    @PublishedMethod
    void setVirtualTargetExecutable(@Nonnull Object virtualTargetExecutable);

    /**
     * Alias for {@link #setVirtualTargetProject(Object)}.
     *
     * @param virtualTargetProject the vVIRTUALtarget executable (VttCmd.exe)
     */
    @PublishedMethod
    void virtualTargetProject(@Nonnull Object virtualTargetProject);

    /**
     * Sets the vVIRTUALtarget project (*.vttproj) for the new project.
     *
     *
     * <div class="extdoc" id="setVirtualTargetProject"><!--Label:ICreateProjectVirtualTargetApi.setVirtualTargetProject-->
     * <h5>vVIRTUALtarget Project</h5> Set the path to the vVIRTUALtarget project (*.vttproj) for the new project with {@link #setVirtualTargetProject(Object)}. This is an
     * optional parameter defaulting to '.\Config\VTT\{@code ProjectName}.vttproj' if the parameter is not provided explicitly. See also
     * {@link ICreateProjectTargetApi#setvVIRTUALtargetSupport(boolean)} and {@link ICreateProjectVirtualTargetApi#setCreateVirtualTargetProjectFile(boolean)} at which both have
     * to be {@code true} to force the creation of the vVIRTUALtarget project.
     * <p>
     * The value given here is converted to {@link Path} using {@link ScriptConverters#TO_SCRIPT_PATH} <!--Ref:ScriptConverters.TO_SCRIPT_PATH-->.
     * <p>
     *
     * </div>
     *
     * @param virtualTargetProject the vVIRTUALtarget executable (VttCmd.exe) for the new project
     */
    @PublishedMethod
    void setVirtualTargetProject(@Nonnull Object virtualTargetProject);
}
