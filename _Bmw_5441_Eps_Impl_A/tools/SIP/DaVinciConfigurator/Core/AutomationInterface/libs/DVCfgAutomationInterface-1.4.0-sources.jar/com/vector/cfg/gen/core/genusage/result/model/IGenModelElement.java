package com.vector.cfg.gen.core.genusage.result.model;

import java.util.Collection;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGenModelElement {

    /**
     * Gets the children.
     *
     * @param <T> the generic type
     * @return the children
     */
    @PublishedMethod
    <T extends IGenModelElement> Collection<T> getChildren();

    /**
     * Gets the all sub childs of type.
     *
     * @param <T> the generic type
     * @param clazz the clazz
     * @return the all sub childs of type
     */
    @PublishedMethod
    <T extends IGenModelElement> Collection<T> getAllSubChildsOfType(Class<T> clazz);
}
