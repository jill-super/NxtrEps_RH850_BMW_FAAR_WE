package com.vector.cfg.gen.core.bswmdmodel.groovy.extensions;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GICList;
import com.vector.cfg.gen.core.bswmdmodel.GIList;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.scripting.groovy.ClosureCalls;

import groovy.lang.Closure;
import groovy.lang.DelegatesTo;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * This class provides extension methods for BswmdModel {@link GIList} and sub types. These method provide usage of Closures with the {@link GIList} API.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public final class GIListExtensions {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GIListExtensions.class);

    private GIListExtensions() {
    }

    /**
     * Creates a new child element and appends it to this {@link GIList}. The closure code is then called with the new object as parameter.
     *
     * @param <MODEL_TYPE> the bswmd model type
     * @param <R> the return type of the closure code
     * @param self the BswmdModel list
     * @param code the code to execute with the new element
     * @return the return value of the closure
     */
    @PublishedMethod
    public static <MODEL_TYPE extends GIModelObject, R> R createAndAdd(@DelegatesTo.Target GIList<MODEL_TYPE> self,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(value = FromString.class, options = "MODEL_TYPE") Closure<R> code) {

        final MODEL_TYPE elem = self.createAndAdd();
        return ClosureCalls.callWithDelegateFirst(elem, code);
    }

    /**
     * Creates a new child element with the passed shortName and appends it to this {@link GIList}. The closure code is then called with the new obejct as parameter.
     *
     * @param <MODEL_TYPE> the bswmd model type
     * @param <R> the return type of the closure code
     * @param self the BswmdModel list
     * @param shortName the shortName of the new element
     * @param code the code to execute with the new element
     * @return the return value of the closure
     */
    @PublishedMethod
    public static <MODEL_TYPE extends GIModelObject, R> R createAndAdd(@DelegatesTo.Target GICList<MODEL_TYPE> self, String shortName,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(value = FromString.class, options = "MODEL_TYPE") Closure<R> code) {

        final MODEL_TYPE elem = self.createAndAdd(shortName);
        return ClosureCalls.callWithDelegateFirst(elem, code);
    }

    /**
     * Gets the container by specified shortName or creates a new one if not existing. The closure is then called with the found container.
     *
     * @param <MODEL_TYPE> the bswmd model type
     * @param <R> the return type of the closure code
     * @param self the BswmdModel list
     * @param shortName the shortName of the element to find
     * @param code the code to execute with the found element
     * @return the return value of the closure
     */
    @PublishedMethod
    public static <MODEL_TYPE extends GIModelObject, R> R byNameOrCreate(@DelegatesTo.Target GICList<MODEL_TYPE> self, String shortName,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(value = FromString.class, options = "MODEL_TYPE") Closure<R> code) {

        final MODEL_TYPE elem = self.byNameOrCreate(shortName);
        return ClosureCalls.callWithDelegateFirst(elem, code);
    }

    /**
     * Gets the container by specified shortName and calls the closure, if the element is null the closure is not called. The closure is then called with the found container.
     *
     * @param <MODEL_TYPE> the bswmd model type
     * @param <R> the return type of the closure code
     * @param self the BswmdModel list
     * @param shortName the shortName of the element to find
     * @param code the code to execute with the found element
     * @return the return value of the closure
     */
    @PublishedMethod
    @Nullable
    public static <MODEL_TYPE extends GIModelObject, R> R byNameOrNull(@DelegatesTo.Target GICList<MODEL_TYPE> self, String shortName,
            @DelegatesTo(strategy = Closure.DELEGATE_FIRST, genericTypeIndex = 0) @ClosureParams(value = FromString.class, options = "MODEL_TYPE") Closure<R> code) {

        final MODEL_TYPE elem = self.byNameOrNull(shortName);
        if (elem == null) {
            return null;
        }
        return ClosureCalls.callWithDelegateFirst(elem, code);
    }

}
