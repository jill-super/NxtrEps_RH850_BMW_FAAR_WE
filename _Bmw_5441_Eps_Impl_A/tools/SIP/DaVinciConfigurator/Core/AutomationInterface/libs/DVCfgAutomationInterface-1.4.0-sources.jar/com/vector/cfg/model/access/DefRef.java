package com.vector.cfg.model.access;

import static com.google.common.base.Preconditions.checkArgument;
import static com.google.common.base.Preconditions.checkNotNull;
import static com.google.common.base.Preconditions.checkState;
import static com.vector.davinci.util.base.VUtil.uncheckedCast;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.text.MessageFormat;
import java.util.List;

import javax.annotation.Nullable;

import com.vector.annotations.obfuscation.Keep;
import com.vector.annotations.obfuscation.KeepName;
import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedField;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.TypedDefRef.TypeInfo;
import com.vector.cfg.model.exceptions.ModelCeAlreadyRemovedException;
import com.vector.cfg.model.exceptions.ModelCeHasNoDefinitionException;
import com.vector.cfg.model.internal.access.IDefRefDefinitionCache;
import com.vector.cfg.model.internal.access.MdfDefRefCache;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.commoncore.autosar.MIReferrable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIHasDefinition;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MITextualValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBooleanParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIChoiceContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIFloatParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIIntegerParamDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIModuleDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfContainerDef;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIParamConfMultiplicity;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIStringParamDef;
import com.vector.cfg.util.IProjectContext;
import com.vector.cfg.util.autosar.AutosarUtil;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.string.StringCache;
import com.vector.cfg.util.string.StringUtil;
import com.vector.cfg.util.testing.IMockProvider;

/**
 * <div class="extdoc" id="Common" data-target-doc="ModelDocumentation;AutomationInterfaceDocumentation">
 * <p>
 * The <code>DefRef</code> class represents an AUTOSAR definition reference (e.g. <code>/MICROSAR/CanIf</code>) without a connection to any model. A {@link DefRef} replaces the
 * {@link String} which represents a definition reference. You shall always use a {@link DefRef} instance, when you want to reference something by it's definition.
 * </p>
 * <p>
 * The class abstracts the behavior of definition references in the AUTOSAR model (e.g. AUTOSAR 3 and AUTOSAR 4 handling).
 * </p>
 * <p>
 * DefRefs are constant; their values can not be changed after they are created. All {@link DefRef} classes are immutable.
 * </p>
 *
 * <p>
 * A {@link DefRef} represents the definition reference as two parts:
 * <ul>
 * <li>Package part - e.g. <code>/MICROSAR</code></li>
 * <li>Definition without the package part - e.g. <code>CanIf/CanIfGeneral</code></li>
 * </ul>
 * This is used to navigate through the AUTOSAR model with refinements and wildcards. So you have to create a {@link DefRef} with the two parts separated.
 * </p>
 *
 * <p>
 * The figure <!--LaTeX: \vref{fig:DefRefClasses} --> shows the structure of the {@link DefRef} class and its sub classes.
 * </p>
 * <img src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAASYAAAEXCAIAAACPgH6FAAAyrUlEQVR42u2dB1QUV/vGvxOwxR5NNIrSpNjA3rAg9igqdhEbIlHRYFdMFNQUIgoKAgKhF+kroLEQu4CCioJKE0EFRVCBGIP5cr7z/z/DXYdhd1lRViPhfc5z9tyZnTu7M3N/+753yt7//B+JRPqA+g/tAhKJkCORCDkSiUTIkUiEHIlEIuRIJELuw6u0tPQs6Z9WWVkZIddQhOP9H9I/rXPnzhFyDQs5R3u708fCKx3G/Bvvo3AoHM/5cHwc75D4WGkHnxI76FQM78CT8BGBRYEnRAGv7f/afmJHV/l4tO/xKN4+xyN9fuXsLeFjnH85FsHbi3M47Cl2mOfRKnvwjgs7xDkUdmeOhQ/zdosNYXYV+CAcwxzM2+UIHAQ7ix0IHxDJ8H7OAbATvMvGipBriMgBtr/LH1T6/t9lnP9bli92KZwH/8X53l/Peef+9Sz3Fee7Yj+FcyrEzq4o4Z31J1wMZ4r9JPPlk4zXvvOyiPMfRbfFfgzfYn7xOP3FI95pLwrTfud8U+wC+AZczjm1/CHv62XwA/ia2Pevld6/+toppfliP89P5pwHX2F+lnf52T3eSc9yOT/NTRT7LpwAl3C+VJLD+2IxnA1fEDsLPv9E7HNPMsUuyjzLOQM+A0f7OxJyhBwh96GRc3R0TExMTE1Nzc7OLiwsLC8vJ+QIOULuPSJnZ2cXGxt7+vTp5ORkUFdSUkLIEXKKQa700S2/4IOzzUy0e2o1atKYnTzoqtFlxlzjqDDPsoK0homcjY1NSEiISCQCdYh1CHSEHCFXV+RePsna57K7U9dO6joa860WfO9nH5ocGXUzNvy6aE+I46L1S3X0dLqodvZ239MAkdu6daufnx+oQ6xDhpmXl0fIEXJ1Qq74QepY4zGd1VW+c7MDZjXZ1mO3ajfVaVMnPM2/1qCQs7W1BXL+/v7h4eEIdMgtCTlC7t2RK3mQOsRwsN4Qfd/zQXJ4Yw5OCh84atCIEYMZdYQcIUfIvTVy46aOAW9g6Y28MSPVHDRq0IxpEwk5Qo6Qe2vk9rv8gHyyNvFNItZpaqn7uTsQcoQcIfcWyP3+KKNT107y+2812c5zt7pal9KHNwg5Qo6Qqy1ywSHu6joa0jiFJkfOXTm/g0pHJWUlFY0u1j+uH2w0VFtPR2Kx3n16RIe4y0FOeJtiI2XlqEBX+ciF+x1o0rixxaLZwopNmzYZNqhvypkIOciFeu9r3LjRsoUzCTlC7qNGbu6imfOtFkiAFHY1GnTJvLtXYsnlGy0WL5gpHzk+ykUFuTZr2uQ1dbKRA5aR/s6IcqjIR7minIRvN6wc0LeXHORQMczXkaIcIfexI6fTS/t7P3sJkOZZLcAntv6sNRLOyNSYoMRQRDyZyO0JcdTupl5L5JBYgjewwZDLv3Vu3GgDTI4ZNTQ//SyQ48GWQA5+mnsZSzLkcm/EjzUcikmjkUNyU0+BN74iIUfIfezIKSkpsevdQn/ZtRM+ccehncKZqlqq0oll+HURlqw9coANcxhyyxbOzkg+gfh22Ntxhfl8FuUqebsqjZzLnu2D+usx5MzNZtxKjEOIC/Z0+HrpXBblxLwRcoTcR46cdOCCP/nkE5nzZfqdkWv3WRs+sezweTtp5ISdwCkTDG8nHWXItWvbhk8sv/i8HSFHyNX7KCczh6zpAt07IyeESknpk5qiXJivUw/dbg9vn+PPWEpUJOQIufqEXI/eutJ9uTbt23KPq0Q4vxE5l3Dnd+7LtWrZQvr0iczE0sVh+wzj8TxyqCh9+oSQI+TqB3KLl8yVPmNpYj4Tn9iuQ3sbl+2RqTGY4xrnMWy8QSe1zhJLWm9ZWfszlhEBLs2aNonwd+H7crcvHwdsPq4/DezXW35fbpTBoGCvvXxfLi0hBrz94vz9gL69CDlCrj4hdzTST1NXU/qinMyLBINGDxYuFp0W279f73e+Lncv7eyYUdyJR+SNyWej5COXnhjXQ0ezKPsSkMu5ftJo5BCuoo7m5fhQQo6Qq0/IvXicoarWRfruk7Cr0YvWL9Xs0U1JWQlW01E3s16Mnlu1rNJ3r4Z6V7r7hJAj5N7uHssAT6euGl3e9h7LyCuR3XW70T2WhBwh9y5PEsybZdxvaL/aP0kQnRozduyIWdMn0ZMEhBwh9y7IlRakTRxnCOoCLh2uTXwbO2bE6JFD6Xk5Qo6Qe/enwp8XpM2bNVVDU3XXod01wXbkZpybvyPyyVnTv6Knwgk5Qk4Bfzfk77FPQ71r9x7aX69d5hCwl10lj74R4xHhtn6r1YD+enjX75BDA/zvE0KOkHtf//D1+6PbRyN9Vixb0K9PL2VlJXZ+X1O965IFs0QhHg32H74IOUKO/seSkCPkCDlCjpAj5Ag5Qo6QexfkHO1tqw+1ExYvHmonND4uVM5oO6c4vx5tJwYOOil2taF2TsDVRtupPuCOeJCd147y40fb+TWKDbVTNeDOMaEjvKuNthPO2/NouHCoHc5x3Dg7zGyoHc6xkkPtCEfbqRpwJ0ZqqJ0jnNlQO+IBd0RwoLOoptF2AsSODnDi7A87wrtsVhFy/0fjy5E+sAg5Gl+Oxpf7QOPL7a4cX46Qo74c9eWoL0fIEXKEHCFHyBFyhBwhR8gRcoQcIUfIEXKEnMKRw3rqjhz/11qdv+wgCjn0RuQmTzAk5Ag5Qq5OyLEodyLaT0tT7Y3IsX8cIuQIufqNHOacOR7eulXLPno9791KAm+X4kUoN2qk/Pnn7Xzc9wG5+xlJRqMMmjRprN1N4/yJCB45UajXimVmQO7CiQj93j24Ku3b/eK6B8jdvXl+QD+9dp+13W+/AwuDt9y0C8OHDsAyffV6piUdFyIHYz6QO3s0WL9X98r1fOZ54Acgh2X2/bitu45mk8bi0cYJOUKu3iP33RbrV8/v7fxu4+SJY4Gcrna3U7EhiHK3Uk4DRSA3bcr4LetW/VmSEx3iqautyZB7/jBt4fwZLMph5glRAKJc2uWTrVq1BHLTp4y3tVmLKLdtgxVDbupXY6ODDyHEHY/yNRgyQIhcmJ9L7546QE5HS+NYhDeiXOqluFYtWzDkIgMPlj1MpShHyP17kPujOAdZ5Z9P7zZr2hTIPc69vvO7DXNmGIM9vAvkEN8qSnIkEsv1qy2c9+5iyBVmJdttWzfbZDLYw1tADkHpj6I73FNzhbcZcnyY4v4Vr5Ey35eDVLt0Rm4J5O7fvrhjy5pZ0yaBPQ6wSuQ43iixJOT+TcghxAmRG9hfP8jb5bgoMDc9QQ5yu77bsG3TaoYccshAr/3HIv1ybpyTg9yzB6ky+3L8Gcv+fXv7HXKIDfPKuHqKR476coTcvw25aVMmFN69vn3rWpOpk4AcALuVcuZZwS3zhXMZcpMnjrG1WQfkTsYE8Ykl+nJLF865ci4WyAGntMunSvJvLDWbzZCbMXUiEsv82wnDhw5kyI0fM3L7ljXgzd9j36D++jKRw3pSLx0tyrmy2HSGNHJKSp8U514h5Ai5eo9csM9BYDbGcPjDrKtA7qDj980//RS9uP0/2zHk7mckjTQYjGywh65W4pkjPHJeB3+2XrUMyDk77Gz+aTNUcfxpO0PuXvpFhL7OnTqKgj0AEpBDAARpKPfsrn390lGZyO233/7pp81atWqx9wcbaeRGjxiM6oQcIVfvkXuvl8IDPB31e3enS+GEHCEnRg7x7X0gt3zJ/JYtmiMo9dXveeXsEUKOkCPk6IYvQo6QI+QIOUKOkCPkCDlCjpAj5Ai5fwVy3NnLGpCLCfVu0qTxoQM/CQbXVvqy4xfhAW41IScK4S4PdPii/f07CQy5EJ8DqBXu78p4e5CRoK6qUnmp4NaUiUYMudcjhr8dcl+NN2S88U8ndPryi0h/51oihyqEHCH3cSHXqJFybLiv+Irc6yh35lhohy8+rwk5VIkJ9VpsOjPU7yBDbvb0r8zmmsyZMYUhF+J9wHT2NBbiONLqgBx3X9hr5FiUOxrmqaWhSsgRch8dcvduJw3sr9+yRXNRqDdD7n7mlRHDBgGYfn163bl6FsjxkU0CubgI386dOgK5vFvcXSbcUwL6PdOTTwE5vkqQ1/61VsvAW3nhrc/bf1b68CbiHhuQ4JuVS/wP7cUy/O2XDDlP5x+1NNUaKStHB7kDtjspJwcP6IPJwQP07ySfAHLc8wSvkRNWFyIHowqQiz/iq9dTB+XP27V1d7QDchlXjo0yGIRa3TRUT0R68ciFeu9btnAWYDsZ5dW7hzaqtG/X1m3vdiCXliDqp9fjs7atf7bbgIWBXHrCkaED9bGMfi+dK6cOA7lgz58xiQDbXVtDFHiAkCPkZCM39avxO7/biBBnu209Q27alAkx4T6IcqdigsEei3KVpOUy5Hhpd1MHdUBu6uRxosNeiHInRAFgj0W5yttQMvNvJYwdPRzI+Xs6rrRYgI6c1fKFiG9AbsSwgdmpZ1hiKYxydjbW4Aq8oQUDuXFGw7dvWY0ot33z6jGjhkkjJzPKhfzi2Ku7NpDDl4w97I4ol3I2slXLFkBuygTD9VZLnuYmhXjv1e6mxpAruH12/szJLMph5pHgg4hyV+JDUQXITZlouG3dcoS4jauXMuS+GjcyxGsPQlx0wAGwB+QaN260xdocUS7M20G1SydCjpCr8VI4f1szQw5zhLf8SyOH198fZZgYTwj02s9On0g8JSBE7s8nmT27awO5GVMnJp2OBnJXzojQc/v9UbqWpvofj29LI1decJMlluxuL6ycPbxT9uA6u+FLPnJMXVU6IbcEcrmpv323ceUM4/EAiXvmKC8ZKwFvEonlGssFe3dvZshlXzu+bb2lyZSx2ppcFSAHnJ5kXQByjzPPM+Qwp2qTlZWB3N5dGxEVzReYXDzqR4klIScPOcAG5P4ozuGRKy/KlOjLSSCHxPLx3avqql0Ks1MYcqUF6RJ9OR45s3kmh/b/UHnbl/iMJcqujrtM50yTiRzfl5NA7nn+tWZNmwiRK7mXXFOU489Y9tfv6X3wR1GQa3pSnBzktm9auWmNOUOun34PL+ddUf4Hbl4UyUHuYfpvEn25MO+9NmuXaWmqOn2/iZAj5GQjN2PqpG2b1mTduKDaVYUhN3GsIZJMIBfk7Tx4QN+akENf7uddNg7ffwvkJowZuWOrNZAL9HIaNKCPBHJIKVF2+H4bj9y+H7/FHH+PvTxy6AKV5F+VidwYw2Essfx24yqWWCKqRAW6FmUnYZIhh+pFOUkykQNgKWejCm6fXzhvGkNu4pgRNustgVxMiCufWKIvt3Du1HNxAUAOOF35LfR+2umFc4wZclMnjUZieScpdujAPgy5MSOHbLFeBt4899v179MTyIE0dOeQWO7/cQt6fYQcIScbuQeZKQZDBmpraVxLOMGQy7+TBNIQ63r10Em7Ei8HuZfFWdONJwC53LSLIA2NG92n1MTjEsjlpl1AtvkwM4lHriArCXPQkeORGz1yKKrLRO5Oysn+fXoBs6GD+mZePQXkooJcMdmiRfMD9t8x5AyHcw8ZyETO8Yet3NMJLVv8vHMjQy7jyrHhQ/phDbraGmdi/XjkXB22W1mYArm9uzexKva26xlytxJj+un16NTxi8NeDgASyN28GA3SUO6urZFwPAjIHQ9319FSB/xYc7CHPSFHyNGlcAVcCvfav7N3Dy26SEDIEXLvF7mlC0xaNP8UMU2/l875OD9CjpAj5OiGL0KOkCPkCDlCjpAj5Ai5D40cDVxMAxcTch8UORINXEzIfeAoRwMX08DFhBz15agvR8gRcoQcIUfIEXKEHCFHyBFyhBwhR8gRcoTcx4Lcvp/outw/dV2OzljSdTkSXZcj5N6fysrKzr2Wo6OjnZ2djY3N1q1bbeuJNm3ahCaLV9v6LF9fX0KuISoxMTE2NjYkJMSv/mjlypVAztTU1K/+C3se+x9HIS8vj5BrEEpNTcVPrEgkwrH3ryfqXSldXV3/ei7sc+x57H8chcLCQkKuQQj5THJyMo46fmvD64M8PT2bN2+O15YtWzo5OYXXZ2GfY89j/+MolJSUEHINQvhxxfHGryxym9P1QZs3bzYwMEDB2NjYwsLidH0W9jn2PPY/jkJ5eTkh1yCEI43fVxxy9CWy64N69erl5uaGgoeHR/fu3bPrs7DPseex/3EUXr16RciRPjo9fvy4RYsWf//9N5tUU1NDlKDdQsiR3pd++uknMzMzfnL16tW2tra0Wwg50vsSssqzZ8/yk0lJSQh0fNAjEXIkRSonJ6djx44SgOnq6gI82jmEHEnx2rhx49q1a2szk0TIkRQgmQFNZugjEXKkukpOt02ig0ci5EgKkJyTkxKnMUmEHEkBknMJTuJiHYmQI9VVcXFxffr0kbPAgAEDRCIR7ShCjqQYrVixAtmjnAV8fX2nT59OO4qQIylAFRUV7du3z8jIkLMMcss2bdqUlpbS7iLkSHVVRESEoaHhGxebOHGil5cX7S5CjlRXLVmyxMnJ6Y2LHT58GNTR7iLkSHVSSUnJW/2HTwN80JOQI32Qo/UfOl6EHImQIxFyhByJkCMRciRCjpAjEXIkQo6QIxFyJEKOkCMRciRCjkTIEXIkQo5EyBFyJEKORMiRCDlCjkTIkQg5Qo5EyJEIORIhR8iRCDkSIUfIkQg5EiFHIuQIORIhRyLkCDkSIUci5EiEHCFHIuRIhBwhRyLkSIQcIUci5EiEHImQI+RIhByJkCPRISTkSIQciZAj5EiEHImQI+RIhByJkCMRcoQciZAjvXfk/lMpW1tblPHaEMqEHOkfRo52DiFXK5WWlp4lyRJaVe0Xtra2blDIUZR7d7G2Raqj6ksTpL7cx4Kc4892p4+FCxzG+zcJH4VDecdzPhwfJ3QI59iaHMx8SuygUzESDjwJH5FlUeAJUUB1+wvsV+Xoaj7O2fd4lNA+nCM5/8rZW6aPif3LsQihvcQO5+25ZpUlv0ufPn3KOFRSUmrduvWmTZuk3+IXyM3NxfzU1FQJhgMCAoSHycnJqWfPno0aNerYseOOHTv4+TVV9PHx6d+/P5bHF1i3bl1FRYVwbVjGwsJCOMfIyOjy5cv8ZHJyssR3wDdXUVGhKKcw5M78GvF3+QOB73Mu4/xfzvlVLoXzeP/F+d5fz4XO5fws95XYd6v5aQ5zhdjZFSUSzvoTLuadWeUnmS+fZFT3nZdFYv9RdLvKj+FbvF9wTn/xSOg0zoWcf+d8s5oLbjCXi51a/lDo63AZ/ID3NWHfJioqytTUlG+pdnZ2u3bt4t8yMzOTPgpo3JaWljUdI3Nzc0NDw/T0dJSLior27dtnb28vpyKyXFQBjSj//fff+HRMCheIiYmZN28eP3nmzBljY2PhAsOGDQOTwjULN4r6coTcP4/ct1s38Lt0w4YNrq6u/OT//vc/DQ0N/i13d3fpowAOw8PDZR4gtHV9fX2QI5xpYmJSU0XwY2VlJZyDL9C8eXPhGjIyMvr27ctPDhky5ObNm0IgZ8+eLRKJhFhKbBQms7OzCwsLy8vLCTlC7h9ArqLsEb9LEZGESRrUpEkT/i3kbNJHAVBlZWXJPEATJkxA66/p8ElXnDZtmsyPkICwWbNmrHzs2DEAJnwLGWx+fn5iYuLIkSNr2qh79+7hU0BdSUkJIadg5P58mhse8cu8RbN0emk3btKYdRi6aHQxmWscFub1suQuISeMcqw145Xfw3/99VfLli3ZW+hcCftdbAHEH3TqhPOROvLVsTaJEMdLZkUENPbpAJWfjzgmURdfCV8MBYQ7BD1+vouLC/p+wq8tc6MQSE+fPo3cFYGOkFMkch4e+zqrdlbX0ZhvteB7P/vQ5Miom7Hh10V7QhwXrV+qraeDdw95OBByPD8IBQgIwj0cHx8/efJk9tbYsWOlDwEWQGiq6QABqprekllRevmgoCDp/h6+yYULF5CUCrt5L168QA5cXFzMB2eGmfRGYXtjY2MRCfPy8gg5xSD34km2scmkzuoq37nZAbOabOuxu2s31YnGY8sfZ1CUg9DhQT9HuId37NiB5I29JTx7KTwbKTwJKaHu3btLpI4gjQEgs6KOjk5BQYFwzqJFi6Q7iuinIQyyHFL4VSXOf7IAKL1RK1aswDoR6JBbEnIKQA68jRozQm+Ivu/5IDm8MQcnhQ8YOXCIwcDX1DXovhyaclRUFCu/fPkSjZiPMKyVSx8CdKXi4uJqOkA+Pj7ozrFrCRUVFR4eHoCKTcqsiMwQjD1//pydL3VwcGjbtq2QK6Zt27YNHz58zZo1/JxHjx4Bb2ESa2JiwtYv3CimGzduEHKKRG76jMngDSy9kTdmpJqgbvLU8RTlunbtyuIDum1owQhE/K7m3+LFwFBRUZE+7yc8Cw/qEI6QMaJzhTzwwYMHbL7Miiz6aWlp4QsANlNTU6R/0utEtokFgBk/x8LCIiQkRLgezGGX5qS/OUU5RSLn7+2sot6lNvFNItapdlP183Ki63IKkcwU9ONZJ7aXkFMMchXP7nVV6yK//yavX6em8rI4u4Ffl6u7kItKJHIf2zopyikMuRMxIRq6GtI4hSZHzl05v4NKRyVlJRWNLtY/rh9sNFRbT0diMR193dhwXx45mbcjKgo5rIohJ1x5o0bKohAP+chFBro1adzYcuk8YcVmTZsYDOl//WKsHOQi/F1QcfniOfKvyzUEUV9OYcgttzCbb7VAAqSwq9GgSyY/EksuWr90wYKZ0lGOI03RUU6IHB/lwFuzpk0rqasROWAZHeyOKIeKfJR7mn91+5bVA/vpyUGukbJyVKDrB4hyH78oyikMud56Pb73s5cAaZ7VAizT+rPWSDgjU2OCEkMR8WQityfEUUNTTT5yPXS17qVfAm+56Zf0euoCM249wR7NP2020mDww8wkhtyj7JTxY0YCj7Gjhz/KTmbI3b+TMGr4EEDl47ZHJnKMOtRisBVkJo43GsGtxNDgYUYCeON/LCSQg8sqoWLIPbh9Ydzo4ZgcM2rY/dvnwRtfsaa+3Nb1K8sL0/BaWV5RVnATr+Lywxtb11WW16GcunXd15Xlr1FXWN6yzhLlLWstS+9fw6u4nH/1dXn58/wUvIrLeclbrLnyZuvlz/KSN1tbVJYtnt27Iihf3vxNZfkbi6e5gvLdpM3fLEN50zfLSu4mbaoqJ74umxffTdi0xpwrrzEvzrnEys2bN3dwcJg1axb15RSGHPJGdr1b6C+7dsIyOw7tFM5U1VKVTizDr3N3PMhH7ttNq1327gJyBx13b/jGkiG31Gz2yyeZXi4/Wy6dz5BbvmT+3ZsXQFpEgJuV5SKGHGb6Htr74vFtq+WLakIOxhyGnMXiudmpZxDlwvycV1mYsSjHeJNGzs1x5+ABfRhyFovmZF49hRB32Gf/ymWmLMpV8ia7L1fl+9dK71+t7pTS/Co/z08WOw++IvSzvMuAROAkzrmcn3JOrOa7CcwlYl8qyRH6InNxNvOFas46Dz+p5nNPMqtclHmWcwbvM3C0vyN7TMnPz8/f35+QUwxy0oEL/uSTT2TOl+k3IncpPmrSOEMgN914wrEoP4Zc3q0EFMoLb7du1ZIh1+6ztnxi2eGL9gy5z9u3A2/IKovuptQGOayETyyxEmnkqjqBysrGk4wyr8Uz5Np91oZPLDt83o6QI+Q+aJSTmUPWdIHujcjBnTt1LH90B3S9LM5kyPF9OSSBDDmJ58oYcnhXfl9OArnqK/mkpigXGXiwp67W4+wk/oylREVCjpB7X8j17dNLui/Xpn1b7jHWCOc3Ioe+nFY39Tcit2zRvNVfL55tMoWdPsG7T+5dZ1EOcYwh1wrhTur0CSJVeeEt8Pbk3rXa9OVatWohffpEZmKJrHLWtIk8cq1atpA+fULIEXKKR26V5RKzNQslQDIxn4ll2nVob+OyPTI1BnNc4zyGjTfopNZZYknzjcuWLpz7RuRiw7zbtGntvv9HHjnrVeYooC+3ZsUSvi+XnXoOpAV4Og7qr8+QQxfOZe9OILfWaplM5KKC3Zs1bRoV5M735TKv/Qbk/A45DOyvJ78vN3rEkFDfA3xf7k7yCfDm6/bzwH69CTlC7j1el9PtoS19UU7mRYJBowdLLKnXt1dchO8bkfujKJPrv91O5JE7uG93k8aNjSeNRfhiyBVkXRk7ejjiVc/u2qkJvzLkCrOujB8zErHO0/mn2lyXe3Dn0lhDg8qVaF27ECsfuTspJ5FePs2/CuTy08+PGTUMHTzMSTknIuQIufd494mmhqrdod3Sl+YWrV+q2aMbOnuwmo66mfVi9NyEy+z2+kFDXbU2d5+cPx4+oJ8ef11O2Jerp3efEHKE3DsiBwf5HNTspvYO91hq6WgG/nKgNvdYNv+0WVSIJ48c4hshR8g1XOTgBXNNhg4f9FZPEowyMpgzw7jBPklAyBFydULuxZPsyRPHgLrAhNDaxLeRRgZGowwa8vNyhBwhVyfk2FPhiHVaWhoOv9jL4W2fr4OurhbiWwN/KpyQI+Tqihz775MgbxdNDbVevXStNlgeCN4fnhIFzCJSRQfDXdZuterfX19TQzXQ+wD99wkhR8gpBjn2D1/HjwStslzcv6+esrIyOxcP0swXzY2L9KN/+CLkCDkFI0f/Y0nIEXKEHCFHyBFyhBwhR8jVHrl99ra/yR5kJyyec2iV40Krj7NzuKZxdk6JHVzNr0fYOSm2jBF2TsAi3nKG2vEXDrJzXOgoP+E4O79yZiPs8JYeXkfgyhF2bDasrBpqJ7zaODvwUThMtuPCPKr7UFxolWND3cU+LG232BChXXnHcD5YzcFiHxHb5UiQ0M7MokDmA2/yflFAlaMDnDj783aEd9lYEXIKQ45Eqv1IeoRcnVRWVnbutRwdHe3s7GxsbLZu3WrbsDVzJvfwxIQJE2xJ1eXr60vIKUyJiYmxsbEhISF+DV69K6Wrq0u7QqbQSGhMAgUoNTUVv1sikQg71L8By9nZ+dNPP8Vry5Yt7e3t/UnVheaBRkIj7yhASBKSk5OxK/EDFt6AtWrVqoEDB6Iwbtw4U1PTcFJ1oXmgkdD4cgoQfrGwE/HThYThdAOWjo7Orl27UPjhhx+6det2mlRdaB5oJDSKqgKE3YcfLexHJOjZDVUJCQnIKjMyMthk586dY2JiskkCoXmgkaCpoMG8evWKkCPVST/99JOZmRk/uXr1altbW9ot9VSEXD1Qr169zp49y08mJSWpqanVNHQwiZAj1Uk5OTkdO3aUAExXVxfg0c4h5EiK18aNG9euXVubmSRCjqQAyQxoMkMfiZAj1VVyum0SHTwSIUdSgOScnJQ4jUki5EgKEEJcamqqzLceP37cokULyi0JOZLCFBcX16dPHzkLDBgwQCQS0Y4i5EiK0YoVK5A9ylnA19d3+vTptKMIOZICVFFR0b59+4yMDDnLILds06ZNaWkp7S5CjlRXRUREGBoavnGxiRMnenl50e4i5Eh11ZIlS5ycnN642OHDh0Ed7S5CjlQnlZSUvNWff3zkT4iRCLl6e7T+Q8eLkCMRciRCjpAjEXIkQo5EyBFyJEKORMgRciRCjkTIEXIkQo5EyJEIOUKORMiRCDlCjkTIkQg5EiFHyJEIORIhR8iRCDkSIUci5Ag5EiFHIuQIORIhRyLkSIQcIUci5EiEHCFHIuRIhByJkCPkSIQciZAj5EiEHImQI+RIhByJkCMRcoQciZAjEXIkOoSEHImQIxFyhByJkCMRcoQciZAjEXIkQo6QIxFypH8AOVtbW6wBr1R+r2VCjpAjfTi9kTrJQ1haWnqW9LEKyNWlem1+g0nv+2dR8m12XEn/VhESH12UY8g5/mx3+li4lMMk/JtMH2UOFTpe7MOc46QdInZsbRzMfKqagzjHSDsQPsl8RK5FgSdEAbLsL8t+1Rxdo49z9j0eJW2fKkdy/lVs7zf6WJV/ORYhba9qDuftybeGp0+fMgKVlJRat269adMmvgHwb/EL5ObmYn5qaqoEvQEBAcKW4+Tk1LNnz0aNGnXs2HHHjh38/Joq+vj49O/fH8vjC6xbt66iokK4NixjYWEhnGNkZHT58mV+Mjk5WeI74JurqKjUJvhcuHBBODlp0qRLly4JNxxbja0IDw8XrkH6E4WbxqrExMS8dV+OIXfm14i/yx9I+b7YZWL/l3O+pEuZ84T+S+x7nJ9LO1fsZ7mvqnxXhp/COcwV1ZzNuUTaWfCfzMW8M2X4SebLJxmyfEfsoir/UXS7mh8z35L2C87pLx5JO63KhZx/F/umpAvgG0KXVzm1/KG0r8NlvB/wvsYf5aioKFNTU76l2tnZ7dq1i3/LzMxMuqGgqVlaWtbUjMzNzQ0NDdPT01EuKirat2+fvb29nIrW1taogiaL8t9//41Px6RwAbTdefPm8ZNnzpwxNjYWLjBs2DAwKVyzcKPkI9e3b19+8ubNm1iVdHUABoTkfyI2DRsiJBlV3jHKEXL/SuT41rBhwwZXV1f+oP/vf//T0NDg33J3d5duKOBQ4ldf2Nb19fVBjnCmiYlJTRXBj5WVlXAOvkDz5s2Fa8jIyAAY/OSQIUPAhhDI2bNni0QiIZYSG1UTcvgyS5Ys4Sexhri4OJnVmzRpIv8TsWnYduFWtGzZEmvOzs4uLCwsLy8n5Bo6cnw7Q0QSJmnC5oW38AMv3VAAVVZWlsw2NGHCBLTFmtq6dMVp06bJ/AgJCJs1a8bKx44dQ3MXvoUMNj8/PzExceTIkfx86Y2SRg51e/fu/ejRIzaJL4ZJ6eovXrzw8PCYOXOm/E/Epj148ICVsU7k5+B20aJF2DpQV1JSohjkfi/J8Qtxm7VwhlZPrUZNGrNEVlWj6+z504+KAv58epeQ+8ijHGvNeOUP+l9//YWfZ/YWOlfSp1sQf9BXEc5H6shXx9okQhwvmRUR0NinA1R+PuKYRF18JXwxlgci6PHzXVxc0PcTfm2ZGyUTOQcHB9bPZJMrV6708/OT3nB0LxGH+TAl8xOFm4a6Ojo627Ztw0xs1OnTp5EzI9DVFblXZfkOB3/4smsndR2N+VYLvvezD02OjLoZG35dtCfEcdH6pTp6ul3VVAK8nQm5j7kvh99y/KILD3p8fPzkyZPZW2PHjpVuJVgAoamm1oyWV9NbMitKLx8UFCTd38M3Qe8IeaCwm4f4gxy4uLiYD84MM+mNkkbu+fPn3bt3xxrYZEFBATiRqI5JHx8fYfZY0ydi0/gwKBRmxsbGIh7m5eXVCbnix3eMjMd0Vlf5zs0OmNVkW4/dqlpqM0wm/16USch9nFEOPRbkP8KDjh9+JG/sLeHZS+HZSOFJSAmhHUukjmiOrAXLrIiGjuYunINkTLqjiHaPiMEyOuFXlTj/yQKg9EZJI4codODAAX4SW4rwxSYlqgMbbIL8T8Sm2dnZyfwgbAsCHXLLd0cOvA0aNVhviL7v+SA5vDEHJ4VjYcNRw4TUEXIfT18OTZnv9L98+RJNio8wrJVLtxJ0pdg5BplCWEB3jl1LqKioQC8IULFJmRXR0MEYYg47X4pkr23btkKumEDI8OHD16xZw89Bfwl4C5NYExMTtn7hRtWEHOjlM09MInaxxFW6OqIrtkj+J9a0T6ZPn15X5F6V3Ud8A29g6Y28MSPVBHWzZ0wh5D7CKNe1a1e+B4L2hF9r/ujzb/FiYKioqEiffxOedgd1aNDIGNHVQR7In1SQWZGFCC0tLXwBwGZqaoo0THqdyDaxABo9P8fCwiIkJES4HsxhF8qkv7nE2lAWQoVJ/jIGq86njvw5UkQzOZ+ITWM5qoT8/f3rihz6b8gnaxPfJGKdlo5mENevI+Q+uutyCpHMFPSjWuf7+IZvVF2j3O8ld7/s2kl+/60m7/b6QVNd9c+Su4Tcx3Zdru5CLio/kfvH1/k+vmEt77GsE3J+h93UdTSkcQpNjpy7cn4HlY5KykoqGl2sf1w/2Giotp6OxGL6/XrHRfox5LqodCp5kMaQiwg8hE/BK0Pu2cP0zp06fmDk8AXYq7QUhRxWxZATrrxRI+XoYHf5yEUGHmzSuLHlknnCis2aNjEY3P/6hRg5yEX4u6Di8sVz5F+XI328UW7WwhnzrRZIgBR2NRp0yWysEktabVlhvmguQ27erGmi0F8YcksWzJ48cQxeGXKiw17zZk39R5DjLUWagpHj4xt4AzzVqJNCrpGycnSQGwqoyEe5p3kp2zevHthPTw5yqBgVePADRDlSTaprX06rp9b3fvYSIM2zWsBdLvysNRLOyNSYoMRQRDyZyDmG7dfR0mTIHdi7y36XDUPuy44d7lw92+GLzxlye77fdsBhJ5DDGn7auVVdrQuQu3gqqo9eD8SEz9u383Hfy5DDAtEhns0/bTbSYPDDrCuMN+5zQzzEMzMvM9ge56RMGDMS1ceNHv4oJ4Uh9yAjyXDEkGZNm/q4OchBrrtOt5wb51DAa++eOuAN70YGuuEjRgwbdP/2JUZaQVbSeKMR+IixhgYFmUkMs/xbF0cNHwyovF3tZSLHqEMtxtvDjEvjjYYDlTGGwx7cucQwY5JADgY5WJLxdv/2hXGjDbiKo4bdv3UevPEVa0KuvDBt6/qVWACvgvKKsoKbeJVRfnhj67rK8jpW/rqy/HXZw9Sq8oPr0uUt6yxL71/bstaSK6+VKF+tKufz5eXP81PwWlW2rixbL3+el8zKm62XP8tL3mxtUVm2eHbviszy03uXN39TWf7G4mluDeW7SZu/WcZdJ/hmWcndpE1V5URZZfPiuwl45cprzItzEvD6unyJlU1nTenQocO4ceNQrmuUU1JSYte7hUbvDsvsOLRTOFNVS1U6sQy/zt1ewJC7GC+aM8MYyCWcPmI0ygCk4fVifDQKM6d9dTE+iiHn77n/z5IcIKerrXkyJgiYhfq7tm7Vkkdu6cI5gOeXgz9bLjXlkVu6cPbL4kwvl8qZlcihkJt2ESEuItDdynIRQ275kvl+h/b9UXQHc+QgZ7Nh1YE9tii47N25fo0FQ27JglkvHt3ydP5x+ZJ5DDmLJfOyU8+gEOZ3cNXyhQw5i8Vzfd32IF6tWm5WE3Jw5RwOOYvFc7Ku/YYoF+rrvNJiAYtyjDdp5Nz27Rw8QJ8ht2zRnIyrJ0HaYZ/9K5eZsijHeKsJOUnfh6+WynYK5/xqfp6fXM15zFek/Szv8rN7Mp0kdq7YTzknyvBdOIF3SZUvleTI9EXmYjib9wUZzoLPw08kfY5zprTPFvHO4H1G6Gh/R/ZIuJ+fX12jnHTggj/55BOZ82WaR67iWW43TTUg9+3mbw4524M0vNpsXI0C5oMchhzjTSKxxHy+kH87EVnl74/ugEMeubzbCUgsywtvczMrkWv3WVs+sezwRXuGHALmH0UZAKwo96oc5C6cDJ84bhQK06eMPxrhzZDLvXkeKWXpw5utWrVkyOEj+MQSH8GQ+7z9Z+ANhcfZl2uDXLvP2vCJJVYijVxVJ1BZ2XiiUebVUww5VOQTyw6ftyPk/iXIyYxyMnNImT4iQA4eOXzIiydZA/vpF91LBWkl99N69dB5UZQ1cvhgdsayEi1xX+5RzlW7b9fPmTEF4U6IHN+XQ27GI8f35biZlchJPPTFkMO7tezLde7UsbQgDXSBGYYc35HDShhpEh/BkOPelduXk0Cu+ko+qSnKRQYc7Kmr9TgrkT9jKVGRkPuXINe9t450X65N+7bcY6wRzm9E7pfoQ3xfDl672mKV5eIJYw35ywOTxo82mzdjrZWFNHIgc9f2jei5Zd84L0SuOC+VRTmELB65J3nXWZTjZlYi9zrcVTt9woWRR3cAWHHedfnImS+cY7V80ezpX7FzJ3i3KCeZRTnEMYYcH+6Ep0/wEWUPb6Lw5G5ybfpyrVq1kD59IjOxRFY5a9pEHrlWLVtInz4h5Oo9cmZL50qfsTQxn4ll2nVob+OyPTI1BnNc4zyGjTfopNZZYsnN31rzZyzhsAB3VPzF1YFHzsd9H+aE+btJI9esadP05PjfH2es/nqJELm1q5YBOfTl1qxcyiNnvcocyKEvt2bFUr4vl3PjPHgL9HIaNKAPQw5duIN7dwGwdVbL5CN35LBnmzat3Jy+55H7ZuVSIIe+3JqvF/N9uczrp1HwP7R3UH99hhy6cM4OtiisXbVUJnKRgW7NmjaJDHTl+3IZKaeAnK/7noH99OT35UaPGBzqs5/vy91JPg7MfN3sB/brTcj9S5A7KgrS0NWQvign8yLBoNGDhYvFph9DW+evy8GPcq/h1/3Zw1s8cqWFtzGnIDtFGrnIYA+klAhWTj/bCpFzddzdpHFj40ljn+Sl8sgd5Gfeu86QK8xKHjeaO53Yq7t2auJxhtyj7JTxY0YiEHm62MtHrryQSwtz0y7wyLk42OEjpkw0QrhjyD3ISBg72gAf0bO79vWLRxlyBZmJ441G4CM8DvxQm+ty929fGGs4DP005I1Xz8fIR+5O8gksVpKXAuTy0s+PGSWumHJWRMj9S5CreHavq1oX6btPwq5GL1q/VLNHNyVlJVhNR93MenH4dZFwGa8gF00NBd99IuzL8RflhH05Rd19cubY4QF99fjrcsK+XP29+4SQqwfIwQHeLl3Uu7ztPZZRKaIe3bUVfo8l4ow0cpipcOSaf9osMsidRw4fQcgRch8IOXjunOl9h/at/ZMEcWnHJowfPWeGMT1JQMgRcu+C3IsnORMnGIG6gEuHaxPfwNsYQwN6Xo6QI+Te/alwUDd/rom6ppqd+66aYItNP+YV7IJ8EvGNngon5Ag5BfzdUJAPd0ake08dy3XL9gQ4sKvkR27GeUUf2vyd9aABfTU11IK8Xei/Twg5Qk4xyMEVz3JPHAleZbm4f189ZWVlduIbpJkvmhcX6U//8EXIEXIKRo7+x5KQI+QIOUKOkCPkCDlCjpCrPXL77G1/q2lgnaqxdcLiOYdKOo655hF25A6sc6rKwTIcE8yPqnOymuWNrXOCWcQ74F0G2ZEcT0fgKGYZI+z8ypkfVUdoOePpVHeEt6zhdV4PshMubU/4KO8w+faIk+1DnEOrOTbUvZoPy7FbbIhMu0o4hvNBGQ6u5iNVdjkSJNPOzCI4kPeBt/F+zgHSdorm7c/bUehdNlZ1RY5EIr2t3hG5srKyc6/l6OhoZ2dnY2OzdetWWxKJJFe+vr7vgpxQiYmJsbGxISEhfiQSqXYCL283JoFQqampgFUkEmEt/iQS6U0CKW898o5QiIzJycmoD2rDSSTSmwRSwMvbjS8nFDBFTfCKKHmaRCK9SSAFvLzdKKpCoQ5IRWVkpdkkEulNAingBdSAnVevXr01ciQSSfGDFtAuIJEIORKJkCORSIrQ/wNkvYMEpDukXwAAAABJRU5ErkJggg==" alt="DefRef class structure" id="fig:DefRefClasses" data-latex-style="scale=0.9"/>
 *
 *
 * <pre>
 * <!--PlantUML: Classes
 *  class DefRef {
 *      packagePart
 *      defRefWithoutPackages
 *  }
 *  class TypedDefRef<DEF,CFG,VAL>{
 *  }
 *  class WrappedTypedDefRef<DEF,CFG,VAL,WRAP>{
 *  }
 *
 *    DefRef <|-_TypedDefRef
 *    TypedDefRef <|-_ WrappedTypedDefRef
 *
 * -->
 * </pre>
 *
 * <h5>Creation</h5>You can create a DefRef object with following public static methods (partial):
 * <ul>
 * <li><code>DefRef.create(DefRef, String)</code> - Parent DefRef, Child name</li>
 * <li><code>DefRef.create(IDefRefWildcard, String)</code> - Wildcard, Definition without package</li>
 * <li><code>DefRef.create(MIHasDefinition)</code> - Model object</li>
 * <li><code>DefRef.create(MIHasDefinition, String)</code> - Parent object, Child name</li>
 * <li><code>DefRef.create(MIParamConfMultiplicity)</code> - Definition object</li>
 * <li><code>DefRef.create(String, String)</code> - Package part, Definition without package</li>
 * </ul>
 *
 * <h5>Wildcards</h5> {@link DefRef} instances can also have a wildcard instead of a package {@link String} ({@link IDefRefWildcard}). The wildcard is used to match on multiple
 * packages. <!--LaTeX:See chapter \vref{sec:IDefRefWildcard} for details.-->
 *
 * <h5>Useful Methods</h5> This section describes some useful methods (Please look at the javadoc of the DefRef class for a full documentation):
 * <ul>
 * <li><code>defRef.isDefinitionOf(MIHasDefinition)</code> - Checks the definition of the configuration element and returns true if the element has the definition. The "defRef"
 * object is e.g. from the Constants class.
 * <ul>
 * <li>Note: The method <code>isDefinitionOf()</code> returns <code>false</code>, if the element is removed or invisible.</li>
 * </ul>
 * </li>
 * <li><code>defRef.asDefinitionOf(MIHasDefinition, Class<>)</code> - Checks the definition of the configuration element and returns the element casted to the configuration
 * subtype, or null.
 * <ul>
 * <li>Note: The method <code>asDefinitionOf()</code> returns <code>null</code>, if the element is removed or invisible.</li>
 * </ul>
 * </li>
 * </ul>
 *
 * <pre>
 * <code class="Java" id="DefRef isDefinitionOf methods">
 * MIObject yourObject = ...;
 * DefRef yourDefRef = ...;
 *
 * if(yourDefRef.isDefinitionOf(yourObject){
 *      //It is the correct instance
 *      //Do something
 * }
 *
 * //Or with an integrated cast in the TypedDefRef case
 * final MIContainer container = yourDefRef.asDefinitionOf(yourObject);
 * if(container  != null){
 *      //Do something
 * }
 * </code>
 * </pre>
 *
 *
 * </div>
 *
 *
 * <p>
 * The {@link DefRef#create(MIHasDefinition)} and {@link DefRef#create(MIParamConfMultiplicity)} support the {@link IMockProvider} interface. See IMockProvider for more details.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class DefRef implements Serializable {
    private static final long serialVersionUID = -3294335890545099585L;

    private static final ILogger logger = Logger.INSTANCE.createLogger(DefRef.class);

    @PublishedField
    public static final String AUTOSAR3_PACKAGE = "/AUTOSAR";

    @PublishedField
    public static final String AUTOSAR4_PACKAGE = "/AUTOSAR/EcucDefs";

    @PublishedField
    public static final String MICROSAR_PACKAGE = "/MICROSAR";

    /** The Constant SEPARATOR for DefRefs. */
    @PublishedField
    public static final String SEPARATOR = "/";

    /*
     * Public section
     */
    /**
     * The Constant INVALID_DEFREF describes a definition ref, which will never be equal to any other definition inclusive DefRefs with any wildcard.
     *
     * It is also NOT equal to itself! This shall prevent from false Map lookups.
     */
    @PublishedField
    public static final DefRef INVALID_DEFREF = new DefRef("/INVALID-PACKAGE", "INVALID-MODULEDEF", null);

    private static final DefRef UNINITIALIZED_DEFREF = new DefRef("/INVALID-PACKAGE", "UNINITIALIZED-DEFREF-MODULEDEF", null);

    /*
     * Private Section
     */
    /*
     * Private member fields
     */

    private final String packagesPart;

    private final String defRefWithoutPackages;

    private final IDefRefWildcard wildcard;

    /*
     * Volatile Data and DefRef specific Caches
     */
    private volatile TypedDefRef<MIModuleDef, MIModuleConfiguration, Void> moduleDefRef;

    /** The parent {@link DefRef} of this {@link DefRef}, if the value was not yet set, it is the UNINITIALIZED_DEFREF. */
    private volatile DefRef parentDefRef = UNINITIALIZED_DEFREF;

    /**
     * The parent {@link DefRef} of this {@link DefRef}, if the value was not yet set, it is the UNINITIALIZED_DEFREF. The DefRef is the passed parent DefRef during construction
     * for hierarchic DefRefs.
     */
    private volatile DefRef parentHierarchicDefRef = UNINITIALIZED_DEFREF;

    private volatile String defRefWithoutModuleDef;

    @Nullable
    private volatile String wholeDefRefString;
    /*
     * ---------------------------------------------------------------------------------------------
     * Static create methods
     * ---------------------------------------------------------------------------------------------
     */

    /**
     * Returns <code>true</code> if the specified {@link DefRef} is <code>null</code> or identical with the {@link #INVALID_DEFREF}.
     *
     * @param defRef
     * @return
     */
    @PublishedMethod
    public static boolean isNullOrInvalid(@Nullable DefRef defRef) {
        return defRef == null || defRef == INVALID_DEFREF;
    }

    /*
     * Model create
     */
    /**
     * Constructs a {@link DefRef} instance from a MDF model object.
     *
     * <p>
     * The {@link DefRef#create(MIHasDefinition)} supports the {@link IMockProvider} interface. See IMockProvider for more details.
     * </p>
     *
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     * @param mdfObj The model object,
     *
     * @return The defRef object
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the mdfObj is null</li>
     * </ul>
     * @exception ModelCeAlreadyRemovedException
     * <ul>
     * <li>if the mdfObj is removed</li>
     * </ul>
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if the mdfObj has no definition</li>
     * </ul>
     *
     * @see #tryCreate(MIHasDefinition)
     */
    @PublishedMethod
    public static DefRef create(final MIHasDefinition mdfObj) {
        if (mdfObj == null) {
            throw new IllegalArgumentException("mdfObj is null.");
        }

        final DefRef result = tryCreate(mdfObj);
        if (result == null) {
            ModelUtil.ensureIsNotRemovedOnly(mdfObj);

            throw new ModelCeHasNoDefinitionException(mdfObj);
        }
        return result;
    }

    /**
     * Constructs a {@link DefRef} instance from a MDF model object.
     *
     * <p>
     * The {@link DefRef#tryCreate(MIHasDefinition)} supports the {@link IMockProvider} interface. See IMockProvider for more details.
     * </p>
     *
     * <p>
     * <b>Remark:</b> This method also works for invisible MDF objects (see the documentation of {@link IModelAccess} for details).
     * </p>
     *
     *
     * @param mdfObj The model object,
     *
     * @return The defRef object or null if the mdfObj has no definition object.
     *
     * @see #create(MIHasDefinition)
     */
    @PublishedMethod
    public static DefRef tryCreate(final MIHasDefinition mdfObj) {

        if (mdfObj instanceof IMockProvider) {
            return handleMockedMDFObjects((IMockProvider) mdfObj);
        }

        final DefRef defRef = MdfDefRefCache.getCachedDefRef(mdfObj);
        if (defRef != null) {
            return defRef;
        }
        return tryCreateCachedHasDefinitionDefRef(mdfObj);
    }

    private static DefRef tryCreateCachedHasDefinitionDefRef(final MIHasDefinition mdfObj) {
        final MIReferrable definition = ModelUtil.getDefinition(mdfObj);
        if (definition instanceof MIParamConfMultiplicity) {
            final DefRef defRef = create((MIParamConfMultiplicity) definition);
            MdfDefRefCache.setDefinitionCache(mdfObj, defRef);
            return defRef;
        }

        return tryCreateDefRefFromObjectWithNoDefinition(mdfObj);
    }

    /**
     * @param mdfObj
     */
    private static DefRef tryCreateDefRefFromObjectWithNoDefinition(final MIHasDefinition mdfObj) {

        if (mdfObj instanceof MIModuleConfiguration) {
            /*
             * We can create a DefRef from a ModuleConfig
             */
            final String moduleDef = ModelUtil.getDefinitionString(mdfObj);
            if (moduleDef != null && moduleDef.length() > 2) {
                final String packageString = AutosarUtil.getPathWithoutLastShortname(moduleDef);
                final String moduleName = AutosarUtil.getLastShortname(moduleDef);
                if (packageString != null && !packageString.isEmpty() && moduleName != null && !moduleName.isEmpty()) {
                    return DefRef.create(packageString, moduleName);
                }
            }
        } else {
            /*
             * We have to retrieve the corresponding ModuleConfig of this element to get the package information.
             */
            final IProjectContext projectContext = ModelUtil.getProjectContext(mdfObj);
            if (projectContext != null) {
                final MIModuleConfiguration moduleConfig = projectContext.getService(IModelAccess.class).getModuleConfiguration(mdfObj);
                if (moduleConfig != null) {
                    String moduleDef = ModelUtil.getDefinitionString(moduleConfig);
                    if (moduleDef != null && moduleDef.length() > 2) {
                        final String elementDef = ModelUtil.getDefinitionString(mdfObj);
                        if (elementDef != null) {
                            int i = moduleDef.lastIndexOf('/');
                            if (i != -1) {
                                moduleDef = moduleDef.substring(i + 1);
                                i = elementDef.indexOf('/' + moduleDef + '/');
                                if (i != -1) {
                                    return DefRef.create(elementDef.substring(0, i), elementDef.substring(i + 1));
                                }
                            }
                        }
                    }
                }
            }
        }

        return null;
    }

    /**
     * Constructs a definition ref by a definition ref string and a parent MDF model object. The defRef String can be absolute or relative to the parent object.
     *
     * @param parentObj The parent model object
     * @param defRefString The definition ref string
     *
     * @return The child defRef object.
     *
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentObj is null</li>
     * <li>if the defRefString is null</li>
     * <li>if the defRefString is empty</li>
     * <li>if the defRef is absolute and is no child of the parent object</li>
     * </ul>
     *
     * @exception ModelCeHasNoDefinitionException
     * <ul>
     * <li>if the parentObj has no definition</li>
     * </ul>
     *
     * @see #tryCreate(MIHasDefinition, String)
     */
    @PublishedMethod
    public static DefRef create(final MIHasDefinition parentObj, final String defRefString) {
        if (parentObj == null) {
            throw new IllegalArgumentException("parentObj is null.");
        }

        final DefRef result = tryCreate(parentObj, defRefString);
        if (result == null) {
            throw new ModelCeHasNoDefinitionException(parentObj);
        }
        return result;
    }

    /**
     * Constructs a definition ref from a Definition object of the MDF model.
     *
     *
     * <p>
     * The {@link DefRef#create(MIParamConfMultiplicity)} supports the {@link IMockProvider} interface. See IMockProvider for more details.
     * </p>
     *
     * @param definitionObj The definition model object,
     *
     * @return The defRef object.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the definitionObj is null</li>
     * </ul>
     */
    @PublishedMethod
    public static DefRef create(final MIParamConfMultiplicity definitionObj) {

        if (definitionObj == null) {
            throw new IllegalArgumentException("definitionObj is null.");
        }
        if (definitionObj instanceof IMockProvider) {
            return handleMockedMDFObjects((IMockProvider) definitionObj);
        }

        final DefRef defRef = MdfDefRefCache.getCachedDefRef(definitionObj);
        if (defRef != null) {
            return defRef;
        }
        return createDefinitionCacheEntry(definitionObj);

    }

    private static DefRef createDefinitionCacheEntry(final MIParamConfMultiplicity definitionObj) {
        final DefRef defRef = TypedDefRef.createDefRefByDefinitionObj(definitionObj);
        if (MdfDefRefCache.setDefinitionCache(definitionObj, defRef)) {
            //The new value was the correct cached element
            return defRef;
        }

        final DefRef cachedDefRef = MdfDefRefCache.getCachedDefRef(definitionObj);
        if (cachedDefRef != null) {
            //Someone else has initialized the definition, so we should use the cached one.
            return cachedDefRef;
        }
        //The cache set was not valid, but also has no cache entry, so just return the instance
        return defRef;
    }

    /**
     * Tries to create a {@link TypedDefRef} from the mocked {@link IMockProvider}.
     *
     * <p>
     * If the mdfObj does not support creation of a {@link TypedDefRef}, a {@link IllegalArgumentException} is thrown!
     * </p>
     *
     * @param mdfObj the MockObject
     * @return the {@link TypedDefRef} of the mocked obj.
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the mdfObj does not support {@link TypedDefRef}s</li>
     * </ul>
     */
    private static DefRef handleMockedMDFObjects(final IMockProvider mdfObj) {
        DefRef defRef = mdfObj.get(TypedDefRef.class);
        if (defRef == null) {
            defRef = mdfObj.get(DefRef.class);
            if (defRef == null) {
                throw new IllegalArgumentException("The passed IMockProvider does not support creation of TypedDefRefs nor DefRefs. " + mdfObj);
            }
        }

        return defRef;
    }

    /**
     * Constructs a definition ref by a definition ref string and a parent MDF model object. The defRef String can be absolute or relative to the parent object.
     *
     * @param parentObj The parent model object
     * @param defRefString The definition ref string
     *
     * @return The child defRef object or <code>null</code> if the parent object has no definition.
     *
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentObj is null</li>
     * <li>if the defRefString is null</li>
     * <li>if the defRefString is empty</li>
     * <li>if the defRefString is absolute and is no child of the parent object</li>
     * </ul>
     *
     * @see #create(MIHasDefinition, String)
     */
    @PublishedMethod
    @Nullable
    public static DefRef tryCreate(final MIHasDefinition parentObj, final String defRefString) {

        final DefRef parentDefRef = tryCreate(parentObj);
        if (parentDefRef == null) {
            // The parent modelObject has no definition
            return null;
        }
        return create(parentDefRef, defRefString);
    }

    /*
     * Create methods
     */

    /**
     * Constructs a definition ref by a definition ref string and a parent DefRef object. The defRef String can be absolute or relative to the parent object.
     *
     * @param parentDefRef The parent defRef
     * @param defRefString The definition ref string of the child
     *
     * @return The child defRef object
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentDefRef is null</li>
     * <li>if the defRef is null</li>
     * <li>if the defRef is empty</li>
     * <li>if the defRef is absolute and is no child of the parent object</li>
     * <li>if the parentDefRef contains any wildcard</li>
     * </ul>
     */
    @PublishedMethod
    public static DefRef create(final DefRef parentDefRef, final String defRefString) {
        final DefRef defRef;
        final String defStr = calculatePathOfChildFromParentDefRef(parentDefRef, defRefString);
        if (!parentDefRef.hasWildcards()) {
            defRef = new DefRef(parentDefRef.getPackagePartOfDefRefString(), defStr, null);
        } else {
            defRef = new DefRef(parentDefRef.getDefRefWildcard(), defStr);
        }

        defRef.setParentHierarchicDefRefIfIsImmediateParent(parentDefRef);
        return defRef;
    }

    /**
     * Constructs a definition ref by a definition ref string and a parent DefRef object. The defRef String can be absolute or relative to the parent object.
     *
     * @param parentDefRef The parent defRef
     * @param defRefString The definition ref string of the child
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     *
     * @return The child defRef object
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentDefRef is null</li>
     * <li>if the defRef is null</li>
     * <li>if the defRef is empty</li>
     * <li>if the defRef is absolute and is no child of the parent object</li>
     * <li>if the parentDefRef contains any wildcard</li>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> create(
            final DefRef parentDefRef,
            final String defRefString,
            final Class<DEF_TYPE> modelDefinitionClass,
            final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass) {

        return create(parentDefRef, defRefString, modelDefinitionClass, modelConfigClass, valueClass, null);
    }

    /**
     * Constructs a definition ref by a definition ref string and a parent DefRef object. The defRef String can be absolute or relative to the parent object.
     *
     * @param parentDefRef The parent defRef
     * @param defRefString The definition ref string of the child
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     * @param additionalInfos Specifies additional type information of the {@link TypedDefRef}
     *
     * @return The child defRef object
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentDefRef is null</li>
     * <li>if the defRef is null</li>
     * <li>if the defRef is empty</li>
     * <li>if the defRef is absolute and is no child of the parent object</li>
     * <li>if the parentDefRef contains any wildcard</li>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> create(
            final DefRef parentDefRef,
            final String defRefString,
            final Class<DEF_TYPE> modelDefinitionClass,
            final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass,
            final TypeInfo additionalInfos) {

        final TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef;
        final String defStr = calculatePathOfChildFromParentDefRef(parentDefRef, defRefString);
        if (!parentDefRef.hasWildcards()) {
            defRef = new TypedDefRef<>(parentDefRef.getPackagePartOfDefRefString(), defStr, null, modelDefinitionClass, modelConfigClass, valueClass, additionalInfos);
        } else {
            defRef = new TypedDefRef<>(parentDefRef.getDefRefWildcard(), defStr, modelDefinitionClass, modelConfigClass, valueClass, additionalInfos);
        }
        ((DefRef) defRef).setParentHierarchicDefRefIfIsImmediateParent(parentDefRef);
        return defRef;
    }

    /**
     * Constructs a definition ref by a definition ref string and a parent DefRef object. The defRef String can be absolute or relative to the parent object.
     *
     * @param parentDefRef The parent defRef
     * @param packagesPartOfDefRef The package for the DefRef to create
     * @param defRefString The definition ref string of the child
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     * @param additionalInfos Specifies additional type information of the {@link TypedDefRef}
     *
     * @return The child defRef object
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentDefRef is null</li>
     * <li>if the packagesPartOfDefRef is null</li>
     * <li>if the packagesPartOfDefRef is empty</li>
     * <li>if the defRef is null</li>
     * <li>if the defRef is empty</li>
     * <li>if the defRef is absolute and is no child of the parent object</li>
     * <li>if the parentDefRef contains any wildcard</li>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * <li>if the additionalInfos is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> create(
            final DefRef parentDefRef,
            final String packagesPartOfDefRef,
            final String defRefString,
            final Class<DEF_TYPE> modelDefinitionClass,
            final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass,
            final TypeInfo additionalInfos) {

        final TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> defRef;
        final String defStr = calculatePathOfChildFromParentDefRef(parentDefRef, defRefString);
        defRef = new TypedDefRef<>(packagesPartOfDefRef, defStr, null, modelDefinitionClass, modelConfigClass, valueClass, additionalInfos);
        ((DefRef) defRef).setParentHierarchicDefRefIfIsImmediateParent(parentDefRef);
        return defRef;
    }

    /**
     * Constructs a definition ref by a definition ref string and the definition ref of the packages. The defRef String must be absolute, and the definition must be a child of
     * the module definition
     *
     * @param packagesPartOfDefRef The first part of the defRef with the packages e.g. /MICROSAR/Can_CanoeemuCanoe, but without the module.
     * @param defRefWithoutPackage The definition ref string starting at the module e.g. Nm/NmGlobalConfig
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the packagesPartOfDefRef is null</li>
     * <li>if the defRefWithoutPackage is null</li>
     * <li>if the packagesPartOfDefRef is empty</li>
     * <li>if the defRefWithoutPackage is empty</li>
     * <li>if the packagesPartOfDefRef is not an absolute definition ref</li>
     * <li>if the defRefWithoutPackage start with "/"</li>
     * <li>if the packagesPartOfDefRef ends with "/"</li>
     * <li>if the defRefWithoutPackage ends with "/"</li>
     * </ul>
     */
    @PublishedMethod
    public static DefRef create(final String packagesPartOfDefRef, final String defRefWithoutPackage) {
        return new DefRef(packagesPartOfDefRef, defRefWithoutPackage, null);
    }

    /**
     * Constructs a definition ref by a definition ref string and the definition ref of the packages. The defRef String must be absolute, and the definition must be a child of
     * the module definition
     *
     * @param packagesPartOfDefRef The first part of the defRef with the packages. E.g. /MICROSAR/Can_CanoeemuCanoe, but without the module.
     * @param moduleDefRef The definition ref string starting at the module. E.g. Nm/NmGlobalConfig
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the packagesPartOfDefRef is null</li>
     * <li>if the moduleDefRef is null</li>
     * <li>if the packagesPartOfDefRef is empty</li>
     * <li>if the moduleDefRef is empty</li>
     * <li>if the packagesPartOfDefRef is not an absolute definition ref</li>
     * <li>if the moduleDefRef start with "/"</li>
     * <li>if the packagesPartOfDefRef ends with "/"</li>
     * <li>if the moduleDefRef ends with "/"</li>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> create(
            final String packagesPartOfDefRef,
            final String moduleDefRef,
            final Class<DEF_TYPE> modelDefinitionClass,
            final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass) {

        return create(packagesPartOfDefRef, moduleDefRef, modelDefinitionClass, modelConfigClass, valueClass, null);
    }

    /**
     * Constructs a definition ref by a definition ref string and the definition ref of the packages. The defRef String must be absolute, and the definition must be a child of
     * the module definition
     *
     * @param packagesPartOfDefRef The first part of the defRef with the packages. E.g. /MICROSAR/Can_CanoeemuCanoe, but without the module.
     * @param defRefString The definition ref string starting at the module. E.g. Nm/NmGlobalConfig
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     * @param additionalInfos Specifies additional type information of the {@link TypedDefRef}
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the packagesPartOfDefRef is null</li>
     * <li>if the defRefString is null</li>
     * <li>if the packagesPartOfDefRef is empty</li>
     * <li>if the defRefString is empty</li>
     * <li>if the packagesPartOfDefRef is not an absolute definition ref</li>
     * <li>if the defRefString start with "/"</li>
     * <li>if the packagesPartOfDefRef ends with "/"</li>
     * <li>if the defRefString ends with "/"</li>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> create(
            final String packagesPartOfDefRef,
            final String defRefString,
            final Class<DEF_TYPE> modelDefinitionClass,
            final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass,
            final TypeInfo additionalInfos) {

        return new TypedDefRef<>(packagesPartOfDefRef, defRefString, null, modelDefinitionClass, modelConfigClass, valueClass, additionalInfos);
    }

    /**
     * Constructs a definition ref by a definition ref string and the definition ref of the packages. The defRef String must be absolute, and the definition must be a child of
     * the module definition
     *
     * @param packagesPartOfDefRef The first part of the defRef with the packages. E.g. /MICROSAR/Can_CanoeemuCanoe, but without the module.
     * @param defRefString The definition ref string starting at the module. E.g. Nm/NmGlobalConfig
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     * @param wrapperClass The class of the Wrapper around the MDF model object. Normally used by the BswmdModel.
     * @param additionalInfos Specifies additional type information of the {@link TypedDefRef}
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the packagesPartOfDefRef is null</li>
     * <li>if the defRefString is null</li>
     * <li>if the packagesPartOfDefRef is empty</li>
     * <li>if the defRefString is empty</li>
     * <li>if the packagesPartOfDefRef is not an absolute definition ref</li>
     * <li>if the defRefString start with "/"</li>
     * <li>if the packagesPartOfDefRef ends with "/"</li>
     * <li>if the defRefString ends with "/"</li>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * <li>if the additionalInfos is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE, WRAPPER_CLASS> WrappedTypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE, WRAPPER_CLASS> create(
            final String packagesPartOfDefRef,
            final String defRefString,
            final Class<DEF_TYPE> modelDefinitionClass,
            final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass,
            final Class<WRAPPER_CLASS> wrapperClass,
            final TypeInfo additionalInfos) {

        if (additionalInfos == null) {
            throw new IllegalArgumentException("additionalInfos is null.");
        }

        return new WrappedTypedDefRef<>(packagesPartOfDefRef, defRefString, null, modelDefinitionClass, modelConfigClass, valueClass,
                wrapperClass, additionalInfos);
    }

    /**
     * Constructs a definition ref by a definition ref string and the definition ref of the packages. The defRef String must be absolute, and the definition must be a child of
     * the module definition
     *
     * @param parentDefRef The parent DefRef to construct from
     * @param defRefString The definition ref string starting at the module. E.g. Nm/NmGlobalConfig, or the shortname only.
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     * @param wrapperClass The class of the Wrapper around the MDF model object. Normally used by the BswmdModel.
     * @param additionalInfos Specifies additional type information of the {@link TypedDefRef}
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the packagesPartOfDefRef is null</li>
     * <li>if the defRefString is null</li>
     * <li>if the packagesPartOfDefRef is empty</li>
     * <li>if the defRefString is empty</li>
     * <li>if the packagesPartOfDefRef is not an absolute definition ref</li>
     * <li>if the defRefString start with "/"</li>
     * <li>if the packagesPartOfDefRef ends with "/"</li>
     * <li>if the defRefString ends with "/"</li>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * <li>if the additionalInfos is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE, WRAPPER_CLASS> WrappedTypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE, WRAPPER_CLASS> create(
            final WrappedTypedDefRef<?, ?, ?, ?> parentDefRef,
            final String defRefString,
            final Class<DEF_TYPE> modelDefinitionClass,
            final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass,
            final Class<WRAPPER_CLASS> wrapperClass,
            final TypeInfo additionalInfos) {

        if (additionalInfos == null) {
            throw new IllegalArgumentException("additionalInfos is null.");
        }

        final WrappedTypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE, WRAPPER_CLASS> defRef;
        final String defStr = calculatePathOfChildFromParentDefRef(parentDefRef, defRefString);
        if (!parentDefRef.hasWildcards()) {
            defRef = new WrappedTypedDefRef<>(parentDefRef.getPackagePartOfDefRefString(), defStr, null, modelDefinitionClass, modelConfigClass, valueClass, wrapperClass,
                    additionalInfos);
        } else {
            defRef = new WrappedTypedDefRef<>(parentDefRef.getDefRefWildcard(), defStr, modelDefinitionClass, modelConfigClass, valueClass, wrapperClass, additionalInfos);
        }
        ((DefRef) defRef).setParentHierarchicDefRefIfIsImmediateParent(parentDefRef);
        return defRef;
    }

    /**
     * Constructs a definition ref by a definition ref string and the definition ref of the packages. The defRef String must be absolute, and the definition must be a child of
     * the module definition
     *
     * @param parentDefRef The parent DefRef to construct from
     * @param packagesPartOfDefRef The PackagePart of the DefRef
     * @param defRefString The definition ref string starting at the module. E.g. Nm/NmGlobalConfig, or the shortname only.
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     * @param wrapperClass The class of the Wrapper around the MDF model object. Normally used by the BswmdModel.
     * @param additionalInfos Specifies additional type information of the {@link TypedDefRef}
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the parentDefRef is null</li>
     * <li>if the packagesPartOfDefRef is null</li>
     * <li>if the defRefString is null</li>
     * <li>if the packagesPartOfDefRef is empty</li>
     * <li>if the defRefString is empty</li>
     * <li>if the packagesPartOfDefRef is not an absolute definition ref</li>
     * <li>if the defRefString start with "/"</li>
     * <li>if the packagesPartOfDefRef ends with "/"</li>
     * <li>if the defRefString ends with "/"</li>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * <li>if the additionalInfos is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE, WRAPPER_CLASS> WrappedTypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE, WRAPPER_CLASS> create(
            final WrappedTypedDefRef<?, ?, ?, ?> parentDefRef,
            final String packagesPartOfDefRef,
            final String defRefString,
            final Class<DEF_TYPE> modelDefinitionClass,
            final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass,
            final Class<WRAPPER_CLASS> wrapperClass,
            final TypeInfo additionalInfos) {

        if (additionalInfos == null) {
            throw new IllegalArgumentException("additionalInfos is null.");
        }

        final WrappedTypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE, WRAPPER_CLASS> defRef;
        final String defStr = calculatePathOfChildFromParentDefRef(parentDefRef, defRefString);
        defRef = new WrappedTypedDefRef<>(packagesPartOfDefRef, defStr, null, modelDefinitionClass, modelConfigClass, valueClass, wrapperClass,
                additionalInfos);

        ((DefRef) defRef).setParentHierarchicDefRefIfIsImmediateParent(parentDefRef);
        return defRef;
    }

    /**
     * Constructs a definition ref by a definition ref string and a {@link IDefRefWildcard wildcard} of the packages. The defRef String must be absolute, and the definition must
     * be a child of the module definition
     *
     * @param packageWildcard The wildcard for the Package definition. E.g. {@link EDefRefWildcard#ANY}
     * @param moduleDefRef The definition ref string starting at the module e.g. Nm/NmGlobalConfig
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the packageWildcard is null</li>
     * <li>if the moduleDefRef is null</li>
     * <li>if the moduleDefRef is empty</li>
     * <li>if the moduleDefRef start with "/"</li>
     * <li>if the moduleDefRef ends with "/"</li>
     * </ul>
     */
    @PublishedMethod
    public static DefRef create(final IDefRefWildcard packageWildcard, final String moduleDefRef) {
        return new DefRef(packageWildcard, moduleDefRef);
    }

    /**
     * Constructs a definition ref by a definition ref string and a {@link IDefRefWildcard wildcard} of the packages. The defRef String must be absolute, and the definition must
     * be a child of the module definition
     *
     * @param packageWildcard The wildcard for the Package definition. E.g. {@link EDefRefWildcard#ANY}
     * @param moduleDefRef The definition ref string starting at the module. E.g. Nm/NmGlobalConfig
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the packageWildcard is null</li>
     * <li>if the moduleDefRef is null</li>
     * <li>if the moduleDefRef is empty</li>
     * <li>if the moduleDefRef start with "/"</li>
     * <li>if the moduleDefRef ends with "/"</li>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> create(
            final IDefRefWildcard packageWildcard, final String moduleDefRef, final Class<DEF_TYPE> modelDefinitionClass, final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass) {

        return new TypedDefRef<>(packageWildcard, moduleDefRef, modelDefinitionClass, modelConfigClass, valueClass, null);
    }

    /**
     * Constructs a definition ref by a definition ref string and a {@link IDefRefWildcard wildcard} of the packages. The defRef String must be absolute, and the definition must
     * be a child of the module definition
     *
     * @param packageWildcard The wildcard for the Package definition. E.g. {@link EDefRefWildcard#ANY}
     * @param moduleDefRef The definition ref string starting at the module. E.g. Nm/NmGlobalConfig
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     * @param additionalInfos Specifies additional type information of the {@link TypedDefRef}
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the packageWildcard is null</li>
     * <li>if the moduleDefRef is null</li>
     * <li>if the moduleDefRef is empty</li>
     * <li>if the moduleDefRef start with "/"</li>
     * <li>if the moduleDefRef ends with "/"</li>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * <li>if the additionalInfos is null</li>
     * </ul>
     */
    @PublishedMethod
    public static <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> create(
            final IDefRefWildcard packageWildcard, final String moduleDefRef, final Class<DEF_TYPE> modelDefinitionClass, final Class<CONFIG_TYPE> modelConfigClass,
            final Class<VALUE_TYPE> valueClass,
            final TypeInfo additionalInfos) {
        if (additionalInfos == null) {
            throw new IllegalArgumentException("additionalInfos is null.");
        }

        return new TypedDefRef<>(packageWildcard, moduleDefRef, modelDefinitionClass, modelConfigClass, valueClass, additionalInfos);
    }

    /*
     * ---------------------------------------------------------------------------------------------
     * Model Object Constructors
     * ---------------------------------------------------------------------------------------------
     */

    /**
     * Constructs a definition ref by a definition ref string. The defRef String must be absolute. Please use {@link DefRef#create(String, String)} instead!
     *
     * <p>
     * <b>Attention:</b> When you construct a DefRef with this constructor, methods which need the packagePart, throw an {@link IllegalStateException} when they are called.
     * Please use {@link DefRef#create(String, String)} instead.
     * </p>
     *
     * @param defRefString The definition ref string
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is null</li>
     * <li>if the defRef is empty</li>
     * <li>if the defRef is not an absolute definition ref</li>
     * </ul>
     */
    @PublishedMethod
    @Deprecated
    public static DefRef create(final String defRefString) {
        return new DefRef(defRefString);
    }

    /**
     * Constructs a {@link DefRef} object the passed String. The defRef String must be absolute and a existing path to a ModuleDefintion.
     *
     * <p>
     * Note: The moduleDefRefString could also contain a {@link EDefRefWildcard}.
     * </p>
     *
     * <p>
     * <b>Attention:</b> When you construct a DefRef and the corresponding ModuleDefinition does not exist an {@link IllegalArgumentException} is thrown.
     * </p>
     *
     * @param moduleDefRefString The definition ref string of the module
     * @param projectContext The {@link IProjectContext}
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is null</li>
     * <li>if the defRef is empty</li>
     * <li>if the defRef is not an absolute definition ref</li>
     * <li>if the defRef is not a DefRef of a ModuleDefintion</li>
     * </ul>
     */
    @PublishedMethod
    public static TypedDefRef<MIModuleDef, MIModuleConfiguration, Void> createModuleDefRefFromString(final String moduleDefRefString, final IProjectContext projectContext) {

        final TypedDefRef<MIModuleDef, MIModuleConfiguration, Void> defRef = createModuleDefRefFromStringDoNotCheckHasValidDefinitionUnsafe(moduleDefRefString);

        final List<MIModuleDef> possibleModuleDefs = defRef.getPossibleDefinitionsForDefRefWithWildcard(projectContext);

        if (possibleModuleDefs.isEmpty()) {
            throw new IllegalArgumentException("The passed string" + moduleDefRefString + " is no ModuleDefinition DefRef, because there is no Module matching on the DefRef");
        }

        if (possibleModuleDefs.size() == 1 && !MIModuleDef.class.isInstance(possibleModuleDefs.get(0))) {
            throw new IllegalArgumentException("The passed string" + moduleDefRefString + " is no ModuleDefinition. Definion:"
                    + ModelAccessUtil.toDebugStringMDFObject(possibleModuleDefs.get(0)));
        }

        return defRef;
    }

    /**
     * Constructs a {@link DefRef} object the passed String. The defRef String must be an absolute path to a ModuleDefintion.
     *
     * <p>
     * Note: The moduleDefRefString could also contain a {@link EDefRefWildcard}.
     * </p>
     *
     *
     * @param moduleDefRefString The definition ref string of the module
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is null</li>
     * <li>if the defRef is empty</li>
     * </ul>
     */
    @KeepSecretFromPublishedApi
    public static TypedDefRef<MIModuleDef, MIModuleConfiguration, Void> createModuleDefRefFromStringDoNotCheckHasValidDefinitionUnsafe(final String moduleDefRefString) {
        if (moduleDefRefString == null) {
            throw new IllegalArgumentException("moduleDefRefString is null.");
        }
        if (moduleDefRefString.isEmpty()) {
            throw new IllegalArgumentException("moduleDefRefString is empty");
        }

        final String msn = AutosarUtil.getLastShortname(moduleDefRefString);
        final String packageStr = AutosarUtil.getPathWithoutLastShortname(moduleDefRefString);

        if (msn == null) {
            throw new IllegalArgumentException("msn is null.");
        }
        if (msn.isEmpty()) {
            throw new IllegalArgumentException("msn is empty");
        }

        if (packageStr == null) {
            throw new IllegalArgumentException("packageStr is null.");
        }
        if (packageStr.isEmpty()) {
            throw new IllegalArgumentException("packageStr is empty");
        }

        final TypedDefRef<MIModuleDef, MIModuleConfiguration, Void> defRef = create(packageStr, msn, MIModuleDef.class, MIModuleConfiguration.class, Void.class);

        return defRef;
    }

    /*
     * ---------------------------------------------------------------------------------------------
     * String Constructors
     * ---------------------------------------------------------------------------------------------
     */

    /**
     * Constructs a definition ref by a definition ref string and the definition ref of the packages. The defRef String must be absolute, and the definition must be a child of
     * the module definition
     *
     *
     *
     * @param packagesPartOfDefRef The first part of the defRef with the packages e.g. /MICROSAR/Can_CanoeemuCanoe, but without the module.
     * @param defRefWithoutPackagesLoc The definition ref string starting at the module e.g. Nm/NmGlobalConfig
     * @param wholeDefRefString the Concatenated defRef string of both DefRef. This is for performance and memory footprint. This can be null.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the packagesPartOfDefRef is null</li>
     * <li>if the moduleDefRef is null</li>
     * <li>if the packagesPartOfDefRef is empty</li>
     * <li>if the moduleDefRef is empty</li>
     * <li>if the packagesPartOfDefRef is not an absolute definition ref</li>
     * <li>if the moduleDefRef start with "/"</li>
     * <li>if the packagesPartOfDefRef ends with "/"</li>
     * <li>if the moduleDefRef ends with "/"</li>
     * </ul>
     */
    DefRef(String packagesPartOfDefRef, String defRefWithoutPackagesLoc, @Nullable String wholeDefRefString) {

        if (logger.isTraceEnabled()) {
            trace("DefRef(String, String)", "called with ({0};{1})", packagesPartOfDefRef, defRefWithoutPackagesLoc);
        }

        if (packagesPartOfDefRef == null) {
            throw new IllegalArgumentException("packagesPartOfDefinition is null");
        }
        if (defRefWithoutPackagesLoc == null) {
            throw new IllegalArgumentException("moduleDefRef is null");
        }
        if (packagesPartOfDefRef.isEmpty()) {
            throw new IllegalArgumentException("packagesPartOfDefinition is empty");
        }
        if (defRefWithoutPackagesLoc.isEmpty()) {
            throw new IllegalArgumentException("moduleDefRef is empty");
        }

        defRefWithoutPackagesLoc = defRefWithoutPackagesLoc.trim();
        packagesPartOfDefRef = packagesPartOfDefRef.trim();

        if (!packagesPartOfDefRef.startsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The packagesPartOfDefinition ({0}) is not absolute. The packagesPartOfDefinition must start with a \"/\".",
                    packagesPartOfDefRef));
        }
        if (packagesPartOfDefRef.endsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The packagesPartOfDefinition ({0}) ends with a \"/\". The package defintion shall not end with a Seperator.",
                    packagesPartOfDefRef));
        }

        if (defRefWithoutPackagesLoc.startsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The moduleDefRef ({0}) is absolute. The module defRef  shall not start with a \"/\".",
                    defRefWithoutPackagesLoc));
        }
        if (defRefWithoutPackagesLoc.endsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The moduleDefRef ({0}) ends with a \"/\". The module defRef shall not end with a Seperator.",
                    defRefWithoutPackagesLoc));
        }

        this.packagesPart = StringCache.INSTANCE.getUniqueString(packagesPartOfDefRef);
        this.defRefWithoutPackages = StringCache.INSTANCE.getUniqueString(defRefWithoutPackagesLoc);
        this.wildcard = EDefRefWildcard.getWildcardByString(packagesPartOfDefRef);
        if (logger.isTraceEnabled()) {
            trace("DefRef(String, String)", "DefRef created PackagePart:({0}) DefRef:({1}).", packagesPart, defRefWithoutPackages);
        }
        this.wholeDefRefString = wholeDefRefString;
    }

    /**
     * Constructs a definition ref by a definition ref string and a {@link IDefRefWildcard wildcard} of the packages. The defRef String must be absolute, and the definition must
     * be a child of the module definition
     *
     * @param packageWildcard The wildcard for the Package definition. E.g. {@link EDefRefWildcard#ANY}
     * @param moduleDefRef The definition ref string starting at the module e.g. Nm/NmGlobalConfig
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the packageWildcard is null</li>
     * <li>if the moduleDefRef is null</li>
     * <li>if the moduleDefRef is empty</li>
     * <li>if the moduleDefRef start with "/"</li>
     * <li>if the moduleDefRef ends with "/"</li>
     * </ul>
     */
    DefRef(final IDefRefWildcard packageWildcard, String moduleDefRef) {
        if (logger.isTraceEnabled()) {
            trace("DefRef(IDefRefWildcard, String)", "called with ({0};{1})", packageWildcard, moduleDefRef);
        }
        if (packageWildcard == null) {
            throw new IllegalArgumentException("packageWildcard is null");
        }
        if (moduleDefRef == null) {
            throw new IllegalArgumentException("moduleDefRef is null");
        }
        if (moduleDefRef.isEmpty()) {
            throw new IllegalArgumentException("moduleDefRef is empty");
        }

        moduleDefRef = moduleDefRef.trim();

        if (moduleDefRef.startsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The moduleDefRef ({0}) is absolute. The module defRef  shall not start with a \"/\".", moduleDefRef));
        }
        if (moduleDefRef.endsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The moduleDefRef ({0}) ends with a \"/\". The module defRef shall not end with a Seperator.", moduleDefRef));
        }

        if (packageWildcard.getWildcardString() == null || packageWildcard.getWildcardString().isEmpty()) {
            throw new IllegalArgumentException("The wildcard does not return an WildcardString. " + packageWildcard);
        }

        this.packagesPart = StringCache.INSTANCE.getUniqueString(packageWildcard.getWildcardString());
        this.defRefWithoutPackages = StringCache.INSTANCE.getUniqueString(moduleDefRef);
        this.wildcard = packageWildcard;

        if (logger.isTraceEnabled()) {
            trace("DefRef(String, String)", "DefRef created Wildcard:({0}) DefRef:({1}).", packageWildcard, defRefWithoutPackages);
        }
    }

    /**
     * Constructs a definition ref by a definition ref string. The defRef String must be absolute.
     *
     * <p>
     * <b>Attention:</b> When you construct a DefRef with this constructor, methods which need the packages, throw an {@link IllegalStateException} when they are called. Please
     * use {@link DefRef#DefRef(String, String)} instead.
     * </p>
     *
     * @param defRef The definition ref string
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the defRef is null</li>
     * <li>if the defRef is empty</li>
     * <li>if the defRef is not an absolute definition ref</li>
     * <li>if the defRef ends with '/'</li>
     * </ul>
     */
    private DefRef(String defRef) {
        if (logger.isTraceEnabled()) {
            trace("DefRef(String defRef)", "called with ({0})", defRef);
        }

        if (defRef == null) {
            throw new IllegalArgumentException("defRef is null");
        }
        if (defRef.isEmpty()) {
            throw new IllegalArgumentException("defRef is Empty");
        }

        defRef = defRef.trim();

        if (!defRef.startsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The defRef ({0}) is not absolute. The defRef must start with a \"/\".", defRef));
        }
        if (defRef.endsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The defRef ({0}) ends with a \"/\". The defRef shall not end with a Seperator.", defRef));
        }

        final IDefRefWildcard wildcardLoc = EDefRefWildcard.startsWithWildcard(defRef);

        if (wildcardLoc != null) {

            this.packagesPart = StringCache.INSTANCE.getUniqueString(wildcardLoc.getWildcardString());
            this.defRefWithoutPackages = StringCache.INSTANCE.getUniqueString(stripLeadingSeperator(defRef.substring(packagesPart.length(), defRef.length())));
            this.wildcard = wildcardLoc;

        } else {
            // No wildcard information for the DefRef and also no package information
            this.packagesPart = null;
            this.defRefWithoutPackages = StringCache.INSTANCE.getUniqueString(defRef);
            this.wholeDefRefString = this.defRefWithoutPackages;
            this.wildcard = null;

        }

        if (logger.isTraceEnabled()) {
            trace("DefRef(String defRef)", "DefRef created PackagePart:({0}) DefRef:({1}).", this.packagesPart, this.toString());
        }
    }

    /**
     * Constructor for DefRef.
     *
     * @param checkNotNull
     */
    DefRef(final DefRef other) {
        if (logger.isTraceEnabled()) {
            trace("DefRef(DefRef other)", "called with ({0})", other);
        }

        if (other.hasWildcards()) {
            this.wildcard = other.wildcard;
            this.packagesPart = StringCache.INSTANCE.getUniqueString(other.wildcard.getWildcardString());
        } else {
            this.packagesPart = StringCache.INSTANCE.getUniqueString(other.packagesPart);
            this.wildcard = null;
        }

        this.defRefWithoutPackages = StringCache.INSTANCE.getUniqueString(other.defRefWithoutPackages);

        if (logger.isTraceEnabled()) {
            trace("DefRef(DefRef defRef)", "DefRef created PackagePart:({0}) DefRef:({1}).", this.packagesPart, this.toString());
        }
    }

    /*
     * ---------------------------------------------------------------------------------------------
     * Private static methods
     * ---------------------------------------------------------------------------------------------
     */

    static String stripLeadingSeperator(String str) {
        if (str.startsWith(SEPARATOR)) {
            str = str.substring(1, str.length());
        }
        return str;
    }

    private static void ensureThatDefRefHasPackageInfo(final DefRef defRef) {
        if (!defRef.hasPackageInfo()) {
            throw new IllegalStateException(
                    MessageFormat
                            .format("You can not access this method, because the DefRef object ({0}) was created without an PackagePart information. To used this method you have to create the DefRef Object with PackagePart information. See DefRef.create(String,String).",
                                    defRef));
        }
    }

    private static String calculatePathOfChildFromParentDefRef(DefRef parentDefRefObj, String defRef) {
        if (parentDefRefObj == null) {
            throw new IllegalArgumentException("parentDefRefObj is null.");
        }
        if (defRef == null) {
            throw new IllegalArgumentException("defRef is null");
        }
        if (defRef.isEmpty()) {
            throw new IllegalArgumentException("defRef is empty");
        }

        if (defRef.endsWith(SEPARATOR)) {
            throw new IllegalArgumentException(MessageFormat.format("The defRef ({0}) ends with a \"/\". The definition ref shall not end with a Seperator.", defRef));
        }

        final String parentDefRefString = parentDefRefObj.getDefRefString();

        final String newDefRef;

        if (defRef.startsWith(SEPARATOR)) {
            // It is a Absolute path
            // check if the the parentObj is really a parent
            if (defRef.startsWith(parentDefRefString + SEPARATOR)) {
                newDefRef = defRef.substring(parentDefRefObj.packagesPart.length() + 1, defRef.length());
            } else {
                throw new IllegalArgumentException(MessageFormat.format(
                        "The defRef ({0}) is an absolute definition ref but does not start with parentDefRef({1}). The defRef must be a child of the moduleDefPath.", defRef,
                        parentDefRefString));
            }

        } else {
            // it is a relative path

            // Check if it is relative but it starts with the module
            final String parentDefRefWithoutPack = parentDefRefObj.defRefWithoutPackages;
            if (parentDefRefWithoutPack != null && defRef.startsWith(parentDefRefWithoutPack + SEPARATOR)) {
                // Stip the module part from new DefRef
                final String tempDef = defRef.substring(parentDefRefWithoutPack.length() + 1, defRef.length());
                newDefRef = parentDefRefWithoutPack + SEPARATOR + tempDef;

            } else {

                // It is full relative so add to whole defref
                newDefRef = parentDefRefWithoutPack + SEPARATOR + defRef;
            }
        }
        return newDefRef;
    }

    /*
     * ---------------------------------------------------------------------------------------------
     * Public methods
     * ---------------------------------------------------------------------------------------------
     */

    /**
     * Checks, if this defRef object has package information.
     *
     * @return true, if successful
     */
    @PublishedMethod
    public boolean hasPackageInfo() {
        if (this.packagesPart != null) {
            return true;
        }
        return false;
    }

    /**
     * Checks if <code>this</code> definition is a child or indirect child of the passed indirectParents definition.
     *
     * @param indirectParent The presumable parent of this
     * @return <code>true</code>, if this is a child of <code>indirectParent</code>.
     */
    @PublishedMethod
    public boolean isChildOf(final MIHasDefinition indirectParent) {
        //Please consider to change the semantics of checkIsChildOf() if you change something here
        final DefRef defRefParent = DefRef.create(indirectParent);
        final DefRef indirectChildDefRef = this;
        final DefRef parentDefRefWithChildPackage = defRefParent.getDefRefWithNewPackage(indirectChildDefRef);
        if (!parentDefRefWithChildPackage.isDefinitionOf(indirectParent)) {
            return false;
        }
        if (!parentDefRefWithChildPackage.isParentOf(indirectChildDefRef)) {
            return false;
        }
        return true;
    }

    /**
     * Checks if <code>this</code> definition is a child or indirect child of the passed indirectParents definition.
     *
     * @param indirectParent The presumable parent of this
     * @exception IllegalArgumentException this DefRef is not an indirect child of the passed indirectParent.
     */
    @PublishedMethod
    public void checkIsChildOf(final MIHasDefinition indirectParent) {
        //Please consider to change the semantics of isChildOf() if you change something here
        final DefRef defRefParent = DefRef.create(indirectParent);
        final DefRef indirectChildDefRef = this;
        final DefRef parentDefRefWithChildPackage = defRefParent.getDefRefWithNewPackage(indirectChildDefRef);
        if (!parentDefRefWithChildPackage.isDefinitionOf(indirectParent)) {
            throw new IllegalArgumentException(
                    "The package of this ChildDefRef is not a matching refinded package of indirectParent's instance:" +
                            "\r\nChildDefRef: " + indirectChildDefRef +
                            "\r\nDefRefOfParentInstance: " + defRefParent +
                            "\r\nParentDefRef with child package: " + parentDefRefWithChildPackage +
                            "\r\nParent MDF instance: " + indirectParent);
        }
        if (!parentDefRefWithChildPackage.isParentOf(indirectChildDefRef)) {
            throw new IllegalArgumentException("This ChildDefRef is not child of the indirectParent's DefRef:" +
                    "\r\nChildDefRef: " + indirectChildDefRef +
                    "\r\nDefRefOfParentInstance: " + defRefParent +
                    "\r\nParentDefRef with child package: " + parentDefRefWithChildPackage +
                    "\r\nParent MDF instance: " + indirectParent);
        }
        // All Valid
    }

    /**
     * Checks if <code>this</code> object is parent of the passed DefRef.
     *
     * @param presumableChild The child DefRef
     * @return <code>true</code>, if the parameter is a child of <code>this</code>.
     *
     * @see AutosarUtil#isParentPath(String, String)
     */
    @PublishedMethod
    public boolean isParentOf(final DefRef presumableChild) {

        if (presumableChild == null) {
            throw new IllegalArgumentException("presumableChild is null");
        }

        if (this.hasWildcards() || presumableChild.hasWildcards()) {
            /*
             * Ignore the packages when one of the object has wildcards enabled for the first comparison
             */
            final boolean result = AutosarUtil.isParentPath(this.getDefRefStringWithoutPackagePart(), presumableChild.getDefRefStringWithoutPackagePart());

            if (!result) {
                // The presumableChild can't be a child of this, because the second path does not match
                return false;
            }

            /*
             * Check the wildcards
             */
            if (wildcardMatches(presumableChild)) {
                return true;
            }

            /*
             * Wildcard have no match
             */
            return false;
        }

        /*
         * the two DefRefs are both DefRef without wildcards, so make an comparison of the whole string
         */
        if (this.hasPackageInfo() && presumableChild.hasPackageInfo()) {
            if (AutosarUtil.isParentPath(this.getDefRefStringWithoutPackagePart(), presumableChild.getDefRefStringWithoutPackagePart())) {

                if (this.getPackagePartOfDefRefString().equals(presumableChild.getPackagePartOfDefRefString())) {
                    return true;
                }

            }
            return false;

        } else {
            return AutosarUtil.isParentPath(this.getDefRefString(), presumableChild.getDefRefString());
        }

    }

    /**
     * Checks if <code>this</code> object is parent of the passed DefRef, ignoring packages.
     *
     * @param presumableChild The child DefRef
     * @return <code>true</code>, if the parameter is a child of <code>this</code>.
     *
     * @see AutosarUtil#isParentPath(String, String)
     */
    @KeepSecretFromPublishedApi
    public boolean isParentOfIgnoringPackages(final DefRef presumableChild) {
        return AutosarUtil.isParentPath(this.getDefRefStringWithoutPackagePart(), presumableChild.getDefRefStringWithoutPackagePart());
    }

    /**
     * Checks if <code>this</code> object is the immediate parent of the passed DefRef.
     *
     * @param presumableChild The child DefRef
     * @return <code>true</code>, if the parameter is a immediate child of <code>this</code>.
     *
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the presumableChild is null</li>
     * </ul>
     */
    @PublishedMethod
    public boolean isImmediateParentOf(final DefRef presumableChild) {

        if (presumableChild == null) {
            throw new IllegalArgumentException("Parameter presumableChild is null");
        }

        if (presumableChild.getParentDefRef().equals(this)) {
            return true;
        }
        return false;
    }

    /**
     * Checks if <code>this</code> object is the immediate parent of the passed DefRef, ignoring packages.
     *
     * @param presumableChild The child DefRef
     * @return <code>true</code>, if the parameter is a immediate child of <code>this</code>.
     *
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the presumableChild is null</li>
     * </ul>
     */
    @KeepSecretFromPublishedApi
    public boolean isImmediateParentOfIgnoringPackages(final DefRef presumableChild) {
        checkNotNull(presumableChild);

        if (presumableChild.getParentDefRef().getDefRefStringWithoutPackagePart().equals(this.getDefRefStringWithoutPackagePart())) {
            return true;
        }
        return false;
    }

    /**
     * Checks if <code>this</code> object is the definition of the passed modelObject.
     *
     * <p>
     * Note: This method tests also refinements. So, if the modelObject is refined of this definition, it will also yield to true.
     * </p>
     *
     * <p>
     * Note: This method is an implicit null and {@link MIHasDefinition} check. This means, if it returns true, the modelObject is an instance of {@link MIHasDefinition}.
     * </p>
     *
     * <p>
     * The method will return <code>false</code>, if the passed modelObject is removed. The method will return <code>false</code>, if the passed modelObject is invisible.
     * </p>
     *
     * @param modelObject The modelObject to check.
     * @return <code>true</code>, if this is the definition of the modelObject and is visible and not removed.
     *
     */
    @PublishedMethod
    public boolean isDefinitionOf(final MIObject modelObject) {

        return isDefinitionOfInternal(modelObject);
    }

    /**
     * Checks if <code>this</code> object is the definition of the passed DefRef object.
     *
     * <p>
     * Note: This method tests also refinements. So, if the presumableDefRef is refined of this definition, it will also yield to true.
     * </p>
     *
     * <p>
     * Note: This method is an implicit null. This means, if it returns true, the presumableDefRef is an instance of {@link DefRef}.
     * </p>
     *
     *
     * @param presumableDefRef The DefRef to check.
     * @param maToTestRefinements the {@link IModelAccess} to check refinements
     * @return <code>true</code>, if this DefRef is equal to presumableDefRef or it is a refinement of this.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the maToTestRefinements is null</li>
     * </ul>
     *
     */
    @PublishedMethod
    public boolean isDefinitionOf(final DefRef presumableDefRef, final IModelAccess maToTestRefinements) {

        if (maToTestRefinements == null) {
            throw new IllegalArgumentException("maToTestRefinements is null");
        }

        if (presumableDefRef != null) {

            if (this.equals(presumableDefRef)) {
                return true;
            }

            if (this.hasPackageInfo() && presumableDefRef.hasPackageInfo() && !this.equalsWithoutPackages(presumableDefRef)) {
                return false;
            }

            if (presumableDefRef.isRefinedOf(this, maToTestRefinements)) {
                return true;
            }

        }
        return false;
    }

    @PublishedMethod
    protected boolean isDefinitionOfInternal(final MIObject modelObject) {

        if (modelObject instanceof MIHasDefinition) {

            if (ModelAccessUtil.isRemovedOrInvisible(modelObject)) {
                /*
                 * Invisible and removed modelObject have "no" definition, because this shall guard the client code from using these elements.
                 *
                 * EVAL00124298:DefRef.isDefinitionOf() returns true on invisible invisible obj since rework that Definitions of Invisible obj are createable
                 */
                return false;
            }

            final DefRef objDef = DefRef.tryCreate((MIHasDefinition) modelObject);
            if (objDef != null) {

                if (this.equals(objDef)) {
                    return true;
                }

                if (this.hasPackageInfo() && objDef.hasPackageInfo() && !this.equalsWithoutPackages(objDef)) {
                    return false;
                }

                // Check refinements
                final IModelAccess ma = ModelUtil.getModelAccess(modelObject);

                if (objDef.isRefinedOf(this, ma)) {
                    return true;
                }

            }
        }

        return false;
    }

    /**
     * Checks if <code>this</code> object is the definition of the passed modelObject and an instance of classToCheck.
     *
     *
     * <p>
     * Note: This method tests also refinements. So, if the modelObject is refined of this definition, it will also yield to true.
     * </p>
     *
     * <p>
     * Note: This method is an implicit null and classToCheck class check. This means, if it returns true, the modelObject is an instance of classToCheck.
     * </p>
     *
     * <p>
     * The method will return <code>false</code>, if the passed modelObject is removed. The method will return <code>false</code>, if the passed modelObject is invisible.
     * </p>
     *
     *
     * @param modelObject The modelObject to check.
     * @param classToCheck The class which the modelObject must be an instance of.
     * @return <code>true</code>, if this is the definition of the modelObject and it is instance of classToCheck.
     * @see #isDefinitionOf(MIObject)
     *
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the classToCheck is null</li>
     * </ul>
     */
    @PublishedMethod
    public boolean isDefinitionOf(final MIObject modelObject, final Class<? extends MIHasDefinition> classToCheck) {

        return isDefinitionOfInternal(modelObject, classToCheck);
    }

    @PublishedMethod
    protected boolean isDefinitionOfInternal(final MIObject modelObject, final Class<? extends MIHasDefinition> classToCheck) {
        if (classToCheck == null) {
            throw new IllegalArgumentException("classToCheck is null.");
        }
        /*
         * Check Definition
         */
        if (!isDefinitionOfInternal(modelObject)) {
            return false;
        }

        if (classToCheck.isInstance(modelObject)) {
            return true;
        }
        return false;
    }

    /**
     * Checks if <code>this</code> object is the definition of the passed modelObject and an instance of classToCheck. If the check is true, the method returns the object casted
     * to classToCheck. Otherwise the method return <code>null</code>.
     *
     * <p>
     * Note: This method tests also refinements. So, if the modelObject is refined of this definition, it will also yield to true.
     * </p>
     *
     * <p>
     * Note: This method is an implicit null and classToCheck class check. This means, if it returns true, the modelObject is an instance of classToCheck.
     * </p>
     *
     * <p>
     * The method will return <code>null</code>, if the passed modelObject is removed. The method will return <code>null</code>, if the passed modelObject is invisible.
     * </p>
     *
     *
     * @param modelObject The modelObject to check.
     * @param classToCheck The class which the modelObject must be an instance of.
     * @return <code>object</code>, if this is the definition of the modelObject and it is instance of classToCheck. Otherwise null.
     * @see #isDefinitionOf(MIObject, Class)
     *
     * @exception NullPointerException
     * <ul>
     * <li>if the classToCheck is null</li>
     * </ul>
     */
    @PublishedMethod
    public <T extends MIHasDefinition> T asDefinitionOf(final MIObject modelObject, final Class<T> classToCheck) {

        return asDefinitionOfInternal(modelObject, classToCheck);
    }

    @PublishedMethod
    @SuppressWarnings("unchecked")
    protected <T extends MIHasDefinition> T asDefinitionOfInternal(final MIObject modelObject, final Class<T> classToCheck) {

        checkNotNull(classToCheck);
        /*
         * Check Definition and class
         */
        if (!isDefinitionOfInternal(modelObject, classToCheck)) {
            return null;
        }
        /*
         * Cast element
         */
        return (T) modelObject;
    }

    /**
     * Checks if <code>this</code> object is a refined definition of the passed DefRef.
     *
     * @param presumableParentDefinition The DefRef
     * @param modelAccess The modelAccess corresponding to the definition refs
     * @return <code>true</code>, if <code>this</code> refines the passed Definition
     *
     * @see IModelAccess#isRefinedModuleDefinition(String, DefRef)
     */
    @PublishedMethod
    public boolean isRefinedOf(final DefRef presumableParentDefinition, final IModelAccess modelAccess) {
        if (this.hasWildcards()) {
            // The asked refinement has a wildcard. A wildcard could never be refined
            return false;
        }
        if (this.getDefRefStringWithoutModuleDef().equals(presumableParentDefinition.getDefRefStringWithoutModuleDef())) {
            final boolean result = modelAccess.isRefinedModuleDefinition(this.getModuleDefRefString(), presumableParentDefinition.getModuleDefinitionDefRef());
            if (result) {
                return true;
            }
        }
        return false;
    }

    /**
     * Returns true, if the equals and hash code methods will used wildcards to evaluate the information.
     *
     * @return
     */
    @PublishedMethod
    public boolean hasWildcards() {
        return wildcard != null;
    }

    /**
     * Returns the {@link IDefRefWildcard} instance of this {@link DefRef}.
     *
     * @return
     * @exception IllegalStateException
     * <ul>
     * <li>if the DefRef has no Wildcard</li>
     * </ul>
     */
    @PublishedMethod
    public IDefRefWildcard getDefRefWildcard() {
        checkState(hasWildcards());
        return wildcard;
    }

    /**
     * Returns the absolute definition ref in string representation.
     *
     * <p>
     * Attention: Do not use toString to retrieve the DefinitionRef string from a defRef object. Wildcard representations a returned.
     * </p>
     *
     * @return The DefRef representation
     */
    @PublishedMethod
    @Override
    public String toString() {
        return "DefinitionRef: " + getDefRefString();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public int hashCode() {
        ensureThatDefRefHasPackageInfo(this);
        return defRefWithoutPackages.hashCode();
    }

    /**
     * <p>
     * <b>Attention:</b> Depending on the involved objects, the packages are ignored or not. When one {@link DefRef} object has {@link #hasWildcards()} enabled, then the
     * packages are ignored.
     * </p>
     *
     * <p>
     * Caution: Refinement of the AUTOSAR definitions are not considered in the {@link DefRef#equals(Object)} methods! So if this DefRef is refined of other DefRef, the method
     * will still return <code>false</code>.
     * </p>
     *
     *
     * <p>
     * Note: The {@link #INVALID_DEFREF} is equal to nothing also not to itself. This shall prevent from false Map lookups.
     * </p>
     *
     * {@inheritDoc}
     *
     */
    @PublishedMethod
    @Override
    public boolean equals(final Object obj) {

        if (checkForInvalidDefRef(obj)) {
            return false;
        }

        if (this == obj) {
            return true;
        }

        if (obj == null) {
            return false;
        }

        if (obj instanceof DefRef) {
            final DefRef otherDef = (DefRef) obj;

            if (!hasWildcards() && !otherDef.hasWildcards()) {

                return equalsExactInternal(otherDef);
            } else {

                return equalsWithWildcardInternal(otherDef);

            }
        }

        return false;
    }

    /**
     * Will return true, if one of the two elements (this, other) is the INVALID_DEFREF.
     *
     * @param other the other DefRef
     * @return
     */
    private boolean checkForInvalidDefRef(final Object other) {

        if (this == INVALID_DEFREF) {
            return true;
        }

        if (other == INVALID_DEFREF) {
            return true;
        }
        return false;
    }

    /**
     * Checks if the DefRef is equal to the passed DefRef.
     *
     * <p>
     * No Package information is ignore, also the /AUTOSAR package is used in equals!
     * </p>
     *
     * <p>
     * Caution: Refinement of the AUTOSAR definitions are not considered in the {@link DefRef#equalsExact(DefRef)} methods! So if this DefRef is refined of other DefRef, the
     * method will still return <code>false</code>.
     * </p>
     *
     * @param defRefString The compare object
     * @return <code>true</code>, if the definition refs are equal.
     */
    @PublishedMethod
    public boolean equalsExact(final DefRef objdefRef) {

        if (checkForInvalidDefRef(objdefRef)) {
            return false;
        }

        if ((this == objdefRef)) {
            return true;
        }

        if (objdefRef == null) {
            return false;
        }

        if (this.hasWildcards() != objdefRef.hasWildcards()) {
            // An exact match, when one of the defRefs has a wildcard, is not possible
            return false;
        }

        return equalsExactInternal(objdefRef);
    }

    private boolean equalsExactInternal(final DefRef objdefRef) {
        /*
         * We can't use the == operator to compare the strings
         */
        if (hasPackageInfo()) {
            if (objdefRef.getDefRefStringWithoutPackagePart().equals(this.getDefRefStringWithoutPackagePart())) {
                if (objdefRef.getPackagePartOfDefRefString().equals(this.getPackagePartOfDefRefString())) {
                    return true;
                }
            }
        } else {
            if (objdefRef.getDefRefString().equals(this.getDefRefString())) {
                return true;
            }
        }

        return false;
    }

    /**
     * Returns the hash code of the definition ref string without the packages.
     *
     * <p>
     * If the defRefWithoutPackages is null, 0 is returned.
     * </p>
     *
     * @return the hash code
     */
    @PublishedMethod
    public int hashCodeWithoutPackages() {
        if (defRefWithoutPackages == null) {
            return 0;
        }
        return defRefWithoutPackages.hashCode();
    }

    /**
     * Returns the hash code of the package of the definition ref string.
     *
     * <p>
     * If the packagePart is null, 0 is returned.
     * </p>
     *
     * @return the hash code
     */
    @PublishedMethod
    public int hashCodeOfPackagePart() {
        if (packagesPart == null) {
            return 0;
        }

        return packagesPart.hashCode();
    }

    /**
     * Checks if the DefRef is equal to the passed DefRef.
     *
     * <p>
     * Caution: Refinement of the AUTOSAR definitions are not considered in the {@link DefRef#equalsWithoutPackages(DefRef)} methods! So if this DefRef is refined of other
     * DefRef, the method will still return <code>false</code>.
     * </p>
     *
     * @param defRefString The compare object
     * @return <code>true</code>, if the definition refs are equal.
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if no packagePart was specified during construction</li>
     * </ul>
     */
    @PublishedMethod
    public boolean equalsWithoutPackages(final DefRef objdefRef) {

        if (checkForInvalidDefRef(objdefRef)) {
            return false;
        }

        if ((this == objdefRef)) {
            return true;
        }

        if (objdefRef == null) {
            return false;
        }

        ensureThatDefRefHasPackageInfo(objdefRef);

        ensureThatDefRefHasPackageInfo(this);

        /*
         * We can't use the == operator to compare the strings
         */
        if (objdefRef.defRefWithoutPackages.equals(this.defRefWithoutPackages)) {
            return true;
        }

        return false;
    }

    /**
     * Checks if the DefRef is equal to the passed DefRef.
     *
     * <p>
     * Caution: Refinement of the AUTOSAR definitions are not considered in the {@link DefRef#equalsWithWildcard(DefRef)} methods! So if this DefRef is refined of other DefRef,
     * the method will still return <code>false</code>.
     * </p>
     *
     * @param defRefString The compare object
     * @return <code>true</code>, if the definition refs are equal.
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if no packagePart was specified during construction</li>
     * </ul>
     */
    @PublishedMethod
    public boolean equalsWithWildcard(final DefRef objdefRef) {
        return equals(objdefRef);
    }

    private boolean equalsWithWildcardInternal(final DefRef objdefRef) {

        ensureThatDefRefHasPackageInfo(objdefRef);

        ensureThatDefRefHasPackageInfo(this);
        /*
         * We can't use the == operator to compare the strings
         */
        if (objdefRef.defRefWithoutPackages.equals(this.defRefWithoutPackages)) {
            // The second part of the DefRef matches
            // Test the wildcards
            if (wildcardMatches(objdefRef)) {
                return true;
            }

        }

        return false;
    }

    /**
     * @param objdefRef
     * @return
     */
    private boolean wildcardMatches(final DefRef otherDefRef) {

        if (this.wildcard != null && otherDefRef.wildcard != null) {
            /*
             * Same Wildcards match
             */
            if (this.wildcard.equals(otherDefRef.wildcard)) {
                return true;

            }

            /*
             * Different Wildcards could not be the same
             */
            return false;

        }

        /*
         * Get wildcard
         */
        final IDefRefWildcard wildcardLoc;
        if (this.wildcard != null) {
            wildcardLoc = this.wildcard;

            return wildcardLoc.matches(otherDefRef);

        } else if (otherDefRef.wildcard != null) {
            wildcardLoc = otherDefRef.wildcard;

            return wildcardLoc.matches(this);
        }

        throw new IllegalStateException("Illegal internal state, because both DefRef objects has no wildcard, but the method wildcardMatches was called");

    }

    /**
     * Returns the absolute definition ref as string.
     *
     * @return The definition ref
     *
     */
    @PublishedMethod
    public String getDefRefString() {
        if (wholeDefRefString == null) {
            buildWholeDefRefString();
        }
        return wholeDefRefString;
    }

    private void buildWholeDefRefString() {
        final StringBuilder builder = new StringBuilder(this.packagesPart.length() + 1 + this.defRefWithoutPackages.length());
        builder.append(this.packagesPart);
        builder.append(SEPARATOR);
        builder.append(this.defRefWithoutPackages);
        wholeDefRefString = StringCache.INSTANCE.getUniqueString(builder.toString());
    }

    /**
     * Returns the MDF definition object.
     *
     * <p>
     * Returns the AUTOSAR definition object if the DefRef has a wildcard. If the passed DefRef is a wildcard DefRef, but has no AUTOSAR definition, the method tries to find one
     * Vendor definition. If one Vendor definition exists, the definition is returned. If none or more then one Definition exist <code>null</code> is returned , see
     * {@link #getPossibleDefinitionsForDefRefWithWildcard(IProjectContext)} for more details.
     * </p>
     *
     * Returns null, if no definition exists.
     *
     * @return The MDF definition object, or null if no definition object exists.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if projectContext is null</li>
     * </ul>
     */
    @PublishedMethod
    public MIParamConfMultiplicity getDefinitionObject(final IProjectContext projectContext) {
        if (projectContext == null) {
            throw new IllegalArgumentException("projectContext is null");
        }
        final List<MIParamConfMultiplicity> defList = projectContext.getService(IDefRefDefinitionCache.class).getDefinitionsByDefRef(this);

        if (defList.size() == 1) {
            // One element found=> This must be the definition
            return defList.get(0);
        }

        // Nothing or too many found for the wildcard element
        return null;
    }

    /**
     * Returns true, if this {@link DefRef} has at least one valid Definition in the MDF model of the passed {@link IProjectContext}.
     *
     * <p>
     * Note: If the {@link DefRef} has wildcard, there must be at least one definition matching the {@link DefRef}.
     * </p>
     *
     * @param projectContext the project context
     * @return true, if there is a Definition
     */
    @PublishedMethod
    public boolean hasValidDefinition(final IProjectContext projectContext) {
        final MIParamConfMultiplicity def = this.getDefinitionObject(projectContext);
        if (def != null) {
            // Definition found check Content
            if (this instanceof TypedDefRef<?, ?, ?>) {
                @SuppressWarnings("unchecked")
                final TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?> typedDefRef = (TypedDefRef<MIParamConfMultiplicity, MIHasDefinition, ?>) this;
                if (!typedDefRef.getModelDefinitionClass().isInstance(def)) {
                    return false;
                }
            }
            return true;
        }

        /*
         * Check if there are multiple Definitions, if true don't report an error
         */
        if (this.getPossibleDefinitionsForDefRefWithWildcard(projectContext).size() > 1) {
            return true;
        }

        return false;
    }

    /**
     * Gets the possible definitions of the DefRef.
     *
     * <p>
     * Attention: This methods returns the AUTOSAR standard definition object, before it returns any other definition. If the passed DefRef is a wildcard DefRef, but has no
     * AUTOSAR definition, the method tries to find any Vendor definition and will return the list of vendor definitions. If the DefRef has an AUTOSAR definition the method will
     * return a list with only the AUTOSAR definition!
     * </p>
     *
     * <p>
     * This DefRef object should have wildcards, otherwise this method makes no sense and returns the definition form {@link #getDefinitionObject(IProjectContext)}.
     * </p>
     *
     *
     *
     * @param projectContext the project context
     * @return the possible definitions for the DefRef
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if projectContext is null</li>
     * </ul>
     *
     */
    @SuppressWarnings("unchecked")
    @PublishedMethod
    public <T extends MIParamConfMultiplicity> List<T> getPossibleDefinitionsForDefRefWithWildcard(final IProjectContext projectContext) {
        if (projectContext == null) {
            throw new IllegalArgumentException("projectContext is null");
        }
        return (List<T>) projectContext.getService(IDefRefDefinitionCache.class).getDefinitionsByDefRef(this);

    }

    /**
     * Returns the definition ref without the packages. The definition ref starts at the module definition.
     *
     * <p>
     * Example: Can/CanConfig
     * </p>
     *
     * @return The defref without packages.
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if no packagePart was specified during construction</li>
     * </ul>
     */
    @PublishedMethod
    public String getDefRefStringWithoutPackagePart() {
        ensureThatDefRefHasPackageInfo(this);

        return defRefWithoutPackages;
    }

    /**
     * Gets the packages of the absolute defRef.
     *
     * <p>
     * Example: defRef is /MICROSAR/Can_CanoeemuCanoe/Can/CanGeneral/CanHardwareCancellation. You will get /MICROSAR/Can_CanoeemuCanoe.
     *
     * @return The PackagePart
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if no packagePart was specified during construction</li>
     * </ul>
     */
    @PublishedMethod
    public String getPackagePartOfDefRefString() {
        ensureThatDefRefHasPackageInfo(this);

        return packagesPart;
    }

    /**
     * Gets a {@link DefRef} object with the moduleDefinition of current defRef, inclusive packageInfo or wildcards.
     *
     * <p>
     * If the this {@link DefRef} is already a ModuleDefinition DefRef, this is returned.
     * </p>
     *
     * <p>
     * Example: The DefRef is /MICROSAR/Can_CanoeemuCanoe/Can/CanGeneral/CanHardwareCancellation. You will get DefRef("/MICROSAR/Can_CanoeemuCanoe","Can").
     * </p>
     *
     * @return New module definition {@link DefRef} object
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if no packagePart was specified during construction</li>
     * </ul>
     */
    @PublishedMethod
    public TypedDefRef<MIModuleDef, MIModuleConfiguration, Void> getModuleDefinitionDefRef() {

        if (moduleDefRef == null) {
            calculateModuleDefinitionDefRef();
            checkState(moduleDefRef != null);
        }

        return moduleDefRef;
    }

    private void calculateModuleDefinitionDefRef() {
        if (!getDefRefStringWithoutPackagePart().contains(SEPARATOR)) {
            //It is already the Module
            if (this instanceof TypedDefRef) {
                final TypedDefRef<?, ?, ?> typedThis = uncheckedCast(this);
                if (typedThis.getModelDefinitionClass() == MIModuleDef.class) {
                    setModuleDefinitionDefRef(uncheckedCast(typedThis));
                    return;
                }
            }
        }

        if (this.parentDefRef != UNINITIALIZED_DEFREF && this.parentDefRef != null) {
            setModuleDefinitionDefRef(this.getParentDefRef().getModuleDefinitionDefRef());
            return;
        }

        final String moduleName = getModuleName();
        if (this.hasWildcards()) {
            setModuleDefinitionDefRef(DefRef.create(this.wildcard, moduleName, MIModuleDef.class, MIModuleConfiguration.class, Void.class));
        } else {
            setModuleDefinitionDefRef(DefRef.create(getPackagePartOfDefRefString(), moduleName, MIModuleDef.class, MIModuleConfiguration.class, Void.class));
        }
    }

    /**
     * Checks if this {@link DefRef} is a module definition {@link DefRef}.
     *
     * @return true, if this is a ModuleDefinition DefRef.
     */
    @PublishedMethod
    public boolean isModuleDefinitionDefRef() {
        if (this.getModuleDefinitionDefRef().equalsExact(this)) {
            return true;
        }
        return false;
    }

    /**
     * Gets the moduleDefinition of the absolute defRef.
     *
     * <p>
     * Example: The DefRef is /MICROSAR/Can_CanoeemuCanoe/Can/CanGeneral/CanHardwareCancellation. You will get /MICROSAR/Can_CanoeemuCanoe/Can.
     * </p>
     *
     * @return The module definition string of this defRef
     *
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if no packagePart was specified during construction</li>
     * </ul>
     */
    @PublishedMethod
    public String getModuleDefRefString() {

        final DefRef moduleDefinitionDefRef = getModuleDefinitionDefRef();
        return moduleDefinitionDefRef.getDefRefString();
    }

    /**
     * @return The moduleDefintion name of the current defref
     */
    private String getModuleName() {
        ensureThatDefRefHasPackageInfo(this);

        final String moduleName = StringUtil.split(getDefRefStringWithoutPackagePart(), SEPARATOR).get(0);
        return moduleName;
    }

    /**
     * Gets the defRef without the moduleDef part, and without an leading '/'.
     *
     * <p>
     * Example: The DefRef is /MICROSAR/Can_CanoeemuCanoe/Can/CanGeneral/CanHardwareCancellation. You will get CanGeneral/CanHardwareCancellation.
     * </p>
     *
     *
     * <p>
     * If the passed DefRef is a ModuleDefRef, the returned {@link String} is empty.
     * </p>
     *
     * @return The striped defRef.
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if no packagePart was specified during construction</li>
     * </ul>
     */
    @PublishedMethod
    public String getDefRefStringWithoutModuleDef() {

        if (defRefWithoutModuleDef == null) {

            ensureThatDefRefHasPackageInfo(this);

            final List<String> list = StringUtil.split(getDefRefStringWithoutPackagePart(), SEPARATOR);

            final StringBuilder builder = new StringBuilder();
            for (int x = 1; x < list.size(); x++) {
                builder.append(SEPARATOR);
                builder.append(list.get(x));
            }
            defRefWithoutModuleDef = stripLeadingSeperator(builder.toString());
        }

        return defRefWithoutModuleDef;
    }

    /**
     * Returns a parent {@link DefRef} object. The last part of this {@link DefRef} object is truncated.
     * <p>
     * Note: This method will not return the hierarchic parent DefRef, see {@link #getParentHierarchicDefRef()}. This means if the hierarchic parent has a different package than
     * this DefRef, this method will construct a new DefRef with the same package as this DefRef, instead of returning the hierarchic parent.
     * </p>
     *
     * @return The parent {@link DefRef}, or <code>null</code>, when there is no parent {@link DefRef}.
     */
    @PublishedMethod
    @Nullable
    public DefRef getParentDefRef() {

        if (parentDefRef == UNINITIALIZED_DEFREF) {
            calculateParentDefRef();
            checkState(parentDefRef != UNINITIALIZED_DEFREF);
        }
        return parentDefRef;
    }

    /**
     * Returns the hierarchic parent {@link DefRef} object. The last part of this {@link DefRef} object is truncated. The main us is to retrieve Class and TypeInformation
     * recursive of the top elements of this DefRef. So when you ask {@link #getParentHierarchicDefRef()} the returned parent will contain TypeInformantion, if they where
     * provided during construction.
     *
     * <p>
     * Note: This method will return the hierarchic parent DefRef, if you want the synthetic parent pleas call {@link #getParentDefRef()}. This means if the hierarchic parent
     * has a different package than this DefRef, this method will return the parent DefRef with the different package, instead of returning the parent with the same package as
     * this DefRef.
     * </p>
     *
     * @return The parent {@link DefRef}, or <code>null</code>, when there is no parent {@link DefRef}.
     */
    @KeepSecretFromPublishedApi
    @Nullable
    public DefRef getParentHierarchicDefRef() {
        if (parentHierarchicDefRef == UNINITIALIZED_DEFREF) {
            return getParentDefRef();
        }
        return parentHierarchicDefRef;
    }

    private void calculateParentDefRef() {
        final String parentString = AutosarUtil.getPathWithoutLastShortname(getDefRefStringWithoutPackagePart());
        if (parentString == null || parentString.isEmpty()) {
            setParentDefRef(null);
            return;
        }

        if (this.hasWildcards()) {
            setParentDefRef(new DefRef(wildcard, parentString));
        } else {
            setParentDefRef(new DefRef(getPackagePartOfDefRefString(), parentString, null));
        }
    }

    private void setModuleDefinitionDefRef(TypedDefRef<MIModuleDef, MIModuleConfiguration, Void> module) {
        checkNotNull(module);
        checkArgument(this.getDefRefStringWithoutPackagePart().startsWith(module.getDefRefStringWithoutPackagePart()));
        synchronized (this) {
            if (moduleDefRef != null) {
                if (moduleDefRef == module) {
                    return;
                }
                if (moduleDefRef.equalsExact(module)) {
                    return;
                }
                throw new IllegalStateException();
            }
            moduleDefRef = module;
        }
    }

    private void setParentHierarchicDefRefIfIsImmediateParent(@Nullable DefRef parent) {

        final String parentString = AutosarUtil.getPathWithoutLastShortname(getDefRefStringWithoutPackagePart());
        if (parent.getDefRefStringWithoutPackagePart().equals(parentString)) {
            setParentHierarchicDefRef(parent);
        }
    }

    private void setParentDefRef(@Nullable DefRef parent) {
        checkArgument(parent != UNINITIALIZED_DEFREF);
        if (parent != null) {
            checkArgument(this.getDefRefStringWithoutPackagePart().startsWith(parent.getDefRefStringWithoutPackagePart()));

        }
        synchronized (this) {
            if (parentDefRef != UNINITIALIZED_DEFREF) {
                if (parentDefRef == parent) {
                    return;
                }
                if (parentDefRef != null && parentDefRef.equalsExact(parent)) {
                    return;
                }

                throw new IllegalStateException();
            }
            parentDefRef = parent;
        }
    }

    private void setParentHierarchicDefRef(@Nullable DefRef parent) {
        checkArgument(parent != UNINITIALIZED_DEFREF);
        if (parent != null) {
            checkArgument(this.getDefRefStringWithoutPackagePart().startsWith(parent.getDefRefStringWithoutPackagePart()));

        }
        synchronized (this) {
            // When the hierarchic parent has the same Package as this element, we could also use it as real parent
            if (parent.getPackagePartOfDefRefString().equals(this.getPackagePartOfDefRefString())) {
                setParentDefRef(parent);
            }

            if (parentHierarchicDefRef != UNINITIALIZED_DEFREF) {
                if (parentHierarchicDefRef == parent) {
                    return;
                }
                if (parentHierarchicDefRef != null && parentHierarchicDefRef.equalsExact(parent)) {
                    return;
                }

                throw new IllegalStateException();
            }
            parentHierarchicDefRef = parent;

        }
    }

    /**
     * Gets a new {@link DefRef} object, where the package info of the this object was replaced by a Wildcard.
     *
     * @return New {@link DefRef} object with wildcard info.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if wildcardParam is null.</li>
     * <li>if the obj has already a wildcard and this.wildcard != wildcardParam.</li>
     * </ul>
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if this was created without package information.</li>
     * </ul>
     *
     */
    @PublishedMethod
    public DefRef getDefRefWithWildcard(final IDefRefWildcard wildcardParam) {

        if (wildcardParam == null) {
            throw new IllegalArgumentException("wildcardParam is null");
        }

        if (this.hasWildcards()) {
            if (this.getDefRefWildcard() != wildcardParam) {
                throw new IllegalArgumentException("The DefRef has already a wildcard. The wildcard of the defref " + this.getDefRefWildcard()
                        + " does not match the new wildcardParam "
                        + wildcardParam + ". A wildcard can not be replaced by another wildcard.");
            } else {
                return this;
            }
        }
        final DefRef newDef;
        if (this instanceof TypedDefRef) {
            final TypedDefRef<?, ?, ?> srcDef = (TypedDefRef<?, ?, ?>) this;
            newDef = DefRef.create(wildcardParam, getDefRefStringWithoutPackagePart(), srcDef.getModelDefinitionClass(), srcDef.getModelConfigurationClass(),
                    srcDef.getModelValueClass());
        } else {
            newDef = DefRef.create(wildcardParam, getDefRefStringWithoutPackagePart());
        }

        return newDef;
    }

    /**
     * Create a new DefRef with a replaced package of the newPackage {@link DefRef} and original DefRef parameter.
     *
     *
     * @param newPackage The DefRef from which the packages is retrieved
     * @return A new created DefRef with the package info of newPackage and the DefRf of this.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the newPackage is null</li>
     * </ul>
     */
    @PublishedMethod
    public DefRef getDefRefWithNewPackage(final DefRef newPackage) {

        if (newPackage == null) {
            throw new IllegalArgumentException("newPackage is null");
        }

        final DefRef defref;
        if (newPackage.hasWildcards()) {
            defref = DefRef.create(newPackage.getDefRefWildcard(), this.getDefRefStringWithoutPackagePart());
        } else {
            defref = DefRef.create(newPackage.getPackagePartOfDefRefString(), this.getDefRefStringWithoutPackagePart());
        }

        return defref;
    }

    /**
     * Creates a new {@link DefRef} with a replaced package and module shortname from the data of the passed refinementParentDefRef is replaced and the suffix of the original
     * DefRef (this) is used. So the path of this is replaced with the package and module of refinementParentDefRef and a new {@link DefRef} is returned.
     *
     * <p>
     * Code example:
     *
     * <pre>
     * <code class="Java" id="Usage of createReplacedRefinementDefRefOf() method in DefRef class">
     * 	DefRef myDef = DefRef.create("/MyPkg", "MyCDD/CddContainer");
     * 	DefRef autosarDef = DefRef.create(DefRef.AUTOSAR4_PACKAGE, "Cdd");
     *
     *  //Caution: You have to check refinements before calling createReplacedRefinementDefRefOf
     *  if(myDef.isRefinedOf(autosarDef, ma)){
     *
     * 	    DefRef replaced = myDef.createReplacedRefinementDefRefOf(autosarDef);
     * 	    //the replaced DefRef will be "/AUTOSAR/EcucDefs/Cdd/CddContainer" instead of "/MyPkg/MyCDD/CddContainer"
     * 	}
     * </code>
     * </pre>
     *
     * <p>
     * Also note that the Module shortname is also replaced. So strange shortnames names are correctly changed to the correct shortname of the parent refinement. E.g. CDD =>
     * Cdd.
     * </p>
     *
     *
     * <p>
     * Caution: The this DefRefs Module DefRef must be refined of the passed refinementParentModuleDefRef, otherwise the method will lead to unpredictable results. So you have
     * to check <code>myDefRef.isRefinedOf(parent, ma);</code before you call this method!
     * </p>
     *
     * @param refinementParentDefRef The DefRef from which the packages and the Module shortname are retrieved. This must not be the same element path. It could simply be the
     * Module {@link DefRef}.
     * @return A new created DefRef with the package info and module of passed defRef and the DefRef path of this.
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the refinementParentDefRef is null</li>
     * <li>if this has wildcards</li>
     * </ul>
     *
     */
    @PublishedMethod
    public DefRef createReplacedRefinementDefRefFrom(final DefRef refinementParentDefRef) {
        if (refinementParentDefRef == null) {
            throw new IllegalArgumentException("refinementParentModuleDefRef is null");
        }
        if (this.hasWildcards()) {
            throw new IllegalArgumentException("this has wildcards");
        }
        final DefRef refinementParentModuleDefRef = refinementParentDefRef.getModuleDefinitionDefRef();

        final String pkg = refinementParentModuleDefRef.getPackagePartOfDefRefString();

        final String path;
        if (!this.isModuleDefinitionDefRef()) {
            final String suffix = SEPARATOR + this.getDefRefStringWithoutModuleDef();
            path = refinementParentModuleDefRef.getDefRefStringWithoutPackagePart() + suffix;
        } else {
            // It is a ModuleDefRef, so we could use the passed refinementParentDefRef without any other info.
            path = refinementParentModuleDefRef.getDefRefStringWithoutPackagePart();
        }

        final DefRef newDefRef = DefRef.create(pkg, path);

        return newDefRef;
    }

    /**
     * Constructs a {@link TypedDefRef} by this {@link DefRef} object.
     *
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * </ul>
     */
    @PublishedMethod
    public <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> createTypedDefRef(
            final Class<DEF_TYPE> modelDefinitionClass, final Class<CONFIG_TYPE> modelConfigClass, final Class<VALUE_TYPE> valueClass) {

        return new TypedDefRef<>(this, modelDefinitionClass, modelConfigClass, valueClass);
    }

    /**
     * Constructs a {@link TypedDefRef} by this {@link DefRef} object.
     *
     * @param modelDefinitionClass The class of the definition of this DefRef. E.g. MIReferenceParamDef.class.
     * @param modelConfigClass The class of the modelObject of thisDefRef. E.g. MINumericalValue.class.
     * @param valueClass The class of the value of parameter of this DefRef. E.g. BigInteger.class. If it has no value you should use Void.class
     * @return the {@link TypedDefRef}
     * @exception IllegalArgumentException
     * <ul>
     * <li>if the modelDefinitionClass is null</li>
     * <li>if the modelConfigClass is null</li>
     * <li>if the valueClass is null</li>
     * </ul>
     */
    @PublishedMethod
    public <DEF_TYPE extends MIParamConfMultiplicity, CONFIG_TYPE extends MIHasDefinition, VALUE_TYPE> TypedDefRef<DEF_TYPE, CONFIG_TYPE, VALUE_TYPE> toTyped(
            final Class<DEF_TYPE> modelDefinitionClass, final Class<CONFIG_TYPE> modelConfigClass, final Class<VALUE_TYPE> valueClass) {
        return createTypedDefRef(modelDefinitionClass, modelConfigClass, valueClass);
    }

    /**
     * Constructs a container {@link TypedDefRef} by this {@link DefRef} object.
     *
     *
     * @return the {@link TypedDefRef}
     */
    @PublishedMethod
    public TypedDefRef<MIParamConfContainerDef, MIContainer, Void> toTypedContainer() {
        return new TypedDefRef<>(this, MIParamConfContainerDef.class, MIContainer.class, Void.class);
    }

    /**
     * Constructs a choice container {@link TypedDefRef} by this {@link DefRef} object.
     *
     *
     * @return the {@link TypedDefRef}
     */
    @PublishedMethod
    public TypedDefRef<MIChoiceContainerDef, MIContainer, Void> toTypedChoiceContainer() {
        return new TypedDefRef<>(this, MIChoiceContainerDef.class, MIContainer.class, Void.class);
    }

    /**
     * Constructs a boolean parameter {@link TypedDefRef} by this {@link DefRef} object.
     *
     *
     * @return the {@link TypedDefRef}
     */
    @PublishedMethod
    public TypedDefRef<MIBooleanParamDef, MINumericalValue, Boolean> toTypedBool() {
        return new TypedDefRef<>(this, MIBooleanParamDef.class, MINumericalValue.class, Boolean.class);
    }

    /**
     * Constructs a integer parameter {@link TypedDefRef} by this {@link DefRef} object.
     *
     *
     * @return the {@link TypedDefRef}
     */
    @PublishedMethod
    public TypedDefRef<MIIntegerParamDef, MINumericalValue, BigInteger> toTypedInt() {
        return new TypedDefRef<>(this, MIIntegerParamDef.class, MINumericalValue.class, BigInteger.class);
    }

    /**
     * Constructs a float parameter {@link TypedDefRef} by this {@link DefRef} object.
     *
     *
     * @return the {@link TypedDefRef}
     */
    @PublishedMethod
    public TypedDefRef<MIFloatParamDef, MINumericalValue, BigDecimal> toTypedFloat() {
        return new TypedDefRef<>(this, MIFloatParamDef.class, MINumericalValue.class, BigDecimal.class);
    }

    /**
     * Constructs a string parameter {@link TypedDefRef} by this {@link DefRef} object.
     *
     *
     * @return the {@link TypedDefRef}
     */
    @PublishedMethod
    public TypedDefRef<MIStringParamDef, MITextualValue, String> toTypedString() {
        return new TypedDefRef<>(this, MIStringParamDef.class, MITextualValue.class, String.class);
    }

    /**
     * Constructs a module configuration {@link TypedDefRef} by this {@link DefRef} object.
     *
     *
     * @return the {@link TypedDefRef}
     */
    @PublishedMethod
    public TypedDefRef<MIModuleDef, MIModuleConfiguration, Void> toTypedModule() {
        return new TypedDefRef<>(this, MIModuleDef.class, MIModuleConfiguration.class, Void.class);
    }

    /**
     * Gets the last ShortName of the DefinitionRef.
     *
     * @return
     */
    @PublishedMethod
    public String getLastShortname() {
        return AutosarUtil.getLastShortname(defRefWithoutPackages);
    }

    /**
     * returns the immediate child if the this DefRef is parent of the indirectChild DefRef.
     *
     * @param indirectChild
     * @return the immediate child DefRef of this
     * @exception NullPointerException
     * <ul>
     * <li>if indirectChild is null</li>
     * </ul>
     * @exception IllegalArgumentException
     * <ul>
     * <li>if presumed indirectChild DefRef is no child of this Parent object.</li>
     * </ul>
     */
    @PublishedMethod
    public DefRef getImmediateChild(final DefRef indirectChild) {
        checkNotNull(indirectChild, "Parameter indirectChild is null");
        if (!isParentOfIgnoringPackages(indirectChild)) {
            throw new IllegalArgumentException("The presumed indirectChild DefRef(" + indirectChild + ") is no child of this Parent DefRef (" + this + ").");
        }
        final String remainingPath = indirectChild.getDefRefStringWithoutPackagePart().substring(getDefRefStringWithoutPackagePart().length() + 1);
        return create(this, AutosarUtil.getFirstShortname(remainingPath));
    }

    /**
     * This class is used to serialize all {@link DefRef} instances, regardless of implementation type. It captures their "logical contents" and they are reconstructed using
     * public static factories. This is necessary to ensure that the existence of a particular implementation type is an implementation detail.
     *
     */
    @Keep
    @PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
    private static class SerializationProxy<E extends DefRef> implements java.io.Serializable {

        private static final long serialVersionUID = 3924044719234374576L;

        private final String packagePartOfDefRefString;

        private final String defRefStringWithoutPackagePart;

        SerializationProxy(final DefRef defRef) {

            packagePartOfDefRefString = defRef.getPackagePartOfDefRefString();
            defRefStringWithoutPackagePart = defRef.getDefRefStringWithoutPackagePart();
        }

        private Object readResolve() {
            return DefRef.create(packagePartOfDefRefString, defRefStringWithoutPackagePart);
        }

    }

    @KeepName
    Object writeReplace() {
        return new SerializationProxy<>(this);
    }

    // readObject method for the serialization proxy pattern
    // See Effective Java, Second Ed., Item 78.
    @KeepName
    private void readObject(final java.io.ObjectInputStream stream) throws java.io.InvalidObjectException {
        throw new java.io.InvalidObjectException("Proxy required");
    }

    /*
     * Trace Methods
     */
    private static void trace(final String method, final String pattern, final Object... arguments) {
        logger.trace(method + ": " + MessageFormat.format(pattern, arguments));
    }

}
