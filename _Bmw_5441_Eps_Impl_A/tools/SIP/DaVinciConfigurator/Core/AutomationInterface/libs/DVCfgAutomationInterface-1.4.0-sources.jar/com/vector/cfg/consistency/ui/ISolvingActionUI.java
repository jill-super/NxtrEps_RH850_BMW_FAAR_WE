package com.vector.cfg.consistency.ui;

import java.util.Collection;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.ISolvingActionExecutionResult;
import com.vector.cfg.consistency.contribution.IHasDescriptionAsMixedText;

/**
 * An {@link ISolvingActionUI} is an executable solution for an {@link IValidationResultUI}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
public interface ISolvingActionUI extends IHasDescriptionAsMixedText, IHasLinkToValidationResult {

    /**
     * Gets the assigned solving action groups to which this solving action group belongs. Each group may only be assigned to one solving action within one validation result to
     * make solving action selection by group (group id) unambiguous.
     *
     * @return the assigned groups
     */
    @PublishedMethod
    Collection<ISolvingActionGroupUI> getAssignedGroups();

    /**
     * Gets the solving action group by id or null if not existing.
     *
     * @param id the id
     * @return the solving action group by id or null if not existing
     */
    @PublishedMethod
    @Nullable
    ISolvingActionGroupUI getSolvingActionGroupById(int id);

    /**
     * Execute this solving action within its own transaction.
     * <p/>
     * <b>Important note about invalidation:</b><div class="extdoc" id="solve_invalidation">Any model modification may invalidate any validation-result. In that case, the
     * responsible validator creates a new validation-result if the inconsistency still exists. Whether this happens for a particular modification/validation-result depends on
     * the validator implementation and is not visible to the user/client.
     *
     * Trying to solve an invalidated validation-result will throw an {@link IllegalStateException}. Therefore it is not safe to solve a particular {@link ISolvingActionUI} that
     * was fetched before the last transaction. Instead, please fetch a solving-action after the last transaction, or use the method <code>ISolver.solve(Closure)</code> which is
     * the most preferred way of solving validation-results with solving-actions.
     *
     * </div>
     *
     * <div class="extdoc" id="solve_return">{@link ISolvingActionUI#solve()} returns an {@link ISolvingActionExecutionResult}.</div>
     *
     * @throws IllegalStateException if {@link IValidationResultUI#isActive()} of this solving-action returns false
     * @return the result
     */
    @PublishedMethod
    ISolvingActionExecutionResult solve();
}
