package com.vector.cfg.dom.runtimesys.groovy.api;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

import groovy.lang.Closure;
import groovy.transform.stc.ClosureParams;
import groovy.transform.stc.FromString;

/**
 * <div class="extdoc" id="IComponentPrototypeCreator"><!--Label:IComponentPrototypeCreator-->{@link IComponentPrototypeCreator} provides an Api to control some aspects, e.g.
 * the naming, of newly created components. </div>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IComponentPrototypeCreator {

    /**
     * <div class="extdoc" id="name"><!--Label:name-->{@link #name(Closure)} computes a name for the component prototypes that should be created for, by the
     * {@link IComponentTypeSelection} provided, component types. </div>
     *
     * @param code A closure that returns a string with a name for the component prototype that should be created.
     */
    @PublishedMethod
    void name(
            @ClosureParams(value = FromString.class, options = "com.vector.cfg.model.sysdesc.api.component.IComponentType") @Nonnull Closure<String> code);

    /**
     * <div class="extdoc" id="count"><!--Label:count-->{@link #count(int)} defines how many component prototypes should be created for each selected component type. The default
     * is 1. </div>
     *
     * @param count The number of prototypes which should be created.
     */
    @PublishedMethod
    void count(int count);

    // -------------- internal API

    @KeepSecretFromPublishedApi
    Closure<String> getComputeNameCode();

    @KeepSecretFromPublishedApi
    int getCount();
}
