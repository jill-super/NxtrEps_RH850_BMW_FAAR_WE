package com.vector.cfg.gen.core.genusage.result.model;

import java.util.Date;

import javax.annotation.Nonnull;
import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.moduleinterface.EGenerationProcessResult;

/**
 * {@link IGenerationResultModel} provides details of an executed or currently running generation process of the generator service. Clients can use the model to navigate through
 * the result of a generation or updated e.g. a view during the running generation.
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGenerationResultModel {

    /**
     * Returns the {@link IGenerationResultRoot} root element of the result tree.
     *
     * @return the root of the result tree.
     */
    @PublishedMethod
    @Nonnull
    IGenerationResultRoot getGenerationResultRoot();

    /**
     * Gets the last {@link EGenerationProcessResult}, or <code>null</code> if the process is currently running, or has no last result.
     *
     * @return the result
     */
    @PublishedMethod
    @Nullable
    EGenerationProcessResult getResult();

    /**
     * Gets the last execution time, or <code>null</code>, if no ExecutionTime is available.
     *
     * @return the last execution time
     */
    @PublishedMethod
    @Nullable
    Date getLastExecutionTime();

    /**
     * Returns the duration in second of the last execution. Or <code>null</code> if there was no execution.
     */
    @PublishedMethod
    @Nullable
    Double getLastExecutionDurationInS();

    /**
     * Gets the duration in second of the last execution. Or {@code <none>} if there was no execution.
     *
     * @return the duration in second of the last execution. Or {@code <none>} if there was no execution.
     */
    @PublishedMethod
    String getFormattedDuration();
}
