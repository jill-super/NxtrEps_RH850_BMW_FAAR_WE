package com.vector.cfg.automation.scripting.api;

import java.util.List;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.automation.scripting.api.IScriptCreationApi.IScriptTaskBuilder;
import com.vector.cfg.automation.scripting.base.IScriptTask;
import com.vector.cfg.automation.scripting.base.IScriptTaskUserDefinedArgumentSpecification;

/**
 * {@link IScriptTaskUserDefinedArgument} defines an script user defined argument create during {@link IScriptTask} by an {@link IScriptTaskBuilder}. The actual value of the
 * argument could be retrieve during {@link IScriptTask} execution, by calling {@link #getValue()} or {@link #getValues()}.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @param <T> the value type of the argument.
 * @see IScriptCreationApi
 * @see IScriptTaskBuilder
 * @see IScriptTask
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IScriptTaskUserDefinedArgument<T> extends IScriptTaskUserDefinedArgumentSpecification<T> {

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    String getArgumentName();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    String getQualifiedArgumentName();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    Class<T> getValueType();

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    String getHelp();

    /**
     * Returns <code>true</code>, if the argument has at least one value.
     *
     * @return true, it has a value, otherwise <code>false</code>.
     */
    @PublishedMethod
    boolean hasValue();

    /**
     * See {@link #hasValue()}.
     *
     * @return true, it has a value, otherwise <code>false</code>.
     */
    @PublishedMethod
    boolean isHasValue();

    /**
     * Returns the value of the argument.
     *
     * @return the value
     * @exception IllegalStateException
     * <ul>
     * <li>If {@link #hasValue()} returns false</li>
     * </ul>
     */
    @PublishedMethod
    T getValue();

    /**
     * Returns the List of values of the argument. This is used, if the argument specified multiple times. The {@link List} is empty, if no argument was specified.
     *
     * @return the values
     */
    @PublishedMethod
    List<T> getValues();

    /**
     * Returns the value of the argument, or <code>null</code>, if the argument has no value.
     *
     * @return the value or <code>null</code>
     */
    @PublishedMethod
    @Nullable
    T getValueOrNull();

}
