package com.vector.cfg.gen.core.bswmdmodel.modelintern;

import static com.google.common.base.Preconditions.checkNotNull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIConfigVariantInfo;
import com.vector.cfg.gen.core.bswmdmodel.GIModuleConfiguration;
import com.vector.cfg.model.access.ecuconfiguration.EEcucConfigurationVariant;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * BswmdModel ConfigurationVariant information retrieved by the {@link GIModuleConfiguration}.
 *
 * <p>
 * Attention: Please use {@link GIConfigVariantInfo} interface in client code.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GVariantInfo implements GIConfigVariantInfo {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(GVariantInfo.class);

    private final GAbstractModuleConfiguration bswmdModuleConfig;

    /**
     * Constructor for GVariantInfo.
     *
     * @param mdfObject
     */
    @PublishedMethod
    public GVariantInfo(GAbstractModuleConfiguration bswmdConfig) {
        checkNotNull(bswmdConfig);
        bswmdModuleConfig = bswmdConfig;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean isPreCompile() {
        return isImplConfigVariant(EEcucConfigurationVariant.VARIANT_PRE_COMPILE);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean isLinkTime() {
        return isImplConfigVariant(EEcucConfigurationVariant.VARIANT_LINK_TIME);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean isPostBuildLoadable() {
        return isImplConfigVariant(EEcucConfigurationVariant.VARIANT_POST_BUILD_LOADABLE);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public boolean isPostBuildSelectable() {
        try {
            bswmdModuleConfig.getGenModelAccessInternal().switchView();

            return bswmdModuleConfig.getEcuConfiguration().supportsPostBuildVariance();

        } finally {
            bswmdModuleConfig.getGenModelAccessInternal().restoreView();
        }
    }

    private boolean isImplConfigVariant(EEcucConfigurationVariant value) {
        try {
            bswmdModuleConfig.getGenModelAccessInternal().switchView();

            final EEcucConfigurationVariant configurationVariant = bswmdModuleConfig.getEcuConfiguration().getConfigurationVariant();
            return configurationVariant == value;

        } finally {
            bswmdModuleConfig.getGenModelAccessInternal().restoreView();
        }
    }

}
