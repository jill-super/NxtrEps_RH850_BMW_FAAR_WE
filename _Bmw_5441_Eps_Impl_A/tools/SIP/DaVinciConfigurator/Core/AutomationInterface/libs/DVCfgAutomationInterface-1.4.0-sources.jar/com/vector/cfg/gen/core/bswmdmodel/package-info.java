/**
 * The BswmdModel interface and base types for the generated Bswmd file base ActiveEcuc model.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.bswmdmodel;