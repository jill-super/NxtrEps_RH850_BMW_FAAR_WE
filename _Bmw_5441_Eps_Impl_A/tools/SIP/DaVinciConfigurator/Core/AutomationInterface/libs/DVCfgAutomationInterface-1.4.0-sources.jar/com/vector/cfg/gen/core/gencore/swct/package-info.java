/**
 * Software component templates and contract phase headers generation types.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.gen.core.gencore.swct;