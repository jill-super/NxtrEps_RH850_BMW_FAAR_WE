package com.vector.cfg.model.annotation.user;

import static com.google.common.base.Preconditions.checkNotNull;

import javax.annotation.Nonnull;
import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.internal.annotation.user.UserAnnotation;
import com.vector.cfg.model.mdf.ar4x.genericstructure.generaltemplateclasses.documentation.annotation.MIAnnotation;
import com.vector.cfg.model.mdf.ar4x.genericstructure.generaltemplateclasses.documentation.annotation.MIHasAnnotation;
import com.vector.cfg.model.mdf.model.autosar.base.MIIdentifiable;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIModuleConfiguration;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIParameterValue;
import com.vector.cfg.model.view.config.IDelegateViewedModelObjectCalls;
import com.vector.cfg.model.view.config.IModelView;
import com.vector.cfg.model.view.config.IViewedModelObject;

/**
 * {@link IUserAnnotation} represent an user annotation in the MDF model, and provides access methods for a user annotation.
 *
 * <p>
 * The {@link IUserAnnotation} can be create with or without an creation {@link IModelView}. If the user annotation was created with an {@link IModelView}, all method will
 * retrieve and set data in the creationModelView. Otherwise the callers current active {@link IModelView} is used.
 * </p>
 *
 * <div class="extdoc" id="Common"> In DaVinci Configurator the user can add AUTOSAR annotations to configuration elements. You can create, modify, read and delete these
 * annotations like in the UI editors.
 *
 * <p>
 * All sub types of {@link MIHasAnnotation} elements support annotations like:
 * <ul>
 * <li>{@link MIModuleConfiguration}s</li>
 * <li>{@link MIContainer}s</li>
 * <li>{@link MIParameterValue}s</li>
 * <li>{@link MIIdentifiable}s</li>
 * </ul>
 * </p>
 *
 *
 * <p>
 * Although annotations are stored in the data model, their <code>changeable</code> state is independent of the configuration element <code>changeable</code> state. Annotations
 * can be added/changed/deleted on every existing configuration element with valid definition, except the project was opened in read-only mode.
 * </p>
 *
 *
 * <p>
 * The {@link IUserAnnotation} interface provide methods like:
 * <ul>
 * <li>{@link #getLabel()} - Returns the label of the annotation, like <code>getName()</code> of a container</li>
 * <li>{@link #setLabel()} - Changes the label</li>
 * <li>{@link #getText()} - Returns the text of the annotation.</li>
 * <li>{@link #setText()} - Changes the text</li>
 * <li>{@link #isChangeable()} - Returns <code>true</code>, if the annotation is changeable</li>
 * <li><code>moRemove()</code> - Deletes the annotation</li>
 * </ul>
 *
 * </div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface IUserAnnotation extends IViewedModelObject, IDelegateViewedModelObjectCalls {

    /**
     * Returns the label of the annotation.
     *
     * @return the label
     */
    @PublishedMethod
    @Nonnull
    String getLabel();

    /**
     * Sets the label of the {@link IUserAnnotation}.
     *
     * @param label the new label
     * @exception IllegalArgumentException if label is <code>null</code>
     */
    @PublishedMethod
    void setLabel(@Nonnull String label);

    /**
     * Returns the text of the annotation.
     *
     * @return the text
     */
    @PublishedMethod
    @Nonnull
    String getText();

    /**
     * Sets the text of the {@link IUserAnnotation}.
     *
     * @param text the new text
     * @exception IllegalArgumentException if text is <code>null</code>
     */
    @PublishedMethod
    void setText(@Nonnull String text);

    /**
     * Returns the underlying element which was annotated with this {@link IUserAnnotation}.
     *
     *
     * @return the annotation owner
     */
    @PublishedMethod
    @Nonnull
    MIHasAnnotation getAnnotationOwner();

    /**
     * Returns <code>true</code> if this annotation can be changed.
     *
     * @return <code>true</code> if changeable.
     */
    @PublishedMethod
    boolean isChangeable();

    /**
     * Returns <code>true</code> if this annotation can be deleted.
     *
     * @return <code>true</code> if deletable.
     */
    @PublishedMethod
    boolean isDeletable();

    /**
     * Returns the underlying {@link MIAnnotation} of this user Annotation.
     *
     *
     * @return The {@link MIAnnotation} of this {@link IUserAnnotation}.
     */
    @Override
    @Nonnull
    @PublishedMethod
    MIAnnotation getMdfObject();

    /**
     * {@inheritDoc}
     *
     * <p>
     * Note: if the object was created without a view, this will nevertheless return the creation {@link IModelView}. See class header for details.
     */
    @Override
    @PublishedMethod
    @Nonnull
    IModelView getCreationModelView();

    /**
     * Return the list of UserAnnotations of the passed {@link MIHasAnnotation}.
     *
     * @param element the element
     * @return the user annotations as <code>List&lt;IUserAnnotation&gt;</code>
     */
    @Nonnull
    @PublishedMethod
    static IUserAnnotationList getUserAnnotations(@Nonnull MIHasAnnotation element) {
        return UserAnnotation.createInternal(element, null);
    }

    /**
     * Return the list of UserAnnotations of the passed {@link MIHasAnnotation}.
     *
     * @param element the element
     * @param creationModelView the modelView to bind the created element to
     * @return the user annotations as <code>List&lt;IUserAnnotation&gt;</code>
     */
    @Nonnull
    @PublishedMethod
    static IUserAnnotationList getUserAnnotations(@Nonnull MIHasAnnotation element, @Nonnull IModelView creationModelView) {
        checkNotNull(creationModelView);
        return UserAnnotation.createInternal(element, creationModelView);
    }

}
