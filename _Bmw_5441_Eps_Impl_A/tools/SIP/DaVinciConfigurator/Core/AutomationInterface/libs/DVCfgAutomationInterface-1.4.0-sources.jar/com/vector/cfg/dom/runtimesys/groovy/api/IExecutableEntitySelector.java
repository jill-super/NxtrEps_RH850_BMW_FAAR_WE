package com.vector.cfg.dom.runtimesys.groovy.api;

import java.util.List;
import java.util.regex.Pattern;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.sysdesc.api.taskmapping.IExecutableEntity;
import com.vector.cfg.model.sysdesc.api.taskmapping.ITaskMapping;
import com.vector.cfg.util.scripting.groovy.VClassClosureParams;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * The {@link IExecutableEntitySelector} Api allows the definition of predicates for executable entities (also called functions) selection.
 * <p>
 * <div class="extdoc" id="IExecutableEntitySelector"> Per default the predicates are combined via logical AND. To realize other combinations, use the 'or','not' and 'and'
 * predicates.</div>
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IExecutableEntitySelector {

    /**
     * <div class="extdoc" id="and">{@link #and(Closure)} combines the predicates inside the closure with a logical AND.</div>
     *
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void and(@Nonnull @VDelegatesToWithClosureParam(IExecutableEntitySelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="or">{@link #or(Closure)} combines the predicates inside the closure with a logical OR.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void or(@Nonnull @VDelegatesToWithClosureParam(IExecutableEntitySelector.class) Closure<?> code);

    /**
     * <div class="extdoc" id="not">{@link #not(Closure)} negates the combination of predicates inside the closure.</div>
     *
     * @param code Closure containing predicates.
     */
    @PublishedMethod
    void not(@Nonnull @VDelegatesToWithClosureParam(IExecutableEntitySelector.class) Closure<?> code);

    // ----------------------------

    /**
     * <div class="extdoc" id="symbol">{@link #symbol(String)} matches runnable entities with the given symbol and bsw schedulable entities whose corresponding bsw module entry
     * short name matches the given symbol.</div>
     *
     * @param symbol An executable entity symbol.
     */
    @PublishedMethod
    void symbol(@Nonnull String symbol);

    /**
     * <div class="extdoc" id="symbolPattern">{@link #symbol(Pattern)} matches runnable entities whose symbol matches the given symbol pattern and bsw schedulable entities whose
     * corresponding bsw module entry short name matches the given symbol pattern.</div>
     *
     * @param symbol An executable entity symbol pattern.
     */
    @PublishedMethod
    void symbol(@Nonnull Pattern symbolPattern);

    /**
     * <div class="extdoc" id="name">{@link #name(String)} matches executable entities (functions) with the given name.</div>
     *
     * @param name An executable entity name.
     */
    @PublishedMethod
    void name(@Nonnull String name);

    /**
     * <div class="extdoc" id="namePattern">{@link #name(Pattern)} matches executable entities (functions) with the given name pattern.</div>
     *
     * @param namePattern An executable entity name pattern.
     */
    @PublishedMethod
    void name(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="asrPath">{@link #asrPath(String)} matches executable entities (functions) with the given autosar path.</div>
     *
     * @param asrPath An executable entity autosar path.
     */
    @PublishedMethod
    void asrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="asrPathPattern">{@link #asrPath(Pattern)} matches executable entities (functions) with the given autosar path pattern.</div>
     *
     * @param asrPathPattern An executable entity autosar path pattern.
     */
    @PublishedMethod
    void asrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="component">{@link #component(String)} matches executable entities (functions) which belong to components with the given component name.</div>
     *
     * @param name A component name.
     */
    @PublishedMethod
    void component(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentPattern">{@link #component(Pattern)} matches executable entities (functions) which belong to components which matches the given component
     * name pattern.</div>
     *
     * @param namePattern A component name pattern.
     */
    @PublishedMethod
    void component(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentType">{@link #componentType(String)} matches executable entities (functions) which are part of the internal behavior of component types
     * with the given component type name.</div>
     *
     * @param name A component type name.
     */
    @PublishedMethod
    void componentType(@Nonnull String name);

    /**
     * <div class="extdoc" id="componentTypePattern">{@link #componentType(Pattern)} matches exectuable entities (functions) which are part of the internal behavior of component
     * types which matches the given component type name pattern.</div>
     *
     * @param namePattern A component type name pattern.
     */
    @PublishedMethod
    void componentType(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="componentTypeAsrPath">{@link #componentTypeAsrPath(String)} matches executable entities (functions) which are part of the internal behavior of
     * component types with the given component type autosar path.</div>
     *
     * @param asrPath A component type autosar path.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="componentTypeAsrPathPattern">{@link #componentTypeAsrPath(Pattern)} matches executable entities (functions) which are part of the internal
     * behavior of component types whose autosar path matches the given component type autosar path pattern.</div>
     *
     * @param asrPathPattern A component type asr path pattern.
     */
    @PublishedMethod
    void componentTypeAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="moduleConfiguration">{@link #moduleConfiguration(String)} matches executable entities (functions) which belong to module configurations with the
     * given module configuration name.</div>
     *
     * @param name A module configuration name.
     */
    @PublishedMethod
    void moduleConfiguration(@Nonnull String name);

    /**
     * <div class="extdoc" id="moduleConfigurationPattern">{@link #moduleConfiguration(Pattern)} matches executable entities (functions) which belong to module configurations
     * which matches the given module configuration name pattern.</div>
     *
     * @param namePattern A module configuration name pattern.
     */
    @PublishedMethod
    void moduleConfiguration(@Nonnull Pattern namePattern);

    /**
     * <div class="extdoc" id="moduleConfigurationAsrPath">{@link #moduleConfigurationAsrPath(String)} matches executable entities (functions) which belong to module
     * configurations with the given module configuration autosar path.</div>
     *
     * @param asrPath A module configuration autosar path.
     */
    @PublishedMethod
    void moduleConfigurationAsrPath(@Nonnull String asrPath);

    /**
     * <div class="extdoc" id="moduleConfigurationAsrPathPattern">{@link #moduleConfigurationAsrPath(Pattern)} matches executable entities (functions) which belong to module
     * configurations whose autosar path matches the given module configuration autosar path pattern.</div>
     *
     * @param asrPathPattern A module configuration asr path pattern.
     */
    @PublishedMethod
    void moduleConfigurationAsrPath(@Nonnull Pattern asrPathPattern);

    /**
     * <div class="extdoc" id="task">{@link #task(String)} matches executable entities (functions) which have at least one event (trigger) that is mapped to a task with the
     * given task name.</div>
     *
     * @param name A task name.
     */
    @PublishedMethod
    void task(@Nonnull String name);

    /**
     * <div class="extdoc" id="taskPattern">{@link #task(Pattern)} matches executable entities (functions) which have at least one event (trigger) that is mapped to a task whose
     * name matches the given task name pattern.</div>
     *
     * @param name A task name pattern.
     */
    @PublishedMethod
    void task(@Nonnull Pattern namePattern);

    // ----------------------------

    /**
     * <div class="extdoc" id="filterAdvanced">{@link #filterAdvanced(Closure)} matches executable entities (functions) for which the given closure results to true.</div>
     *
     * @param code The closure to select executable entities.
     */
    @PublishedMethod
    void filterAdvanced(@Nonnull @VClassClosureParams(IExecutableEntity.class) Closure<Boolean> code);

    /**
     * <div class="extdoc" id="bswSchedulableEntity">{@link #bswSchedulableEntity()} matches executable entities (functions) which are bsw schedulable entities.</div>
     */
    @PublishedMethod
    void bswSchedulableEntity();

    /**
     * <div class="extdoc" id="runnableEntity">{@link #runnableEntity()} matches executable entities (functions) which are runnable entities.</div>
     */
    @PublishedMethod
    void runnableEntity();

    /**
     * <div class="extdoc" id="unmapped">{@link #unmapped()} matches executable entities (functions) with at least one unmapped event (trigger).</div>
     */
    @PublishedMethod
    void unmapped();

    /**
     * <div class="extdoc" id="mapped">{@link #mapped()} matches executable entities (functions) with at least one mapped event (trigger).</div>
     */
    @PublishedMethod
    void mapped();

    /**
     * <div class="extdoc" id="fullyUnmapped">{@link #fullyUnmapped()} matches executable entities (functions) with all of its events (triggers) being not mapped in any context
     * to a task.</div>
     */
    @PublishedMethod
    void fullyUnmapped();

    /**
     * <div class="extdoc" id="fullyMapped">{@link #fullyMapped()} matches executable entities (functions) with all of its events (triggers) being mapped in each context to a
     * task.</div>
     */
    @PublishedMethod
    void fullyMapped();

    // -------------- internal API

    @KeepSecretFromPublishedApi
    List<IExecutableEntity> getSelectedExecutableEntities();

    @KeepSecretFromPublishedApi
    List<ITaskMapping> getSelectedTaskMappings();

}
