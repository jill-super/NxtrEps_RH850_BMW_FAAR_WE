package com.vector.annotations.publishedapi;

import java.lang.annotation.Documented;
import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * The {@link PublishedApiDomain} annotation restricts the visibility of the {@link PublishedApi} to a certain API domain. See {@link DomainType} enum for a list of valid domain
 * types.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @see PublishedApi
 * @see DomainType
 */
@PublishedApi(ChangePolicy.CLASS_DEPENDENCY)
@Documented
@Retention(RetentionPolicy.CLASS)
@Target(ElementType.TYPE)
public @interface PublishedApiDomain {

    /**
     * Defines the {@link DomainType}s where the {@link PublishedApi} is visible.
     *
     * @return the domain type[]
     */
    @PublishedMethod
    DomainType[] value();
}
