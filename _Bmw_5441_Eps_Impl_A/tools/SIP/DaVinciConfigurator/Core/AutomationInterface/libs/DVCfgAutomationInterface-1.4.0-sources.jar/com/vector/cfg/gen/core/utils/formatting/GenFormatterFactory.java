package com.vector.cfg.gen.core.utils.formatting;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.utils.formatting.formatter.TwoSpacesPerArray;
import com.vector.cfg.gen.core.utils.formatting.formatter.TwoSpacesPerElement;

/**
 * {@link GenFormatterFactory} provides default {@link IGenFormatProvider} for the standard uses cases:
 * <ul>
 * <li>TwoSpacesPerElement</li>
 * <li>TwoSpacesPerArray</li>
 * </ul>
 *
 * See {@link EFormatType} for more details.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// @CHECKSTYLE:OFF Singleton and PublishedApi
public enum GenFormatterFactory {
    // @CHECKSTYLE:ON
    INSTANCE;

    /**
     * Creates a new {@link TwoSpacesPerElement} formatter object with the default start indentation level of 0.
     *
     * @return New IGenFormatProvider
     */
    @PublishedMethod
    public IGenFormatProvider createTwoSpacesPerElementFormatter() {
        return new TwoSpacesPerElement();
    }

    /**
     * Creates a new {@link TwoSpacesPerElement} formatter object with a start indentation of (startIndentationLevel).
     *
     * <p>
     * Attention: The startIndentationLevel is expanded with the internal whitespace count. This means the TwoSpacePerElementFormatter will add 4 space when you
     * pass 2.
     * </p>
     *
     * @param startIndentationLevel the start indentation level. NOT whitespace count.
     * @return New IGenFormatProvider
     */
    @PublishedMethod
    public IGenFormatProvider createTwoSpacesPerElementFormatter(int startIndentationLevel) {
        return new TwoSpacesPerElement(startIndentationLevel);
    }

    /**
     * Creates a new {@link TwoSpacesPerArray} formatter object.
     *
     * @return New IGenFormatProvider
     */
    @PublishedMethod
    public IGenFormatProvider createTwoSpacesPerArrayFormatter() {
        return new TwoSpacesPerArray();
    }

    /**
     * Creates a new {@link TwoSpacesPerArray} formatter object with a start indentation of (startIndentationLevel).
     *
     * <p>
     * Attention: The startIndentationLevel is expanded with the internal whitespace count. This means the TwoSpacePerArrayFormatter will add 4 space when you
     * pass 2.
     * </p>
     *
     * @param startIndentationLevel the start indentation level. NOT whitespace count.
     * @return New IGenFormatProvider
     */
    @PublishedMethod
    public IGenFormatProvider createTwoSpacesPerArrayFormatter(int startIndentationLevel) {
        return new TwoSpacesPerArray(startIndentationLevel);
    }
}
