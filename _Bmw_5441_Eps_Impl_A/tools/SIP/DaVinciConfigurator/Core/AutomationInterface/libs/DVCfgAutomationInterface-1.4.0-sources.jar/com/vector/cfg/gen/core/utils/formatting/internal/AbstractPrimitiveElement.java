package com.vector.cfg.gen.core.utils.formatting.internal;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.GIParameter;
import com.vector.cfg.gen.core.bswmdmodel.IGeneratorModelAccess;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelException;
import com.vector.cfg.gen.core.moduleinterface.IGeneratorPackage;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.IPrimitiveGenElement;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;
import com.vector.cfg.util.text.mixedtext.IFormatSpec;

/**
 * {@link AbstractPrimitiveElement} provides an abstract implementation for {@link IPrimitiveGenElement}s.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public abstract class AbstractPrimitiveElement<E extends AbstractPrimitiveElement<E>> extends AbstractGenElement<E> implements IPrimitiveGenElement {
    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(AbstractPrimitiveElement.class);

    private String prefix;

    private String postfix;

    /**
     * Instantiates a new abstract primitive element.
     */
    @PublishedMethod
    protected AbstractPrimitiveElement() {

    }

    /**
     * Report bswmd paramter not exists error.
     *
     * @param bswmdModelObj the bswmd model obj
     */
    @PublishedMethod
    protected void reportBswmdParamterNotExistsError(GIParameter<?> bswmdModelObj) {
        /*
         * Parameter does not exist, so report a Error
         */
        try {
            bswmdModelObj.getValueMdf();
        } catch (final BswmdModelException ex) {
            if (bswmdModelObj.getGeneratorModelAccess() instanceof IGeneratorModelAccess) {
                final IGeneratorModelAccess genMa = (IGeneratorModelAccess) bswmdModelObj.getGeneratorModelAccess();
                final IGeneratorPackage generatorPackage = genMa.getGeneratorPackage();

                generatorPackage.getGenerationProcessor().getResultSink().reportValidationResult(ex.getResults());
                comment("ERROR Erroneous value: " + ex.getResults().get(0).getDescription().getFormattedText(IFormatSpec.DEFAULT_SPEC));
            } else {
                throw ex;
            }

        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected final void generateInternal(StringBuilder builder, IGenFormatter formatter, int indent, boolean rootElement) {

        generatePrefixComment(builder);

        if (prefix != null) {
            builder.append(prefix);
        }
        generatePrimitiveInternal(builder, formatter, indent);

        if (postfix != null) {
            builder.append(postfix);
        }

        generatePostfixComment(builder);

    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    public E prefix(String prefixParam) {
        ensureObjectIsMutable();
        if (prefixParam == null) {
            throw new IllegalArgumentException("prefixParam is null");
        }

        if (prefix != null) {
            throw new IllegalStateException("The prefix was already set! It is not allowed to change the prefix.");
        }

        prefix = prefixParam;

        return (E) this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @SuppressWarnings("unchecked")
    public E postfix(String postfixParam) {
        ensureObjectIsMutable();
        if (postfixParam == null) {
            throw new IllegalArgumentException("postfixParam is null");
        }

        if (postfix != null) {
            throw new IllegalStateException("The postfix was already set! It is not allowed to change the prefix.");
        }

        postfix = postfixParam;

        return (E) this;
    }

    /**
     * Generate this primitive type, by the subclass. This method does the actual work of generating the type.
     *
     * @param builder the builder
     * @param formatter the formatter
     * @param indent the indent
     */
    @PublishedMethod
    protected abstract void generatePrimitiveInternal(StringBuilder builder, IGenFormatter formatter, int indent);

    /**
     * Copy setting to element.
     *
     * @param genElement the gen element
     */
    @PublishedMethod
    protected void copySettingToElement(AbstractPrimitiveElement<?> genElement) {
        ensureObjectIsMutable();
        if (this.getPostfixComment() != null) {
            genElement.comment(this.getPostfixComment());
        }

        if (this.getPrefixComment() != null) {
            genElement.prefixComment(this.getPrefixComment());
        }

        if (this.prefix != null) {
            genElement.prefix(this.prefix);
        }

        if (this.postfix != null) {
            genElement.postfix(this.postfix);
        }

    }

}
