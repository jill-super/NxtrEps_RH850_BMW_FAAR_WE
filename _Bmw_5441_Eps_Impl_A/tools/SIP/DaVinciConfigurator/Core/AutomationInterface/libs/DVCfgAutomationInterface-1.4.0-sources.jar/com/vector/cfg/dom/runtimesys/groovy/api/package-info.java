/**
 * The runtime system domain API is specifically designed to support runtime system related use cases.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.dom.runtimesys.groovy.api;