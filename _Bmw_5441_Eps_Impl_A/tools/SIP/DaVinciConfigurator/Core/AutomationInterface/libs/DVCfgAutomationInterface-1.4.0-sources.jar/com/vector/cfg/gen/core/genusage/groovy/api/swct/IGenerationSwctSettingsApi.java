package com.vector.cfg.gen.core.genusage.groovy.api.swct;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.gencore.swct.ISwctComponentUsage;
import com.vector.cfg.gen.core.genusage.groovy.exceptions.GeneratorNotFoundException;
import com.vector.cfg.model.access.AsrPath;

/**
 * <div class="extdoc" id="Settings"> The class {@link IGenerationSwctSettingsApi} encapsulates all settings which belong to a Swct generation process. <br/>
 * Examples:
 * <ul>
 * <li>Select the software components to execute</li>
 * <li>Retrieve the available software components</li>
 * </ul>
 *
 * </div>
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@NotThreadSafe
public interface IGenerationSwctSettingsApi {

    /**
     * Selects the passed software components by name.
     *
     * <p>
     * The names are resolved with {@link #softwareComponentByName(String)}.
     * </p>
     *
     * @param componentName the component to select
     * @param additionalComponentNames additional names to select
     * @throws GeneratorNotFoundException If no associated component could be found for one of the passed componentNames
     * @see #softwareComponentByName(String)
     */
    @PublishedMethod
    void selectSoftwareComponent(String componentName, String... additionalComponentNames);

    /**
     * Selects the passed software components.
     *
     * @param component the component to select
     * @param additionalComponent additional names to select
     * @throws GeneratorNotFoundException If no associated component could be found for one of the passed componentNames
     */
    @PublishedMethod
    void selectSoftwareComponent(ISwctComponentUsage component, ISwctComponentUsage... additionalComponent);

    /**
     * This method selects a List of {{@link ISwctComponentUsage} to be executed. <br/>
     * Already selected component are not removed by this method. <br/>
     *
     * @param component List of ISwctComponentUsage to select
     */
    @PublishedMethod
    void selectSoftwareComponents(List<ISwctComponentUsage> component);

    /**
     * Selects all available {{@link ISwctComponentUsage} to be executed.
     *
     */
    @PublishedMethod
    void selectAll();

    /**
     * Deselects all available {{@link ISwctComponentUsage} to be executed.
     */
    @PublishedMethod
    void deselectAll();

    /**
     * Deselects the passed software components by name.
     *
     * <p>
     * The names are resolved with {@link #softwareComponentByName(String)}.
     * </p>
     *
     * @param componentName name of the component to deselect
     * @param additionalComponentNames additional names to deselect
     */
    @PublishedMethod
    void deselectSoftwareComponent(String componentName, String... additionalComponentNames);

    /**
     * Deselects the passed software components.
     *
     * @param component the component to deselect
     * @param additionalComponents additional names to deselect
     */
    @PublishedMethod
    void deselectSoftwareComponent(ISwctComponentUsage component, ISwctComponentUsage... additionalComponents);

    /**
     * Deselects the passed software components.
     *
     * @param components the components to deselect
     */
    @PublishedMethod
    void deselectSoftwareComponents(List<ISwctComponentUsage> components);

    /**
     * Returns all valid Swct software components in this project.
     *
     * @return list of available software components.
     */
    @PublishedMethod
    List<ISwctComponentUsage> getAllSoftwareComponents();

    /**
     * Searches the component by name, and the first match is returned.
     * <p>
     * First the {@link ISwctComponentUsage#getName()} is tested. If nothing is found the componentName is converted to an {@link AsrPath}, and the tested against
     * {@link ISwctComponentUsage#getAsrPath()}. If still nothing found, an {@link GeneratorNotFoundException} is thrown.
     * </p>
     *
     * @param componentName the component name
     * @return the found component
     * @exception GeneratorNotFoundException If no associated component could be found for the passed componentName.
     */
    @PublishedMethod
    ISwctComponentUsage softwareComponentByName(String componentName);

    /**
     * Searches the component by name, and the first match is returned.
     * <p>
     * The {@link ISwctComponentUsage#getAsrPath()} is tested against the componentPath. If nothing found, an {@link GeneratorNotFoundException} is thrown.
     * </p>
     *
     * @param componentName the component name
     * @return the found component
     * @exception GeneratorNotFoundException If no associated component could be found for the passed componentName.
     */
    @PublishedMethod
    ISwctComponentUsage softwareComponentByAsrPath(AsrPath componentPath);

    /**
     * Returns the selected generators.
     *
     * @return selected generators
     */
    @PublishedMethod
    List<ISwctComponentUsage> getSelectedSoftwareComponents();

    /**
     * Overtakes the selected software components from the project file.
     */
    @PublishedMethod
    void loadProjectSettings();

}
