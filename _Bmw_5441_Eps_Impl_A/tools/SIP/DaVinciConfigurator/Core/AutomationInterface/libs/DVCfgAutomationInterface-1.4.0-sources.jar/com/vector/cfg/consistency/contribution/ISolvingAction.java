package com.vector.cfg.consistency.contribution;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.cfg.consistency.IHasDescription;

/**
 *
 * An IValidationResult may have one or more SolvingActions, whereby one of these can be the AutoSolvingAction. A SolvingAction is a runnable with a descriptive
 * text. see {@link http://wiki.vi.vector.int/wiki-psc/Cfg5Development/Consistency}
 *
 *
 * <p>
 * For variant aware {@link ISolvingAction}, also the the interface {@link IVariantSolvingAction}. This marks a solving action that it is variant aware!
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.CHANGES_FORBIDDEN)
public interface ISolvingAction extends Runnable, IHasDescription {

}
