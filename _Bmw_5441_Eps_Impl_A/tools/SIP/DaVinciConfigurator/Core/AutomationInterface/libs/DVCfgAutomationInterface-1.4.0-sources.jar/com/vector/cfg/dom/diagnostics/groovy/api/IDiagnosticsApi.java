package com.vector.cfg.dom.diagnostics.groovy.api;

import java.util.List;

import javax.annotation.Nonnull;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.dom.diagnostics.groovy.events.IDemEvent;
import com.vector.cfg.dom.diagnostics.groovy.events.INewDemEventApi;
import com.vector.cfg.util.scripting.groovy.VDelegatesToWithClosureParam;

import groovy.lang.Closure;

/**
 * {@link IDiagnosticsApi} provides high convenience support for diagnostics related use cases.
 * <div class="extdoc" id="IDiagnosticsApi"><!--Label:IDiagnosticsApi-->{@link IDiagnosticsApi} provides high convenience support for diagnostics related use cases.</div>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IDiagnosticsApi {

    /**
     * {@link #getDemEvents()} returns a list of all {@link IDemEvent}s in the configuration.
     *
     * <div class="extdoc" id="getDemEvents"><!--Label:IDiagnosticsApi.getDemEvents-->
     * <h5>Accessing Dem Events</h5>{@link #getDemEvents()} returns a list of all {@link IDemEvent}s in the configuration.</div>
     *
     * @return a list of all {@link IDemEvent}s in the configuration (never {@code null}, may be empty)
     */
    @PublishedMethod
    List<IDemEvent> getDemEvents();

    /**
     * {@link #isJ1939Enabled()} checks, if J1939 is licensed and the J1939Nm module is active in the configuration.
     *
     * <div class="extdoc" id="isJ1939Enabled"><!--Label:IDiagnosticsApi.isJ1939Enabled-->
     * <h5>Check for J1939</h5>{@link #isJ1939Enabled()} checks, if J1939 is available in the configuration. This means, that the J1939 feature is licensed and the J1939Nm
     * module is active in this configuration.</div>
     *
     * @return {@code true} if J1939 is enabled in the configuration, otherwise {@code false}.
     */
    @PublishedMethod
    boolean isJ1939Enabled();

    /**
     * {@link #setJ1939Enabled(boolean)} enables or disables J1939 in the configuration.
     *
     * <div class="extdoc" id="setJ1939Enabled"><!--Label:IDiagnosticsApi.setJ1939Enabled-->
     * <h5>Enable J1939</h5>{@link #setJ1939Enabled(boolean)} enables or disables J1939 in the configuration. This means, that it will activate or deactivate the J1939Nm module.
     * Note, that J1939 can only be enabled, if a valid SIP license was found.</div>
     *
     * @param obd2Enabled
     */
    @PublishedMethod
    void setJ1939Enabled(boolean j1939Enabled);

    /**
     * {@link #isObd2Enabled()} checks, if OBD II is licensed and enabled in the configuration.
     *
     * <div class="extdoc" id="isObd2Enabled"><!--Label:IDiagnosticsApi.isObd2Enabled-->
     * <h5>Check for OBD II</h5>{@link #isObd2Enabled()} checks, if OBD II is available in the configuration.</div>
     *
     * @return {@code true} if OBD II is enabled in the configuration, otherwise {@code false}.
     */
    @PublishedMethod
    boolean isObd2Enabled();

    /**
     * {@link #setObd2Enabled(boolean)} enables or disables OBD II in the configuration.
     *
     * <div class="extdoc" id="setObd2Enabled"><!--Label:IDiagnosticsApi.setObd2Enabled-->
     * <h5>Enable OBD II</h5>{@link #setObd2Enabled(boolean)} enables or disables OBD II in the configuration. Note, that OBD II can only be enabled, if a valid SIP license was
     * found.</div>
     *
     * @param obd2Enabled
     */
    @PublishedMethod
    void setObd2Enabled(boolean obd2Enabled);

    /**
     * {@link #isWwhObdEnabled()} checks, if WWH-OBD is licensed and enabled in the configuration.
     *
     * <div class="extdoc" id="isWwhObdEnabled"><!--Label:IDiagnosticsApi.isWwhObdEnabled-->
     * <h5>Check for WWH-OBD</h5>{@link #isWwhObdEnabled()} checks, if WWH-OBD is available in the configuration.</div>
     *
     * @return {@code true} if WWH-OBD is enabled in the configuration, otherwise {@code false}.
     */
    @PublishedMethod
    boolean isWwhObdEnabled();

    /**
     * {@link #setWwhObdEnabled(boolean)} enables or disables WWH-OBD in the configuration.
     *
     * <div class="extdoc" id="setWwhObdEnabled"><!--Label:IDiagnosticsApi.setWwhObdEnabled-->
     * <h5>Enable WWH-OBD</h5>{@link #setWwhObdEnabled(boolean)} enables or disables WWH-OBD in the configuration. Note, that WWH-OBD can only be enabled, if a valid SIP license
     * was found.</div>
     *
     * @param wwhObdEnabled
     */
    @PublishedMethod
    void setWwhObdEnabled(boolean wwhObdEnabled);

    /**
     * {@link #setOBDMaster()} enabled the OBD mode for a Master ECU.
     *
     * <div class="extdoc" id="setOBDMaster"><!--Label:IDiagnosticsApi.setOBDMaster-->
     * <h5>Set OBD mode for a Master ECU</h5>{@link #setOBDMaster()} sets the parameter {@code Dem/DemGeneral/DemOBDSupport} to the value {@code DEM_OBD_MASTER_ECU}.</div>
     *
     */
    @PublishedMethod
    void setOBDMaster();

    /**
     * {@link #createDemEvent(Closure)} can be used to create a new Dem event of various types.
     *
     * <div class="extdoc" id="createDemEvent"><!--Label:IDiagnosticsApi.createDemEvent-->
     * <h5>Creating Dem Events</h5>{@link #createDemEvent(Closure)} is used to create diagnostic events of different kinds.</div>
     *
     * @param code the code (a {@link Closure}) used to create a diagnostic event. See {@link INewDemEventApi} on how events can be created.
     * @return the {@link IDemEvent} create by the given {@link Closure}.
     */
    @PublishedMethod
    IDemEvent createDemEvent(@Nonnull @VDelegatesToWithClosureParam(INewDemEventApi.class) Closure<?> code);

}
