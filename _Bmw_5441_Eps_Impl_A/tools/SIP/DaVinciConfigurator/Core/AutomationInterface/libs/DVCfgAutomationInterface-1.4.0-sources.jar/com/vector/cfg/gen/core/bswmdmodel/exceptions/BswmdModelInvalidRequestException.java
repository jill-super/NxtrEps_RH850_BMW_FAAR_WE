package com.vector.cfg.gen.core.bswmdmodel.exceptions;

import java.util.List;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.consistency.contribution.IValidationResult;
import com.vector.cfg.gen.core.bswmdmodel.GIModelObject;
import com.vector.cfg.util.log.ILogger;
import com.vector.cfg.util.log.Logger;

/**
 * The {@link BswmdModelInvalidRequestException} represents any invalid request issued by an untyped access to the BswmdModel.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public final class BswmdModelInvalidRequestException extends BswmdModelException {
    private static final long serialVersionUID = 5604493204019388541L;

    @SuppressWarnings("unused")
    private static final ILogger logger = Logger.INSTANCE.createLogger(BswmdModelInvalidRequestException.class);

    /**
     * Constructor for BswmdModelInvalidRequestException.
     *
     * @param generatorResults the generator results
     * @param parent the parent
     * @param ex
     */
    @PublishedMethod
    public BswmdModelInvalidRequestException(List<? extends IValidationResult> generatorResults, GIModelObject parent, Throwable cause) {
        super(generatorResults, parent, cause);
    }

    /**
     * Constructor for BswmdModelInvalidRequestException.
     *
     * @param generatorResults the generator results
     * @param parent the parent
     * @param ex
     */
    @PublishedMethod
    public BswmdModelInvalidRequestException(List<? extends IValidationResult> generatorResults, GIModelObject parent) {
        super(generatorResults, parent);
    }

    /**
     * Constructor for BswmdModelInvalidRequestException.
     *
     * @param generatorResult the generator result
     * @param parent the parent
     */
    @PublishedMethod
    public BswmdModelInvalidRequestException(IValidationResult generatorResult, GIModelObject parent) {
        super(generatorResult, parent);
    }

}
