package com.vector.cfg.gen.core.bswmdmodel;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelReferenceTargetException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIContainer;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MIReferenceValue;

/**
 * Base interface of bswmd model references which point to a {@link GIContainer}.
 *
 * <div class="extdoc" id="Common"> The following references are references to container (References pointing to container) and are subtypes of the
 * {@link GIReferenceToContainer}.
 * <ul>
 * <li>Normal Reference</li>
 * <li>SymbolicNameReference</li>
 * <li>ChoiceReference</li>
 * </ul>
 *
 * <p>
 * References have the method <code>getRefTarget()</code>, which returns the target as BswmdModel object. If the type of the target is known at model generation time, the return
 * type will be the generated type, otherwise the return type is {@link GIContainer}.
 * </p>
 * <p>
 * <b>Note: </b>It is always allowed to call <code>getRefTarget()</code>, also for references pointing to external types.
 * </p>
 *
 * There is the other method <code>getPossibleRefTargets()</code>, which returns all possible target container as list. If the type of the targets is known at model generation
 * time, the list type will be the generated type, e.G. <code>List&lt;CanGeneral&gt;</code>. Otherwise the return type is <code>List<{@link GIContainer}></code>.</div>
 *
 * <p>
 * All method parameters must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
// CHECKSTYLE:OFF Class Naming problem
public interface GIReferenceToContainer extends GIReference<MIContainer> {
    // CHECKSTYLE:ON

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    MIReferenceValue getMdfObject();

    /**
     * Returns the resolved target object as BswmdModel object instead of {@link MIObject}.
     *
     * @return
     *
     * @exception BswmdModelReferenceTargetException
     * <ul>
     * <li>if the target of the reference is null or has an invalid value.</li>
     * </ul>
     */
    @PublishedMethod
    GIContainer getRefTarget();

    /**
     * Returns all possible reference target container as list.
     */
    @PublishedMethod
    List<? extends GIContainer> getPossibleRefTargets();
}
