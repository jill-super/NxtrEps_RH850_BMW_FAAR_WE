package com.vector.cfg.gen.core.utils.formatting.primitives;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.param.GString;
import com.vector.cfg.gen.core.utils.formatting.IGenElement;
import com.vector.cfg.gen.core.utils.formatting.IGenFormatter;
import com.vector.cfg.gen.core.utils.formatting.internal.AbstractPrimitiveElement;
import com.vector.cfg.gen.core.utils.frameworkinternal.GeneratorUtilFrameworkHelper;
import com.vector.cfg.gen.core.utils.templateutils.TemplateUtil;

/**
 * The format element for String/MDF enum objects
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class StringGenElement extends AbstractPrimitiveElement<StringGenElement> {

    private String stringObj;

    private boolean isWithQuotes;

    private GString bswmdModelObj;

    private boolean convertToUpperWithUnderScore;

    private String upperscoreMsn;

    private StringGenElement() {
        isWithQuotes = false;
    }

    /**
     * Constructor for StringGenElement.
     *
     * @param obj
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if stringObj is null</li>
     * </ul>
     */
    StringGenElement(String stringObj) {
        this();

        if (stringObj == null) {
            throw new IllegalArgumentException("stringObj is null");
        }

        this.stringObj = stringObj;

    }

    /**
     * Constructor for StringGenElement.
     *
     * @param gString
     *
     * @exception IllegalArgumentException
     * <ul>
     * <li>if gString is null</li>
     * </ul>
     */
    StringGenElement(GString gString) {
        this();
        if (gString == null) {
            throw new IllegalArgumentException("gString is null");
        }

        bswmdModelObj = gString;

        if (!bswmdModelObj.existsMDF()) {

            reportBswmdParamterNotExistsError(bswmdModelObj);

            this.stringObj = "";

        } else {
            this.stringObj = gString.getValue();
        }
    }

    /**
     * Generates Quotes around the string value. Normally a string is generated as it is. <br/>
     * The following output is generated: "&lt;Value&gt;".
     *
     *
     * <p>
     * <b>Note:</b> You have to call {@link IGenElement#generate()} to get the result.
     * </p>
     *
     * @return The GenElement
     */
    @PublishedMethod
    public StringGenElement withQuotes() {
        ensureObjectIsMutable();
        isWithQuotes = true;
        return this;
    }

    /**
     * Converts the content into uppercase and replaces CamelCase notation into UPPER_WITH_UNDERSCORE.
     * <p>
     * Leading module ShortName of the GeneratorPackage is preserved. E.g. NvMTestParam is converted to NVM_TEST_PARAM
     * </p>
     *
     * @return the GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if toUpperCaseWithUnderscore() was already called</li>
     * </ul>
     */
    @PublishedMethod
    public StringGenElement toUpperCaseWithUnderscore() {
        ensureObjectIsMutable();
        if (convertToUpperWithUnderScore) {
            throw new IllegalStateException("The toUpperCaseWithUnderscore() method was already called. You can not call the format method twice.");
        }
        convertToUpperWithUnderScore = true;
        return this;
    }

    /**
     * Converts the content into uppercase and replaces CamelCase notation into UPPER_WITH_UNDERSCORE.
     * <p>
     * Leading msn of the elemnt is preserved. E.g. NvMTestParam is converted to NVM_TEST_PARAM
     * </p>
     *
     * @param msn The msn of the element, which will be preserved
     * @return the GenElement
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if toUpperCaseWithUnderscore() was already called</li>
     * </ul>
     */
    @PublishedMethod
    public StringGenElement toUpperCaseWithUnderscore(String msn) {
        ensureObjectIsMutable();
        if (convertToUpperWithUnderScore) {
            throw new IllegalStateException("The toUpperCaseWithUnderscore() method was already called. You can not call the format method twice.");
        }
        convertToUpperWithUnderScore = true;
        upperscoreMsn = msn;
        return this;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected void generatePrimitiveInternal(StringBuilder builder, IGenFormatter formatter, int indent) {

        if (isWithQuotes) {
            builder.append("\"");
        }

        String data = "";

        if (convertToUpperWithUnderScore) {
            final String msn;
            if (upperscoreMsn != null) {
                msn = upperscoreMsn;
            } else {
                msn = GeneratorUtilFrameworkHelper.getCurrentGeneratorPackage().getMSN();
            }
            data = TemplateUtil.convertCamelCaseToUppercaseWithUnderScore(stringObj, msn);
        } else {
            data = stringObj.toString();
        }

        builder.append(data);

        if (isWithQuotes) {

            builder.append("\"");
        }
    }
}
