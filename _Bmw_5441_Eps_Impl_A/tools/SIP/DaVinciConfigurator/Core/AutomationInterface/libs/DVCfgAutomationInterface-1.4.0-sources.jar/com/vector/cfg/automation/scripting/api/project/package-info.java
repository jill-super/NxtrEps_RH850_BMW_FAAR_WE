/**
 * AutomationInterface project API for client side scripts for Groovy code. This package provides access to loaded project with the
 * {@link com.vector.cfg.automation.scripting.api.project.IProject} interface.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 */
package com.vector.cfg.automation.scripting.api.project;