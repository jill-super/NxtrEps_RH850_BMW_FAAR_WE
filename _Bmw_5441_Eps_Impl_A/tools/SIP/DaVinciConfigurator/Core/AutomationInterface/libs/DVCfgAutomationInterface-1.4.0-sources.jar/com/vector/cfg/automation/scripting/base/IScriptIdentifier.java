package com.vector.cfg.automation.scripting.base;

import javax.annotation.concurrent.ThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IScriptIdentifier} defines the common methods in {@link IScriptContainer}s and {@link IScript}s to identify them in the system.
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@ThreadSafe
public interface IScriptIdentifier extends Comparable<IScriptIdentifier> {

    /**
     * Returns the name of the script or script container.
     * <p>
     * Note: this is the simple name without any qualifier.
     * </p>
     *
     * @return the script name
     */
    @PublishedMethod
    String getScriptName();

    /**
     * Returns the path to the script or script container in the file system.
     *
     * @return the script path
     */
    @PublishedMethod
    IScriptPath getScriptPath();
}
