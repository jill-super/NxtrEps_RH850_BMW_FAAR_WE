package com.vector.cfg.automation.scripting.base;

import javax.annotation.Nullable;
import javax.annotation.concurrent.Immutable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * {@link IScriptTaskExecutionResult} represents the result of one {@link IScriptTask} execution. The result contains:
 * <ul>
 * <li>Return value of the task code</li>
 * <li>System out</li>
 * <li>System error</li>
 * <li>Logger entries made to the script logger, see {@link IScript#getScriptLogger()}</li>
 * </ul>
 *
 * <p>
 * All method parameters and return values must be non-null unless documented otherwise.
 * </p>
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 *
 * @see IScriptTask
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
@Immutable
public interface IScriptTaskExecutionResult {

    /**
     * Gets the task, which had generated this execution result.
     *
     * @return the executed task
     */
    @PublishedMethod
    IScriptTask getTask();

    /**
     * Returns the log messages made to the script logger of the {@link IScript#getScriptLogger()} during the {@link IScriptTask} execution.
     *
     * <p>
     * The log messages are concatenated to one String.
     * </p>
     *
     * @return the script log messages of the task execution
     */
    @PublishedMethod
    String getScriptLogMessages();

    /**
     * Returns the return value of the executed {@link IScriptTask}.
     *
     * @return the return value
     *
     * @exception IllegalStateException
     * <ul>
     * <li>if the {@link IScriptTaskExecutionResult} was not newly created, but retrieved later in time. The result is not available anymore after execution.</li>
     * </ul>
     */
    @PublishedMethod
    @Nullable
    Object getReturnValue();

}