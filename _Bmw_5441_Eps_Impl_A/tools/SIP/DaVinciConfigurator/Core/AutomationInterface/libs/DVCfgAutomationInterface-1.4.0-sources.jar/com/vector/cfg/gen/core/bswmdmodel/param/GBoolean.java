package com.vector.cfg.gen.core.bswmdmodel.param;

import javax.annotation.Nullable;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.annotations.publishedapi.ReworkThisAtNextBreakingChange;
import com.vector.cfg.gen.core.bswmdmodel.GIBoolParameter;
import com.vector.cfg.gen.core.bswmdmodel.GIContainer;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.BswmdModelInternalElementFactory;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.GAbstractParam;
import com.vector.cfg.gen.core.bswmdmodel.modelintern.IInternalGeneratorModelAccess;
import com.vector.cfg.gen.core.utils.formatting.primitives.BoolGenElement;
import com.vector.cfg.gen.core.utils.formatting.primitives.F;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucBooleanDefinition;
import com.vector.cfg.model.access.ecuconfiguration.elements.IEcucParameter;
import com.vector.cfg.model.access.ecuconfiguration.elements.parameter.IEcucBooleanParameter;
import com.vector.cfg.model.mdf.model.autosar.commonpatterns.varianthandling.attributevaluevariationpoints.MINumericalValueVariationPoint;
import com.vector.cfg.model.mdf.model.autosar.ecucdescription.MINumericalValue;
import com.vector.cfg.model.mdf.model.autosar.ecucparamdef.MIBooleanParamDef;

/**
 * Boolean parameter of a bswmd model.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public class GBoolean extends GAbstractParam<Boolean> implements GIBoolParameter {

    private Boolean value;

    /**
     * Constructor.
     */
    @KeepSecretFromPublishedApi
    public GBoolean(IInternalGeneratorModelAccess modelAccess, DefRef defRef, MINumericalValue parameter, GIContainer parent, boolean onlyOneElement) {
        super(modelAccess, defRef, parameter, parent, onlyOneElement);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MINumericalValue getMdfObject() {
        return (MINumericalValue) super.getMdfObject();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    protected MINumericalValue getMdfObjectUnsafe() {
        return (MINumericalValue) super.getMdfObjectUnsafe();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    @ReworkThisAtNextBreakingChange("Remove method - implemented in base type")
    public boolean hasValue() {
        return super.hasValue();
    }

    @Nullable
    private MINumericalValueVariationPoint getValueVariationPoint() {
        try {
            switchView();

            if (getMdfObject() != null) {
                return getMdfObject().getValue();
            }
            return null;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @Override
    @PublishedMethod
    public Boolean getValue() {
        return getValueMdf();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Boolean getValueOrDefault(Boolean defaultValue) {
        if (hasValue()) {
            return getValue();
        }

        return defaultValue;
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public Boolean getValueMdf() {
        if (isValueChecked()) {
            return value;
        }
        try {
            switchView();

            getModelVerifier().assertParameterValueNotNull(this, getValueVariationPoint());
            getModelVerifier().assertParameterHasLegalValue(this, "Boolean");

            final MINumericalValue parameter = getMdfObject();
            value = getGeneratorModelAccess().getMdfModelAccess().getAsBoolean(parameter);

            setValueChecked();
            return value;

        } finally {
            restoreView();
        }
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public BoolGenElement formatValue() {
        return F.formatBool(this);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValueMdf(Boolean valueOf) {

        BswmdModelInternalElementFactory.setValueMdf(this, () -> getGeneratorModelAccess().getMdfModelAccess().setAsBoolean(getMdfObject(), valueOf));
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public void setValue(boolean newValue) {
        this.setValueMdf(newValue);
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public MIBooleanParamDef getDefinition() {
        return (MIBooleanParamDef) super.getDefinition();
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucBooleanDefinition getEcucDefinition() {

        return getGeneratorModelAccess().getEcucDefinitionAccess().def(getDefinition());
    }

    /**
     * {@inheritDoc}
     */
    @PublishedMethod
    @Override
    public IEcucBooleanParameter getEcuConfiguration() {

        final IEcucParameter cfg = super.getEcuConfiguration();
        return (IEcucBooleanParameter) cfg;
    }

}
