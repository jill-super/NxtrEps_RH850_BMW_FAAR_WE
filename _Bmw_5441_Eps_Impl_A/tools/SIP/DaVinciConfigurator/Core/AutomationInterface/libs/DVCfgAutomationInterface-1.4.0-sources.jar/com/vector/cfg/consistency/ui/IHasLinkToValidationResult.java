package com.vector.cfg.consistency.ui;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 * An interface to navigate from something e.g. an {@link ISolvingActionUI} to an {@link IValidationResultUI}.
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain({ DomainType.AUTOMATION_IF_INTERNAL_ADDONS, DomainType.AUTOMATION_IF })
public interface IHasLinkToValidationResult {
    @PublishedMethod
    IValidationResultUI getValidationResult();
}
