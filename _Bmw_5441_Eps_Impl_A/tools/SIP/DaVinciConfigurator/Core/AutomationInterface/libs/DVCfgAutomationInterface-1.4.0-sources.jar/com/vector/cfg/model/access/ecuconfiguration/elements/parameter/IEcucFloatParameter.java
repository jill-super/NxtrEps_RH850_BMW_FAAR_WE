package com.vector.cfg.model.access.ecuconfiguration.elements.parameter;

import java.math.BigDecimal;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.model.access.ecucdefinition.elements.parameter.IEcucFloatDefinition;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @since 1.0
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public interface IEcucFloatParameter extends IEcucNumericalParameter<BigDecimal> {

    /**
     * {@inheritDoc}
     */
    @SuppressWarnings("unchecked")
    @Override
    @PublishedMethod
    IEcucFloatDefinition getEcucDefinition();

    /**
     * Sets the parameter value.
     *
     * @param value
     */
    @PublishedMethod
    void setValue(double value);

}
