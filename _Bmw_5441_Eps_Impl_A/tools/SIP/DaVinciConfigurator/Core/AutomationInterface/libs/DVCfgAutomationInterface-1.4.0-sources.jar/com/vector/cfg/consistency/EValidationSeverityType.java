package com.vector.cfg.consistency;

import java.util.HashMap;
import java.util.Map;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;

/**
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.<BR>
 * <BR>
 *
 * The Severity of a IValidationResult. <BR>
 * FATAL_ERROR is not allowed for any regular IValidationResult
 * </p>
 *
 * @since 1.0
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
public enum EValidationSeverityType {

    /**
     * See class doc.
     */
    FATAL_ERROR("FatalError"),
    /**
     * See class doc.
     */
    ERROR("Error"),
    /**
     * See class doc.
     */
    WARNING("Warning"),
    /**
     * See class doc.
     */
    IMPROVEMENT("Improvement"),
    /**
     * See class doc.
     */
    INFO("Info");

    /*
     * Internal Section
     */

    private final String descriptiveName;

    EValidationSeverityType(String descriptiveName) {
        this.descriptiveName = descriptiveName;

    }

    @PublishedMethod
    public String getDescriptiveName() {
        return descriptiveName;
    }

    @PublishedMethod
    public static EValidationSeverityType fromDescriptiveName(String descriptiveName) {
        if (descriptiveName != null) {
            return map.get(descriptiveName);
        }
        return null;
    }

    @PublishedMethod
    public boolean isHigherSeverityThan(EValidationSeverityType other) {
        if (other == this) {
            return false;
        }

        if (this == FATAL_ERROR) {
            return other != FATAL_ERROR;
        } else if (this == ERROR) {
            return other != FATAL_ERROR;
        } else if (this == WARNING) {
            return other != FATAL_ERROR && other != ERROR;
        } else if (this == IMPROVEMENT) {
            return other == INFO;
        } else {
            return false;
        }
    }

    private static final Map<String, EValidationSeverityType> map = new HashMap<>();

    static {
        for (final EValidationSeverityType value : values()) {
            map.put(value.descriptiveName, value);
        }
    }

}
