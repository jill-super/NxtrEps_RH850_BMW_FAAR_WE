package com.vector.cfg.automation.api.userinteraction;

import java.util.Map;
import java.util.function.Supplier;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;

import groovy.lang.Closure;

@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IUserInputApi {

    /**
     * Request a {@link Long} values from the user. See {@link #longValue(Map, String, Long)} for more details.
     *
     * @param message the message
     * @param defaultValue the default value
     * @return the supplier
     */
    @PublishedMethod
    Supplier<Long> longValue(String message, Long defaultValue);

    /**
     * Request a {@link Long} values from the user.
     *
     * <p>
     * <b>Named parameters:</b>
     * <ul>
     * <li>min: {@link Long}</li>
     * <li>max: {@link Long}</li>
     * <li>validate: {@link Closure}</li>
     * </ul>
     * </p>
     *
     * <b>Usage examples:</b>
     *
     * <pre>
     * <code class="Groovy" id="Groovy usage examples">
     * def myInput1 = userInputs.longValue("How many Containers to create?", 1)
     * def myInput2 = userInputs.longValue("How many Parameters to create?", 2, min:10, max:80)
     * def myInput3 = userInputs.longValue("How many special items?",2, min: -5, max: 50,  validate:{currentValue->
     *       currentValue%2 ? "Number must be even": null
     *   })
     *
     * def value1 = myInput1.get()
     * def value2 = myInput2.get()
     * def value3 = myInput3.get()
     * </code>
     * </pre>
     *
     * <pre>
     * <code class="Java" id="Java usage examples">
     * Supplier&lt;Long&gt;  myInput1 = userInputs.longValue("How many Containers to create?", 1)
     * Supplier&lt;Long&gt;  myInput2 = userInputs.longValue(ImmutableMap.of("min",10,"max",80), "How many Parameters to create?", 2)
     *
     * Long value1 = myInput1.get()
     * Long value2 = myInput2.get()
     * </code>
     * </pre>
     *
     * @param properties the properties
     * @param message the message
     * @param defaultValue the default value
     * @return the supplier
     */
    @PublishedMethod
    Supplier<Long> longValue(Map<String, Object> properties, String message, Long defaultValue);

}