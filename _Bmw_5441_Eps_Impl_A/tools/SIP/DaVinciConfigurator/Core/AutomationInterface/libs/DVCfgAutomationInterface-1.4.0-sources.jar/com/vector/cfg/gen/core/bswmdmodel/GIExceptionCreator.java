package com.vector.cfg.gen.core.bswmdmodel;

import java.util.List;

import javax.annotation.concurrent.NotThreadSafe;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelInvalidRequestException;
import com.vector.cfg.gen.core.bswmdmodel.exceptions.BswmdModelReferenceTargetException;
import com.vector.cfg.gen.core.bswmdmodel.param.GChoiceReference;
import com.vector.cfg.model.access.DefRef;
import com.vector.cfg.model.exceptions.ModelException;
import com.vector.cfg.model.mdf.MIObject;
import com.vector.cfg.util.text.mixedtext.IMixedText;

/**
 * Interface class for throwing {@link BswmdModelException}s inside of the BswmdModel.
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 * @noimplement This interface is not intended to be implemented by clients.
 */
@NotThreadSafe
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
//CHECKSTYLE:OFF Class Naming problem
public interface GIExceptionCreator {
    //CHECKSTYLE:ON

    @PublishedMethod
    BswmdModelReferenceTargetException issueExceptionBecauseReferencePointsToIncorrectTarget(final GChoiceReference choiceRef, final Class<?> targetClass,
            final DefRef targetDefRef);

    @PublishedMethod
    BswmdModelException issueExceptionFromModelException(GIModelObject parent, ModelException ex);

    @PublishedMethod
    BswmdModelInvalidRequestException issueInvalidRequestExceptionWithText(GIModelObject parent, IMixedText text);

    @PublishedMethod
    BswmdModelInvalidRequestException issueInvalidRequestExceptionWithText(GIModelObject parent, IMixedText text, List<? extends MIObject> errorCEs);
}
