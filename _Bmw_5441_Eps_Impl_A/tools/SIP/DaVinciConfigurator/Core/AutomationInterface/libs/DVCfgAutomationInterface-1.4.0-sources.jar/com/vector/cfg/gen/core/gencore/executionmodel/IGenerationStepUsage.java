package com.vector.cfg.gen.core.gencore.executionmodel;

import com.vector.annotations.publishedapi.ChangePolicy;
import com.vector.annotations.publishedapi.DomainType;
import com.vector.annotations.publishedapi.KeepSecretFromPublishedApi;
import com.vector.annotations.publishedapi.PublishedApi;
import com.vector.annotations.publishedapi.PublishedApiDomain;
import com.vector.annotations.publishedapi.PublishedMethod;
import com.vector.cfg.gen.core.gencore.generationsteps.IGenerationStep;
import com.vector.cfg.gen.core.moduleinterface.EGenerationPhaseType;

/**
 * This class represents one specific usage (execution) of a generation step. <br/>
 *
 *
 * <p>
 * (c) Copyright Vector Informatik GmbH. All Rights Reserved.
 * </p>
 *
 */
@PublishedApi(ChangePolicy.ADDITIONS_ALLOWED)
@PublishedApiDomain(DomainType.AUTOMATION_IF)
public interface IGenerationStepUsage {

    /**
     * Returns the wrapped {@link IGenerationStep}.
     *
     * @return the generation step
     */
    @PublishedMethod
    IGenerationStep getGenerationStep();

    /**
     * Returns the name of the external generation step. <br/>
     * The name is also treated as the ID.
     *
     * @return the name
     */
    @PublishedMethod
    String getName();

    /**
     * Returns the selection status of the external generation step.<br/>
     * If the step is selected, it will be executed on the next generation process.
     *
     * @return
     */
    @PublishedMethod
    boolean isSelected();

    /**
     * Returns <code>true</code>, if the step shall be executen in the validation phase {@link EGenerationPhaseType.VALIDATION}.
     *
     * @return
     */
    @PublishedMethod
    boolean isValidation();

    /**
     * Returns <code>true</code>, if the enum is {@link #GENERATION}.
     *
     * @return true, if is generation
     */
    @PublishedMethod
    boolean isGeneration();

    /**
     * Checks if step shall be executed parallel to other parallel neighbor steps.
     *
     * @return true, if is parallel execution
     */
    @PublishedMethod
    boolean isParallelExecution();

    /**
     * Selects the step for execution.
     */
    @PublishedMethod
    void select();

    /**
     * Sets the current Object to read only. If read only is enabled, changes on this object result in an {@link IllegalStateException}. <br/>
     *
     */
    @KeepSecretFromPublishedApi
    void setReadOnly();
}
