@echo off
polyspace-code-prover-nodesktop.exe -options-file server-options.opt
