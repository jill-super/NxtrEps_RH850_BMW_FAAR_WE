typedef char __PST__CHAR;
typedef void __PST__VOID;
typedef signed char __PST__SINT8;
typedef signed short __PST__SINT16;
typedef signed int __PST__SINT32;
typedef signed long long __PST__SINT64;
typedef unsigned char __PST__UINT8;
typedef unsigned short __PST__UINT16;
typedef unsigned int __PST__UINT32;
typedef unsigned long long __PST__UINT64;
typedef float __PST__FLOAT32;
typedef __PST__VOID *__PST__g__11;
typedef double __PST__FLOAT64;
typedef __PST__VOID __PST__g__15(void);
typedef __PST__UINT32 *__PST__g__17;
typedef __PST__VOID __PST__g__16(__PST__g__17);
typedef __PST__VOID __PST__g__18(__PST__UINT16, __PST__UINT8, __PST__UINT8);
typedef __PST__FLOAT64 __PST__g__19(void);
typedef __PST__g__11 *__PST__g__21;
typedef volatile __PST__FLOAT64 __PST__g__22;
typedef __PST__SINT8 *__PST__g__24;
typedef volatile __PST__g__24 __PST__g__23;
typedef __PST__SINT8 __PST__g__54[4];
typedef __PST__SINT32 __PST__g__55[1];
union __PST__g__31
  {
    __PST__g__55 __pst_unused_field_0;
    __PST__UINT32 UINT32;
  };
struct __PST__g__26
  {
    __PST__g__54 __pst_unused_field_0;
    __PST__g__54 __pst_unused_field_1;
    union __PST__g__31 DAT2;
    __PST__g__54 __pst_unused_field_3;
  };
typedef volatile struct __PST__g__26 __PST__g__25;
union __PST__g__27
  {
    __PST__g__55 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__28
  {
    __PST__UINT32 __pst_unused_field_0 : 32;
  };
union __PST__g__29
  {
    __PST__g__55 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__30
  {
    __PST__UINT32 __pst_unused_field_0 : 32;
  };
struct __PST__g__32
  {
    __PST__UINT32 __pst_unused_field_0 : 32;
  };
union __PST__g__33
  {
    __PST__g__55 __pst_unused_field_0;
    __PST__UINT32 __pst_unused_field_1;
  };
struct __PST__g__34
  {
    __PST__UINT32 __pst_unused_field_0 : 32;
  };
typedef __PST__VOID __PST__g__35(__PST__SINT32);
typedef __PST__g__25 *__PST__g__36;
typedef volatile union __PST__g__31 __PST__g__37;
typedef __PST__g__37 *__PST__g__38;
typedef volatile __PST__UINT32 __PST__g__39;
typedef __PST__g__39 *__PST__g__40;
typedef __PST__g__15 *__PST__g__41;
typedef volatile __PST__SINT32 __PST__g__42;
typedef __PST__SINT8 __PST__g__48(void);
typedef volatile __PST__SINT8 __PST__g__49;
typedef __PST__UINT8 __PST__g__50(void);
typedef volatile __PST__UINT8 __PST__g__51;
typedef __PST__SINT32 __PST__g__52(void);
typedef __PST__UINT32 __PST__g__53(void);
