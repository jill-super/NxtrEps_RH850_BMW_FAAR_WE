#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT32 _main_gen_init_g8(void);

extern union __PST__g__31 _main_gen_init_g31(void);

extern __PST__g__25 _main_gen_init_g25(void);

union __PST__g__31 _main_gen_init_g31(void)
{
    static union __PST__g__31 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__25 _main_gen_init_g25(void)
{
    __PST__g__25 x;
    /* struct/union type */
    x.DAT2 = _main_gen_init_g31();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_BRAM(void)
{
    extern __PST__g__25 BRAM;
    
    /* initialization with random value */
    {
        BRAM = _main_gen_init_g25();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable BRAM */
    _main_gen_init_sym_BRAM();
    
}
