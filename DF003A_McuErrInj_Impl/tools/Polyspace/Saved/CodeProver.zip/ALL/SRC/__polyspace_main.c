#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT16 _main_gen_init_g7(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_ReadErrInjReg_Oper(void)
{
    extern __PST__VOID ReadErrInjReg_Oper(__PST__g__17);

    __PST__g__17 __arg__0;
    
    /* pointer */
    {
        static __PST__UINT32 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT32)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT32); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g8();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT32) / 2];
    }
    
    /* call it */
    ReadErrInjReg_Oper(__arg__0);
}

static void _main_gen_call_UpdErrInjReg_Oper(void)
{
    extern __PST__VOID UpdErrInjReg_Oper(__PST__UINT16, __PST__UINT8, __PST__UINT8);

    __PST__UINT16 __arg__0;
    __PST__UINT8 __arg__1;
    __PST__UINT8 __arg__2;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g6();
    __arg__2 = _main_gen_init_g6();
    
    /* call it */
    UpdErrInjReg_Oper(__arg__0, __arg__1, __arg__2);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function ClrErrInjReg_Oper */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID ClrErrInjReg_Oper(__PST__VOID);

            ClrErrInjReg_Oper();
        }
        
        /* call of function McuErrInjInit1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID McuErrInjInit1(__PST__VOID);

            McuErrInjInit1();
        }
        
        /* call of function McuErrInjPer1 */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID McuErrInjPer1(__PST__VOID);

            McuErrInjPer1();
        }
        
        /* call of function ReadErrInjReg_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_ReadErrInjReg_Oper();
        }
        
        /* call of function UpdErrInjReg_Oper */
        if (PST_TRUE())
        {
            _main_gen_call_UpdErrInjReg_Oper();
        }
        
        /* call of function McuDiagcTestTrustd */
        if (PST_TRUE())
        { /* call it */
            extern __PST__VOID McuDiagcTestTrustd(__PST__VOID);

            McuDiagcTestTrustd();
        }
        
    }
}
