#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT16 pst_random_g_7;
static volatile __PST__SINT16 pst_random_g_3;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern __PST__SINT16 _main_gen_init_g3(void);

extern __PST__UINT16 _main_gen_init_g7(void);

__PST__UINT16 _main_gen_init_g7(void)
{
    __PST__UINT16 x;
    /* base type */
    x = pst_random_g_7;
    return x;
}

__PST__SINT16 _main_gen_init_g3(void)
{
    __PST__SINT16 x;
    /* base type */
    x = pst_random_g_3;
    return x;
}


/* Definition of variables init procedures */


/* Definition of functions */

static void _main_gen_call_LnrIntrpn_u16_u16FixdXu16VariY(void)
{
    extern __PST__UINT16 LnrIntrpn_u16_u16FixdXu16VariY(__PST__UINT16, __PST__g__16, __PST__UINT16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__16 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__UINT16 __arg__3;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_1;
        for (_i_main_gen_tmp_1 = 0; _i_main_gen_tmp_1 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_1++)
        {
            _main_gen_tmp_0[_i_main_gen_tmp_1] = _main_gen_init_g7();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_0[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = LnrIntrpn_u16_u16FixdXu16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpn_s16_u16FixdXs16VariY(void)
{
    extern __PST__SINT16 LnrIntrpn_s16_u16FixdXs16VariY(__PST__UINT16, __PST__g__19, __PST__UINT16, __PST__UINT16);

    __PST__SINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__19 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__UINT16 __arg__3;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_2[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_3;
        for (_i_main_gen_tmp_3 = 0; _i_main_gen_tmp_3 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_3++)
        {
            _main_gen_tmp_2[_i_main_gen_tmp_3] = _main_gen_init_g3();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_2[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = LnrIntrpn_s16_u16FixdXs16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpn_u16_u16VariXu16VariY(void)
{
    extern __PST__UINT16 LnrIntrpn_u16_u16VariXu16VariY(__PST__g__16, __PST__g__16, __PST__UINT16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__g__16 __arg__0;
    __PST__g__16 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__UINT16 __arg__3;
    
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_5;
        for (_i_main_gen_tmp_5 = 0; _i_main_gen_tmp_5 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_5++)
        {
            _main_gen_tmp_4[_i_main_gen_tmp_5] = _main_gen_init_g7();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_4[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_7;
        for (_i_main_gen_tmp_7 = 0; _i_main_gen_tmp_7 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_7++)
        {
            _main_gen_tmp_6[_i_main_gen_tmp_7] = _main_gen_init_g7();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_6[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = LnrIntrpn_u16_u16VariXu16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpn_u16_s16VariXu16VariY(void)
{
    extern __PST__UINT16 LnrIntrpn_u16_s16VariXu16VariY(__PST__g__19, __PST__g__16, __PST__UINT16, __PST__SINT16);

    __PST__UINT16 __ret__;
    __PST__g__19 __arg__0;
    __PST__g__16 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__SINT16 __arg__3;
    
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_8[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_9;
        for (_i_main_gen_tmp_9 = 0; _i_main_gen_tmp_9 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_9++)
        {
            _main_gen_tmp_8[_i_main_gen_tmp_9] = _main_gen_init_g3();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_8[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_11;
        for (_i_main_gen_tmp_11 = 0; _i_main_gen_tmp_11 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_11++)
        {
            _main_gen_tmp_10[_i_main_gen_tmp_11] = _main_gen_init_g7();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_10[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = LnrIntrpn_u16_s16VariXu16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpn_s16_s16VariXs16VariY(void)
{
    extern __PST__SINT16 LnrIntrpn_s16_s16VariXs16VariY(__PST__g__19, __PST__g__19, __PST__UINT16, __PST__SINT16);

    __PST__SINT16 __ret__;
    __PST__g__19 __arg__0;
    __PST__g__19 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__SINT16 __arg__3;
    
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_12[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_13;
        for (_i_main_gen_tmp_13 = 0; _i_main_gen_tmp_13 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_13++)
        {
            _main_gen_tmp_12[_i_main_gen_tmp_13] = _main_gen_init_g3();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_12[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_14[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_15;
        for (_i_main_gen_tmp_15 = 0; _i_main_gen_tmp_15 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_15++)
        {
            _main_gen_tmp_14[_i_main_gen_tmp_15] = _main_gen_init_g3();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_14[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = LnrIntrpn_s16_s16VariXs16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpn_s16_u16VariXs16VariY(void)
{
    extern __PST__SINT16 LnrIntrpn_s16_u16VariXs16VariY(__PST__g__16, __PST__g__19, __PST__UINT16, __PST__UINT16);

    __PST__SINT16 __ret__;
    __PST__g__16 __arg__0;
    __PST__g__19 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__UINT16 __arg__3;
    
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_17;
        for (_i_main_gen_tmp_17 = 0; _i_main_gen_tmp_17 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_17++)
        {
            _main_gen_tmp_16[_i_main_gen_tmp_17] = _main_gen_init_g7();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_16[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_18[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_19;
        for (_i_main_gen_tmp_19 = 0; _i_main_gen_tmp_19 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_19++)
        {
            _main_gen_tmp_18[_i_main_gen_tmp_19] = _main_gen_init_g3();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_18[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = LnrIntrpn_s16_u16VariXs16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpnWithRound_u16_u16FixdXu16VariY(void)
{
    extern __PST__UINT16 LnrIntrpnWithRound_u16_u16FixdXu16VariY(__PST__UINT16, __PST__g__16, __PST__UINT16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__16 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__UINT16 __arg__3;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_21;
        for (_i_main_gen_tmp_21 = 0; _i_main_gen_tmp_21 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_21++)
        {
            _main_gen_tmp_20[_i_main_gen_tmp_21] = _main_gen_init_g7();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_20[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = LnrIntrpnWithRound_u16_u16FixdXu16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpnWithRound_s16_u16FixdXs16VariY(void)
{
    extern __PST__SINT16 LnrIntrpnWithRound_s16_u16FixdXs16VariY(__PST__UINT16, __PST__g__19, __PST__UINT16, __PST__UINT16);

    __PST__SINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__g__19 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__UINT16 __arg__3;
    
    __arg__0 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_22[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_23;
        for (_i_main_gen_tmp_23 = 0; _i_main_gen_tmp_23 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_23++)
        {
            _main_gen_tmp_22[_i_main_gen_tmp_23] = _main_gen_init_g3();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_22[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = LnrIntrpnWithRound_s16_u16FixdXs16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpnWithRound_u16_u16VariXu16VariY(void)
{
    extern __PST__UINT16 LnrIntrpnWithRound_u16_u16VariXu16VariY(__PST__g__16, __PST__g__16, __PST__UINT16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__g__16 __arg__0;
    __PST__g__16 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__UINT16 __arg__3;
    
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_25;
        for (_i_main_gen_tmp_25 = 0; _i_main_gen_tmp_25 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_25++)
        {
            _main_gen_tmp_24[_i_main_gen_tmp_25] = _main_gen_init_g7();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_24[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_27;
        for (_i_main_gen_tmp_27 = 0; _i_main_gen_tmp_27 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_27++)
        {
            _main_gen_tmp_26[_i_main_gen_tmp_27] = _main_gen_init_g7();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_26[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = LnrIntrpnWithRound_u16_u16VariXu16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpnWithRound_u16_s16VariXu16VariY(void)
{
    extern __PST__UINT16 LnrIntrpnWithRound_u16_s16VariXu16VariY(__PST__g__19, __PST__g__16, __PST__UINT16, __PST__SINT16);

    __PST__UINT16 __ret__;
    __PST__g__19 __arg__0;
    __PST__g__16 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__SINT16 __arg__3;
    
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_28[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_29;
        for (_i_main_gen_tmp_29 = 0; _i_main_gen_tmp_29 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_29++)
        {
            _main_gen_tmp_28[_i_main_gen_tmp_29] = _main_gen_init_g3();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_28[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_31;
        for (_i_main_gen_tmp_31 = 0; _i_main_gen_tmp_31 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_31++)
        {
            _main_gen_tmp_30[_i_main_gen_tmp_31] = _main_gen_init_g7();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_30[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = LnrIntrpnWithRound_u16_s16VariXu16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpnWithRound_s16_s16VariXs16VariY(void)
{
    extern __PST__SINT16 LnrIntrpnWithRound_s16_s16VariXs16VariY(__PST__g__19, __PST__g__19, __PST__UINT16, __PST__SINT16);

    __PST__SINT16 __ret__;
    __PST__g__19 __arg__0;
    __PST__g__19 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__SINT16 __arg__3;
    
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_32[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_33;
        for (_i_main_gen_tmp_33 = 0; _i_main_gen_tmp_33 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_33++)
        {
            _main_gen_tmp_32[_i_main_gen_tmp_33] = _main_gen_init_g3();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_32[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_34[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_35;
        for (_i_main_gen_tmp_35 = 0; _i_main_gen_tmp_35 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_35++)
        {
            _main_gen_tmp_34[_i_main_gen_tmp_35] = _main_gen_init_g3();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_34[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g3();
    
    /* call it */
    __ret__ = LnrIntrpnWithRound_s16_s16VariXs16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_LnrIntrpnWithRound_s16_u16VariXs16VariY(void)
{
    extern __PST__SINT16 LnrIntrpnWithRound_s16_u16VariXs16VariY(__PST__g__16, __PST__g__19, __PST__UINT16, __PST__UINT16);

    __PST__SINT16 __ret__;
    __PST__g__16 __arg__0;
    __PST__g__19 __arg__1;
    __PST__UINT16 __arg__2;
    __PST__UINT16 __arg__3;
    
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_37;
        for (_i_main_gen_tmp_37 = 0; _i_main_gen_tmp_37 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_37++)
        {
            _main_gen_tmp_36[_i_main_gen_tmp_37] = _main_gen_init_g7();
        }
        __arg__0 = PST_TRUE() ? 0 : &_main_gen_tmp_36[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_38[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_39;
        for (_i_main_gen_tmp_39 = 0; _i_main_gen_tmp_39 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_39++)
        {
            _main_gen_tmp_38[_i_main_gen_tmp_39] = _main_gen_init_g3();
        }
        __arg__1 = PST_TRUE() ? 0 : &_main_gen_tmp_38[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    __arg__2 = _main_gen_init_g7();
    __arg__3 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = LnrIntrpnWithRound_s16_u16VariXs16VariY(__arg__0, __arg__1, __arg__2, __arg__3);
}

static void _main_gen_call_BilnrIntrpnWithRound_u16_u16CmnXu16MplY(void)
{
    extern __PST__UINT16 BilnrIntrpnWithRound_u16_u16CmnXu16MplY(__PST__UINT16, __PST__UINT16, __PST__g__16, __PST__UINT16, __PST__g__16, __PST__g__16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT16 __arg__1;
    __PST__g__16 __arg__2;
    __PST__UINT16 __arg__3;
    __PST__g__16 __arg__4;
    __PST__g__16 __arg__5;
    __PST__UINT16 __arg__6;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_41;
        for (_i_main_gen_tmp_41 = 0; _i_main_gen_tmp_41 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_41++)
        {
            _main_gen_tmp_40[_i_main_gen_tmp_41] = _main_gen_init_g7();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_40[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__3 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_42[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_43;
        for (_i_main_gen_tmp_43 = 0; _i_main_gen_tmp_43 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_43++)
        {
            _main_gen_tmp_42[_i_main_gen_tmp_43] = _main_gen_init_g7();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_42[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_45;
        for (_i_main_gen_tmp_45 = 0; _i_main_gen_tmp_45 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_45++)
        {
            _main_gen_tmp_44[_i_main_gen_tmp_45] = _main_gen_init_g7();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_44[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__6 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = BilnrIntrpnWithRound_u16_u16CmnXu16MplY(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6);
}

static void _main_gen_call_BilnrIntrpnWithRound_s16_u16CmnXs16MplY(void)
{
    extern __PST__SINT16 BilnrIntrpnWithRound_s16_u16CmnXs16MplY(__PST__UINT16, __PST__UINT16, __PST__g__16, __PST__UINT16, __PST__g__16, __PST__g__19, __PST__UINT16);

    __PST__SINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT16 __arg__1;
    __PST__g__16 __arg__2;
    __PST__UINT16 __arg__3;
    __PST__g__16 __arg__4;
    __PST__g__19 __arg__5;
    __PST__UINT16 __arg__6;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_46[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_47;
        for (_i_main_gen_tmp_47 = 0; _i_main_gen_tmp_47 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_47++)
        {
            _main_gen_tmp_46[_i_main_gen_tmp_47] = _main_gen_init_g7();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_46[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__3 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_48[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_49;
        for (_i_main_gen_tmp_49 = 0; _i_main_gen_tmp_49 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_49++)
        {
            _main_gen_tmp_48[_i_main_gen_tmp_49] = _main_gen_init_g7();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_48[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_50[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_51;
        for (_i_main_gen_tmp_51 = 0; _i_main_gen_tmp_51 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_51++)
        {
            _main_gen_tmp_50[_i_main_gen_tmp_51] = _main_gen_init_g3();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_50[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    __arg__6 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = BilnrIntrpnWithRound_s16_u16CmnXs16MplY(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6);
}

static void _main_gen_call_BilnrIntrpnWithRound_s16_s16CmnXs16MplY(void)
{
    extern __PST__SINT16 BilnrIntrpnWithRound_s16_s16CmnXs16MplY(__PST__UINT16, __PST__SINT16, __PST__g__16, __PST__UINT16, __PST__g__19, __PST__g__19, __PST__UINT16);

    __PST__SINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__SINT16 __arg__1;
    __PST__g__16 __arg__2;
    __PST__UINT16 __arg__3;
    __PST__g__19 __arg__4;
    __PST__g__19 __arg__5;
    __PST__UINT16 __arg__6;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g3();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_52[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_53;
        for (_i_main_gen_tmp_53 = 0; _i_main_gen_tmp_53 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_53++)
        {
            _main_gen_tmp_52[_i_main_gen_tmp_53] = _main_gen_init_g7();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_52[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__3 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_54[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_55;
        for (_i_main_gen_tmp_55 = 0; _i_main_gen_tmp_55 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_55++)
        {
            _main_gen_tmp_54[_i_main_gen_tmp_55] = _main_gen_init_g3();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_54[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_56[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_57;
        for (_i_main_gen_tmp_57 = 0; _i_main_gen_tmp_57 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_57++)
        {
            _main_gen_tmp_56[_i_main_gen_tmp_57] = _main_gen_init_g3();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_56[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    __arg__6 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = BilnrIntrpnWithRound_s16_s16CmnXs16MplY(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6);
}

static void _main_gen_call_BilnrIntrpnWithRound_u16_s16CmnXu16MplY(void)
{
    extern __PST__UINT16 BilnrIntrpnWithRound_u16_s16CmnXu16MplY(__PST__UINT16, __PST__SINT16, __PST__g__16, __PST__UINT16, __PST__g__19, __PST__g__16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__SINT16 __arg__1;
    __PST__g__16 __arg__2;
    __PST__UINT16 __arg__3;
    __PST__g__19 __arg__4;
    __PST__g__16 __arg__5;
    __PST__UINT16 __arg__6;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g3();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_58[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_59;
        for (_i_main_gen_tmp_59 = 0; _i_main_gen_tmp_59 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_59++)
        {
            _main_gen_tmp_58[_i_main_gen_tmp_59] = _main_gen_init_g7();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_58[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__3 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_60[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_61;
        for (_i_main_gen_tmp_61 = 0; _i_main_gen_tmp_61 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_61++)
        {
            _main_gen_tmp_60[_i_main_gen_tmp_61] = _main_gen_init_g3();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_60[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_62[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_63;
        for (_i_main_gen_tmp_63 = 0; _i_main_gen_tmp_63 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_63++)
        {
            _main_gen_tmp_62[_i_main_gen_tmp_63] = _main_gen_init_g7();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_62[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__6 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = BilnrIntrpnWithRound_u16_s16CmnXu16MplY(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6);
}

static void _main_gen_call_BilnrIntrpnWithRound_u16_u16MplXu16MplY(void)
{
    extern __PST__UINT16 BilnrIntrpnWithRound_u16_u16MplXu16MplY(__PST__UINT16, __PST__UINT16, __PST__g__16, __PST__UINT16, __PST__g__16, __PST__g__16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT16 __arg__1;
    __PST__g__16 __arg__2;
    __PST__UINT16 __arg__3;
    __PST__g__16 __arg__4;
    __PST__g__16 __arg__5;
    __PST__UINT16 __arg__6;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_64[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_65;
        for (_i_main_gen_tmp_65 = 0; _i_main_gen_tmp_65 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_65++)
        {
            _main_gen_tmp_64[_i_main_gen_tmp_65] = _main_gen_init_g7();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_64[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__3 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_66[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_67;
        for (_i_main_gen_tmp_67 = 0; _i_main_gen_tmp_67 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_67++)
        {
            _main_gen_tmp_66[_i_main_gen_tmp_67] = _main_gen_init_g7();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_66[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_68[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_69;
        for (_i_main_gen_tmp_69 = 0; _i_main_gen_tmp_69 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_69++)
        {
            _main_gen_tmp_68[_i_main_gen_tmp_69] = _main_gen_init_g7();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_68[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__6 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = BilnrIntrpnWithRound_u16_u16MplXu16MplY(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6);
}

static void _main_gen_call_BilnrIntrpnWithRound_u16_s16MplXu16MplY(void)
{
    extern __PST__UINT16 BilnrIntrpnWithRound_u16_s16MplXu16MplY(__PST__UINT16, __PST__SINT16, __PST__g__16, __PST__UINT16, __PST__g__19, __PST__g__16, __PST__UINT16);

    __PST__UINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__SINT16 __arg__1;
    __PST__g__16 __arg__2;
    __PST__UINT16 __arg__3;
    __PST__g__19 __arg__4;
    __PST__g__16 __arg__5;
    __PST__UINT16 __arg__6;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g3();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_70[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_71;
        for (_i_main_gen_tmp_71 = 0; _i_main_gen_tmp_71 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_71++)
        {
            _main_gen_tmp_70[_i_main_gen_tmp_71] = _main_gen_init_g7();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_70[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__3 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_72[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_73;
        for (_i_main_gen_tmp_73 = 0; _i_main_gen_tmp_73 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_73++)
        {
            _main_gen_tmp_72[_i_main_gen_tmp_73] = _main_gen_init_g3();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_72[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_74[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_75;
        for (_i_main_gen_tmp_75 = 0; _i_main_gen_tmp_75 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_75++)
        {
            _main_gen_tmp_74[_i_main_gen_tmp_75] = _main_gen_init_g7();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_74[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__6 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = BilnrIntrpnWithRound_u16_s16MplXu16MplY(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6);
}

static void _main_gen_call_BilnrIntrpnWithRound_s16_s16MplXs16MplY(void)
{
    extern __PST__SINT16 BilnrIntrpnWithRound_s16_s16MplXs16MplY(__PST__UINT16, __PST__SINT16, __PST__g__16, __PST__UINT16, __PST__g__19, __PST__g__19, __PST__UINT16);

    __PST__SINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__SINT16 __arg__1;
    __PST__g__16 __arg__2;
    __PST__UINT16 __arg__3;
    __PST__g__19 __arg__4;
    __PST__g__19 __arg__5;
    __PST__UINT16 __arg__6;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g3();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_76[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_77;
        for (_i_main_gen_tmp_77 = 0; _i_main_gen_tmp_77 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_77++)
        {
            _main_gen_tmp_76[_i_main_gen_tmp_77] = _main_gen_init_g7();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_76[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__3 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_78[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_79;
        for (_i_main_gen_tmp_79 = 0; _i_main_gen_tmp_79 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_79++)
        {
            _main_gen_tmp_78[_i_main_gen_tmp_79] = _main_gen_init_g3();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_78[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_80[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_81;
        for (_i_main_gen_tmp_81 = 0; _i_main_gen_tmp_81 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_81++)
        {
            _main_gen_tmp_80[_i_main_gen_tmp_81] = _main_gen_init_g3();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_80[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    __arg__6 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = BilnrIntrpnWithRound_s16_s16MplXs16MplY(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6);
}

static void _main_gen_call_BilnrIntrpnWithRound_s16_u16MplXs16MplY(void)
{
    extern __PST__SINT16 BilnrIntrpnWithRound_s16_u16MplXs16MplY(__PST__UINT16, __PST__UINT16, __PST__g__16, __PST__UINT16, __PST__g__16, __PST__g__19, __PST__UINT16);

    __PST__SINT16 __ret__;
    __PST__UINT16 __arg__0;
    __PST__UINT16 __arg__1;
    __PST__g__16 __arg__2;
    __PST__UINT16 __arg__3;
    __PST__g__16 __arg__4;
    __PST__g__19 __arg__5;
    __PST__UINT16 __arg__6;
    
    __arg__0 = _main_gen_init_g7();
    __arg__1 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_82[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_83;
        for (_i_main_gen_tmp_83 = 0; _i_main_gen_tmp_83 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_83++)
        {
            _main_gen_tmp_82[_i_main_gen_tmp_83] = _main_gen_init_g7();
        }
        __arg__2 = PST_TRUE() ? 0 : &_main_gen_tmp_82[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    __arg__3 = _main_gen_init_g7();
    /* pointer */
    {
        static __PST__UINT16 _main_gen_tmp_84[ARRAY_NBELEM(__PST__UINT16)];
        __PST__UINT32 _i_main_gen_tmp_85;
        for (_i_main_gen_tmp_85 = 0; _i_main_gen_tmp_85 < ARRAY_NBELEM(__PST__UINT16); _i_main_gen_tmp_85++)
        {
            _main_gen_tmp_84[_i_main_gen_tmp_85] = _main_gen_init_g7();
        }
        __arg__4 = PST_TRUE() ? 0 : &_main_gen_tmp_84[ARRAY_NBELEM(__PST__UINT16) / 2];
    }
    /* pointer */
    {
        static __PST__SINT16 _main_gen_tmp_86[ARRAY_NBELEM(__PST__SINT16)];
        __PST__UINT32 _i_main_gen_tmp_87;
        for (_i_main_gen_tmp_87 = 0; _i_main_gen_tmp_87 < ARRAY_NBELEM(__PST__SINT16); _i_main_gen_tmp_87++)
        {
            _main_gen_tmp_86[_i_main_gen_tmp_87] = _main_gen_init_g3();
        }
        __arg__5 = PST_TRUE() ? 0 : &_main_gen_tmp_86[ARRAY_NBELEM(__PST__SINT16) / 2];
    }
    __arg__6 = _main_gen_init_g7();
    
    /* call it */
    __ret__ = BilnrIntrpnWithRound_s16_u16MplXs16MplY(__arg__0, __arg__1, __arg__2, __arg__3, __arg__4, __arg__5, __arg__6);
}


/* Main */

void main(void)
{
    /* Initialization of global variables */

    while (PST_TRUE())
    {
        
        /* Call of functions */

        /* call of function LnrIntrpn_u16_u16FixdXu16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpn_u16_u16FixdXu16VariY();
        }
        
        /* call of function LnrIntrpn_s16_u16FixdXs16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpn_s16_u16FixdXs16VariY();
        }
        
        /* call of function LnrIntrpn_u16_u16VariXu16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpn_u16_u16VariXu16VariY();
        }
        
        /* call of function LnrIntrpn_u16_s16VariXu16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpn_u16_s16VariXu16VariY();
        }
        
        /* call of function LnrIntrpn_s16_s16VariXs16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpn_s16_s16VariXs16VariY();
        }
        
        /* call of function LnrIntrpn_s16_u16VariXs16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpn_s16_u16VariXs16VariY();
        }
        
        /* call of function LnrIntrpnWithRound_u16_u16FixdXu16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpnWithRound_u16_u16FixdXu16VariY();
        }
        
        /* call of function LnrIntrpnWithRound_s16_u16FixdXs16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpnWithRound_s16_u16FixdXs16VariY();
        }
        
        /* call of function LnrIntrpnWithRound_u16_u16VariXu16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpnWithRound_u16_u16VariXu16VariY();
        }
        
        /* call of function LnrIntrpnWithRound_u16_s16VariXu16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpnWithRound_u16_s16VariXu16VariY();
        }
        
        /* call of function LnrIntrpnWithRound_s16_s16VariXs16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpnWithRound_s16_s16VariXs16VariY();
        }
        
        /* call of function LnrIntrpnWithRound_s16_u16VariXs16VariY */
        if (PST_TRUE())
        {
            _main_gen_call_LnrIntrpnWithRound_s16_u16VariXs16VariY();
        }
        
        /* call of function BilnrIntrpnWithRound_u16_u16CmnXu16MplY */
        if (PST_TRUE())
        {
            _main_gen_call_BilnrIntrpnWithRound_u16_u16CmnXu16MplY();
        }
        
        /* call of function BilnrIntrpnWithRound_s16_u16CmnXs16MplY */
        if (PST_TRUE())
        {
            _main_gen_call_BilnrIntrpnWithRound_s16_u16CmnXs16MplY();
        }
        
        /* call of function BilnrIntrpnWithRound_s16_s16CmnXs16MplY */
        if (PST_TRUE())
        {
            _main_gen_call_BilnrIntrpnWithRound_s16_s16CmnXs16MplY();
        }
        
        /* call of function BilnrIntrpnWithRound_u16_s16CmnXu16MplY */
        if (PST_TRUE())
        {
            _main_gen_call_BilnrIntrpnWithRound_u16_s16CmnXu16MplY();
        }
        
        /* call of function BilnrIntrpnWithRound_u16_u16MplXu16MplY */
        if (PST_TRUE())
        {
            _main_gen_call_BilnrIntrpnWithRound_u16_u16MplXu16MplY();
        }
        
        /* call of function BilnrIntrpnWithRound_u16_s16MplXu16MplY */
        if (PST_TRUE())
        {
            _main_gen_call_BilnrIntrpnWithRound_u16_s16MplXu16MplY();
        }
        
        /* call of function BilnrIntrpnWithRound_s16_s16MplXs16MplY */
        if (PST_TRUE())
        {
            _main_gen_call_BilnrIntrpnWithRound_s16_s16MplXs16MplY();
        }
        
        /* call of function BilnrIntrpnWithRound_s16_u16MplXs16MplY */
        if (PST_TRUE())
        {
            _main_gen_call_BilnrIntrpnWithRound_s16_u16MplXs16MplY();
        }
        
    }
}
