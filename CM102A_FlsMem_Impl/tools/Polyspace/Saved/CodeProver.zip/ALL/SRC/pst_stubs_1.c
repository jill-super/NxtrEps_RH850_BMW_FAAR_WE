#include "pst_stub_types.h"

extern void assert(int);


#define PST_TRUE() pst_random_int

/* Definition of max array size */

/* Number of bits of 1 byte and addressable unit size */

#define PST_SIZE_CHAR_IN_BITS 8

/* Memory zone addressable according to the target and the pointer configuration */

#define ARRAY_SIZE (2147483647 / PST_SIZE_CHAR_IN_BITS)
#define ARRAY_NBELEM_0(TY) (((ARRAY_SIZE / 2) - 1) / sizeof (TY))
#define ARRAY_NBELEM(TY) (ARRAY_NBELEM_0(TY) < 1 ? 1 : ARRAY_NBELEM_0(TY))


/* Declaration of random variables */

static volatile __PST__CHAR pst_random_char;

static volatile int pst_random_int;

static volatile __PST__UINT32 pst_random_g_8;
static volatile __PST__UINT8 pst_random_g_6;


/* Definition of needed stubs for function pointers */


/* Definition of init procedures */

extern union __PST__g__185 _main_gen_init_g185(void);

extern __PST__g__161 _main_gen_init_g161(void);

extern union __PST__g__158 _main_gen_init_g158(void);

extern union __PST__g__145 _main_gen_init_g145(void);

extern union __PST__g__140 _main_gen_init_g140(void);

extern union __PST__g__136 _main_gen_init_g136(void);

extern union __PST__g__132 _main_gen_init_g132(void);

extern __PST__g__120 _main_gen_init_g120(void);

extern struct __PST__g__117 _main_gen_init_g117(void);

extern union __PST__g__116 _main_gen_init_g116(void);

extern struct __PST__g__115 _main_gen_init_g115(void);

extern union __PST__g__114 _main_gen_init_g114(void);

extern struct __PST__g__108 _main_gen_init_g108(void);

extern union __PST__g__107 _main_gen_init_g107(void);

extern struct __PST__g__94 _main_gen_init_g94(void);

extern union __PST__g__93 _main_gen_init_g93(void);

extern union __PST__g__91 _main_gen_init_g91(void);

extern union __PST__g__89 _main_gen_init_g89(void);

extern union __PST__g__87 _main_gen_init_g87(void);

extern union __PST__g__68 _main_gen_init_g68(void);

extern union __PST__g__35 _main_gen_init_g35(void);

extern __PST__g__32 _main_gen_init_g32(void);

extern __PST__UINT8 _main_gen_init_g6(void);

extern __PST__UINT32 _main_gen_init_g8(void);

__PST__UINT32 _main_gen_init_g8(void)
{
    __PST__UINT32 x;
    /* base type */
    x = pst_random_g_8;
    return x;
}

__PST__UINT8 _main_gen_init_g6(void)
{
    __PST__UINT8 x;
    /* base type */
    x = pst_random_g_6;
    return x;
}

union __PST__g__35 _main_gen_init_g35(void)
{
    static union __PST__g__35 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__68 _main_gen_init_g68(void)
{
    static union __PST__g__68 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__32 _main_gen_init_g32(void)
{
    __PST__g__32 x;
    /* struct/union type */
    x.PINT0 = _main_gen_init_g35();
    x.PINTCLR0 = _main_gen_init_g68();
    return x;
}

union __PST__g__87 _main_gen_init_g87(void)
{
    static union __PST__g__87 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__89 _main_gen_init_g89(void)
{
    static union __PST__g__89 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__91 _main_gen_init_g91(void)
{
    static union __PST__g__91 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__94 _main_gen_init_g94(void)
{
    static struct __PST__g__94 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.TCE = bitf;
    }
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 3);
        x.CHNE = bitf;
    }
    return x;
}

union __PST__g__93 _main_gen_init_g93(void)
{
    static union __PST__g__93 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g94();
    x.UINT32 = _main_gen_init_g8();
    return x;
}

struct __PST__g__108 _main_gen_init_g108(void)
{
    static struct __PST__g__108 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.REQEN = bitf;
    }
    return x;
}

union __PST__g__107 _main_gen_init_g107(void)
{
    static union __PST__g__107 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g108();
    return x;
}

struct __PST__g__115 _main_gen_init_g115(void)
{
    static struct __PST__g__115 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DRQS = bitf;
    }
    return x;
}

union __PST__g__114 _main_gen_init_g114(void)
{
    static union __PST__g__114 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g115();
    return x;
}

struct __PST__g__117 _main_gen_init_g117(void)
{
    static struct __PST__g__117 x;
    /* struct/union type */
    {
        __PST__UINT32 bitf;
        bitf = _main_gen_init_g8();
        unchecked_assert(bitf <= 1);
        x.DRQC = bitf;
    }
    return x;
}

union __PST__g__116 _main_gen_init_g116(void)
{
    static union __PST__g__116 x;
    /* struct/union type */
    x.BIT = _main_gen_init_g117();
    return x;
}

union __PST__g__132 _main_gen_init_g132(void)
{
    static union __PST__g__132 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__136 _main_gen_init_g136(void)
{
    static union __PST__g__136 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__140 _main_gen_init_g140(void)
{
    static union __PST__g__140 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__145 _main_gen_init_g145(void)
{
    static union __PST__g__145 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__120 _main_gen_init_g120(void)
{
    __PST__g__120 x;
    /* struct/union type */
    x.CFSTCLR_VCI = _main_gen_init_g132();
    x.CFOVFSTR_VCI = _main_gen_init_g136();
    x.CF1STERSTR_VCI = _main_gen_init_g140();
    x.CF1STEADR0_VCI = _main_gen_init_g145();
    x.CFSTCLR_PE1 = _main_gen_init_g132();
    x.CFOVFSTR_PE1 = _main_gen_init_g136();
    x.CF1STERSTR_PE1 = _main_gen_init_g140();
    x.CF1STEADR0_PE1 = _main_gen_init_g145();
    return x;
}

union __PST__g__158 _main_gen_init_g158(void)
{
    static union __PST__g__158 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

union __PST__g__185 _main_gen_init_g185(void)
{
    static union __PST__g__185 x;
    /* struct/union type */
    x.UINT32 = _main_gen_init_g8();
    return x;
}

__PST__g__161 _main_gen_init_g161(void)
{
    __PST__g__161 x;
    /* struct/union type */
    x.ESSTC1 = _main_gen_init_g185();
    return x;
}


/* Definition of variables init procedures */

static void _main_gen_init_sym_FlsMem_Pim_CodFlsCrcChkStrtTi(void)
{
    extern __PST__UINT32 FlsMem_Pim_CodFlsCrcChkStrtTi;
    
    /* initialization with random value */
    {
        FlsMem_Pim_CodFlsCrcChkStrtTi = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Pim_CodFlsSngBitErr(void)
{
    extern __PST__UINT8 FlsMem_Pim_CodFlsSngBitErr;
    
    /* initialization with random value */
    {
        FlsMem_Pim_CodFlsSngBitErr = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FlsMem_Pim_CrcChkCmpl(void)
{
    extern __PST__UINT8 FlsMem_Pim_CrcChkCmpl;
    
    /* initialization with random value */
    {
        FlsMem_Pim_CrcChkCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FlsMem_Pim_CrcHwIdxKey(void)
{
    extern __PST__UINT32 FlsMem_Pim_CrcHwIdxKey;
    
    /* initialization with random value */
    {
        FlsMem_Pim_CrcHwIdxKey = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Pim_PwrOnRstCrcChkCmpl(void)
{
    extern __PST__UINT8 FlsMem_Pim_PwrOnRstCrcChkCmpl;
    
    /* initialization with random value */
    {
        FlsMem_Pim_PwrOnRstCrcChkCmpl = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_INTIF(void)
{
    extern __PST__g__32 INTIF;
    
    /* initialization with random value */
    {
        INTIF = _main_gen_init_g32();
    }
}

static void _main_gen_init_sym_DTSCfg(void)
{
    extern __PST__g__84 DTSCfg;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_0_0;
            
            for (_main_gen_tmp_0_0 = 0; _main_gen_tmp_0_0 < 128; _main_gen_tmp_0_0++)
            {
                /* struct/union type */
                DTSCfg[_main_gen_tmp_0_0].DMASSDTSA = _main_gen_init_g87();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTDA = _main_gen_init_g89();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTTC = _main_gen_init_g91();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTTCT = _main_gen_init_g93();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTFSL = _main_gen_init_g107();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTFSS = _main_gen_init_g114();
                DTSCfg[_main_gen_tmp_0_0].DMASSDTFSC = _main_gen_init_g116();
            }
        }
    }
}

static void _main_gen_init_sym_ECCFLI(void)
{
    extern __PST__g__120 ECCFLI;
    
    /* initialization with random value */
    {
        ECCFLI = _main_gen_init_g120();
    }
}

static void _main_gen_init_sym_DTSMstrCfg(void)
{
    extern __PST__g__155 DTSMstrCfg;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_1_0;
            
            for (_main_gen_tmp_1_0 = 0; _main_gen_tmp_1_0 < 128; _main_gen_tmp_1_0++)
            {
                /* struct/union type */
                DTSMstrCfg[_main_gen_tmp_1_0].DTSnnnCM = _main_gen_init_g158();
            }
        }
    }
}

static void _main_gen_init_sym_ECM(void)
{
    extern __PST__g__161 ECM;
    
    /* initialization with random value */
    {
        ECM = _main_gen_init_g161();
    }
}

static void _main_gen_init_sym_CCT_Range_01_Start(void)
{
    extern __PST__g__221 CCT_Range_01_Start;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_2_0;
            
            for (_main_gen_tmp_2_0 = 0; _main_gen_tmp_2_0 < pst_random_g_8; _main_gen_tmp_2_0++)
            {
                /* base type */
                CCT_Range_01_Start[_main_gen_tmp_2_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_01_Address(void)
{
    extern __PST__g__221 CCT_Range_01_Address;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_3_0;
            
            for (_main_gen_tmp_3_0 = 0; _main_gen_tmp_3_0 < pst_random_g_8; _main_gen_tmp_3_0++)
            {
                /* base type */
                CCT_Range_01_Address[_main_gen_tmp_3_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_01_Length(void)
{
    extern __PST__g__221 CCT_Range_01_Length;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_4_0;
            
            for (_main_gen_tmp_4_0 = 0; _main_gen_tmp_4_0 < pst_random_g_8; _main_gen_tmp_4_0++)
            {
                /* base type */
                CCT_Range_01_Length[_main_gen_tmp_4_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_02_Start(void)
{
    extern __PST__g__221 CCT_Range_02_Start;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_5_0;
            
            for (_main_gen_tmp_5_0 = 0; _main_gen_tmp_5_0 < pst_random_g_8; _main_gen_tmp_5_0++)
            {
                /* base type */
                CCT_Range_02_Start[_main_gen_tmp_5_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_02_Address(void)
{
    extern __PST__g__221 CCT_Range_02_Address;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_6_0;
            
            for (_main_gen_tmp_6_0 = 0; _main_gen_tmp_6_0 < pst_random_g_8; _main_gen_tmp_6_0++)
            {
                /* base type */
                CCT_Range_02_Address[_main_gen_tmp_6_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_02_Length(void)
{
    extern __PST__g__221 CCT_Range_02_Length;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_7_0;
            
            for (_main_gen_tmp_7_0 = 0; _main_gen_tmp_7_0 < pst_random_g_8; _main_gen_tmp_7_0++)
            {
                /* base type */
                CCT_Range_02_Length[_main_gen_tmp_7_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_03_Start(void)
{
    extern __PST__g__221 CCT_Range_03_Start;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_8_0;
            
            for (_main_gen_tmp_8_0 = 0; _main_gen_tmp_8_0 < pst_random_g_8; _main_gen_tmp_8_0++)
            {
                /* base type */
                CCT_Range_03_Start[_main_gen_tmp_8_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_03_Address(void)
{
    extern __PST__g__221 CCT_Range_03_Address;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_9_0;
            
            for (_main_gen_tmp_9_0 = 0; _main_gen_tmp_9_0 < pst_random_g_8; _main_gen_tmp_9_0++)
            {
                /* base type */
                CCT_Range_03_Address[_main_gen_tmp_9_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_03_Length(void)
{
    extern __PST__g__221 CCT_Range_03_Length;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_10_0;
            
            for (_main_gen_tmp_10_0 = 0; _main_gen_tmp_10_0 < pst_random_g_8; _main_gen_tmp_10_0++)
            {
                /* base type */
                CCT_Range_03_Length[_main_gen_tmp_10_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_04_Start(void)
{
    extern __PST__g__221 CCT_Range_04_Start;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_11_0;
            
            for (_main_gen_tmp_11_0 = 0; _main_gen_tmp_11_0 < pst_random_g_8; _main_gen_tmp_11_0++)
            {
                /* base type */
                CCT_Range_04_Start[_main_gen_tmp_11_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_04_Address(void)
{
    extern __PST__g__221 CCT_Range_04_Address;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_12_0;
            
            for (_main_gen_tmp_12_0 = 0; _main_gen_tmp_12_0 < pst_random_g_8; _main_gen_tmp_12_0++)
            {
                /* base type */
                CCT_Range_04_Address[_main_gen_tmp_12_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_CCT_Range_04_Length(void)
{
    extern __PST__g__221 CCT_Range_04_Length;
    
    /* initialization with random value */
    {
        { /* array type */
            __PST__UINT32 _main_gen_tmp_13_0;
            
            for (_main_gen_tmp_13_0 = 0; _main_gen_tmp_13_0 < pst_random_g_8; _main_gen_tmp_13_0++)
            {
                /* base type */
                CCT_Range_04_Length[_main_gen_tmp_13_0] = pst_random_g_6;
            }
        }
    }
}

static void _main_gen_init_sym_FlsMem_Srv_GetTiSpan100MicroSec32bit_TiSpan(void)
{
    extern __PST__UINT32 FlsMem_Srv_GetTiSpan100MicroSec32bit_TiSpan;
    
    /* initialization with random value */
    {
        FlsMem_Srv_GetTiSpan100MicroSec32bit_TiSpan = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_CrcHwInRegAdr(void)
{
    extern __PST__UINT32 FlsMem_Srv_ResvCrcHwUnit_CrcHwInRegAdr;
    
    /* initialization with random value */
    {
        FlsMem_Srv_ResvCrcHwUnit_CrcHwInRegAdr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_CrcHwOutRegAdr(void)
{
    extern __PST__UINT32 FlsMem_Srv_ResvCrcHwUnit_CrcHwOutRegAdr;
    
    /* initialization with random value */
    {
        FlsMem_Srv_ResvCrcHwUnit_CrcHwOutRegAdr = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_ResvKey(void)
{
    extern __PST__UINT32 FlsMem_Srv_ResvCrcHwUnit_ResvKey;
    
    /* initialization with random value */
    {
        FlsMem_Srv_ResvCrcHwUnit_ResvKey = _main_gen_init_g8();
    }
}

static void _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_Return(void)
{
    extern __PST__UINT8 FlsMem_Srv_ResvCrcHwUnit_Return;
    
    /* initialization with random value */
    {
        FlsMem_Srv_ResvCrcHwUnit_Return = _main_gen_init_g6();
    }
}

static void _main_gen_init_sym_FlsMem_Srv_SetNtcSts_Return(void)
{
    extern __PST__UINT8 FlsMem_Srv_SetNtcSts_Return;
    
    /* initialization with random value */
    {
        FlsMem_Srv_SetNtcSts_Return = _main_gen_init_g6();
    }
}


/* Definition of functions */


/* Extern init */

void _extern_init(void)
{
    /* Initialization of extern variables */

    /* init for variable FlsMem_Op_CodFlsCrcChkCmpl : useless (never read) */

    /* init for variable FlsMem_Op_SwApplCrc : useless (never read) */

    /* init for variable FlsMem_Pim_CodFlsCrcChkStrtTi */
    _main_gen_init_sym_FlsMem_Pim_CodFlsCrcChkStrtTi();
    
    /* init for variable FlsMem_Pim_CodFlsSngBitErr */
    _main_gen_init_sym_FlsMem_Pim_CodFlsSngBitErr();
    
    /* init for variable FlsMem_Pim_CrcChkCmpl */
    _main_gen_init_sym_FlsMem_Pim_CrcChkCmpl();
    
    /* init for variable FlsMem_Pim_CrcHwIdxKey */
    _main_gen_init_sym_FlsMem_Pim_CrcHwIdxKey();
    
    /* init for variable FlsMem_Pim_PwrOnRstCrcChkCmpl */
    _main_gen_init_sym_FlsMem_Pim_PwrOnRstCrcChkCmpl();
    
    /* init for variable INTIF */
    _main_gen_init_sym_INTIF();
    
    /* init for variable DTSCfg */
    _main_gen_init_sym_DTSCfg();
    
    /* init for variable FlsMem_Pim_CodFlsDummyRead1 : useless (never read) */

    /* init for variable FlsMem_Pim_CodFlsDummyRead2 : useless (never read) */

    /* init for variable FlsMem_Pim_CodFlsDummyRead3 : useless (never read) */

    /* init for variable FlsMem_Pim_CodFlsDummyRead4 : useless (never read) */

    /* init for variable ECCFLI */
    _main_gen_init_sym_ECCFLI();
    
    /* init for variable DTSMstrCfg */
    _main_gen_init_sym_DTSMstrCfg();
    
    /* init for variable ECM */
    _main_gen_init_sym_ECM();
    
    /* init for variable CCT_Range_01_Start */
    _main_gen_init_sym_CCT_Range_01_Start();
    
    /* init for variable CCT_Range_01_Address */
    _main_gen_init_sym_CCT_Range_01_Address();
    
    /* init for variable CCT_Range_01_Length */
    _main_gen_init_sym_CCT_Range_01_Length();
    
    /* init for variable CCT_Range_02_Start */
    _main_gen_init_sym_CCT_Range_02_Start();
    
    /* init for variable CCT_Range_02_Address */
    _main_gen_init_sym_CCT_Range_02_Address();
    
    /* init for variable CCT_Range_02_Length */
    _main_gen_init_sym_CCT_Range_02_Length();
    
    /* init for variable CCT_Range_03_Start */
    _main_gen_init_sym_CCT_Range_03_Start();
    
    /* init for variable CCT_Range_03_Address */
    _main_gen_init_sym_CCT_Range_03_Address();
    
    /* init for variable CCT_Range_03_Length */
    _main_gen_init_sym_CCT_Range_03_Length();
    
    /* init for variable CCT_Range_04_Start */
    _main_gen_init_sym_CCT_Range_04_Start();
    
    /* init for variable CCT_Range_04_Address */
    _main_gen_init_sym_CCT_Range_04_Address();
    
    /* init for variable CCT_Range_04_Length */
    _main_gen_init_sym_CCT_Range_04_Length();
    
    /* init for variable FlsMem_Srv_GetTiSpan100MicroSec32bit_RefTmr : useless (never read) */

    /* init for variable FlsMem_Srv_GetTiSpan100MicroSec32bit_TiSpan */
    _main_gen_init_sym_FlsMem_Srv_GetTiSpan100MicroSec32bit_TiSpan();
    
    /* init for variable FlsMem_Srv_ResvCrcHwUnit_Mod : useless (never read) */

    /* init for variable FlsMem_Srv_ResvCrcHwUnit_CrcCfg : useless (never read) */

    /* init for variable FlsMem_Srv_ResvCrcHwUnit_CrcHwInRegAdr */
    _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_CrcHwInRegAdr();
    
    /* init for variable FlsMem_Srv_ResvCrcHwUnit_CrcHwOutRegAdr */
    _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_CrcHwOutRegAdr();
    
    /* init for variable FlsMem_Srv_ResvCrcHwUnit_StrtVal : useless (never read) */

    /* init for variable FlsMem_Srv_ResvCrcHwUnit_ResvKey */
    _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_ResvKey();
    
    /* init for variable FlsMem_Srv_ResvCrcHwUnit_Return */
    _main_gen_init_sym_FlsMem_Srv_ResvCrcHwUnit_Return();
    
    /* init for variable FlsMem_Srv_SetNtcSts_NtcNr : useless (never read) */

    /* init for variable FlsMem_Srv_SetNtcSts_NtcStInfo : useless (never read) */

    /* init for variable FlsMem_Srv_SetNtcSts_NtcSts : useless (never read) */

    /* init for variable FlsMem_Srv_SetNtcSts_DebStep : useless (never read) */

    /* init for variable FlsMem_Srv_SetNtcSts_Return */
    _main_gen_init_sym_FlsMem_Srv_SetNtcSts_Return();
    
}
